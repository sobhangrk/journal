'use strict';
/* ==========================================================================
   SmartJournal — پرداخت کارت‌به‌کارت
   شماره کارت روی سایت → کاربر فیش و کد پیگیری ثبت می‌کند → مدیر تایید/رد می‌کند
   → اشتراک واقعی تمدید و یک ردیف payment رسمی ساخته می‌شود.

   این ماژول به دامنه‌ی موجود متصل می‌شود و چیزی را دور نمی‌زند:
   permission، CSRF، نشست کاربر، audit log و جدول‌های plans/subscriptions/payments
   همگی همان‌های قبلی‌اند.
   ========================================================================== */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { payablePrice } = require('./plan-pricing');

const RECEIPT_MIMES = new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf']);
const MAX_RECEIPT_BYTES = 8 * 1024 * 1024;

function install(ctx) {
  const {
    app, db, logAudit, id, iso, clientIp, userAuth, allowPermissions,
    dataUrlParts, imageMime, UPLOAD_DIR,
  } = ctx;

  const RECEIPT_DIR = path.resolve(UPLOAD_DIR, '_receipts');
  fs.mkdirSync(RECEIPT_DIR, { recursive: true });

  /* ----------------------------------------------------------- schema ---- */
  db.exec(`
    CREATE TABLE IF NOT EXISTS bank_cards (
      id          TEXT PRIMARY KEY,
      bank_name   TEXT NOT NULL,
      holder      TEXT NOT NULL DEFAULT '',
      card_number TEXT NOT NULL,
      sheba       TEXT NOT NULL DEFAULT '',
      is_enabled  INTEGER NOT NULL DEFAULT 1,
      sort_order  INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL,
      updated_at  TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS payment_receipts (
      id                TEXT PRIMARY KEY,
      user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      plan_id           TEXT NOT NULL REFERENCES plans(id),
      bank_card_id      TEXT REFERENCES bank_cards(id) ON DELETE SET NULL,
      amount            INTEGER NOT NULL DEFAULT 0,
      tracking_code     TEXT NOT NULL,
      note              TEXT NOT NULL DEFAULT '',
      receipt_key       TEXT NOT NULL DEFAULT '',
      receipt_mime      TEXT NOT NULL DEFAULT '',
      receipt_size      INTEGER NOT NULL DEFAULT 0,
      receipt_checksum  TEXT NOT NULL DEFAULT '',
      status            TEXT NOT NULL DEFAULT 'pending'
                        CHECK(status IN ('pending','approved','rejected')),
      admin_note        TEXT NOT NULL DEFAULT '',
      granted_days      INTEGER NOT NULL DEFAULT 0,
      payment_id        TEXT REFERENCES payments(id) ON DELETE SET NULL,
      reviewed_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      reviewed_at       TEXT,
      ip                TEXT NOT NULL DEFAULT '',
      created_at        TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_receipts_status ON payment_receipts(status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_receipts_user   ON payment_receipts(user_id, created_at DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_receipts_tracking
      ON payment_receipts(tracking_code) WHERE tracking_code <> '';
  `);

  /* ---------------------------------------------------------- helpers ---- */
  const FA = '۰۱۲۳۴۵۶۷۸۹';
  const AR = '٠١٢٣٤٥٦٧٨٩';
  const toEn = (v) => String(v ?? '').replace(/[۰-۹٠-٩]/g, (d) => {
    const i = FA.indexOf(d);
    return String(i > -1 ? i : AR.indexOf(d));
  });
  const digits = (v) => toEn(v).replace(/\D/g, '');
  const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max);
  const maskCard = (nStr) => {
    const d = digits(nStr);
    return d.length >= 10 ? `${d.slice(0, 6)}••••${d.slice(-4)}` : d;
  };
  const bad = (message, status = 400) => Object.assign(new Error(message), { status });

  // Luhn — catches typos in a card number before it ever reaches a customer
  function luhnValid(nStr) {
    const d = digits(nStr);
    if (d.length !== 16) return false;
    let sum = 0;
    for (let i = 0; i < 16; i += 1) {
      let v = Number(d[15 - i]);
      if (i % 2 === 1) { v *= 2; if (v > 9) v -= 9; }
      sum += v;
    }
    return sum % 10 === 0;
  }

  function planRow(planId) {
    return db.prepare('SELECT * FROM plans WHERE id=?').get(String(planId || ''));
  }

  // NOTE: the shared dataUrlParts() only accepts images, so receipts parse the
  // data URL here — otherwise a PDF receipt could never be uploaded.
  const RECEIPT_DATA_URL = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,([A-Za-z0-9+/=\r\n]+)$/i;

  function decodeReceipt(dataUrl) {
    const match = RECEIPT_DATA_URL.exec(String(dataUrl || ''));
    if (!match) throw bad('فیش باید تصویر JPG/PNG/WebP یا فایل PDF باشد.');
    let buffer;
    try { buffer = Buffer.from(match[2].replace(/\s/g, ''), 'base64'); }
    catch { throw bad('فرمت فیش معتبر نیست.'); }
    if (!buffer.length) throw bad('فایل فیش خالی است.');
    if (buffer.length > MAX_RECEIPT_BYTES) throw bad('حجم فیش نباید بیشتر از ۸ مگابایت باشد.', 413);

    const claimed = match[1].toLowerCase();
    const isPdf = buffer.slice(0, 5).toString('latin1') === '%PDF-';
    const sniffed = isPdf ? 'application/pdf' : imageMime(buffer);
    // the claimed content-type must match what the bytes actually are
    if (!sniffed || sniffed !== claimed || !RECEIPT_MIMES.has(sniffed)) {
      throw bad('فیش باید تصویر JPG/PNG/WebP یا فایل PDF واقعی باشد.');
    }
    return { buffer, mime: sniffed };
  }

  function saveReceiptFile(userId, buffer, mime) {
    const checksum = crypto.createHash('sha256').update(buffer).digest('hex');
    const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'application/pdf': 'pdf' }[mime];
    const key = path.posix.join(userId, `${id('rcpt')}.${ext}`);
    const target = path.resolve(RECEIPT_DIR, ...key.split('/'));
    // defence in depth: never let a crafted id escape the receipts directory
    if (!target.startsWith(RECEIPT_DIR + path.sep)) throw bad('مسیر فایل معتبر نیست.');
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, buffer, { mode: 0o600 });
    return { key, checksum, size: buffer.length };
  }

  function receiptFile(key) {
    const target = path.resolve(RECEIPT_DIR, ...String(key).split('/'));
    if (!target.startsWith(RECEIPT_DIR + path.sep) || !fs.existsSync(target)) return null;
    return target;
  }

  function publicCards() {
    return db.prepare(
      `SELECT id, bank_name, holder, card_number, sheba
         FROM bank_cards WHERE is_enabled=1 ORDER BY sort_order, created_at`
    ).all();
  }

  /* ------------------------------------------------- user-facing routes -- */

  app.get('/api/billing/bank-cards', userAuth, (req, res) => {
    res.json({ rows: publicCards() });
  });

  app.post('/api/billing/receipts', userAuth, (req, res, next) => {
    try {
      const body = req.body || {};
      const plan = planRow(body.planId);
      if (!plan || !plan.is_active) throw bad('پلن انتخابی معتبر نیست.');
      if (Number(plan.price_monthly) <= 0) throw bad('این پلن نیازی به پرداخت ندارد.');

      const tracking = clean(toEn(body.trackingCode), 60);
      if (tracking.length < 4) throw bad('کد پیگیری واریز را وارد کنید.');
      if (db.prepare('SELECT 1 FROM payment_receipts WHERE tracking_code=?').get(tracking)) {
        throw bad('این کد پیگیری قبلاً ثبت شده است.', 409);
      }

      const pending = Number(db.prepare(
        "SELECT COUNT(*) c FROM payment_receipts WHERE user_id=? AND status='pending'"
      ).get(req.user.id).c);
      if (pending >= 3) throw bad('شما ۳ فیش در انتظار بررسی دارید. تا تعیین تکلیف آن‌ها فیش جدید ثبت نمی‌شود.', 429);

      const card = body.bankCardId
        ? db.prepare('SELECT * FROM bank_cards WHERE id=? AND is_enabled=1').get(String(body.bankCardId))
        : null;

      const { buffer, mime } = decodeReceipt(body.receipt);
      const stored = saveReceiptFile(req.user.id, buffer, mime);

      const row = {
        id: id('rcpt'),
        user_id: req.user.id,
        plan_id: plan.id,
        bank_card_id: card ? card.id : null,
        amount: payablePrice(plan),   /* قیمت با تخفیفِ فعال، همان چیزی که در سایت دیده است */
        tracking_code: tracking,
        note: clean(body.note, 400),
        receipt_key: stored.key,
        receipt_mime: mime,
        receipt_size: stored.size,
        receipt_checksum: stored.checksum,
        ip: clientIp(req),
        created_at: iso(),
      };
      db.prepare(`INSERT INTO payment_receipts
        (id,user_id,plan_id,bank_card_id,amount,tracking_code,note,receipt_key,receipt_mime,
         receipt_size,receipt_checksum,status,ip,created_at)
        VALUES (@id,@user_id,@plan_id,@bank_card_id,@amount,@tracking_code,@note,@receipt_key,
                @receipt_mime,@receipt_size,@receipt_checksum,'pending',@ip,@created_at)`).run(row);

      logAudit({
        adminId: null,
        action: 'PAYMENT_RECEIPT_SUBMITTED',
        entityType: 'payment_receipt',
        entityId: row.id,
        details: { planId: plan.id, amount: row.amount, tracking },
        ip: row.ip,
      });

      res.status(201).json({ ok: true, id: row.id, status: 'pending' });
    } catch (error) { next(error); }
  });

  app.get('/api/billing/receipts', userAuth, (req, res) => {
    const rows = db.prepare(
      `SELECT r.id, r.plan_id, p.name_fa plan_title, r.amount, r.tracking_code, r.status,
              r.admin_note, r.granted_days, r.created_at, r.reviewed_at,
              CASE WHEN r.receipt_key<>'' THEN 1 ELSE 0 END has_receipt
         FROM payment_receipts r JOIN plans p ON p.id=r.plan_id
        WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 30`
    ).all(req.user.id);
    res.json({ rows });
  });

  // a user may only ever read their own receipt image
  app.get('/api/billing/receipts/:id/image', userAuth, (req, res) => {
    const row = db.prepare('SELECT * FROM payment_receipts WHERE id=? AND user_id=?')
      .get(req.params.id, req.user.id);
    const file = row && row.receipt_key ? receiptFile(row.receipt_key) : null;
    if (!file) return res.status(404).json({ error: 'فیش پیدا نشد.' });
    res.setHeader('Content-Type', row.receipt_mime);
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    fs.createReadStream(file).pipe(res);
  });

  /* ------------------------------------------------------- admin: cards -- */

  app.get('/api/admin/bank-cards', allowPermissions('billing.view'), (req, res) => {
    res.json({ rows: db.prepare('SELECT * FROM bank_cards ORDER BY sort_order, created_at').all() });
  });

  app.post('/api/admin/bank-cards', allowPermissions('billing.manage'), (req, res, next) => {
    try {
      const b = req.body || {};
      const number = digits(b.cardNumber);
      if (!luhnValid(number)) throw bad('شماره کارت ۱۶ رقمی معتبر نیست (کنترل Luhn رد شد).');
      const sheba = digits(b.sheba);
      if (sheba && sheba.length !== 24) throw bad('شماره شبا باید ۲۴ رقم بعد از IR باشد.');
      if (db.prepare('SELECT 1 FROM bank_cards WHERE card_number=?').get(number)) {
        throw bad('این شماره کارت قبلاً ثبت شده است.', 409);
      }
      const count = Number(db.prepare('SELECT COUNT(*) c FROM bank_cards').get().c);
      const row = {
        id: id('card'),
        bank_name: clean(b.bankName, 60) || 'بانک',
        holder: clean(b.holder, 80),
        card_number: number,
        sheba,
        is_enabled: b.isEnabled === false ? 0 : 1,
        sort_order: Number.isFinite(Number(b.sortOrder)) ? Number(b.sortOrder) : count,
        created_at: iso(),
        updated_at: iso(),
      };
      db.prepare(`INSERT INTO bank_cards
        (id,bank_name,holder,card_number,sheba,is_enabled,sort_order,created_at,updated_at)
        VALUES (@id,@bank_name,@holder,@card_number,@sheba,@is_enabled,@sort_order,@created_at,@updated_at)`)
        .run(row);
      logAudit({
        adminId: req.admin.id, action: 'BANK_CARD_CREATED', entityType: 'bank_card', entityId: row.id,
        details: { bankName: row.bank_name, card: maskCard(number) }, ip: clientIp(req),
      });
      res.status(201).json({ ok: true, row });
    } catch (error) { next(error); }
  });

  app.patch('/api/admin/bank-cards/:id', allowPermissions('billing.manage'), (req, res, next) => {
    try {
      const cur = db.prepare('SELECT * FROM bank_cards WHERE id=?').get(req.params.id);
      if (!cur) throw bad('کارت پیدا نشد.', 404);
      const b = req.body || {};
      const number = b.cardNumber === undefined ? cur.card_number : digits(b.cardNumber);
      if (!luhnValid(number)) throw bad('شماره کارت ۱۶ رقمی معتبر نیست (کنترل Luhn رد شد).');
      const sheba = b.sheba === undefined ? cur.sheba : digits(b.sheba);
      if (sheba && sheba.length !== 24) throw bad('شماره شبا باید ۲۴ رقم بعد از IR باشد.');
      db.prepare(`UPDATE bank_cards SET bank_name=?,holder=?,card_number=?,sheba=?,is_enabled=?,sort_order=?,updated_at=?
                  WHERE id=?`).run(
        b.bankName === undefined ? cur.bank_name : clean(b.bankName, 60),
        b.holder === undefined ? cur.holder : clean(b.holder, 80),
        number, sheba,
        b.isEnabled === undefined ? cur.is_enabled : (b.isEnabled ? 1 : 0),
        b.sortOrder === undefined ? cur.sort_order : Number(b.sortOrder) || 0,
        iso(), req.params.id,
      );
      logAudit({
        adminId: req.admin.id, action: 'BANK_CARD_UPDATED', entityType: 'bank_card', entityId: req.params.id,
        details: { card: maskCard(number) }, ip: clientIp(req),
      });
      res.json({ ok: true, row: db.prepare('SELECT * FROM bank_cards WHERE id=?').get(req.params.id) });
    } catch (error) { next(error); }
  });

  app.delete('/api/admin/bank-cards/:id', allowPermissions('billing.manage'), (req, res, next) => {
    try {
      const cur = db.prepare('SELECT * FROM bank_cards WHERE id=?').get(req.params.id);
      if (!cur) throw bad('کارت پیدا نشد.', 404);
      db.prepare('DELETE FROM bank_cards WHERE id=?').run(req.params.id);
      logAudit({
        adminId: req.admin.id, action: 'BANK_CARD_DELETED', entityType: 'bank_card', entityId: req.params.id,
        details: { card: maskCard(cur.card_number) }, ip: clientIp(req),
      });
      res.json({ ok: true });
    } catch (error) { next(error); }
  });

  /* ---------------------------------------------------- admin: receipts -- */

  const receiptSelect = `
    SELECT r.*, u.name user_name, u.mobile user_mobile, p.name_fa plan_title,
           p.duration_days plan_duration, c.bank_name, c.card_number,
           a.name reviewer_name,
           CASE WHEN r.receipt_key<>'' THEN 1 ELSE 0 END has_receipt
      FROM payment_receipts r
      JOIN users u ON u.id=r.user_id
      JOIN plans p ON p.id=r.plan_id
      LEFT JOIN bank_cards c ON c.id=r.bank_card_id
      LEFT JOIN admins a ON a.id=r.reviewed_by_admin_id`;

  app.get('/api/admin/receipts', allowPermissions('billing.view'), (req, res) => {
    const status = String(req.query.status || 'pending');
    const q = clean(req.query.q, 60);
    const args = [];
    let where = ' WHERE 1=1';
    if (status && status !== 'all') { where += ' AND r.status=?'; args.push(status); }
    if (q) {
      // LOWER() on both sides keeps search case-insensitive on PostgreSQL too
      where += ' AND (LOWER(u.name) LIKE LOWER(?) OR u.mobile LIKE ? OR LOWER(r.tracking_code) LIKE LOWER(?))';
      args.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
    const rows = db.prepare(`${receiptSelect}${where} ORDER BY r.created_at DESC LIMIT 300`).all(...args)
      .map((r) => ({ ...r, card_number: r.card_number ? maskCard(r.card_number) : null }));
    const counts = db.prepare('SELECT status, COUNT(*) c FROM payment_receipts GROUP BY status')
      .all().reduce((acc, r) => ({ ...acc, [r.status]: r.c }), { pending: 0, approved: 0, rejected: 0 });
    res.json({ rows, counts });
  });

  app.get('/api/admin/receipts-summary', allowPermissions('billing.view'), (req, res) => {
    // CASE WHEN (not SUM(status='x')) so this works on SQLite *and* PostgreSQL —
    // Postgres has no SUM(boolean).
    const c = db.prepare(`SELECT
        COALESCE(SUM(CASE WHEN status='pending'  THEN 1 ELSE 0 END),0) pending,
        COALESCE(SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END),0) approved,
        COALESCE(SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END),0) rejected,
        COALESCE(SUM(CASE WHEN status='approved' THEN amount ELSE 0 END),0) revenue
      FROM payment_receipts`).get();
    res.json(c);
  });

  app.get('/api/admin/receipts/:id/image', allowPermissions('billing.view'), (req, res) => {
    const row = db.prepare('SELECT * FROM payment_receipts WHERE id=?').get(req.params.id);
    const file = row && row.receipt_key ? receiptFile(row.receipt_key) : null;
    if (!file) return res.status(404).json({ error: 'فیش پیدا نشد.' });
    res.setHeader('Content-Type', row.receipt_mime);
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    fs.createReadStream(file).pipe(res);
  });

  /* approve → real payment row + real subscription extension, in one transaction */
  app.post('/api/admin/receipts/:id/approve', allowPermissions('billing.manage'), (req, res, next) => {
    try {
      const row = db.prepare('SELECT * FROM payment_receipts WHERE id=?').get(req.params.id);
      if (!row) throw bad('فیش پیدا نشد.', 404);
      if (row.status === 'approved') throw bad('این فیش قبلاً تایید شده است.', 409);

      const plan = planRow(row.plan_id);
      if (!plan) throw bad('پلن این فیش دیگر وجود ندارد.');
      const days = Math.max(1, Math.min(3650,
        Math.round(Number(req.body?.days) || Number(plan.duration_days) || 30)));
      const note = clean(req.body?.note, 300);

      const result = db.transaction(() => {
        const sub = db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(row.user_id);
        const base = sub && sub.expires_at && new Date(sub.expires_at) > new Date()
          ? new Date(sub.expires_at) : new Date();
        const expiresAt = new Date(base.getTime() + days * 86400000).toISOString();

        let subscriptionId;
        if (sub) {
          subscriptionId = sub.id;
          db.prepare(`UPDATE subscriptions
                      SET plan_id=?, status='active', expires_at=?, updated_at=? WHERE id=?`)
            .run(plan.id, expiresAt, iso(), sub.id);
        } else {
          subscriptionId = id('sub');
          db.prepare(`INSERT INTO subscriptions
            (id,user_id,plan_id,status,started_at,expires_at,auto_renew,discount_amount,updated_at)
            VALUES (?,?,?,'active',?,?,0,0,?)`)
            .run(subscriptionId, row.user_id, plan.id, iso(), expiresAt, iso());
        }

        // a real, auditable payment record in the same table the gateway uses
        const paymentId = id('pay');
        const seq = Number(db.prepare('SELECT COUNT(*) c FROM payments').get().c) + 1;
        const invoice = `INV-CTC-${String(seq).padStart(6, '0')}`;
        db.prepare(`INSERT INTO payments
          (id,user_id,subscription_id,amount,discount_amount,refunded_amount,currency,status,
           provider,tracking_code,invoice_number,created_at,paid_at)
          VALUES (?,?,?,?,0,0,'TOMAN','paid','card_to_card',?,?,?,?)`)
          .run(paymentId, row.user_id, subscriptionId, row.amount, row.tracking_code,
               invoice, row.created_at, iso());

        db.prepare(`UPDATE payment_receipts
          SET status='approved', admin_note=?, granted_days=?, payment_id=?,
              reviewed_by_admin_id=?, reviewed_at=? WHERE id=?`)
          .run(note, days, paymentId, req.admin.id, iso(), row.id);

        return { expiresAt, paymentId, invoice };
      })();

      logAudit({
        adminId: req.admin.id,
        action: 'PAYMENT_RECEIPT_APPROVED',
        entityType: 'payment_receipt',
        entityId: row.id,
        details: { userId: row.user_id, planId: plan.id, days, amount: row.amount, invoice: result.invoice },
        ip: clientIp(req),
      });

      res.json({ ok: true, days, expiresAt: result.expiresAt, invoice: result.invoice });
    } catch (error) { next(error); }
  });

  app.post('/api/admin/receipts/:id/reject', allowPermissions('billing.manage'), (req, res, next) => {
    try {
      const row = db.prepare('SELECT * FROM payment_receipts WHERE id=?').get(req.params.id);
      if (!row) throw bad('فیش پیدا نشد.', 404);
      if (row.status === 'approved') throw bad('فیش تاییدشده را نمی‌توان رد کرد؛ ابتدا بازپرداخت را ثبت کنید.', 409);
      const note = clean(req.body?.note, 300) || 'فیش واریز تایید نشد.';
      db.prepare(`UPDATE payment_receipts
        SET status='rejected', admin_note=?, reviewed_by_admin_id=?, reviewed_at=? WHERE id=?`)
        .run(note, req.admin.id, iso(), row.id);
      logAudit({
        adminId: req.admin.id, action: 'PAYMENT_RECEIPT_REJECTED', entityType: 'payment_receipt',
        entityId: row.id, details: { userId: row.user_id, reason: note }, ip: clientIp(req),
      });
      res.json({ ok: true });
    } catch (error) { next(error); }
  });

  return { publicCards };
}

module.exports = { install };
