'use strict';
/* ==========================================================================
   فونت مشترک همه صفحات سرور-رندر

   باگی که پیدا شد: فقط index.html بلوک @font-face داشت. صفحات /pricing،
   /faq، /about، /contact، /guides، /quick-start، /legal/* و پنل مدیریت
   `font-family:Vazirmatn` می‌نوشتند ولی هیچ‌وقت فایل فونت را لود نمی‌کردند،
   پس مرورگر بی‌سروصدا به Tahoma برمی‌گشت.
   ========================================================================== */

const FONT_FACE = `
@font-face{font-family:'Vazirmatn';src:url('/fonts/vazirmatn-var.woff2') format('woff2-variations'),url('/fonts/vazirmatn-var.woff2') format('woff2');font-weight:400 900;font-style:normal;font-display:swap}
@font-face{font-family:'JetBrains Mono';src:url('/fonts/jetbrains-mono-var.woff2') format('woff2-variations'),url('/fonts/jetbrains-mono-var.woff2') format('woff2');font-weight:400 800;font-style:normal;font-display:swap}
`.trim();

const PRELOAD = '<link rel="preload" href="/fonts/vazirmatn-var.woff2" as="font" type="font/woff2" crossorigin>';

/** بلوک کامل <link preload> + <style> برای گذاشتن داخل <head> */
function headTag() {
  /* استایل اسکرول‌بار هم همراه فونت به همه صفحات سرور-رندر تزریق می‌شود
     تا نوار اسکرول سفیدِ ویندوزی کنار طراحی تیره دیده نشود. */
  const scrollbar = require('./shared-scrollbar').styleTag();
  /* کف اندازهٔ متن روی موبایل (متن‌های ۷ تا ۱۰ پیکسلی صفحهٔ اصلی) */
  const mobileType = require('./shared-mobile-type').styleTag();
  return `${PRELOAD}<style id="pa-shared-fonts">${FONT_FACE}</style>${scrollbar}${mobileType}<script src="/support-widget.js" defer></script>`;
}

module.exports = { FONT_FACE, PRELOAD, headTag };
