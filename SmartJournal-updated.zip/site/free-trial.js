'use strict';
/* ==========================================================================
   پلن رایگان = دسترسی کامل، ولی فقط ۷ روز

   نکته‌ی مهم: تابع journalAccessForUser وقتی اشتراک منقضی می‌شود به «پلن
   رایگان» برمی‌گردد. اگر رایگان دسترسی کامل بدهد، محدودیت ۷ روزه بی‌اثر
   می‌شد. برای همین یک پلن مخفی «expired» ساخته می‌شود که fallback واقعی است:
   کاربر بعد از پایان آزمایش داده‌هایش را می‌بیند ولی نمی‌تواند چیز جدیدی
   ثبت کند تا وقتی اشتراک بخرد.
   ========================================================================== */

const TRIAL_DAYS = Number(process.env.FREE_TRIAL_DAYS || 7);

// همه ۱۱ بخش ژورنال
const ALL_SECTIONS = ['dashboard', 'new', 'history', 'calendar', 'prop',
  'risk', 'checklist', 'documents', 'import', 'settings', 'pwa'];

// بعد از پایان دوره آزمایشی: فقط دیدن داده‌های قبلی
const AFTER_TRIAL_SECTIONS = ['dashboard', 'history', 'calendar', 'settings'];

function install({ db, id, iso, logger }) {
  const log = (event, msg) => { try { logger.info({ event }, msg); } catch { /* noop */ } };

  const setSections = (planId, enabled) => {
    const rows = db.prepare('SELECT section_key FROM plan_journal_sections WHERE plan_id=?').all(planId);
    const have = new Set(rows.map((r) => r.section_key));
    ALL_SECTIONS.forEach((key, index) => {
      const on = enabled.includes(key) ? 1 : 0;
      if (have.has(key)) {
        db.prepare(`UPDATE plan_journal_sections SET is_enabled=?,sort_order=?,updated_at=?
                    WHERE plan_id=? AND section_key=?`)
          .run(on, (index + 1) * 10, iso(), planId, key);
      } else {
        db.prepare(`INSERT INTO plan_journal_sections
                    (id,plan_id,section_key,is_enabled,sort_order,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?)`)
          .run(id('pjs'), planId, key, on, (index + 1) * 10, iso(), iso());
      }
    });
  };

  /* ---- ۱) پلن رایگان: دسترسی کامل، ۷ روز ---- */
  const free = db.prepare("SELECT * FROM plans WHERE name='free' LIMIT 1").get();
  if (free) {
    if (Number(free.duration_days) !== TRIAL_DAYS) {
      db.prepare('UPDATE plans SET duration_days=? WHERE id=?').run(TRIAL_DAYS, free.id);
      log('free_trial_duration', `free plan duration set to ${TRIAL_DAYS} days`);
    }
    const enabled = db.prepare(
      "SELECT COUNT(*) c FROM plan_journal_sections WHERE plan_id=? AND is_enabled=1").get(free.id).c;
    if (Number(enabled) !== ALL_SECTIONS.length) {
      setSections(free.id, ALL_SECTIONS);
      log('free_trial_sections', 'free plan now unlocks every journal section');
    }
    // سهمیه‌ها هم باید در دوره آزمایشی دست‌وپاگیر نباشند
    const proQuota = db.prepare("SELECT max_trades,max_storage_bytes FROM plans WHERE name='pro' LIMIT 1").get();
    if (proQuota && Number(free.max_trades) < Number(proQuota.max_trades)) {
      db.prepare('UPDATE plans SET max_trades=?,max_storage_bytes=? WHERE id=?')
        .run(proQuota.max_trades, proQuota.max_storage_bytes, free.id);
      log('free_trial_quota', 'free trial quota matched to the pro plan');
    }
  }

  /* ---- ۲) پلن مخفی «expired» به‌عنوان fallback واقعی ---- */
  let expired = db.prepare("SELECT * FROM plans WHERE name='expired' LIMIT 1").get();
  if (!expired) {
    db.prepare(`INSERT INTO plans
      (id,name,name_fa,price_monthly,currency,max_trades,max_storage_bytes,max_sms_monthly,
       color,tagline,is_recommended,sort_order,is_active,duration_days)
      VALUES (?,?,?,0,'TOMAN',?,?,0,'#8b95a7',?,0,99,0,0)`)
      .run('plan_expired', 'expired', 'پایان دوره آزمایشی',
           Number(free?.max_trades || 100), Number(free?.max_storage_bytes || 104857600),
           'دوره آزمایشی تمام شده؛ داده‌ها در دسترس‌اند ولی ثبت جدید نیاز به اشتراک دارد.');
    expired = db.prepare("SELECT * FROM plans WHERE name='expired' LIMIT 1").get();
    log('expired_plan_created', 'hidden fallback plan created for finished trials');
  }
  // idempotent: اگر اجرای قبلی نیمه‌کاره مانده باشد، اینجا کامل می‌شود
  if (expired) {
    const current = db.prepare(
      'SELECT section_key,is_enabled FROM plan_journal_sections WHERE plan_id=?').all(expired.id);
    const want = new Set(AFTER_TRIAL_SECTIONS);
    const same = current.length === ALL_SECTIONS.length
      && current.every((r) => !!r.is_enabled === want.has(r.section_key));
    if (!same) {
      setSections(expired.id, AFTER_TRIAL_SECTIONS);
      log('expired_plan_sections', 'read-only section set applied to the expired plan');
    }
    if (Number(expired.is_active) !== 0) {
      db.prepare('UPDATE plans SET is_active=0 WHERE id=?').run(expired.id);
    }
  }

  return {
    trialDays: TRIAL_DAYS,
    allSections: ALL_SECTIONS,
    afterTrialSections: AFTER_TRIAL_SECTIONS,
  };
}

module.exports = { install, TRIAL_DAYS, ALL_SECTIONS, AFTER_TRIAL_SECTIONS };
