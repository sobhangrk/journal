'use strict';
const fs=require('node:fs');
const IORedis=require('ioredis');
const {Queue,QueueEvents}=require('bullmq');
const {logger}=require('./observability');
const enabled=String(process.env.QUEUE_ENABLED||'false')==='true';
let workerConnection=null,producerConnection=null,smsQueue=null,smsEvents=null,mediaQueue=null;
function password(){return process.env.REDIS_PASSWORD||(process.env.REDIS_PASSWORD_FILE?fs.readFileSync(process.env.REDIS_PASSWORD_FILE,'utf8').trim():undefined)}
function base(){if(!enabled)throw new Error('Queue is disabled.');if(!process.env.REDIS_URL)throw new Error('REDIS_URL is required when QUEUE_ENABLED=true.');return {password:password(),enableReadyCheck:true,lazyConnect:true,tls:process.env.REDIS_TLS==='true'?{}:undefined}}
function observe(connection,kind){connection.on('error',error=>logger.error({event:'redis_error',kind,err:error},'Redis queue connection error'));connection.on('ready',()=>logger.info({event:'redis_ready',kind},'Redis queue connection ready'));return connection}
function redis(){if(!workerConnection)workerConnection=observe(new IORedis(process.env.REDIS_URL,{...base(),maxRetriesPerRequest:null}),'worker');return workerConnection}
function producer(){if(!producerConnection)producerConnection=observe(new IORedis(process.env.REDIS_URL,{...base(),maxRetriesPerRequest:1,enableOfflineQueue:false,connectTimeout:Number(process.env.REDIS_CONNECT_TIMEOUT_MS||2000),commandTimeout:Number(process.env.REDIS_COMMAND_TIMEOUT_MS||1500)}),'producer');return producerConnection}
const defaults={attempts:5,backoff:{type:'exponential',delay:1000},removeOnComplete:{age:3600,count:1000},removeOnFail:{age:7*86400,count:5000}};
function queue(){if(!smsQueue)smsQueue=new Queue('pa-journal-sms',{connection:producer(),defaultJobOptions:defaults});return smsQueue}
function media(){if(!mediaQueue)mediaQueue=new Queue('pa-journal-media',{connection:producer(),defaultJobOptions:{...defaults,attempts:4,backoff:{type:'exponential',delay:3000}}});return mediaQueue}
function events(){if(!smsEvents)smsEvents=new QueueEvents('pa-journal-sms',{connection:redis().duplicate()});return smsEvents}
/* اگر هیچ کارگری روی صف نباشد، منتظر ماندن بی‌فایده است: کاربرِ در حال
   ثبت‌نام ۵۰ ثانیه پشت یک کار بی‌صاحب می‌ماند و بعد خطا می‌گیرد. پس اول
   می‌پرسیم کارگری هست یا نه (نتیجه ۱۰ ثانیه کش می‌شود تا هزینه نداشته باشد). */
let workersCheckedAt=0,workersAvailable=false;
async function hasWorker(){
  const now=Date.now();
  if(now-workersCheckedAt<10000)return workersAvailable;
  workersCheckedAt=now;
  try{
    const list=await Promise.race([
      queue().getWorkers(),
      new Promise((_,reject)=>setTimeout(()=>reject(new Error('workers timeout')),1500)),
    ]);
    workersAvailable=Array.isArray(list)&&list.length>0;
  }catch{workersAvailable=false}
  return workersAvailable;
}
async function enqueueSmsAndWait(encryptedPayload,jobId){
  if(!await hasWorker())throw new Error('NO_SMS_WORKER: صف پیامک کارگر فعال ندارد.');
  const job=await queue().add('deliver',{payload:encryptedPayload},{jobId:String(jobId).replace(/[^a-zA-Z0-9_-]/g,'_')});
  logger.info({event:'sms_job_enqueued',jobId:job.id},'SMS job enqueued');
  return await job.waitUntilFinished(events(),Number(process.env.SMS_JOB_TIMEOUT_MS||20000));
}
async function enqueueMedia(fileId){const job=await media().add('verify-and-mirror',{fileId},{jobId:`media_${String(fileId).replace(/[^a-zA-Z0-9_-]/g,'_')}`});logger.info({event:'media_job_enqueued',jobId:job.id,fileId},'Media processing job enqueued');return job.id}
async function health(){if(!enabled)return {enabled:false,ready:true};try{const response=await Promise.race([producer().ping(),new Promise((_,reject)=>setTimeout(()=>reject(new Error('Redis queue health timeout')),Number(process.env.REDIS_HEALTH_TIMEOUT_MS||1500)))]);return {enabled:true,ready:response==='PONG'}}catch(error){return {enabled:true,ready:false,error:error.message}}}
async function close(){await Promise.allSettled([smsEvents&&smsEvents.close(),smsQueue&&smsQueue.close(),mediaQueue&&mediaQueue.close(),producerConnection&&producerConnection.quit(),workerConnection&&workerConnection.quit()].filter(Boolean))}
module.exports={enabled,redis,enqueueSmsAndWait,enqueueMedia,health,close};
