/* bcrypt-worker.js — پردازشگر هش در نخ جدا */
'use strict';
const { parentPort } = require('worker_threads');
const bcrypt = require('bcryptjs');

parentPort.on('message', msg => {
  try {
    if (msg.op === 'hash') parentPort.postMessage({ id: msg.id, ok: true, value: bcrypt.hashSync(msg.password, msg.cost) });
    else if (msg.op === 'compare') parentPort.postMessage({ id: msg.id, ok: true, value: bcrypt.compareSync(msg.password, msg.hash) });
    else parentPort.postMessage({ id: msg.id, ok: false, error: 'op ناشناخته' });
  } catch (e) {
    parentPort.postMessage({ id: msg.id, ok: false, error: String(e && e.message || e) });
  }
});
