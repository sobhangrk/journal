'use strict';

const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const bcryptPool = require('./bcrypt-pool');
/* هش ساختگی برای یکسان‌سازی زمان پاسخ ورود: وقتی شماره‌ای وجود ندارد، باز هم
   یک مقایسهٔ bcrypt واقعی انجام می‌شود تا مهاجم نتواند با اندازه‌گیری زمان
   بفهمد کدام شماره‌ها حساب دارند (پیش‌ازاین: موجود ~500ms، ناموجود ~3ms). */
const DUMMY_PASSWORD_HASH = bcryptPool.hashSync('timing-equalizer-dummy-value', 12);
const crypto = require('crypto');
const zlib = require('node:zlib');
const fs = require('fs');
const path = require('path');
const net = require('net');
const dns = require('dns').promises;
const http = require('http');
const https = require('https');
const QRCode = require('qrcode');
const { generateRegistrationOptions, verifyRegistrationResponse, generateAuthenticationOptions, verifyAuthenticationResponse } = require('@simplewebauthn/server');
const {logger,requestObservability,captureError,setReadiness,metrics,metricsContentType,setupSentryErrorHandler}=require('./observability');
const {planPricing,payablePrice,withPricing}=require('./plan-pricing');
const redisStore=require('./redis-store');
const smsQueue=require('./queue');
const storage=require('./storage');
const {TYPES:LEGAL_TYPES,TITLES:LEGAL_TITLES}=require('./legal-content');
const {FAQS,GUIDES}=require('./marketing-content');
const {escapeHtml:escapeMarketingHtml,seoHead,productSchema,faqSchema,organizationSchema,webSiteSchema,renderHomePage,renderMarketingPage,renderGuidePage,renderNotFound}=require('./marketing-pages');
const {
  db,
  initDb,
  logAudit,
  recordSystemError,
  recordSecurityAlert,
  cleanupExpiredSessions,
  normalizeMobile,
  id,
  iso,
  DB_PATH,
  DATABASE_ENGINE,
  PERMISSION_KEYS,
  DEFAULT_ROLE_PERMISSIONS,
  syncUserContacts
} = require('./db');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const IS_PROD = process.env.NODE_ENV === 'production';
/* کوکی امن فقط روی HTTPS ارسال می‌شود. اگر هنوز دامنه و گواهی ندارید و
   می‌خواهید موقتاً با IP سایت را ببینید، COOKIE_SECURE=false بگذارید.
   روی سرور واقعی و بعد از گرفتن دامنه، حتماً برش دارید. */
const COOKIE_SECURE = process.env.COOKIE_SECURE === 'false' ? false
  : process.env.COOKIE_SECURE === 'true' ? true
  : IS_PROD;
function configuredSecret(name){const direct=process.env[name];if(direct)return String(direct).trim();const file=process.env[`${name}_FILE`];if(file){try{return fs.readFileSync(file,'utf8').trim()}catch(error){throw new Error(`Unable to read ${name}_FILE: ${error.message}`)}}return ''}
const COOKIE_NAME = 'pa_admin_session';
const USER_COOKIE_NAME = 'pa_user_session';
const SESSION_HOURS = Number(process.env.ADMIN_SESSION_HOURS || 12);
const USER_SESSION_DAYS = Math.max(1,Math.min(365,Number(process.env.USER_SESSION_DAYS || 30)));
const USER_DEVICE_COOKIE='pa_user_device';
const ADMIN_MFA_COOKIE='pa_admin_mfa';
const APP_ENCRYPTION_SECRET=configuredSecret('APP_ENCRYPTION_KEY')||(IS_PROD?'':'pa-journal-development-encryption-key-change-me');
if(!APP_ENCRYPTION_SECRET)throw new Error('APP_ENCRYPTION_KEY is required in production for SMS and MFA secrets.');
if(IS_PROD&&Buffer.byteLength(APP_ENCRYPTION_SECRET,'utf8')<32)throw new Error('APP_ENCRYPTION_KEY must contain at least 32 bytes in production.');
const APP_ENCRYPTION_KEY=crypto.createHash('sha256').update(APP_ENCRYPTION_SECRET).digest();
initDb();
const MANAGED_ROLES = ['admin','support','finance','security','content_manager'];
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, 'data', 'uploads'));
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(requestObservability);
const FRAME_ANCESTORS = process.env.FRAME_ANCESTORS || (IS_PROD ? "'none'" : '*');
const ALLOW_FRAMING = FRAME_ANCESTORS !== "'none'";
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false,
  frameguard: ALLOW_FRAMING ? false : { action: 'sameorigin' } }));
app.use(compression());
app.use(cookieParser());
app.use('/api/journal', userAuth);
app.use('/api/journal', express.json({ limit: '32mb' }));
app.use(express.json({ limit: '128kb' }));
/* هر تصویری که کاربر بفرستد، پیش از رسیدن به منطق برنامه WebP می‌شود */
app.use(require('./image-webp').webpRequestBody());
try{require('./free-trial').install({db,id,iso,logger})}catch(error){logger.warn({event:'free_trial_setup_failed',err:String(error&&error.message)},'free trial setup skipped')}

/* تبدیل خودکار به WebP فقط وقتی معنی دارد که خود WebP جزو فرمت‌های مجاز باشد. */
try{
  const fsRow=db.prepare("SELECT allowed_mime_types FROM file_settings WHERE id='default'").get();
  if(fsRow){
    let list; try{list=JSON.parse(fsRow.allowed_mime_types)}catch{list=String(fsRow.allowed_mime_types||'').split(',').map(v=>v.trim()).filter(Boolean)}
    if(Array.isArray(list)&&!list.includes('image/webp')){
      list.push('image/webp');
      db.prepare("UPDATE file_settings SET allowed_mime_types=?,updated_at=? WHERE id='default'").run(JSON.stringify(list),iso());
      logger.info({event:'webp_mime_allowed'},'image/webp added to allowed upload formats');
    }
  }
}catch(error){ /* جدول هنوز ساخته نشده؛ در اجرای بعدی اعمال می‌شود */ }

app.use((req,res,next)=>{
  if(!['GET','HEAD'].includes(req.method)||req.path.startsWith('/api/')||req.path.startsWith('/internal/'))return next();
  const queryIndex=req.originalUrl.indexOf('?'),query=queryIndex>=0?req.originalUrl.slice(queryIndex):'';
  if(req.path==='/index.html')return res.redirect(308,`/${query}`);
  if(req.path.length>1&&req.path.endsWith('/'))return res.redirect(308,`${req.path.replace(/\/+$/,'')}${query}`);
  next();
});

app.use('/admin', (req, res, next) => {
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data:",
    "font-src 'self'",
    "connect-src 'self'",
    ...(ALLOW_FRAMING ? [] : [`frame-ancestors ${FRAME_ANCESTORS}`]),
    "base-uri 'self'",
    "form-action 'self'"
  ].join('; '));
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  next();
});

const loginAttempts = new Map();
const supportAttempts = new Map();
const marketingEventAttempts = new Map();
function clientIp(req) { return String(req.ip || req.socket.remoteAddress || '').slice(0, 100); }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'})[char]); }
function tokenHash(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function secureToken(bytes = 32) { return crypto.randomBytes(bytes).toString('base64url'); }
function publicOrigin(req){
  const configured=String(process.env.PUBLIC_BASE_URL||process.env.WEBAUTHN_ORIGIN||'').trim();
  try{if(configured){const parsed=new URL(configured);if(['http:','https:'].includes(parsed.protocol))return parsed.origin}}catch{}
  const host=String(req.get('host')||`localhost:${PORT}`).replace(/[\r\n]/g,'');
  return `${req.protocol==='https'?'https':'http'}://${host}`;
}
function publicPlans(){
  const features=db.prepare('SELECT plan_id,feature_key,label,description,is_enabled,sort_order FROM plan_features ORDER BY sort_order,id').all(),sections=db.prepare('SELECT plan_id,section_key,is_enabled,sort_order FROM plan_journal_sections ORDER BY sort_order,id').all(),byPlan={},sectionsByPlan={},labels=new Map(JOURNAL_SECTION_DEFINITIONS);
  features.forEach(feature=>(byPlan[feature.plan_id]||(byPlan[feature.plan_id]=[])).push({...feature,is_enabled:!!feature.is_enabled}));sections.forEach(section=>(sectionsByPlan[section.plan_id]||(sectionsByPlan[section.plan_id]=[])).push({...section,label:labels.get(section.section_key)||section.section_key,is_enabled:!!section.is_enabled}));
  return db.prepare('SELECT id,name,name_fa,price_monthly,max_trades,max_storage_bytes,max_sms_monthly,color,tagline,badge_label,cta_label,is_recommended,sort_order,duration_days,discount_percent,discount_price,discount_label,discount_until FROM plans WHERE is_active=1 ORDER BY sort_order,price_monthly,id').all().map(plan=>({...withPricing(plan),price_monthly:Number(plan.price_monthly||0),max_trades:Number(plan.max_trades||0),max_storage_bytes:Number(plan.max_storage_bytes||0),max_sms_monthly:Number(plan.max_sms_monthly||0),duration_days:Number(plan.duration_days||0),is_recommended:!!plan.is_recommended,features:byPlan[plan.id]||[],journal_sections:sectionsByPlan[plan.id]||[]}))
}
function publicFaqs(){return db.prepare("SELECT id,category,question,answer,is_featured,sort_order,updated_at FROM marketing_faqs WHERE status='published' ORDER BY CASE category WHEN 'why' THEN 0 ELSE 1 END,sort_order,created_at").all().map(item=>({...item,is_featured:!!item.is_featured}))}
function marketingContext(req){return {origin:publicOrigin(req),menus:db.prepare("SELECT label,url FROM cms_menu_items WHERE menu_key='header' AND status='published' ORDER BY sort_order,created_at").all(),footerMenus:db.prepare("SELECT label,url FROM cms_menu_items WHERE menu_key='footer' AND status='published' ORDER BY sort_order,created_at").all(),plans:publicPlans(),faqs:publicFaqs(),verification:{google:configuredSecret('GOOGLE_SITE_VERIFICATION'),bing:configuredSecret('BING_SITE_VERIFICATION')},supportEmail:String(process.env.SUPPORT_EMAIL||'').trim()}}
function cachePublicHtml(res){res.setHeader('Cache-Control',IS_PROD?'public, max-age=60, stale-while-revalidate=300':'no-cache');res.setHeader('Vary','Accept-Encoding')}

function encryptSecret(value){if(value===null||value===undefined)return null;const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',APP_ENCRYPTION_KEY,iv),encrypted=Buffer.concat([cipher.update(JSON.stringify(value),'utf8'),cipher.final()]),tag=cipher.getAuthTag();return Buffer.concat([iv,tag,encrypted]).toString('base64url')}
function decryptSecret(value){if(!value)return null;try{const raw=Buffer.from(value,'base64url'),iv=raw.subarray(0,12),tag=raw.subarray(12,28),encrypted=raw.subarray(28),decipher=crypto.createDecipheriv('aes-256-gcm',APP_ENCRYPTION_KEY,iv);decipher.setAuthTag(tag);return JSON.parse(Buffer.concat([decipher.update(encrypted),decipher.final()]).toString('utf8'))}catch{return null}}
const BASE32='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(buffer){let bits=0,value=0,output='';for(const byte of buffer){value=(value<<8)|byte;bits+=8;while(bits>=5){output+=BASE32[(value>>>(bits-5))&31];bits-=5}}if(bits>0)output+=BASE32[(value<<(5-bits))&31];return output}
function base32Decode(input){const clean=String(input||'').toUpperCase().replace(/[^A-Z2-7]/g,'');let bits=0,value=0,bytes=[];for(const char of clean){const index=BASE32.indexOf(char);if(index<0)continue;value=(value<<5)|index;bits+=5;if(bits>=8){bytes.push((value>>>(bits-8))&255);bits-=8}}return Buffer.from(bytes)}
function totpAt(secret,step=30,digits=6,time=Date.now()){const counter=Math.floor(time/1000/step),buffer=Buffer.alloc(8);buffer.writeBigUInt64BE(BigInt(counter));const hmac=crypto.createHmac('sha1',base32Decode(secret)).update(buffer).digest(),offset=hmac[hmac.length-1]&15,number=(hmac.readUInt32BE(offset)&0x7fffffff)%10**digits;return {code:String(number).padStart(digits,'0'),counter}}
function verifyTotp(secret,code,lastUsedStep=null){const normalized=String(code||'').trim();if(!/^\d{6}$/.test(normalized))return null;for(let drift=-1;drift<=1;drift++){const item=totpAt(secret,30,6,Date.now()+drift*30000);if(crypto.timingSafeEqual(Buffer.from(item.code),Buffer.from(normalized))&&(!Number.isFinite(Number(lastUsedStep))||item.counter>Number(lastUsedStep)))return item.counter}return null}
function otpHash(challengeId,code){return crypto.createHmac('sha256',APP_ENCRYPTION_KEY).update(`${challengeId}:${code}`).digest('hex')}
function authSecuritySettings(){return db.prepare("SELECT * FROM auth_security_settings WHERE id='default'").get()||{max_devices:5,trusted_device_days:30,otp_ttl_seconds:120,otp_max_attempts:5,captcha_failure_threshold:3,new_device_otp:1,notify_new_login:1}}
function currentLegalDocument(type){return db.prepare("SELECT id,document_type,version,title,content,content_sha256,effective_at,published_at FROM legal_documents WHERE document_type=? AND status='published' AND effective_at<=? ORDER BY effective_at DESC,created_at DESC LIMIT 1").get(type,iso())||null}
function legalDocumentSummary(document){return document?{type:document.document_type,version:document.version,title:document.title,effectiveAt:document.effective_at,publishedAt:document.published_at,url:`/legal/${document.document_type}`} : null}
function legalDocumentHtml(document){const lines=String(document.content||'').split(/\r?\n/),parts=[];for(const raw of lines){const line=raw.trim();if(!line||line===document.title||/^نسخه\s/.test(line))continue;const safe=escapeHtml(line);if(/^[۰-۹0-9]+[.)،.]\s+/.test(line))parts.push(`<h2>${safe}</h2>`);else if(line.startsWith('•'))parts.push(`<p class="bullet">${safe}</p>`);else parts.push(`<p>${safe}</p>`)}return parts.join('\n')}
function requiredSignupDocuments(){const documents=['terms','privacy','disclaimer'].map(currentLegalDocument);if(documents.some(document=>!document))throw Object.assign(new Error('اسناد حقوقی لازم هنوز برای این محیط منتشر نشده‌اند.'),{status:503});return documents}
function recordMarketingConsent({userId=null,contactId=null,mobile,granted,policyVersion,source,ip=null,userAgent=null,adminId=null}){const now=iso(),normalized=normalizeMobile(mobile),mobileHash=crypto.createHash('sha256').update(normalized).digest('hex');db.prepare(`INSERT INTO marketing_consent_events (id,user_id,contact_id,mobile_hash,channel,purpose,granted,policy_version,source,occurred_at,ip,user_agent,actor_admin_id) VALUES (?,?,?,?,'sms','marketing',?,?,?,?,?,?,?)`).run(id('mcons'),userId,contactId,mobileHash,granted?1:0,policyVersion,source,now,ip,userAgent&&String(userAgent).slice(0,500),adminId);if(contactId)db.prepare(`UPDATE user_contacts SET sms_consent=?,sms_consent_at=?,sms_consent_version=?,sms_consent_source=?,sms_consent_revoked_at=?,updated_at=? WHERE id=?`).run(granted?1:0,granted?now:null,policyVersion,source,granted?null:now,now,contactId);return now}
function deviceLabel(userAgent=''){const ua=String(userAgent);const browser=/Edg\//.test(ua)?'Edge':/Firefox\//.test(ua)?'Firefox':/Chrome\//.test(ua)?'Chrome':/Safari\//.test(ua)?'Safari':'مرورگر';const os=/Android/.test(ua)?'Android':/iPhone|iPad/.test(ua)?'iOS':/Windows/.test(ua)?'Windows':/Mac OS/.test(ua)?'macOS':/Linux/.test(ua)?'Linux':'دستگاه ناشناس';return `${browser} · ${os}`}
function deviceHash(raw){return tokenHash(`device:${String(raw||'')}`)}
function currentDevice(req){const raw=String(req.cookies[USER_DEVICE_COOKIE]||'');return raw?{raw,hash:deviceHash(raw)}:null}
function setDeviceCookie(res,raw){res.cookie(USER_DEVICE_COOKIE,raw,{httpOnly:true,secure:COOKIE_SECURE,sameSite:'strict',path:'/',maxAge:365*86400000})}
function recordUserSecurityEvent({userId=null,eventType,severity='info',title,details=null,ip=null,deviceId=null}){const eventId=id('usec');db.prepare('INSERT INTO user_security_events (id,user_id,event_type,severity,title,details,ip,device_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(eventId,userId,eventType,severity,title,details?JSON.stringify(details):null,ip,deviceId,iso());return eventId}
function sanitizeSmsProvider(provider){const config=jsonDetails(provider.config_json)||{};return {...provider,config,configured:!!decryptSecret(provider.credentials_encrypted),credentials_encrypted:undefined,config_json:undefined}}
/* ترجمه کدهای خطای ملی‌پیامک به فارسی — مدیر باید بفهمد چه کار کند،
   نه اینکه فقط عدد ۲ یا ‎-۵ ببیند. مرجع: melipayamak.com/api/sendbybasenumber3 */
/* ریشه‌ی وب‌سرویس REST ملی‌پیامک.
   طبق SDK رسمی، همه‌ی متدها زیر /api/SendSMS/ هستند:
     /api/SendSMS/SendSMS · /api/SendSMS/BaseServiceNumber · /api/SendSMS/GetCredit
   نسخه‌ی قبلی این تابع `/SendSMS` را از انتهای آدرسِ پیش‌فرض هم برمی‌داشت و
   نتیجه‌اش `/api/GetCredit` می‌شد ⇒ سرور ملی‌پیامک ۴۰۴ می‌داد. */
function melipayamakRoot(configUrl){
  let root=String(configUrl||'').trim().replace(/\/+$/,'');
  if(!root)return 'https://rest.payamak-panel.com/api/SendSMS';
  root=root.replace(/\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i,'');
  root=root.replace(/\/SendSMS\/SendSMS$/i,'/SendSMS');
  return root;
}
const MELIPAYAMAK_ERRORS={'0':'نام کاربری یا رمز عبور ملی‌پیامک اشتباه است.','2':'اعتبار پنل ملی‌پیامک کافی نیست؛ شارژ کنید.','3':'محدودیت ارسال روزانه.','4':'محدودیت حجم ارسال.','5':'شماره فرستنده معتبر نیست.','6':'سامانه ملی‌پیامک در حال به‌روزرسانی است؛ چند دقیقه بعد دوباره تلاش کنید.','7':'متن پیام حاوی کلمه فیلترشده است؛ با واحد اداری ملی‌پیامک تماس بگیرید.','9':'ارسال از خطوط عمومی با وب‌سرویس ممکن نیست — باید از «خط خدماتی اشتراکی» با کد متن الگو استفاده کنید.','10':'کاربر پنل ملی‌پیامک فعال نیست.','11':'پیام ارسال نشد.','12':'مدارک حساب ملی‌پیامک کامل نیست؛ تا تکمیل مدارک ارسال انجام نمی‌شود.','14':'متن پیام حاوی لینک است.','16':'شماره گیرنده یافت نشد.','17':'متن پیامک خالی است.','18':'شماره گیرنده نامعتبر است.','19':'از محدودیت ساعتی فراتر رفته‌اید.','35':'شماره گیرنده در لیست سیاه مخابرات است — برای رساندن کد ورود باید از «خط خدماتی اشتراکی» (کد متن الگو) استفاده کنید.','-1':'دسترسی وب‌سرویس الگو برای حساب شما فعال نیست؛ از پشتیبانی ملی‌پیامک بخواهید فعالش کند.','-2':'در هر درخواست فقط یک شماره مجاز است.','-3':'خط ارسالی در سیستم تعریف نشده است؛ با پشتیبانی ملی‌پیامک تماس بگیرید.','-4':'کد متن (bodyId) اشتباه است یا هنوز تأیید نشده.','-5':'متن ارسالی با متغیرهای الگو همخوانی ندارد — الگو باید دقیقاً یک متغیر داشته باشد.','-6':'خطای داخلی ملی‌پیامک؛ با پشتیبانی تماس بگیرید.','-7':'مشکل در شماره فرستنده؛ با پشتیبانی ملی‌پیامک تماس بگیرید.','-8':'متن ارسالی باید با @ شروع شود (خطای قالب).','-9':'خط ارسالی تعریف نشده است.','-10':'در متغیرهای ارسالی لینک وجود دارد.','-108':'IP سرور شما به دلیل تلاش‌های ناموفق مسدود شده است.','-109':'باید IP سرور را در پنل ملی‌پیامک در فهرست IPهای مجاز ثبت کنید.','-110':'پنل شما الزام کرده به‌جای رمز عبور از API Key استفاده کنید؛ در فیلد «رمز API» کلید را بگذارید.','-111':'IP درخواست‌کننده نامعتبر است.'};
function melipayamakError(value,result){const key=String(value||'').trim(),text=MELIPAYAMAK_ERRORS[key];if(text)return text;const status=result?.StrRetStatus||result?.RetStatus;return `ملی‌پیامک پاسخ ناشناخته داد (${key||status||'بدون کد'})`}
async function deliverWithProvider(provider,mobile,message,otpCode=null){const credentials=decryptSecret(provider.credentials_encrypted),config=jsonDetails(provider.config_json)||{};if(!credentials)throw new Error('اطلاعات اتصال ارائه‌دهنده تنظیم نشده است.');const timeout=AbortSignal.timeout(10000);if(provider.provider_type==='kavenegar'){if(otpCode&&config.template){const url=`https://api.kavenegar.com/v1/${encodeURIComponent(credentials.apiKey)}/verify/lookup.json?receptor=${encodeURIComponent(mobile)}&token=${encodeURIComponent(otpCode)}&template=${encodeURIComponent(config.template)}`,response=await fetch(url,{signal:timeout});if(!response.ok)throw new Error(`KAVENEGAR_${response.status}`);return await response.json()}const params=new URLSearchParams({receptor:mobile,message,...(config.sender?{sender:config.sender}:{})}),response=await fetch(`https://api.kavenegar.com/v1/${encodeURIComponent(credentials.apiKey)}/sms/send.json`,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:params,signal:timeout});if(!response.ok)throw new Error(`KAVENEGAR_${response.status}`);return await response.json()}
  if(provider.provider_type==='melipayamak'){
    /* ملی‌پیامک دو مسیر دارد:
         BaseServiceNumber → «خط خدماتی اشتراکی/الگو» با کد متن (bodyId).
             تنها مسیری که کد ورود را حتی به شماره‌های داخل لیست سیاه مخابرات
             می‌رساند؛ برای OTP همین درست است.
         SendSMS         → ارسال معمولی با خط اختصاصی؛ برای پیام‌های اطلاع‌رسانی.
       اگر کد متن الگو پر شده باشد و پیام OTP باشد، خودکار مسیر الگو انتخاب می‌شود. */
    const base=melipayamakRoot(config.url),
          bodyId=String(config.template||config.bodyId||'').trim(),
          secret=credentials.password||credentials.apiKey||'',
          usePattern=!!(otpCode&&bodyId),
          payload=usePattern
            ?{username:credentials.username,password:secret,text:String(otpCode),to:mobile,bodyId:Number(bodyId)||bodyId}
            :{username:credentials.username,password:secret,to:mobile,from:config.sender||'',text:message,isFlash:false},
          response=await fetch(`${base}/${usePattern?'BaseServiceNumber':'SendSMS'}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload),signal:timeout});
    if(!response.ok)throw new Error(`ملی‌پیامک پاسخ HTTP ${response.status} داد`);
    const result=await response.json(),value=String(result?.Value??result?.value??'');
    /* موفق = recId؛ عددی بلندتر از ۱۵ رقم. هر عدد کوتاه یا منفی، کد خطاست. */
    if(Number(result?.RetStatus)===1&&/^\d{15,}$/.test(value))return result;
    throw new Error(melipayamakError(value,result));
  }
  if(provider.provider_type==='generic_webhook')return await deliverSafeWebhook(config,credentials,{mobile,message,code:otpCode,type:'otp',sender:config.sender||null})
  if(provider.provider_type==='development'&&!IS_PROD)return {development:true};throw new Error('نوع ارائه‌دهنده پشتیبانی نمی‌شود.')}
async function deliverSmsDirect({userId=null,mobile,type='otp',message,code=null,ip=null}){const providers=db.prepare("SELECT * FROM sms_providers WHERE is_enabled=1 ORDER BY is_primary DESC,CASE status WHEN 'healthy' THEN 0 WHEN 'degraded' THEN 1 ELSE 2 END,priority").all(),settings=db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();let lastError=null;let attempted=0;for(const provider of providers){if(!provider.credentials_encrypted&&provider.provider_type!=='development')continue;attempted++;try{await deliverWithProvider(provider,mobile,message,code);db.prepare("UPDATE sms_providers SET status='healthy',last_checked_at=?,updated_at=? WHERE id=?").run(iso(),iso(),provider.id);db.prepare(`INSERT INTO sms_logs (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at) VALUES (?,?,?,?, 'sent',?,?,NULL,?,0,NULL,?)`).run(id('sms'),userId,mobile,type,provider.name,Number(provider.unit_cost||0),ip,iso());return {ok:true,provider:provider.name}}catch(error){lastError=error;db.prepare("UPDATE sms_providers SET status='degraded',last_error_at=?,last_checked_at=?,updated_at=? WHERE id=?").run(iso(),iso(),iso(),provider.id);db.prepare(`INSERT INTO sms_logs (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at) VALUES (?,?,?,?, 'failed',?,?,?, ?,0,NULL,?)`).run(id('sms'),userId,mobile,type,provider.name,0,String(error.message).slice(0,120),ip,iso());if(!settings?.auto_failover)break}}
  /* fallback توسعه فقط وقتی هیچ درگاه تنظیم‌شده‌ای وجود نداشت.
     اگر درگاه واقعی هست ولی خطا داد، خطا را پنهان نمی‌کنیم — وگرنه مدیر
     لوکال «موفق» می‌بیند و روی سرور واقعی ثبت‌نام می‌شکند. */
  if(!IS_PROD&&!attempted){db.prepare(`INSERT INTO sms_logs (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at) VALUES (?,?,?,?, 'sent','Development OTP',0,NULL,?,0,NULL,?)`).run(id('sms'),userId,mobile,type,ip,iso());return {ok:true,provider:'Development OTP',development:true}}
  throw lastError||new Error('هیچ ارائه‌دهنده پیامک تنظیم‌شده و فعالی وجود ندارد.')}
/* صف پیامک اختیاری است و فقط برای مقیاس بالا لازم می‌شود. اگر روشن باشد ولی
   کارگر (worker) اجرا نشده باشد، کار در صف می‌ماند و بعد از ۵۰ ثانیه تایم‌اوت
   می‌شود — یعنی هیچ کاربری نمی‌تواند ثبت‌نام کند. این دقیقاً روی سرور واقعی
   رخ داد. حالا به‌جای شکست، همان لحظه مستقیم ارسال می‌کنیم و هشدار می‌دهیم. */
async function sendSms(payload){
  if(!smsQueue.enabled)return deliverSmsDirect(payload);
  const jobId=id('smsjob'),queued={...payload,jobId,queuedAt:iso()};
  try{
    return await smsQueue.enqueueSmsAndWait(encryptSecret(queued),jobId);
  }catch(error){
    logger.warn({event:'sms_queue_fallback',jobId,error:String(error.message||error).slice(0,200)},
      'صف پیامک جواب نداد؛ ارسال مستقیم انجام شد. کارگر صف را اجرا کنید یا QUEUE_ENABLED=false بگذارید.');
    return await deliverSmsDirect(payload);
  }
}
/* آیا CAPTCHA اصلاً پیکربندی شده؟ اگر نه، نباید کاربر را قفل کنیم.
   قبلاً وقتی کلید Turnstile تنظیم نبود، در production همیشه false برمی‌گشت و
   هر کاربری که ۳ بار رمز را اشتباه می‌زد، **برای همیشه** پشت CAPTCHAیی می‌ماند
   که اصلاً وجود نداشت. محدودیت نرخ و قفل حساب سر جایشان هستند؛ CAPTCHA فقط
   لایه‌ی اضافه بود. */
function captchaSecret(){const settings=authSecuritySettings();return decryptSecret(settings.turnstile_secret_encrypted)?.secret||process.env.TURNSTILE_SECRET_KEY||''}
function captchaConfigured(){const settings=authSecuritySettings();return !!captchaSecret()&&!!(settings.turnstile_site_key||process.env.TURNSTILE_SITE_KEY)}
let captchaWarned=false;
async function verifyTurnstile(token,ip){const settings=authSecuritySettings(),secret=captchaSecret();if(!secret){if(!captchaWarned&&IS_PROD){captchaWarned=true;logger.warn({event:'captcha_not_configured'},'کلید Turnstile تنظیم نشده؛ مرحله CAPTCHA نادیده گرفته می‌شود تا کاربران قفل نشوند.')}return true}try{const form=new URLSearchParams({secret,response:String(token||''),remoteip:ip||''}),response=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:form,signal:AbortSignal.timeout(8000)}),result=await response.json();return !!result.success}catch{return false}}
function captchaRequiredFor(mobile){const settings=authSecuritySettings(),user=db.prepare('SELECT failed_login_count FROM users WHERE mobile=? AND deleted_at IS NULL').get(mobile);return Number(user?.failed_login_count||0)>=Number(settings.captcha_failure_threshold||3)}
function otpMessage(code){const template=db.prepare("SELECT otp_template FROM sms_settings WHERE id='default'").get()?.otp_template||'کد ورود SmartJournal: {code}';return template.replaceAll('{code}',code)}
async function createOtpChallenge(req,{user=null,mobile,purpose,payload=null,remember=true,captchaVerified=false}){const settings=authSecuritySettings(),now=iso(),windowStart=new Date(Date.now()-10*60000).toISOString(),mobileCount=db.prepare('SELECT COUNT(*) count FROM user_otp_challenges WHERE mobile=? AND created_at>=?').get(mobile,windowStart).count,ipCount=db.prepare('SELECT COUNT(*) count FROM user_otp_challenges WHERE ip=? AND created_at>=?').get(clientIp(req),windowStart).count,smsSettings=db.prepare("SELECT mobile_limit_count,ip_limit_count FROM sms_settings WHERE id='default'").get();if(mobileCount>=Number(smsSettings?.mobile_limit_count||5)||ipCount>=Number(smsSettings?.ip_limit_count||12))throw Object.assign(new Error('تعداد درخواست کد بیش از حد مجاز است؛ کمی بعد دوباره تلاش کن.'),{status:429});const challengeId=id('otp'),rawChallenge=secureToken(24),code=String(crypto.randomInt(100000,1000000)),expiresAt=new Date(Date.now()+Number(settings.otp_ttl_seconds||120)*1000).toISOString(),device=currentDevice(req);db.prepare("UPDATE user_otp_challenges SET consumed_at=COALESCE(consumed_at,?) WHERE mobile=? AND purpose=? AND consumed_at IS NULL").run(now,mobile,purpose);db.prepare(`INSERT INTO user_otp_challenges (id,challenge_hash,user_id,mobile,purpose,code_hash,payload,attempts,max_attempts,created_at,expires_at,ip,device_hash,remember,captcha_verified) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(challengeId,tokenHash(rawChallenge),user?.id||null,mobile,purpose,otpHash(challengeId,code),payload?JSON.stringify(payload):null,0,Number(settings.otp_max_attempts||5),now,expiresAt,clientIp(req),device?.hash||null,remember?1:0,captchaVerified?1:0);let delivery;try{delivery=await sendSms({userId:user?.id||null,mobile,type:purpose==='security'?'security':'otp',message:otpMessage(code),code,ip:clientIp(req)})}catch(error){db.prepare('DELETE FROM user_otp_challenges WHERE id=?').run(challengeId);throw Object.assign(new Error(`ارسال پیامک ناموفق بود: ${error.message}`),{status:503})}return {challengeToken:rawChallenge,expiresAt,delivery:delivery.provider,...(delivery.development?{devCode:code}:{})}}
function consumeOtp(rawChallenge,code,purpose){const challenge=db.prepare('SELECT * FROM user_otp_challenges WHERE challenge_hash=? AND purpose=? AND consumed_at IS NULL AND expires_at>?').get(tokenHash(String(rawChallenge||'')),purpose,iso());if(!challenge)throw Object.assign(new Error('کد منقضی یا درخواست نامعتبر است.'),{status:400});if(challenge.attempts>=challenge.max_attempts)throw Object.assign(new Error('تعداد تلاش برای این کد تمام شده است.'),{status:429});if(!crypto.timingSafeEqual(Buffer.from(challenge.code_hash),Buffer.from(otpHash(challenge.id,String(code||''))))){db.prepare('UPDATE user_otp_challenges SET attempts=attempts+1 WHERE id=?').run(challenge.id);throw Object.assign(new Error('کد واردشده صحیح نیست.'),{status:400})}db.prepare('UPDATE user_otp_challenges SET consumed_at=?,attempts=attempts+1 WHERE id=?').run(iso(),challenge.id);return {...challenge,payload:jsonDetails(challenge.payload)}}

function parsePositiveInt(value, fallback, max = 100) {
  const number = Number.parseInt(value, 10);
  return Number.isFinite(number) && number > 0 ? Math.min(number, max) : fallback;
}
function safeLike(value) { return `%${String(value || '').trim().replace(/[\\%_]/g, '\\$&')}%`; }
function jsonDetails(value) {
  if (!value) return null;
  try { return JSON.parse(value); } catch { return value; }
}
function requestMeta(req) {
  return { ip: clientIp(req), userAgent: String(req.get('user-agent') || '').slice(0, 500) };
}
function parseAllowedMimeTypes(value) {
  try { const parsed = JSON.parse(value || '[]'); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
}
function removeStoredFile(storageKey) {
  if (!storageKey) return false;
  const target = path.resolve(UPLOAD_DIR, String(storageKey));
  if (target !== UPLOAD_DIR && !target.startsWith(`${UPLOAD_DIR}${path.sep}`)) return false;
  if(storage.s3Enabled)storage.deleteObject(storageKey).catch(error=>captureError(error,{source:'S3_MEDIA_DELETE'}));
  try { if (fs.existsSync(target) && fs.statSync(target).isFile()) { fs.unlinkSync(target); return true; } } catch {}
  return storage.s3Enabled;
}
function runAutomaticFileCleanup() {
  const settings = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
  if (!settings || !settings.auto_cleanup) return;
  const cutoff = new Date(Date.now() - Number(settings.orphan_retention_days) * 86400000).toISOString();
  const files = db.prepare("SELECT * FROM media_files WHERE status!='deleted' AND trade_ref IS NULL AND COALESCE(orphaned_at,uploaded_at)<=?").all(cutoff);
  if (!files.length) return;
  const deletedAt = iso(), perUser = new Map();
  files.forEach(file => { if (file.user_id) perUser.set(file.user_id, (perUser.get(file.user_id) || 0) + Number(file.size_bytes)); });
  const tx = db.transaction(() => {
    const update = db.prepare("UPDATE media_files SET status='deleted',deleted_at=?,reviewed_at=? WHERE id=?");
    files.forEach(file => update.run(deletedAt, deletedAt, file.id));
    const updateUser = db.prepare('UPDATE users SET storage_bytes=MAX(0,storage_bytes-?) WHERE id=?');
    perUser.forEach((size, userId) => updateUser.run(size, userId));
  });
  tx();
  let physicalDeleted = 0; files.forEach(file => { if (removeStoredFile(file.storage_key)) physicalDeleted += 1; });
  logAudit({ action: 'ORPHAN_FILES_AUTO_CLEANED', entityType: 'media_file', details: { count: files.length, physicalDeleted, retentionDays: settings.orphan_retention_days }, ip: 'system' });
}
const fileCleanupTimer = smsQueue.enabled?null:setInterval(() => { try { cleanupExpiredSessions();runAutomaticFileCleanup(); } catch (error) { recordSystemError({ source: 'FILE_CLEANUP_JOB', message: error.message, stack: error.stack }); } }, 6 * 60 * 60 * 1000);
if(fileCleanupTimer)fileCleanupTimer.unref();

async function distributedLimit(scope,key,limit,windowMs,memory){const identity=tokenHash(key),distributed=await redisStore.fixedWindowRateLimit(scope,identity,limit,windowMs);if(distributed)return distributed;const now=Date.now();let state=memory.get(key);if(!state||now>state.resetAt)state={count:0,resetAt:now+windowMs};state.count+=1;memory.set(key,state);return {count:state.count,remaining:Math.max(0,limit-state.count),resetMs:Math.max(0,state.resetAt-now),limited:state.count>limit,source:'memory'}}
async function clearDistributedLimit(scope,key,memory){memory.delete(key);await redisStore.resetRateLimit(scope,tokenHash(key))}
async function rateLimitLogin(req, res, next) {
  try{const ip = clientIp(req), identifier=String(req.body?.identifier||req.body?.mobile||'').trim(), normalized=normalizeMobile(identifier);
  const username=/^[A-Za-z][A-Za-z0-9._-]{2,31}$/.test(identifier)?identifier.toLowerCase():'';
  const mobile=/^09\d{9}$/.test(normalized)?normalized:(username?db.prepare('SELECT mobile FROM admins WHERE lower(username)=?').get(username)?.mobile||'':'');
  const key = `${ip}:${identifier.toLowerCase()}`, nowIso = iso();
  db.prepare("UPDATE security_blocks SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?").run(nowIso);
  const block = db.prepare(`SELECT * FROM security_blocks WHERE status='active' AND (expires_at IS NULL OR expires_at>?)
    AND ((block_type='ip' AND block_value=?) OR (block_type='mobile' AND block_value=?)) ORDER BY created_at DESC LIMIT 1`).get(nowIso, ip, mobile);
  if (block) {logAudit({ action: 'LOGIN_BLOCKED', entityType: 'security_block', entityId: block.id, details: { ip, mobile, reason: block.reason }, ip });return res.status(429).json({ error: 'دسترسی این شماره یا IP به‌صورت موقت محدود شده است.' })}
  const state=await distributedLimit('admin-login',key,7,15*60*1000,loginAttempts);req.loginRateKey=key;req.loginRateCount=state.count;
  if(state.limited){if(state.count===8)recordSecurityAlert({category:'authentication',severity:'critical',title:'احتمال حمله Brute Force به ورود مدیر',details:{ip,mobile,attempts:state.count,windowMinutes:15,source:state.source}});res.setHeader('Retry-After',String(Math.max(1,Math.ceil(state.resetMs/1000))));return res.status(429).json({error:'تعداد تلاش‌ها بیش از حد مجاز است. چند دقیقه دیگر دوباره امتحان کن.'})}
  next()}catch(error){next(error)}
}

function adminAuth(req, res, next) {
  const token = req.cookies[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'برای ادامه وارد پنل مدیریت شو.' });
  const session = db.prepare(`
    SELECT s.id AS session_id,s.csrf_token,s.expires_at,s.mfa_verified,s.auth_method,a.id,a.name,a.username,a.mobile,a.role,a.status,a.mfa_required
    FROM admin_sessions s JOIN admins a ON a.id=s.admin_id
    WHERE s.token_hash=? AND s.expires_at>? LIMIT 1
  `).get(tokenHash(token), iso());
  if (!session || session.status !== 'active') {
    res.clearCookie(COOKIE_NAME, { path: '/' });
    return res.status(401).json({ error: 'نشست مدیریت منقضی شده است.' });
  }
  req.admin = session;
  req.rawSessionToken = token;
  next();
}

function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const token = String(req.get('x-csrf-token') || '');
  if (!req.admin || !token || token !== req.admin.csrf_token) {
    return res.status(403).json({ error: 'درخواست امنیتی معتبر نیست؛ صفحه را تازه‌سازی کن.' });
  }
  next();
}

function allowRoles(...roles) {
  return (req, res, next) => roles.includes(req.admin.role)
    ? next()
    : res.status(403).json({ error: 'سطح دسترسی شما برای این عملیات کافی نیست.' });
}
function permissionsFor(role) {
  if (role === 'owner') return ['*'];
  if (!MANAGED_ROLES.includes(role)) return [];
  return db.prepare('SELECT permission FROM role_permissions WHERE role=? AND enabled=1 ORDER BY permission').all(role).map(row => row.permission);
}
function hasAdminPermission(admin, permission) { const scopes = permissionsFor(admin?.role); return scopes.includes('*') || scopes.includes(permission); }
function allowPermissions(...permissions) {
  return (req, res, next) => permissions.some(permission => hasAdminPermission(req.admin, permission))
    ? next()
    : res.status(403).json({ error: 'سطح دسترسی شما برای این عملیات کافی نیست.' });
}
function adminMfaStatus(adminId){const totp=!!db.prepare('SELECT 1 FROM admin_totp WHERE admin_id=? AND enabled=1').get(adminId),passkeys=Number(db.prepare('SELECT COUNT(*) count FROM admin_passkeys WHERE admin_id=?').get(adminId).count),recoveryCodes=Number(db.prepare('SELECT COUNT(*) count FROM admin_recovery_codes WHERE admin_id=? AND used_at IS NULL').get(adminId).count);return {totp,passkeys,recoveryCodes,enabled:totp||passkeys>0}}
function adminNeedsMfa(admin){return admin?.role==='owner'||!!admin?.mfa_required}
function adminPayload(admin) { return { id: admin.id, name: admin.name, username: admin.username, mobile: admin.mobile, role: admin.role, permissions: permissionsFor(admin.role),mfaRequired:adminNeedsMfa(admin),mfa:adminMfaStatus(admin.id) }; }


const userLoginAttempts = new Map();
const JOURNAL_SECTION_DEFINITIONS=[['dashboard','داشبورد'],['new','ثبت معامله جدید'],['history','تاریخچه معاملات'],['calendar','تقویم و Heatmap'],['prop','قوانین پراپ‌فرم'],['risk','ریسک و بینش هوشمند'],['checklist','چک‌لیست معاملاتی'],['documents','مستندات و گالری'],['import','ورود CSV / MetaTrader'],['settings','حساب‌ها و تنظیمات'],['pwa','اپ همراه']];
const JOURNAL_SECTION_KEYS=new Set(JOURNAL_SECTION_DEFINITIONS.map(item=>item[0]));
function journalAccessForUser(userId){
  const now=iso(),latest=db.prepare(`SELECT s.id AS subscription_id,s.status,s.started_at,s.expires_at,s.auto_renew,p.* FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.user_id=? ORDER BY CASE s.status WHEN 'active' THEN 0 WHEN 'trial' THEN 1 WHEN 'cancelled' THEN 2 ELSE 3 END,s.started_at DESC LIMIT 1`).get(userId),eligible=latest&&(['active','trial'].includes(latest.status)||(latest.status==='cancelled'&&latest.expires_at&&latest.expires_at>now))&&(!latest.expires_at||latest.expires_at>now),plan=eligible?latest:(db.prepare("SELECT * FROM plans WHERE name='expired' LIMIT 1").get()||db.prepare("SELECT * FROM plans WHERE name='free' LIMIT 1").get())||null;
  const rows=plan?db.prepare('SELECT section_key,is_enabled,sort_order FROM plan_journal_sections WHERE plan_id=? ORDER BY sort_order,section_key').all(plan.id):[],configured=new Map(rows.map(row=>[row.section_key,!!row.is_enabled])),sections=JOURNAL_SECTION_DEFINITIONS.map(([key,label],index)=>({key,label,enabled:configured.has(key)?configured.get(key):key==='dashboard',sortOrder:Number(rows.find(row=>row.section_key===key)?.sort_order||((index+1)*10))})),expiresAt=eligible?latest.expires_at:null,remainingDays=expiresAt?Math.max(0,Math.ceil((new Date(expiresAt).getTime()-Date.now())/86400000)):null;
  return {plan:plan?{id:plan.id,name:plan.name,nameFa:plan.name_fa,durationDays:Number(plan.duration_days||0)}:null,subscription:latest?{id:latest.subscription_id,status:eligible?latest.status:'expired',startedAt:latest.started_at,expiresAt:latest.expires_at,autoRenew:!!latest.auto_renew,effective:!!eligible}:null,expiresAt,remainingDays,sections,allowedSections:sections.filter(item=>item.enabled).map(item=>item.key)};
}
function requireJournalSection(section){return (req,res,next)=>{const access=journalAccessForUser(req.user.id);if(access.allowedSections.includes(section)){req.journalAccess=access;return next()}return res.status(403).json({error:'این بخش در پلن فعلی شما فعال نیست.',code:'PLAN_SECTION_UNAVAILABLE',section,access})}}
function journalStorageWriteAccess(req,res,next){const key=journalKey(req.params.key),section=key&&(key==='pa-trade-documents-v1'||key.startsWith('pa-chart-'))?'documents':key&&(key==='pa-accounts'||key==='pa-trades')?'new':'settings';return requireJournalSection(section)(req,res,next)}
function logUserActivity({ userId=null,action,entityType=null,entityId=null,details=null,ip=null }) {
  db.prepare('INSERT INTO user_activity_logs (id,user_id,action,entity_type,entity_id,details,ip,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(id('uact'),userId,action,entityType,entityId,details?JSON.stringify(details):null,ip,iso());
}
function userPayload(user) {
  const subscription=db.prepare(`SELECT s.status,s.expires_at,s.auto_renew,p.id AS plan_id,p.name,p.name_fa,p.max_trades,p.max_storage_bytes,p.max_sms_monthly,p.duration_days
    FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.user_id=? ORDER BY CASE s.status WHEN 'active' THEN 0 WHEN 'trial' THEN 1 ELSE 2 END,s.started_at DESC LIMIT 1`).get(user.id),entitlements=journalAccessForUser(user.id);
  return {id:user.id,name:user.name,mobile:user.mobile,mobileVerified:!!user.mobile_verified_at,status:user.status,accessMode:user.access_mode,limitedUntil:user.limited_until,securityLevel:user.security_level,require2fa:!!user.require_2fa,createdAt:user.created_at,lastSeenAt:user.last_seen_at,storageBytes:Number(user.storage_bytes||0),tradesCount:Number(user.trades_count||0),subscription:subscription||null,entitlements};
}
async function rateLimitUserLogin(req,res,next){try{const identifier=normalizeMobile(req.body?.mobile||req.body?.identifier),ip=clientIp(req),key=`${ip}:${identifier}`,state=await distributedLimit('user-login',key,8,15*60*1000,userLoginAttempts);req.userLoginRateKey=key;req.userLoginRateCount=state.count;if(state.limited){if(state.count===9)recordSecurityAlert({category:'authentication',severity:'warning',title:'تلاش پرتکرار ورود کاربر',details:{ip,mobile:identifier,attempts:state.count,source:state.source}});res.setHeader('Retry-After',String(Math.max(1,Math.ceil(state.resetMs/1000))));return res.status(429).json({error:'تعداد تلاش‌ها بیش از حد مجاز است؛ کمی بعد دوباره امتحان کن.'})}next()}catch(error){next(error)}}
function trustedDevice(req,user){const device=currentDevice(req);if(!device)return null;return db.prepare("SELECT * FROM user_trusted_devices WHERE user_id=? AND device_hash=? AND status='active' AND trusted_until>?").get(user.id,device.hash,iso())||null}
function trustCurrentDevice(req,res,user){const settings=authSecuritySettings(),meta=requestMeta(req),current=currentDevice(req),raw=current?.raw||secureToken(32),hash=deviceHash(raw),now=iso(),until=new Date(Date.now()+Number(settings.trusted_device_days||30)*86400000).toISOString(),existing=db.prepare('SELECT * FROM user_trusted_devices WHERE user_id=? AND device_hash=?').get(user.id,hash),deviceId=existing?.id||id('udev');if(existing)db.prepare("UPDATE user_trusted_devices SET label=?,user_agent=?,last_ip=?,trusted_at=?,trusted_until=?,last_seen_at=?,status='active',revoked_at=NULL WHERE id=?").run(deviceLabel(meta.userAgent),meta.userAgent,meta.ip,now,until,now,deviceId);else db.prepare(`INSERT INTO user_trusted_devices (id,user_id,device_hash,label,user_agent,first_ip,last_ip,trusted_at,trusted_until,last_seen_at,status) VALUES (?,?,?,?,?,?,?,?,?,?,'active')`).run(deviceId,user.id,hash,deviceLabel(meta.userAgent),meta.userAgent,meta.ip,meta.ip,now,until,now);setDeviceCookie(res,raw);const active=db.prepare("SELECT id FROM user_trusted_devices WHERE user_id=? AND status='active' ORDER BY last_seen_at DESC").all(user.id),overflow=active.slice(Number(settings.max_devices||5));overflow.forEach(item=>{db.prepare("UPDATE user_trusted_devices SET status='revoked',revoked_at=? WHERE id=?").run(now,item.id);db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND device_id=? AND revoked_at IS NULL').run(now,user.id,item.id)});return db.prepare('SELECT * FROM user_trusted_devices WHERE id=?').get(deviceId)}
function issueUserSession(req,res,user,remember=true,authMethod='password',mfaVerified=false){
  const rawToken=secureToken(36),csrfToken=secureToken(24),now=iso(),expiresAt=new Date(Date.now()+(remember?USER_SESSION_DAYS*86400000:12*3600000)).toISOString(),meta=requestMeta(req),sessionId=id('uses'),device=trustCurrentDevice(req,res,user);
  db.prepare(`INSERT INTO user_sessions (id,user_id,token_hash,csrf_token,device,ip,user_agent,device_id,auth_method,mfa_verified,created_at,last_seen_at,expires_at,revoked_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)`).run(sessionId,user.id,tokenHash(rawToken),csrfToken,device.label,meta.ip,meta.userAgent,device.id,authMethod,mfaVerified?1:0,now,now,expiresAt);
  db.prepare('UPDATE users SET last_seen_at=?,last_login_at=?,last_login_ip=?,failed_login_count=0,updated_at=COALESCE(updated_at,?) WHERE id=?').run(now,now,meta.ip,now,user.id);
  redisStore.sessionSet('user',tokenHash(rawToken),{sessionId,userId:user.id,expiresAt},Math.ceil((new Date(expiresAt).getTime()-Date.now())/1000));
  res.cookie(USER_COOKIE_NAME,rawToken,{httpOnly:true,secure:COOKIE_SECURE,sameSite:'strict',path:'/',maxAge:remember?USER_SESSION_DAYS*86400000:undefined});
  return {csrfToken,sessionId,expiresAt,device:{id:device.id,label:device.label},authMethod,mfaVerified:!!mfaVerified};
}
function userAuth(req,res,next){
  const rawToken=req.cookies[USER_COOKIE_NAME];if(!rawToken)return res.status(401).json({error:'برای ادامه وارد حساب ژورنال شو.'});
  const row=db.prepare(`SELECT u.*,s.id AS session_id,s.csrf_token,s.expires_at,s.revoked_at,s.device_id,s.mfa_verified,s.auth_method FROM user_sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>? AND u.deleted_at IS NULL LIMIT 1`).get(tokenHash(rawToken),iso());
  if(!row||row.status!=='active'){res.clearCookie(USER_COOKIE_NAME,{path:'/'});return res.status(401).json({error:row&&row.status==='suspended'?'حساب کاربری شما تعلیق شده است.':'نشست ژورنال منقضی شده است.'})}
  const now=iso();if(row.access_mode==='limited'&&row.limited_until&&row.limited_until<=now){db.prepare("UPDATE users SET access_mode='normal',limited_until=NULL,restriction_reason=NULL,updated_at=? WHERE id=?").run(now,row.id);row.access_mode='normal';row.limited_until=null;row.restriction_reason=null}
  req.user=row;req.userSessionId=row.session_id;req.rawUserSessionToken=rawToken;
  db.prepare('UPDATE user_sessions SET last_seen_at=? WHERE id=?').run(now,row.session_id);db.prepare('UPDATE users SET last_seen_at=? WHERE id=?').run(now,row.id);next();
}
function userCsrf(req,res,next){if(['GET','HEAD','OPTIONS'].includes(req.method))return next();const token=String(req.get('x-csrf-token')||'');if(!req.user||!token||token!==req.user.csrf_token)return res.status(403).json({error:'درخواست امنیتی معتبر نیست؛ صفحه را تازه‌سازی کن.'});next()}
function journalWriteGuard(req,res,next){if(req.user.access_mode==='limited'&&(!req.user.limited_until||req.user.limited_until>iso()))return res.status(403).json({error:req.user.restriction_reason||'دسترسی نوشتن این حساب موقتاً محدود شده است.'});next()}

app.get('/api/auth/security-config',(req,res)=>{const settings=authSecuritySettings(),legal={};for(const type of LEGAL_TYPES){const document=currentLegalDocument(type);if(document)legal[type]=legalDocumentSummary(document)}res.json({turnstileSiteKey:settings.turnstile_site_key||process.env.TURNSTILE_SITE_KEY||null,captchaConfigured:!!(settings.turnstile_secret_encrypted||process.env.TURNSTILE_SECRET_KEY),policy:{maxDevices:Number(settings.max_devices),trustedDeviceDays:Number(settings.trusted_device_days),otpTtlSeconds:Number(settings.otp_ttl_seconds),newDeviceOtp:!!settings.new_device_otp},legal})});
app.post('/api/auth/signup',rateLimitUserLogin,async(req,res,next)=>{try{const settings=db.prepare("SELECT signup_enabled FROM system_settings WHERE id='default'").get();if(!settings?.signup_enabled)return res.status(403).json({error:'ثبت‌نام جدید در حال حاضر غیرفعال است.'});const name=String(req.body.name||'').trim(),mobile=normalizeMobile(req.body.mobile),password=String(req.body.password||''),remember=req.body.remember!==false;if(name.length<2||name.length>100)return res.status(400).json({error:'نام باید بین ۲ تا ۱۰۰ کاراکتر باشد.'});if(!/^09\d{9}$/.test(mobile))return res.status(400).json({error:'شماره موبایل معتبر نیست.'});if(password.length<8||password.length>128||!/[A-Za-z\u0600-\u06ff]/.test(password)||!/[0-9]/.test(password))return res.status(400).json({error:'رمز باید حداقل ۸ کاراکتر و شامل حرف و عدد باشد.'});if(db.prepare('SELECT 1 FROM users WHERE mobile=? AND deleted_at IS NULL').get(mobile))return res.status(409).json({error:'برای این شماره موبایل قبلاً حساب ساخته شده است.'});const legalDocuments=requiredSignupDocuments();if(req.body.acceptTerms!==true||req.body.acceptPrivacy!==true||req.body.acceptDisclaimer!==true)return res.status(400).json({error:'پذیرش جداگانه قوانین، حریم خصوصی و سلب مسئولیت مالی برای ساخت حساب لازم است.',legalRequired:true,documents:legalDocuments.map(legalDocumentSummary)});const legalAcceptances=legalDocuments.map(document=>({type:document.document_type,version:document.version,sha256:document.content_sha256})),marketingConsent=req.body.marketingConsent===true;const requiresCaptcha=captchaConfigured()&&Number(req.userLoginRateCount||0)>Number(authSecuritySettings().captcha_failure_threshold||3);if(requiresCaptcha&&!await verifyTurnstile(req.body.captchaToken,clientIp(req)))return res.status(428).json({error:'تأیید امنیتی لازم است.',captchaRequired:true});const passwordHash=await bcryptPool.hash(password,12),challenge=await createOtpChallenge(req,{mobile,purpose:'signup',payload:{name,passwordHash,legalAcceptances,marketingConsent,marketingPolicyVersion:legalDocuments.find(document=>document.document_type==='privacy').version},remember,captchaVerified:!requiresCaptcha||!!req.body.captchaToken});res.status(202).json({ok:true,verificationRequired:true,purpose:'signup',maskedMobile:`${mobile.slice(0,4)}***${mobile.slice(-4)}`,...challenge})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,captchaRequired:error.status===428});next(error)}});
app.post('/api/auth/signup/verify',async(req,res,next)=>{try{const challenge=consumeOtp(req.body.challengeToken,req.body.code,'signup'),name=String(challenge.payload?.name||'').trim(),mobile=challenge.mobile,passwordHash=challenge.payload?.passwordHash,legalAcceptances=Array.isArray(challenge.payload?.legalAcceptances)?challenge.payload.legalAcceptances:[];if(!name||!passwordHash||legalAcceptances.length!==3)return res.status(400).json({error:'اطلاعات یا پذیرش‌های ثبت‌نام ناقص است.'});for(const acceptance of legalAcceptances){const valid=db.prepare('SELECT 1 FROM legal_documents WHERE document_type=? AND version=? AND content_sha256=?').get(acceptance.type,acceptance.version,acceptance.sha256);if(!valid)return res.status(409).json({error:'نسخه سند حقوقی ثبت‌نام معتبر نیست؛ فرایند را دوباره آغاز کنید.'})}if(db.prepare('SELECT 1 FROM users WHERE mobile=? AND deleted_at IS NULL').get(mobile))return res.status(409).json({error:'حساب قبلاً ساخته شده است.'});const userId=id('usr'),now=iso();db.transaction(()=>{db.prepare(`INSERT INTO users (id,name,mobile,password_hash,status,created_at,updated_at,last_seen_at,mobile_verified_at,require_2fa) VALUES (?,?,?,?,'active',?,?,?,?,0)`).run(userId,name,mobile,passwordHash,now,now,now,now);const free=db.prepare("SELECT id,duration_days FROM plans WHERE name='free' LIMIT 1").get();if(free){const freeExpires=Number(free.duration_days||0)>0?new Date(Date.now()+Number(free.duration_days)*86400000).toISOString():null;db.prepare(`INSERT INTO subscriptions (id,user_id,plan_id,status,started_at,expires_at,auto_renew,coupon_id,discount_amount,updated_at) VALUES (?,?,?,'active',?,?,0,NULL,0,?)`).run(id('sub'),userId,free.id,now,freeExpires,now)};const accept=db.prepare(`INSERT INTO user_legal_acceptances (id,user_id,document_type,document_version,document_sha256,accepted_at,acceptance_method,ip,user_agent) VALUES (?,?,?,?,?,?,'signup_checkbox',?,?)`);for(const acceptance of legalAcceptances)accept.run(id('lacc'),userId,acceptance.type,acceptance.version,acceptance.sha256,now,clientIp(req),String(req.get('user-agent')||'').slice(0,500))})();syncUserContacts();const contact=db.prepare('SELECT id FROM user_contacts WHERE user_id=?').get(userId);recordMarketingConsent({userId,contactId:contact?.id||null,mobile,granted:challenge.payload?.marketingConsent===true,policyVersion:String(challenge.payload?.marketingPolicyVersion||'1.0.0'),source:'signup_checkbox',ip:clientIp(req),userAgent:req.get('user-agent')});const user=db.prepare('SELECT * FROM users WHERE id=?').get(userId),session=issueUserSession(req,res,user,!!challenge.remember,'signup_otp',true);logUserActivity({userId,action:'USER_REGISTERED_VERIFIED',entityType:'user',entityId:userId,details:{mobile,deviceId:session.device.id},ip:clientIp(req)});recordUserSecurityEvent({userId,eventType:'mobile_verified',title:'شماره موبایل تأیید شد',ip:clientIp(req),deviceId:session.device.id});res.status(201).json({ok:true,user:userPayload(user),csrfToken:session.csrfToken,session})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
/* ورود با «شماره + رمزِ درست» پیامک نمی‌خواهد. کد پیامکی فقط برای ثبت‌نام،
   ورود با کد یک‌بارمصرف و بازیابی رمز است — به‌علاوه‌ی حالت‌های انتخابی:
   کاربری که خودش ۲FA را روشن کرده، حساب حساس، یا وقتی مدیر گزینه‌ی
   «OTP برای دستگاه جدید» را در پنل فعال کند (پیش‌فرض: خاموش). */
app.post('/api/auth/login',rateLimitUserLogin,async(req,res,next)=>{try{const mobile=normalizeMobile(req.body.mobile||req.body.identifier),password=String(req.body.password||''),remember=req.body.remember!==false;if(!/^09\d{9}$/.test(mobile)||password.length<8||password.length>128)return res.status(400).json({error:'شماره موبایل یا رمز عبور معتبر نیست.'});const user=db.prepare('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL LIMIT 1').get(mobile),captchaRequired=(captchaConfigured()&&captchaRequiredFor(mobile));if(captchaRequired&&!await verifyTurnstile(req.body.captchaToken,clientIp(req)))return res.status(428).json({error:'پس از چند تلاش ناموفق، تأیید CAPTCHA لازم است.',captchaRequired:true});const valid=await (async()=>{const hash=user&&user.password_hash||DUMMY_PASSWORD_HASH;const match=await bcryptPool.compare(password,hash);return !!(user&&user.password_hash&&match)})();if(!valid){if(user)db.prepare('UPDATE users SET failed_login_count=failed_login_count+1 WHERE id=?').run(user.id);logUserActivity({userId:user?.id||null,action:'USER_LOGIN_FAILED',entityType:'user',entityId:user?.id||null,details:{mobile},ip:clientIp(req)});recordUserSecurityEvent({userId:user?.id||null,eventType:'login_failed',severity:'warning',title:'تلاش ورود ناموفق',details:{mobile},ip:clientIp(req)});await new Promise(resolve=>setTimeout(resolve,220));return res.status(401).json({error:'شماره موبایل یا رمز عبور صحیح نیست.',captchaRequired:user?Number(user.failed_login_count||0)+1>=Number(authSecuritySettings().captcha_failure_threshold||3):false})}if(user.status!=='active')return res.status(403).json({error:'حساب کاربری شما فعال نیست.'});await clearDistributedLimit('user-login',req.userLoginRateKey,userLoginAttempts);const trusted=trustedDevice(req,user),settings=authSecuritySettings(),newDevice=!trusted,ipChanged=trusted&&trusted.last_ip!==clientIp(req),requiresOtp=!user.mobile_verified_at||!!user.require_2fa||user.security_level==='sensitive'||(!!settings.new_device_otp&&newDevice);if(requiresOtp){const reason=newDevice?'new_device':!user.mobile_verified_at?'unverified_mobile':ipChanged?'ip_change':'two_factor',challenge=await createOtpChallenge(req,{user,mobile,purpose:'login',payload:{reason},remember,captchaVerified:!captchaRequired||!!req.body.captchaToken});recordUserSecurityEvent({userId:user.id,eventType:newDevice?'new_device_challenge':'login_2fa_challenge',severity:newDevice?'warning':'info',title:newDevice?'ورود از دستگاه جدید':'تأیید دومرحله‌ای ورود',details:{ipChanged},ip:clientIp(req),deviceId:trusted?.id||null});return res.status(202).json({ok:true,mfaRequired:true,method:'sms_otp',reason,...challenge})}const session=issueUserSession(req,res,user,remember,'password',false);logUserActivity({userId:user.id,action:'USER_LOGIN_SUCCESS',entityType:'user',entityId:user.id,details:{sessionId:session.sessionId,deviceId:session.device.id,newDevice,ipChanged},ip:clientIp(req)});if(newDevice||ipChanged){recordUserSecurityEvent({userId:user.id,eventType:newDevice?'new_device_login':'new_ip_login',severity:'warning',title:newDevice?'ورود از دستگاه جدید':'ورود از IP جدید',details:{device:session.device.label,ipChanged},ip:clientIp(req),deviceId:session.device.id});if(authSecuritySettings().notify_new_login)sendSms({userId:user.id,mobile:user.mobile,type:'security',message:`ورود جدید به SmartJournal از ${session.device.label} در ${new Date().toLocaleString('fa-IR')}`,ip:clientIp(req)}).catch(()=>{})}res.json({ok:true,user:userPayload({...user,last_seen_at:iso()}),csrfToken:session.csrfToken,session})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/login/verify',async(req,res,next)=>{try{const challenge=consumeOtp(req.body.challengeToken,req.body.code,'login'),user=db.prepare('SELECT * FROM users WHERE id=? AND status=\'active\' AND deleted_at IS NULL').get(challenge.user_id);if(!user)return res.status(403).json({error:'حساب کاربری فعال نیست.'});const wasNew=!trustedDevice(req,user),session=issueUserSession(req,res,user,!!challenge.remember,'password+sms',true),now=iso();if(!user.mobile_verified_at)db.prepare('UPDATE users SET mobile_verified_at=?,updated_at=? WHERE id=?').run(now,now,user.id);logUserActivity({userId:user.id,action:'USER_LOGIN_2FA_SUCCESS',entityType:'user',entityId:user.id,details:{deviceId:session.device.id},ip:clientIp(req)});recordUserSecurityEvent({userId:user.id,eventType:wasNew?'new_device_login':'two_factor_login',severity:wasNew?'warning':'info',title:wasNew?'ورود موفق از دستگاه جدید':'ورود دومرحله‌ای موفق',details:{device:session.device.label},ip:clientIp(req),deviceId:session.device.id});if(authSecuritySettings().notify_new_login)sendSms({userId:user.id,mobile:user.mobile,type:'security',message:`ورود جدید به SmartJournal از ${session.device.label} در ${new Date().toLocaleString('fa-IR')}`,ip:clientIp(req)}).catch(()=>{});res.json({ok:true,user:userPayload({...user,mobile_verified_at:user.mobile_verified_at||now}),csrfToken:session.csrfToken,session})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/otp/request',rateLimitUserLogin,async(req,res,next)=>{try{const mobile=normalizeMobile(req.body.mobile),user=db.prepare("SELECT * FROM users WHERE mobile=? AND status='active' AND deleted_at IS NULL").get(mobile),captchaRequired=(captchaConfigured()&&captchaRequiredFor(mobile));if(captchaRequired&&!await verifyTurnstile(req.body.captchaToken,clientIp(req)))return res.status(428).json({error:'تأیید امنیتی لازم است.',captchaRequired:true});if(!user)return res.status(202).json({ok:true,message:'اگر حسابی برای این شماره وجود داشته باشد، کد ارسال می‌شود.'});const challenge=await createOtpChallenge(req,{user,mobile,purpose:'passwordless',remember:req.body.remember!==false,captchaVerified:!captchaRequired||!!req.body.captchaToken});res.status(202).json({ok:true,verificationRequired:true,purpose:'passwordless',...challenge})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/otp/verify',async(req,res,next)=>{try{const challenge=consumeOtp(req.body.challengeToken,req.body.code,'passwordless'),user=db.prepare("SELECT * FROM users WHERE id=? AND status='active' AND deleted_at IS NULL").get(challenge.user_id);if(!user)return res.status(403).json({error:'حساب فعال نیست.'});const session=issueUserSession(req,res,user,!!challenge.remember,'sms_otp',true);if(!user.mobile_verified_at)db.prepare('UPDATE users SET mobile_verified_at=?,updated_at=? WHERE id=?').run(iso(),iso(),user.id);logUserActivity({userId:user.id,action:'USER_PASSWORDLESS_LOGIN',entityType:'user',entityId:user.id,details:{deviceId:session.device.id},ip:clientIp(req)});res.json({ok:true,user:userPayload({...user,mobile_verified_at:user.mobile_verified_at||iso()}),csrfToken:session.csrfToken,session})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/recovery/request',rateLimitUserLogin,async(req,res,next)=>{try{const mobile=normalizeMobile(req.body.mobile),user=db.prepare('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL').get(mobile),captchaRequired=(captchaConfigured()&&captchaRequiredFor(mobile));if(captchaRequired&&!await verifyTurnstile(req.body.captchaToken,clientIp(req)))return res.status(428).json({error:'تأیید امنیتی لازم است.',captchaRequired:true});if(!user)return res.status(202).json({ok:true,message:'اگر حساب موجود باشد، کد بازیابی ارسال می‌شود.'});const challenge=await createOtpChallenge(req,{user,mobile,purpose:'recovery',remember:false,captchaVerified:!captchaRequired||!!req.body.captchaToken});recordUserSecurityEvent({userId:user.id,eventType:'recovery_requested',severity:'warning',title:'درخواست بازیابی حساب',ip:clientIp(req)});res.status(202).json({ok:true,verificationRequired:true,purpose:'recovery',...challenge})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/recovery/verify',(req,res,next)=>{try{const challenge=consumeOtp(req.body.challengeToken,req.body.code,'recovery'),rawToken=secureToken(32),now=iso(),expiresAt=new Date(Date.now()+15*60000).toISOString();db.prepare("UPDATE account_recovery_requests SET status='cancelled' WHERE user_id=? AND status='pending'").run(challenge.user_id);db.prepare(`INSERT INTO account_recovery_requests (id,user_id,token_hash,status,created_at,expires_at) VALUES (?,?,?,'pending',?,?)`).run(id('rec'),challenge.user_id,tokenHash(rawToken),now,expiresAt);res.json({ok:true,resetToken:rawToken,expiresAt})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/recovery/reset',async(req,res,next)=>{try{const token=db.prepare("SELECT * FROM account_recovery_requests WHERE token_hash=? AND status='pending' AND expires_at>?").get(tokenHash(String(req.body.resetToken||'')),iso()),password=String(req.body.newPassword||'');if(!token)return res.status(400).json({error:'توکن بازیابی نامعتبر یا منقضی است.'});if(password.length<8||password.length>128||!/[A-Za-z\u0600-\u06ff]/.test(password)||!/[0-9]/.test(password))return res.status(400).json({error:'رمز جدید باید حداقل ۸ کاراکتر و شامل حرف و عدد باشد.'});const hash=await bcryptPool.hash(password,12),now=iso();db.transaction(()=>{db.prepare('UPDATE users SET password_hash=?,failed_login_count=0,updated_at=? WHERE id=?').run(hash,now,token.user_id);db.prepare('UPDATE account_recovery_requests SET status=\'completed\',completed_at=? WHERE id=?').run(now,token.id);db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(now,token.user_id);db.prepare("UPDATE user_trusted_devices SET status='revoked',revoked_at=? WHERE user_id=? AND status='active'").run(now,token.user_id)})();recordUserSecurityEvent({userId:token.user_id,eventType:'account_recovered',severity:'critical',title:'رمز حساب بازیابی شد',ip:clientIp(req)});res.json({ok:true})}catch(error){next(error)}});
app.use('/api/auth/me',userAuth);
app.get('/api/auth/me',(req,res)=>{res.setHeader('Cache-Control','no-store');res.json({user:userPayload(req.user),csrfToken:req.user.csrf_token,session:{id:req.userSessionId,expiresAt:req.user.expires_at}})});
app.post('/api/auth/logout',userAuth,userCsrf,(req,res)=>{db.prepare('UPDATE user_sessions SET revoked_at=? WHERE id=?').run(iso(),req.userSessionId);redisStore.sessionDelete('user',tokenHash(req.rawUserSessionToken));logUserActivity({userId:req.user.id,action:'USER_LOGOUT',entityType:'user_session',entityId:req.userSessionId,ip:clientIp(req)});res.clearCookie(USER_COOKIE_NAME,{path:'/'});res.json({ok:true})});
app.post('/api/auth/logout-all',userAuth,userCsrf,(req,res)=>{db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(iso(),req.user.id);logUserActivity({userId:req.user.id,action:'USER_LOGOUT_ALL',entityType:'user',entityId:req.user.id,ip:clientIp(req)});res.clearCookie(USER_COOKIE_NAME,{path:'/'});res.json({ok:true})});
app.get('/api/auth/sessions',userAuth,(req,res)=>{res.setHeader('Cache-Control','no-store');const rows=db.prepare('SELECT id,device,device_id,ip,auth_method,mfa_verified,created_at,last_seen_at,expires_at FROM user_sessions WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY last_seen_at DESC').all(req.user.id,iso()).map(row=>({...row,current:row.id===req.userSessionId,mfa_verified:!!row.mfa_verified}));res.json({rows})});
app.get('/api/auth/devices',userAuth,(req,res)=>{res.setHeader('Cache-Control','no-store');const settings=authSecuritySettings(),rows=db.prepare("SELECT d.*,(SELECT COUNT(*) FROM user_sessions s WHERE s.device_id=d.id AND s.revoked_at IS NULL AND s.expires_at>?) active_sessions FROM user_trusted_devices d WHERE d.user_id=? AND d.status='active' ORDER BY d.last_seen_at DESC").all(iso(),req.user.id).map(row=>({...row,current:row.id===req.user.device_id,device_hash:undefined,user_agent:undefined}));res.json({rows,policy:{maxDevices:Number(settings.max_devices),trustedDeviceDays:Number(settings.trusted_device_days)}})});
app.patch('/api/auth/devices/:id',userAuth,userCsrf,(req,res)=>{const label=String(req.body.label||'').trim();if(label.length<2||label.length>80)return res.status(400).json({error:'نام دستگاه باید بین ۲ تا ۸۰ کاراکتر باشد.'});const result=db.prepare("UPDATE user_trusted_devices SET label=?,last_seen_at=? WHERE id=? AND user_id=? AND status='active'").run(label,iso(),req.params.id,req.user.id);if(!result.changes)return res.status(404).json({error:'دستگاه پیدا نشد.'});db.prepare('UPDATE user_sessions SET device=? WHERE device_id=? AND user_id=?').run(label,req.params.id,req.user.id);res.json({ok:true})});
app.delete('/api/auth/devices/:id',userAuth,userCsrf,(req,res)=>{const device=db.prepare("SELECT id FROM user_trusted_devices WHERE id=? AND user_id=? AND status='active'").get(req.params.id,req.user.id);if(!device)return res.status(404).json({error:'دستگاه پیدا نشد.'});const now=iso();db.transaction(()=>{db.prepare("UPDATE user_trusted_devices SET status='revoked',revoked_at=? WHERE id=?").run(now,device.id);db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND device_id=? AND revoked_at IS NULL').run(now,req.user.id,device.id)})();recordUserSecurityEvent({userId:req.user.id,eventType:'device_revoked',severity:'warning',title:'دسترسی یک دستگاه لغو شد',details:{deviceId:device.id},ip:clientIp(req),deviceId:device.id});if(req.user.device_id===device.id){res.clearCookie(USER_COOKIE_NAME,{path:'/'});res.clearCookie(USER_DEVICE_COOKIE,{path:'/'})}res.json({ok:true,current:req.user.device_id===device.id})});
app.get('/api/auth/security-events',userAuth,(req,res)=>{const rows=db.prepare('SELECT id,event_type,severity,title,details,ip,device_id,created_at,notified_at FROM user_security_events WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(req.user.id).map(row=>({...row,details:jsonDetails(row.details)}));res.json({rows})});
app.get('/api/auth/privacy-center',userAuth,(req,res)=>{const documents={},acceptances=db.prepare('SELECT document_type,document_version,document_sha256,accepted_at,acceptance_method FROM user_legal_acceptances WHERE user_id=? ORDER BY accepted_at DESC').all(req.user.id);for(const type of LEGAL_TYPES){const document=currentLegalDocument(type);if(document)documents[type]=legalDocumentSummary(document)}const marketing=db.prepare("SELECT granted,policy_version,source,occurred_at FROM marketing_consent_events WHERE user_id=? AND channel='sms' AND purpose='marketing' ORDER BY occurred_at DESC LIMIT 1").get(req.user.id)||{granted:0,policy_version:documents.privacy?.version||'1.0.0',source:null,occurred_at:null},requests=db.prepare('SELECT id,request_type,status,requested_at,due_at,completed_at,cancelled_at,rejection_reason,result_summary,updated_at FROM privacy_requests WHERE user_id=? ORDER BY requested_at DESC LIMIT 30').all(req.user.id);res.setHeader('Cache-Control','no-store');res.json({documents,acceptances,marketing:{...marketing,granted:!!marketing.granted},requests,deletionRequestedAt:req.user.deletion_requested_at||null,retention:{operationalDeletionDays:30,backupMaximumDays:90,securityLogMonths:12}})});
app.post('/api/auth/privacy/marketing-consent',userAuth,userCsrf,(req,res)=>{const granted=req.body.granted===true,privacy=currentLegalDocument('privacy');if(!privacy)return res.status(503).json({error:'نسخه فعال سیاست حریم خصوصی در دسترس نیست.'});const contact=db.prepare('SELECT id FROM user_contacts WHERE user_id=?').get(req.user.id),occurredAt=recordMarketingConsent({userId:req.user.id,contactId:contact?.id||null,mobile:req.user.mobile,granted,policyVersion:privacy.version,source:'privacy_center',ip:clientIp(req),userAgent:req.get('user-agent')});logUserActivity({userId:req.user.id,action:granted?'MARKETING_SMS_CONSENT_GRANTED':'MARKETING_SMS_CONSENT_WITHDRAWN',entityType:'marketing_consent',details:{channel:'sms',policyVersion:privacy.version},ip:clientIp(req)});res.json({ok:true,granted,policyVersion:privacy.version,occurredAt})});
app.post('/api/auth/privacy/export',userAuth,userCsrf,async(req,res,next)=>{try{const password=String(req.body.currentPassword||''),current=db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);if(!current?.password_hash||!await bcryptPool.compare(password,current.password_hash))return res.status(400).json({error:'برای دریافت نسخه داده، رمز فعلی را صحیح وارد کنید.'});const now=iso(),requestId=id('privacy'),dueAt=new Date(Date.now()+30*86400000).toISOString();db.prepare(`INSERT INTO privacy_requests (id,user_id,request_type,status,requested_at,due_at,completed_at,result_summary,request_ip,updated_at) VALUES (?,?,'access_export','completed',?,?,?,?,?,?)`).run(requestId,req.user.id,now,dueAt,now,'نسخه JSON در همان درخواست تحویل شد.',clientIp(req),now);const user=db.prepare('SELECT id,name,mobile,status,created_at,updated_at,last_seen_at,mobile_verified_at,require_2fa,security_level,storage_bytes,trades_count,deletion_requested_at FROM users WHERE id=?').get(req.user.id),exportData={format:'SMARTJOURNAL-USER-EXPORT-1',generatedAt:now,requestId,user,contact:db.prepare('SELECT name,mobile,tags,note,sms_consent,sms_consent_at,sms_consent_version,sms_consent_source,sms_consent_revoked_at,created_at,updated_at FROM user_contacts WHERE user_id=?').get(req.user.id)||null,subscriptions:db.prepare('SELECT s.*,p.name plan_name,p.name_fa plan_name_fa FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.user_id=? ORDER BY s.started_at').all(req.user.id),payments:db.prepare('SELECT id,subscription_id,amount,discount_amount,refunded_amount,currency,status,provider,tracking_code,invoice_number,created_at,paid_at,refunded_at FROM payments WHERE user_id=? ORDER BY created_at').all(req.user.id),journal:{accounts:db.prepare('SELECT id,name,starting_balance,payload,created_at,updated_at,deleted_at FROM journal_accounts WHERE user_id=?').all(req.user.id),trades:db.prepare('SELECT id,account_id,symbol,direction,result_type,amount,entry_at,payload,created_at,updated_at,deleted_at FROM journal_trades WHERE user_id=?').all(req.user.id),preferences:db.prepare('SELECT key,value,version,created_at,updated_at FROM journal_preferences WHERE user_id=?').all(req.user.id)},media:db.prepare('SELECT id,trade_ref,original_name,mime_type,size_bytes,checksum_sha256,status,scan_status,uploaded_at,orphaned_at,deleted_at FROM media_files WHERE user_id=?').all(req.user.id),devices:db.prepare('SELECT id,label,first_ip,last_ip,trusted_at,trusted_until,last_seen_at,status,revoked_at FROM user_trusted_devices WHERE user_id=?').all(req.user.id),sessions:db.prepare('SELECT id,device,ip,auth_method,mfa_verified,created_at,last_seen_at,expires_at,revoked_at FROM user_sessions WHERE user_id=?').all(req.user.id),activity:db.prepare('SELECT action,entity_type,entity_id,details,ip,created_at FROM user_activity_logs WHERE user_id=? ORDER BY created_at').all(req.user.id).map(row=>({...row,details:jsonDetails(row.details)})),securityEvents:db.prepare('SELECT event_type,severity,title,details,ip,device_id,created_at,notified_at FROM user_security_events WHERE user_id=? ORDER BY created_at').all(req.user.id).map(row=>({...row,details:jsonDetails(row.details)})),legalAcceptances:db.prepare('SELECT document_type,document_version,document_sha256,accepted_at,acceptance_method,withdrawn_at FROM user_legal_acceptances WHERE user_id=? ORDER BY accepted_at').all(req.user.id),marketingConsentEvents:db.prepare('SELECT channel,purpose,granted,policy_version,source,occurred_at FROM marketing_consent_events WHERE user_id=? ORDER BY occurred_at').all(req.user.id),privacyRequests:db.prepare('SELECT id,request_type,status,requested_at,due_at,completed_at,cancelled_at,rejection_reason,result_summary FROM privacy_requests WHERE user_id=? ORDER BY requested_at').all(req.user.id)};logUserActivity({userId:req.user.id,action:'PRIVACY_DATA_EXPORTED',entityType:'privacy_request',entityId:requestId,ip:clientIp(req)});res.setHeader('Cache-Control','no-store');res.setHeader('Content-Disposition',`attachment; filename="smartjournal-data-${req.user.id}.json"`);res.type('application/json').send(JSON.stringify(exportData,null,2))}catch(error){next(error)}});
app.post('/api/auth/privacy/deletion-request',userAuth,userCsrf,async(req,res,next)=>{try{const password=String(req.body.currentPassword||''),current=db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);if(!current?.password_hash||!await bcryptPool.compare(password,current.password_hash))return res.status(400).json({error:'برای ثبت درخواست حذف، رمز فعلی را صحیح وارد کنید.'});const existing=db.prepare("SELECT * FROM privacy_requests WHERE user_id=? AND request_type='deletion' AND status IN ('pending','in_progress') ORDER BY requested_at DESC LIMIT 1").get(req.user.id);if(existing)return res.status(409).json({error:'درخواست حذف فعال از قبل وجود دارد.',request:existing});const now=iso(),dueAt=new Date(Date.now()+30*86400000).toISOString(),requestId=id('privacy');db.transaction(()=>{db.prepare(`INSERT INTO privacy_requests (id,user_id,request_type,status,requested_at,due_at,request_ip,updated_at) VALUES (?,?,'deletion','pending',?,?,?,?)`).run(requestId,req.user.id,now,dueAt,clientIp(req),now);db.prepare('UPDATE users SET deletion_requested_at=?,updated_at=? WHERE id=?').run(now,now,req.user.id)})();const contact=db.prepare('SELECT id FROM user_contacts WHERE user_id=?').get(req.user.id),privacy=currentLegalDocument('privacy');recordMarketingConsent({userId:req.user.id,contactId:contact?.id||null,mobile:req.user.mobile,granted:false,policyVersion:privacy?.version||'1.0.0',source:'deletion_request',ip:clientIp(req),userAgent:req.get('user-agent')});recordUserSecurityEvent({userId:req.user.id,eventType:'deletion_requested',severity:'critical',title:'درخواست حذف اطلاعات ثبت شد',details:{requestId,dueAt},ip:clientIp(req),deviceId:req.user.device_id});res.status(202).json({ok:true,requestId,requestedAt:now,dueAt,message:'درخواست ثبت شد؛ حذف یا ناشناس‌سازی عملیاتی حداکثر ظرف ۳۰ روز انجام می‌شود.'})}catch(error){next(error)}});
app.post('/api/auth/privacy/deletion-request/cancel',userAuth,userCsrf,async(req,res,next)=>{try{const password=String(req.body.currentPassword||''),current=db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);if(!current?.password_hash||!await bcryptPool.compare(password,current.password_hash))return res.status(400).json({error:'رمز فعلی صحیح نیست.'});const request=db.prepare("SELECT id FROM privacy_requests WHERE user_id=? AND request_type='deletion' AND status='pending' ORDER BY requested_at DESC LIMIT 1").get(req.user.id);if(!request)return res.status(404).json({error:'درخواست حذف قابل لغوی وجود ندارد.'});const now=iso();db.transaction(()=>{db.prepare("UPDATE privacy_requests SET status='cancelled',cancelled_at=?,updated_at=? WHERE id=?").run(now,now,request.id);db.prepare('UPDATE users SET deletion_requested_at=NULL,updated_at=? WHERE id=?').run(now,req.user.id)})();res.json({ok:true,cancelledAt:now})}catch(error){next(error)}});
app.delete('/api/auth/sessions/:id',userAuth,userCsrf,(req,res)=>{const target=db.prepare('SELECT id FROM user_sessions WHERE id=? AND user_id=? AND revoked_at IS NULL').get(req.params.id,req.user.id);if(!target)return res.status(404).json({error:'نشست پیدا نشد.'});db.prepare('UPDATE user_sessions SET revoked_at=? WHERE id=?').run(iso(),target.id);logUserActivity({userId:req.user.id,action:'USER_SESSION_REVOKED',entityType:'user_session',entityId:target.id,ip:clientIp(req)});if(target.id===req.userSessionId)res.clearCookie(USER_COOKIE_NAME,{path:'/'});res.json({ok:true,current:target.id===req.userSessionId})});
app.patch('/api/auth/profile',userAuth,userCsrf,async(req,res,next)=>{try{const current=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id),name=String(req.body.name??current.name).trim(),mobile=normalizeMobile(req.body.mobile??current.mobile),currentPassword=String(req.body.currentPassword||''),newPassword=String(req.body.newPassword||'');if(!current.password_hash||!await bcryptPool.compare(currentPassword,current.password_hash))return res.status(400).json({error:'رمز فعلی صحیح نیست.'});if(name.length<2||name.length>100||!/^09\d{9}$/.test(mobile))return res.status(400).json({error:'نام یا شماره موبایل معتبر نیست.'});if(newPassword&&(newPassword.length<8||newPassword.length>128||!/[A-Za-z\u0600-\u06ff]/.test(newPassword)||!/[0-9]/.test(newPassword)))return res.status(400).json({error:'رمز جدید باید حداقل ۸ کاراکتر و شامل حرف و عدد باشد.'});if(db.prepare('SELECT 1 FROM users WHERE mobile=? AND id!=? AND deleted_at IS NULL').get(mobile,current.id))return res.status(409).json({error:'این شماره برای حساب دیگری استفاده شده است.'});if(mobile!==current.mobile)return res.status(400).json({error:'برای تغییر موبایل از فرایند تأیید شماره جدید استفاده کن.',mobileVerificationRequired:true});const hash=newPassword?await bcryptPool.hash(newPassword,12):current.password_hash,now=iso();db.transaction(()=>{db.prepare('UPDATE users SET name=?,mobile=?,password_hash=?,updated_at=? WHERE id=?').run(name,mobile,hash,now,current.id);db.prepare('UPDATE user_contacts SET name=?,mobile=?,updated_at=? WHERE user_id=?').run(name,mobile,now,current.id);db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND id!=? AND revoked_at IS NULL').run(now,current.id,req.userSessionId)})();logUserActivity({userId:current.id,action:'USER_PROFILE_UPDATED',entityType:'user',entityId:current.id,details:{nameChanged:name!==current.name,mobileChanged:mobile!==current.mobile,passwordChanged:!!newPassword,otherSessionsRevoked:true},ip:clientIp(req)});res.json({ok:true,user:userPayload({...current,name,mobile,updated_at:now})})}catch(error){next(error)}});


const JOURNAL_SPECIAL_KEYS=new Set(['pa-accounts','pa-trades']);
function journalKey(value){const key=String(value||'');return /^pa-[a-z0-9][a-z0-9._-]{0,119}$/i.test(key)?key:null}
function journalVersion(userId,key){return db.prepare('SELECT version,updated_at FROM journal_sync_versions WHERE user_id=? AND key=?').get(userId,key)||{version:0,updated_at:null}}
function bumpJournalVersion(userId,key,now=iso()){db.prepare(`INSERT INTO journal_sync_versions (user_id,key,version,updated_at) VALUES (?,?,1,?) ON CONFLICT(user_id,key) DO UPDATE SET version=journal_sync_versions.version+1,updated_at=excluded.updated_at`).run(userId,key,now);return journalVersion(userId,key)}
function parsePayload(value,fallback=null){try{return JSON.parse(value)}catch{return fallback}}
function journalRowsValue(userId,key){
  if(key==='pa-accounts'){const rows=db.prepare('SELECT payload FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL ORDER BY created_at,id').all(userId).map(row=>parsePayload(row.payload)).filter(Boolean);return rows.length?JSON.stringify(rows):null}
  if(key==='pa-trades'){const rows=db.prepare('SELECT payload FROM journal_trades WHERE user_id=? AND deleted_at IS NULL ORDER BY entry_at DESC,created_at DESC').all(userId).map(row=>parsePayload(row.payload)).filter(Boolean);return rows.length?JSON.stringify(rows):null}
  return db.prepare('SELECT value FROM journal_preferences WHERE user_id=? AND key=?').get(userId,key)?.value??null;
}
function cleanClientId(value){const result=String(value||'').trim();return /^[A-Za-z0-9_-]{1,80}$/.test(result)?result:null}
function saveJournalAccounts(userId,value,now){const rows=parsePayload(value);if(!Array.isArray(rows)||rows.length>100)throw Object.assign(new Error('ساختار حساب‌های معاملاتی معتبر نیست.'),{status:400});const ids=[];const upsert=db.prepare(`INSERT INTO journal_accounts (user_id,id,name,starting_balance,payload,created_at,updated_at,deleted_at) VALUES (?,?,?,?,?,?,?,NULL) ON CONFLICT(user_id,id) DO UPDATE SET name=excluded.name,starting_balance=excluded.starting_balance,payload=excluded.payload,updated_at=excluded.updated_at,deleted_at=NULL`);rows.forEach(row=>{const accountId=cleanClientId(row?.id),name=String(row?.name||'').trim(),balance=Number(row?.startingBalance||0);if(!accountId||name.length<1||name.length>120||!Number.isFinite(balance)||Math.abs(balance)>1e15)throw Object.assign(new Error('یکی از حساب‌های معاملاتی معتبر نیست.'),{status:400});const payload=JSON.stringify({...row,id:accountId,name,startingBalance:balance});if(Buffer.byteLength(payload)>256*1024)throw Object.assign(new Error('اطلاعات حساب بیش از حد مجاز است.'),{status:413});ids.push(accountId);upsert.run(userId,accountId,name,balance,payload,String(row.createdAt||now),now)});if(ids.length){const marks=ids.map(()=>'?').join(',');db.prepare(`UPDATE journal_accounts SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL AND id NOT IN (${marks})`).run(now,now,userId,...ids)}else db.prepare('UPDATE journal_accounts SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL').run(now,now,userId)}
function userTradeLimit(userId){const planId=journalAccessForUser(userId).plan?.id;return Number((planId&&db.prepare('SELECT max_trades FROM plans WHERE id=?').get(planId)?.max_trades)||100)}
function saveJournalTrades(userId,value,now){const rows=parsePayload(value),limit=userTradeLimit(userId);if(!Array.isArray(rows))throw Object.assign(new Error('ساختار معاملات معتبر نیست.'),{status:400});if(rows.length>limit)return (()=>{throw Object.assign(new Error(`سقف پلن فعلی ${limit} معامله است.`),{status:403})})();const accountIds=new Set(db.prepare('SELECT id FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL').all(userId).map(row=>row.id)),ids=[];const upsert=db.prepare(`INSERT INTO journal_trades (user_id,id,account_id,entry_at,symbol,direction,result_type,amount,payload,created_at,updated_at,deleted_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL) ON CONFLICT(user_id,id) DO UPDATE SET account_id=excluded.account_id,entry_at=excluded.entry_at,symbol=excluded.symbol,direction=excluded.direction,result_type=excluded.result_type,amount=excluded.amount,payload=excluded.payload,updated_at=excluded.updated_at,deleted_at=NULL`);rows.forEach(row=>{const tradeId=cleanClientId(row?.id),accountId=cleanClientId(row?.accountId),entry=row?.entryDate?new Date(row.entryDate):null,entryAt=entry&&!Number.isNaN(entry.getTime())?entry.toISOString():null,symbol=String(row?.symbol||'').slice(0,40),direction=['buy','sell'].includes(row?.direction)?row.direction:null,resultType=['profit','loss'].includes(row?.resultType)?row.resultType:null,amount=Number(row?.amount||0);if(!tradeId||!accountId||!accountIds.has(accountId)||!Number.isFinite(amount)||Math.abs(amount)>1e15)throw Object.assign(new Error('یکی از معاملات یا حساب مرتبط معتبر نیست.'),{status:400});const payload=JSON.stringify({...row,id:tradeId,accountId});if(Buffer.byteLength(payload)>1024*1024)throw Object.assign(new Error('اطلاعات یک معامله بیش از حد مجاز است.'),{status:413});ids.push(tradeId);upsert.run(userId,tradeId,accountId,entryAt,symbol||null,direction,resultType,amount,payload,String(row.createdAt||now),now)});if(ids.length){const marks=ids.map(()=>'?').join(',');db.prepare(`UPDATE journal_trades SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL AND id NOT IN (${marks})`).run(now,now,userId,...ids)}else db.prepare('UPDATE journal_trades SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL').run(now,now,userId);db.prepare('UPDATE users SET trades_count=?,updated_at=? WHERE id=?').run(rows.length,now,userId)}
function dataUrlParts(value){const match=/^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=\r\n]+)$/i.exec(String(value||''));if(!match)return null;let buffer;try{buffer=Buffer.from(match[2].replace(/\s/g,''),'base64')}catch{return null}return {claimed:match[1].toLowerCase(),buffer}}
function imageMime(buffer){if(buffer.length>=12&&buffer[0]===0xff&&buffer[1]===0xd8&&buffer[2]===0xff)return'image/jpeg';if(buffer.length>=8&&buffer.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])))return'image/png';if(buffer.length>=12&&buffer.toString('ascii',0,4)==='RIFF'&&buffer.toString('ascii',8,12)==='WEBP')return'image/webp';if(buffer.length>=6&&['GIF87a','GIF89a'].includes(buffer.toString('ascii',0,6)))return'image/gif';return null}
function journalQuota(userId){const planId=journalAccessForUser(userId).plan?.id;return Number((planId&&db.prepare('SELECT max_storage_bytes FROM plans WHERE id=?').get(planId)?.max_storage_bytes)||100*1024*1024)}
function storeJournalImage(userId,dataUrl,tradeRef,createdFiles){const parts=dataUrlParts(dataUrl);if(!parts)throw Object.assign(new Error('فرمت تصویر معتبر نیست.'),{status:400});const mime=imageMime(parts.buffer),settings=db.prepare("SELECT * FROM file_settings WHERE id='default'").get(),allowed=parseAllowedMimeTypes(settings?.allowed_mime_types);if(!mime||mime!==parts.claimed||!allowed.includes(mime))throw Object.assign(new Error('نوع واقعی تصویر مجاز نیست.'),{status:400});if(parts.buffer.length>Number(settings?.max_file_size_bytes||12*1024*1024))throw Object.assign(new Error('حجم تصویر از سقف مجاز بیشتر است.'),{status:413});const checksum=crypto.createHash('sha256').update(parts.buffer).digest('hex'),existing=db.prepare("SELECT id FROM media_files WHERE user_id=? AND checksum_sha256=? AND status='active' AND scan_status='safe' LIMIT 1").get(userId,checksum);if(existing)return existing.id;const used=Number(db.prepare('SELECT storage_bytes FROM users WHERE id=?').get(userId)?.storage_bytes||0);if(used+parts.buffer.length>journalQuota(userId))throw Object.assign(new Error('فضای ذخیره‌سازی پلن شما کافی نیست.'),{status:403});const fileId=id('file'),ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif'}[mime],date=new Date(),storageKey=path.posix.join(userId,String(date.getUTCFullYear()),String(date.getUTCMonth()+1).padStart(2,'0'),`${fileId}.${ext}`),target=path.resolve(UPLOAD_DIR,...storageKey.split('/')),scanStatus=smsQueue.enabled?'pending':'safe';fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,parts.buffer,{flag:'wx'});try{db.transaction(()=>{db.prepare(`INSERT INTO media_files (id,user_id,trade_ref,original_name,storage_key,mime_type,size_bytes,checksum_sha256,status,scan_status,uploaded_at,orphaned_at) VALUES (?,?,?,?,?,?,?,?,'active',?,?,NULL)`).run(fileId,userId,tradeRef||null,`${fileId}.${ext}`,storageKey,mime,parts.buffer.length,checksum,scanStatus,iso());db.prepare('UPDATE users SET storage_bytes=storage_bytes+?,updated_at=? WHERE id=?').run(parts.buffer.length,iso(),userId)})()}catch(error){try{fs.unlinkSync(target)}catch{}throw error}createdFiles.push(fileId);if(smsQueue.enabled)smsQueue.enqueueMedia(fileId).catch(error=>captureError(error,{source:'MEDIA_QUEUE_ENQUEUE'}));else if(storage.s3Enabled)storage.uploadFile(storageKey,target,mime,checksum).catch(error=>captureError(error,{source:'S3_MEDIA_UPLOAD'}));return fileId}
function mediaIdFromUrl(value){const match=/^\/api\/journal\/media\/(file_[A-Za-z0-9_-]+)$/.exec(String(value||''));return match?match[1]:null}
function normalizeJournalMedia(userId,key,value){const createdFiles=[],refs=[];let normalized=String(value);const normalize=(raw,tradeRef,refPath)=>{if(!raw)return raw;let fileId=dataUrlParts(raw)?storeJournalImage(userId,raw,tradeRef,createdFiles):mediaIdFromUrl(raw);if(!fileId)return raw;const owned=db.prepare("SELECT 1 FROM media_files WHERE id=? AND user_id=? AND status='active'").get(fileId,userId);if(!owned)throw Object.assign(new Error('تصویر متعلق به این حساب نیست.'),{status:403});refs.push({path:refPath,fileId,tradeRef});return `/api/journal/media/${fileId}`};
  if(key.startsWith('pa-chart-'))normalized=normalize(normalized,key.slice(9),'value');else if(key==='pa-trade-documents-v1'){const docs=parsePayload(normalized);if(!docs||typeof docs!=='object'||Array.isArray(docs))throw Object.assign(new Error('ساختار مستندات تصویری معتبر نیست.'),{status:400});Object.entries(docs).forEach(([tradeId,item])=>{['before','after'].forEach(stage=>{const part=item&&item[stage];if(!part||typeof part!=='object')return;['data','originalData'].forEach(field=>{if(part[field])part[field]=normalize(part[field],tradeId,`${tradeId}.${stage}.${field}`)})})});normalized=JSON.stringify(docs)}
  return {value:normalized,refs,createdFiles}}
function updateJournalMediaRefs(userId,key,refs,now){const previous=db.prepare('SELECT file_id FROM journal_media_refs WHERE user_id=? AND storage_key=?').all(userId,key).map(row=>row.file_id);db.prepare('DELETE FROM journal_media_refs WHERE user_id=? AND storage_key=?').run(userId,key);const insert=db.prepare('INSERT INTO journal_media_refs (user_id,storage_key,ref_path,file_id,created_at) VALUES (?,?,?,?,?)');refs.forEach(ref=>{insert.run(userId,key,ref.path,ref.fileId,now);db.prepare('UPDATE media_files SET trade_ref=COALESCE(?,trade_ref),orphaned_at=NULL WHERE id=? AND user_id=?').run(ref.tradeRef||null,ref.fileId,userId)});[...new Set(previous)].forEach(fileId=>{if(!db.prepare('SELECT 1 FROM journal_media_refs WHERE file_id=? LIMIT 1').get(fileId))db.prepare("UPDATE media_files SET trade_ref=NULL,orphaned_at=? WHERE id=? AND user_id=? AND status='active'").run(now,fileId,userId)})}
function rollbackCreatedMedia(userId,fileIds){[...new Set(fileIds)].forEach(fileId=>{const file=db.prepare('SELECT * FROM media_files WHERE id=? AND user_id=?').get(fileId,userId);if(!file)return;try{removeStoredFile(file.storage_key)}catch{}db.prepare('DELETE FROM media_files WHERE id=?').run(file.id);db.prepare('UPDATE users SET storage_bytes=MAX(0,storage_bytes-?) WHERE id=?').run(file.size_bytes,userId)})}
function saveJournalKey(user,key,rawValue,baseVersion){const current=journalVersion(user.id,key);if(baseVersion!==undefined&&baseVersion!==null&&Number(baseVersion)!==Number(current.version)){const error=Object.assign(new Error('نسخه جدیدتری از این داده روی سرور وجود دارد.'),{status:409,conflict:{key,serverVersion:current.version,updatedAt:current.updated_at}});throw error}if(typeof rawValue!=='string')throw Object.assign(new Error('مقدار ذخیره‌سازی معتبر نیست.'),{status:400});const now=iso(),media=normalizeJournalMedia(user.id,key,rawValue);try{db.transaction(()=>{if(key==='pa-accounts')saveJournalAccounts(user.id,media.value,now);else if(key==='pa-trades')saveJournalTrades(user.id,media.value,now);else{if(Buffer.byteLength(media.value)>4*1024*1024)throw Object.assign(new Error('حجم این بخش از اطلاعات بیش از حد مجاز است.'),{status:413});db.prepare(`INSERT INTO journal_preferences (user_id,key,value,version,created_at,updated_at) VALUES (?,?,?,1,?,?) ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value,version=journal_preferences.version+1,updated_at=excluded.updated_at`).run(user.id,key,media.value,now,now)}updateJournalMediaRefs(user.id,key,media.refs,now);bumpJournalVersion(user.id,key,now)})()}catch(error){rollbackCreatedMedia(user.id,media.createdFiles);throw error}return {...journalVersion(user.id,key),value:media.value}}
function deleteJournalKey(user,key,baseVersion){const current=journalVersion(user.id,key);if(baseVersion!==undefined&&baseVersion!==null&&Number(baseVersion)!==Number(current.version))throw Object.assign(new Error('نسخه جدیدتری از این داده روی سرور وجود دارد.'),{status:409,conflict:{key,serverVersion:current.version,updatedAt:current.updated_at}});const now=iso();db.transaction(()=>{if(key==='pa-accounts'){db.prepare('UPDATE journal_accounts SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL').run(now,now,user.id);db.prepare('UPDATE journal_trades SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL').run(now,now,user.id);db.prepare('UPDATE users SET trades_count=0,updated_at=? WHERE id=?').run(now,user.id)}else if(key==='pa-trades'){db.prepare('UPDATE journal_trades SET deleted_at=?,updated_at=? WHERE user_id=? AND deleted_at IS NULL').run(now,now,user.id);db.prepare('UPDATE users SET trades_count=0,updated_at=? WHERE id=?').run(now,user.id)}else db.prepare('DELETE FROM journal_preferences WHERE user_id=? AND key=?').run(user.id,key);updateJournalMediaRefs(user.id,key,[],now);bumpJournalVersion(user.id,key,now)})();return journalVersion(user.id,key)}

app.post('/api/auth/mobile/request',userAuth,userCsrf,async(req,res,next)=>{try{const current=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id),password=String(req.body.currentPassword||''),mobile=normalizeMobile(req.body.mobile);if(!current.password_hash||!await bcryptPool.compare(password,current.password_hash))return res.status(400).json({error:'رمز فعلی صحیح نیست.'});if(!/^09\d{9}$/.test(mobile)||mobile===current.mobile)return res.status(400).json({error:'شماره جدید معتبر و متفاوت وارد کن.'});if(db.prepare('SELECT 1 FROM users WHERE mobile=? AND id!=? AND deleted_at IS NULL').get(mobile,current.id))return res.status(409).json({error:'این شماره برای حساب دیگری استفاده شده است.'});const challenge=await createOtpChallenge(req,{user:current,mobile,purpose:'verify_mobile',payload:{newMobile:mobile},remember:false});res.status(202).json({ok:true,verificationRequired:true,...challenge})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});
app.post('/api/auth/mobile/verify',userAuth,userCsrf,(req,res,next)=>{try{const challenge=consumeOtp(req.body.challengeToken,req.body.code,'verify_mobile');if(challenge.user_id!==req.user.id)return res.status(403).json({error:'درخواست تأیید متعلق به این حساب نیست.'});const mobile=normalizeMobile(challenge.payload?.newMobile),now=iso();if(!/^09\d{9}$/.test(mobile))return res.status(400).json({error:'شماره جدید معتبر نیست.'});db.transaction(()=>{db.prepare('UPDATE users SET mobile=?,mobile_verified_at=?,updated_at=? WHERE id=?').run(mobile,now,now,req.user.id);db.prepare('UPDATE user_contacts SET mobile=?,updated_at=? WHERE user_id=?').run(mobile,now,req.user.id);db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND id!=? AND revoked_at IS NULL').run(now,req.user.id,req.userSessionId)})();recordUserSecurityEvent({userId:req.user.id,eventType:'mobile_changed',severity:'critical',title:'شماره موبایل حساب تغییر کرد',details:{mobile},ip:clientIp(req),deviceId:req.user.device_id});res.json({ok:true,mobile})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});next(error)}});

app.use('/api/journal',userCsrf);
app.get('/api/journal/entitlements',(req,res)=>{res.setHeader('Cache-Control','no-store');res.json(journalAccessForUser(req.user.id))});
app.get('/api/journal/summary',(req,res)=>{const accounts=db.prepare('SELECT COUNT(*) count FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL').get(req.user.id).count,trades=db.prepare('SELECT COUNT(*) count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(req.user.id).count,preferenceKeys=db.prepare('SELECT key FROM journal_preferences WHERE user_id=? ORDER BY key').all(req.user.id).map(row=>row.key),media=db.prepare("SELECT COUNT(*) count,COALESCE(SUM(size_bytes),0) bytes FROM media_files WHERE user_id=? AND status='active'").get(req.user.id);res.json({hasData:accounts>0||trades>0||preferenceKeys.length>0,accounts,trades,preferenceKeys,media,user:userPayload(req.user)})});
app.get('/api/journal/storage',(req,res)=>{const keys=db.prepare('SELECT key FROM journal_preferences WHERE user_id=?').all(req.user.id).map(row=>row.key);if(db.prepare('SELECT 1 FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL LIMIT 1').get(req.user.id))keys.push('pa-accounts');if(db.prepare('SELECT 1 FROM journal_trades WHERE user_id=? AND deleted_at IS NULL LIMIT 1').get(req.user.id))keys.push('pa-trades');res.json({keys:[...new Set(keys)].sort(),shared:true})});
app.get('/api/journal/storage/:key',(req,res)=>{const key=journalKey(req.params.key);if(!key)return res.status(400).json({error:'کلید داده معتبر نیست.'});const value=journalRowsValue(req.user.id,key),version=journalVersion(req.user.id,key);if(value===null)return res.status(404).json({error:'داده‌ای برای این کلید وجود ندارد.',key,...version});res.json({key,value,...version,updatedAt:version.updated_at,shared:true})});
app.put('/api/journal/storage/:key',journalStorageWriteAccess,journalWriteGuard,(req,res)=>{const key=journalKey(req.params.key);if(!key)return res.status(400).json({error:'کلید داده معتبر نیست.'});try{const result=saveJournalKey(req.user,key,req.body?.value,req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_DATA_SAVED',entityType:'journal_storage',entityId:key,details:{version:result.version,bytes:Buffer.byteLength(result.value)},ip:clientIp(req)});res.json({ok:true,key,value:result.value,version:result.version,updatedAt:result.updated_at,shared:true})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.delete('/api/journal/storage/:key',journalStorageWriteAccess,journalWriteGuard,(req,res)=>{const key=journalKey(req.params.key);if(!key)return res.status(400).json({error:'کلید داده معتبر نیست.'});try{const version=deleteJournalKey(req.user,key,req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_DATA_DELETED',entityType:'journal_storage',entityId:key,details:{version:version.version},ip:clientIp(req)});res.json({ok:true,key,...version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.post('/api/journal/migrate',requireJournalSection('new'),journalWriteGuard,(req,res)=>{const entries=Array.isArray(req.body?.entries)?req.body.entries:null;if(!entries||entries.length>500)return res.status(400).json({error:'بسته مهاجرت داده معتبر نیست.'});const existing=db.prepare('SELECT COUNT(*) count FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL').get(req.user.id).count+db.prepare('SELECT COUNT(*) count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(req.user.id).count+db.prepare('SELECT COUNT(*) count FROM journal_preferences WHERE user_id=?').get(req.user.id).count;if(existing&&!req.body.force)return res.status(409).json({error:'حساب شما از قبل داده سروری دارد؛ مهاجرت خودکار برای جلوگیری از بازنویسی متوقف شد.',existing:true});const rank=key=>key==='pa-accounts'?0:key==='pa-trades'?1:2,order=entries.slice().sort((a,b)=>rank(a.key)-rank(b.key)),results=[],created=[];try{order.forEach(entry=>{const key=journalKey(entry.key);if(!key||typeof entry.value!=='string')throw Object.assign(new Error('یکی از رکوردهای مهاجرت معتبر نیست.'),{status:400});const result=saveJournalKey(req.user,key,entry.value,undefined);results.push({key,version:result.version});created.push(key)});logUserActivity({userId:req.user.id,action:'JOURNAL_LOCAL_DATA_MIGRATED',entityType:'journal_storage',details:{keys:results.map(x=>x.key),count:results.length},ip:clientIp(req)});res.json({ok:true,migrated:results})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,migrated:created});throw error}});
app.post('/api/journal/media',requireJournalSection('documents'),journalWriteGuard,(req,res)=>{const created=[];try{const fileId=storeJournalImage(req.user.id,String(req.body?.data||''),cleanClientId(req.body?.tradeId)||null,created);db.prepare('UPDATE media_files SET orphaned_at=COALESCE(orphaned_at,?) WHERE id=? AND user_id=?').run(iso(),fileId,req.user.id);logUserActivity({userId:req.user.id,action:'JOURNAL_MEDIA_UPLOADED',entityType:'media_file',entityId:fileId,details:{tradeId:req.body?.tradeId||null},ip:clientIp(req)});res.status(201).json({ok:true,id:fileId,url:`/api/journal/media/${fileId}`})}catch(error){if(error.status)return res.status(error.status).json({error:error.message});throw error}});
app.get('/api/journal/media/:id',async(req,res,next)=>{try{const file=db.prepare("SELECT * FROM media_files WHERE id=? AND user_id=? AND status='active' AND scan_status='safe'").get(req.params.id,req.user.id);if(!file)return res.status(404).json({error:'تصویر پیدا نشد.'});const target=path.resolve(UPLOAD_DIR,String(file.storage_key));if(target!==UPLOAD_DIR&&!target.startsWith(`${UPLOAD_DIR}${path.sep}`))return res.status(404).json({error:'مسیر تصویر معتبر نیست.'});if(fs.existsSync(target)){res.setHeader('Cache-Control','private, max-age=3600, immutable');res.setHeader('Content-Type',file.mime_type);res.setHeader('Content-Length',String(file.size_bytes));return fs.createReadStream(target).pipe(res)}if(storage.s3Enabled)return await storage.streamObject(file.storage_key,res,file.mime_type,file.size_bytes);return res.status(404).json({error:'فایل تصویر در دسترس نیست.'})}catch(error){next(error)}});
app.get('/api/journal/accounts',(req,res)=>{const rows=db.prepare('SELECT id,name,starting_balance,payload,created_at,updated_at FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL ORDER BY created_at,id').all(req.user.id).map(row=>({...parsePayload(row.payload,{}),id:row.id,name:row.name,startingBalance:row.starting_balance,createdAt:row.created_at,updatedAt:row.updated_at}));res.json({rows,...journalVersion(req.user.id,'pa-accounts')})});
app.get('/api/journal/trades',(req,res)=>{const accountId=req.query.accountId?cleanClientId(req.query.accountId):null,page=parsePositiveInt(req.query.page,1,100000),limit=parsePositiveInt(req.query.limit,100,500),where=['user_id=@userId','deleted_at IS NULL'],params={userId:req.user.id,limit,offset:(page-1)*limit};if(accountId){where.push('account_id=@accountId');params.accountId=accountId}const clause=where.join(' AND '),total=db.prepare(`SELECT COUNT(*) count FROM journal_trades WHERE ${clause}`).get(params).count,rows=db.prepare(`SELECT payload FROM journal_trades WHERE ${clause} ORDER BY entry_at DESC,created_at DESC LIMIT @limit OFFSET @offset`).all(params).map(row=>parsePayload(row.payload)).filter(Boolean);res.json({rows,pagination:{page,limit,total,pages:Math.max(1,Math.ceil(total/limit))},...journalVersion(req.user.id,'pa-trades')})});
app.post('/api/journal/accounts',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const rows=parsePayload(journalRowsValue(req.user.id,'pa-accounts')||'[]',[]),account={...req.body,id:cleanClientId(req.body?.id)||id('acc'),createdAt:iso()};delete account.baseVersion;if(rows.some(row=>row.id===account.id))return res.status(409).json({error:'شناسه حساب تکراری است.'});const result=saveJournalKey(req.user,'pa-accounts',JSON.stringify([...rows,account]),req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_ACCOUNT_CREATED',entityType:'journal_account',entityId:account.id,ip:clientIp(req)});res.status(201).json({ok:true,account:parsePayload(result.value).find(row=>row.id===account.id),version:result.version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.patch('/api/journal/accounts/:id',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const rows=parsePayload(journalRowsValue(req.user.id,'pa-accounts')||'[]',[]),index=rows.findIndex(row=>row.id===req.params.id);if(index<0)return res.status(404).json({error:'حساب معاملاتی پیدا نشد.'});rows[index]={...rows[index],...req.body,id:rows[index].id,updatedAt:iso()};delete rows[index].baseVersion;const result=saveJournalKey(req.user,'pa-accounts',JSON.stringify(rows),req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_ACCOUNT_UPDATED',entityType:'journal_account',entityId:req.params.id,ip:clientIp(req)});res.json({ok:true,account:parsePayload(result.value)[index],version:result.version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.delete('/api/journal/accounts/:id',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const accounts=parsePayload(journalRowsValue(req.user.id,'pa-accounts')||'[]',[]);if(!accounts.some(row=>row.id===req.params.id))return res.status(404).json({error:'حساب معاملاتی پیدا نشد.'});const trades=parsePayload(journalRowsValue(req.user.id,'pa-trades')||'[]',[]),now=iso();let versions;db.transaction(()=>{const accountResult=saveJournalKey(req.user,'pa-accounts',JSON.stringify(accounts.filter(row=>row.id!==req.params.id)),req.body?.accountVersion);const tradeResult=saveJournalKey(req.user,'pa-trades',JSON.stringify(trades.filter(row=>row.accountId!==req.params.id)),req.body?.tradeVersion);versions={accounts:accountResult.version,trades:tradeResult.version}})();logUserActivity({userId:req.user.id,action:'JOURNAL_ACCOUNT_DELETED',entityType:'journal_account',entityId:req.params.id,details:{deletedTrades:trades.filter(row=>row.accountId===req.params.id).length},ip:clientIp(req)});res.json({ok:true,versions})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.post('/api/journal/trades',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const rows=parsePayload(journalRowsValue(req.user.id,'pa-trades')||'[]',[]),trade={...req.body,id:cleanClientId(req.body?.id)||id('trade'),createdAt:iso()};delete trade.baseVersion;if(rows.some(row=>row.id===trade.id))return res.status(409).json({error:'شناسه معامله تکراری است.'});const result=saveJournalKey(req.user,'pa-trades',JSON.stringify([trade,...rows]),req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_TRADE_CREATED',entityType:'journal_trade',entityId:trade.id,ip:clientIp(req)});res.status(201).json({ok:true,trade:parsePayload(result.value).find(row=>row.id===trade.id),version:result.version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.patch('/api/journal/trades/:id',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const rows=parsePayload(journalRowsValue(req.user.id,'pa-trades')||'[]',[]),index=rows.findIndex(row=>row.id===req.params.id);if(index<0)return res.status(404).json({error:'معامله پیدا نشد.'});rows[index]={...rows[index],...req.body,id:rows[index].id,accountId:req.body?.accountId||rows[index].accountId,updatedAt:iso()};delete rows[index].baseVersion;const result=saveJournalKey(req.user,'pa-trades',JSON.stringify(rows),req.body?.baseVersion);logUserActivity({userId:req.user.id,action:'JOURNAL_TRADE_UPDATED',entityType:'journal_trade',entityId:req.params.id,ip:clientIp(req)});res.json({ok:true,trade:parsePayload(result.value)[index],version:result.version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});
app.delete('/api/journal/trades/:id',requireJournalSection('new'),journalWriteGuard,(req,res)=>{try{const rows=parsePayload(journalRowsValue(req.user.id,'pa-trades')||'[]',[]);if(!rows.some(row=>row.id===req.params.id))return res.status(404).json({error:'معامله پیدا نشد.'});const result=saveJournalKey(req.user,'pa-trades',JSON.stringify(rows.filter(row=>row.id!==req.params.id)),req.body?.baseVersion);deleteJournalKey(req.user,`pa-chart-${req.params.id}`,undefined);logUserActivity({userId:req.user.id,action:'JOURNAL_TRADE_DELETED',entityType:'journal_trade',entityId:req.params.id,ip:clientIp(req)});res.json({ok:true,version:result.version})}catch(error){if(error.status)return res.status(error.status).json({error:error.message,...error.conflict});throw error}});

function nextSupportReference(){let reference;do{reference=`SJ-${new Date().getUTCFullYear().toString().slice(-2)}${crypto.randomBytes(4).toString('hex').toUpperCase()}`}while(db.prepare('SELECT 1 FROM support_requests WHERE public_reference=?').get(reference));return reference}
function supportMessages(requestId,includeInternal=false){const rows=db.prepare(`SELECT m.*,a.name AS admin_name,u.name AS user_name FROM support_messages m LEFT JOIN admins a ON a.id=m.admin_id LEFT JOIN users u ON u.id=m.user_id WHERE m.request_id=? ${includeInternal?'':"AND m.is_internal=0"} ORDER BY m.created_at,m.id`).all(requestId).map(row=>({...row,is_internal:!!row.is_internal}));if(!rows.length){const item=db.prepare('SELECT message,created_at,user_id,name FROM support_requests WHERE id=?').get(requestId);if(item)rows.push({id:`initial_${requestId}`,request_id:requestId,author_type:'user',user_id:item.user_id,admin_id:null,message:item.message,is_internal:false,created_at:item.created_at,read_at:item.created_at,user_name:item.name,admin_name:null})}return rows}
app.get('/api/journal/support/tickets',(req,res)=>{const rows=db.prepare(`SELECT r.id,r.category,r.subject,r.status,r.priority,r.public_reference,r.created_at,r.updated_at,r.resolved_at,(SELECT m.message FROM support_messages m WHERE m.request_id=r.id AND m.is_internal=0 ORDER BY m.created_at DESC LIMIT 1) AS last_message,(SELECT COUNT(*) FROM support_messages m WHERE m.request_id=r.id AND m.author_type='admin' AND m.is_internal=0 AND m.read_at IS NULL) AS unread_count FROM support_requests r WHERE r.user_id=? ORDER BY r.updated_at DESC LIMIT 100`).all(req.user.id);res.setHeader('Cache-Control','no-store');res.json({rows})});
app.post('/api/journal/support/tickets',(req,res)=>{const category=['general','account','technical','billing','privacy','security'].includes(req.body.category)?req.body.category:'general',subject=String(req.body.subject||'').trim(),message=String(req.body.message||'').trim(),openCount=Number(db.prepare("SELECT COUNT(*) count FROM support_requests WHERE user_id=? AND status IN ('open','in_progress')").get(req.user.id).count||0);if(openCount>=10)return res.status(429).json({error:'حداکثر ۱۰ تیکت فعال مجاز است؛ لطفاً ابتدا پاسخ تیکت‌های قبلی را بررسی کنید.'});if(subject.length<4||subject.length>160||message.length<20||message.length>4000)return res.status(400).json({error:'موضوع باید حداقل ۴ و متن پیام حداقل ۲۰ کاراکتر باشد.'});const requestId=id('support'),reference=nextSupportReference(),now=iso(),ipHash=crypto.createHmac('sha256',APP_ENCRYPTION_KEY).update(clientIp(req)||'unknown').digest('hex');db.transaction(()=>{db.prepare(`INSERT INTO support_requests (id,user_id,name,mobile,email,category,subject,message,status,priority,public_reference,request_ip_hash,user_agent,created_at,updated_at) VALUES (?,?,?,?,NULL,?,?,?,'open','normal',?,?,?,?,?)`).run(requestId,req.user.id,req.user.name,req.user.mobile,category,subject,message,reference,ipHash,String(req.get('user-agent')||'').slice(0,500),now,now);db.prepare(`INSERT INTO support_messages (id,request_id,author_type,user_id,admin_id,message,is_internal,created_at,read_at) VALUES (?,?,'user',?,NULL,?,0,?,NULL)`).run(id('support_message'),requestId,req.user.id,message,now)})();logUserActivity({userId:req.user.id,action:'SUPPORT_TICKET_CREATED',entityType:'support_request',entityId:requestId,details:{reference,category},ip:clientIp(req)});res.status(201).json({ok:true,id:requestId,reference})});
app.get('/api/journal/support/tickets/:id',(req,res)=>{const ticket=db.prepare('SELECT id,category,subject,status,priority,public_reference,created_at,updated_at,resolved_at FROM support_requests WHERE id=? AND user_id=?').get(req.params.id,req.user.id);if(!ticket)return res.status(404).json({error:'تیکت پیدا نشد.'});db.prepare("UPDATE support_messages SET read_at=COALESCE(read_at,?) WHERE request_id=? AND author_type='admin' AND is_internal=0").run(iso(),ticket.id);res.setHeader('Cache-Control','no-store');res.json({ticket,messages:supportMessages(ticket.id,false)})});
app.post('/api/journal/support/tickets/:id/messages',(req,res)=>{const ticket=db.prepare('SELECT * FROM support_requests WHERE id=? AND user_id=?').get(req.params.id,req.user.id);if(!ticket)return res.status(404).json({error:'تیکت پیدا نشد.'});if(['closed','spam'].includes(ticket.status))return res.status(409).json({error:'این تیکت بسته شده است؛ یک تیکت جدید ایجاد کنید.'});const message=String(req.body.message||'').trim();if(message.length<2||message.length>4000)return res.status(400).json({error:'متن پاسخ باید بین ۲ تا ۴۰۰۰ کاراکتر باشد.'});const now=iso();db.transaction(()=>{db.prepare(`INSERT INTO support_messages (id,request_id,author_type,user_id,admin_id,message,is_internal,created_at,read_at) VALUES (?,?,'user',?,NULL,?,0,?,NULL)`).run(id('support_message'),ticket.id,req.user.id,message,now);db.prepare("UPDATE support_requests SET status='open',updated_at=?,resolved_at=NULL WHERE id=?").run(now,ticket.id)})();logUserActivity({userId:req.user.id,action:'SUPPORT_TICKET_REPLIED',entityType:'support_request',entityId:ticket.id,details:{reference:ticket.public_reference},ip:clientIp(req)});res.status(201).json({ok:true})});

function issueAdminSession(req,res,admin,mfaVerified=true,authMethod='password'){cleanupExpiredSessions();const rawToken=secureToken(36),csrfToken=secureToken(24),expiresAt=new Date(Date.now()+SESSION_HOURS*3600000).toISOString(),meta=requestMeta(req),sessionId=id('ses'),hashedToken=tokenHash(rawToken);db.prepare(`INSERT INTO admin_sessions (id,admin_id,token_hash,csrf_token,mfa_verified,auth_method,created_at,expires_at,ip,user_agent) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(sessionId,admin.id,hashedToken,csrfToken,mfaVerified?1:0,authMethod,iso(),expiresAt,meta.ip,meta.userAgent);db.prepare('UPDATE admins SET last_login_at=? WHERE id=?').run(iso(),admin.id);redisStore.sessionSet('admin',hashedToken,{sessionId,adminId:admin.id,expiresAt},Math.ceil((new Date(expiresAt).getTime()-Date.now())/1000));res.cookie(COOKIE_NAME,rawToken,{httpOnly:true,secure:COOKIE_SECURE,sameSite:'strict',path:'/',maxAge:SESSION_HOURS*3600000});return {csrfToken,sessionId,expiresAt}}
function createAdminLoginChallenge(req,admin,methods){const raw=secureToken(32),challengeId=id('amfa'),now=iso(),expiresAt=new Date(Date.now()+5*60000).toISOString(),meta=requestMeta(req);db.prepare(`INSERT INTO admin_auth_challenges (id,admin_id,challenge_hash,purpose,payload,created_at,expires_at,ip,user_agent) VALUES (?,?,?,'login',?,?,?,?,?)`).run(challengeId,admin.id,tokenHash(raw),JSON.stringify({methods}),now,expiresAt,meta.ip,meta.userAgent);return {challengeToken:raw,expiresAt,methods}}
function pendingAdminChallenge(raw,purpose='login'){return db.prepare('SELECT * FROM admin_auth_challenges WHERE challenge_hash=? AND purpose=? AND consumed_at IS NULL AND expires_at>? AND attempts<max_attempts').get(tokenHash(String(raw||'')),purpose,iso())}
function failAdminChallenge(challenge){if(challenge)db.prepare('UPDATE admin_auth_challenges SET attempts=attempts+1,consumed_at=CASE WHEN attempts+1>=max_attempts THEN ? ELSE consumed_at END WHERE id=?').run(iso(),challenge.id)}
function webauthnContext(req){return {rpID:process.env.WEBAUTHN_RP_ID||req.hostname,origin:process.env.WEBAUTHN_ORIGIN||`${req.protocol}://${req.get('host')}`,rpName:process.env.WEBAUTHN_RP_NAME||'SmartJournal Admin'}}
function generateRecoveryCodes(adminId){const codes=Array.from({length:10},()=>`${crypto.randomBytes(3).toString('hex').toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`),now=iso();db.prepare('DELETE FROM admin_recovery_codes WHERE admin_id=?').run(adminId);const insert=db.prepare('INSERT INTO admin_recovery_codes (id,admin_id,code_hash,created_at) VALUES (?,?,?,?)');codes.forEach(code=>insert.run(id('mfarec'),adminId,tokenHash(code.replace(/-/g,'').toLowerCase()),now));return codes}
function verifyRecoveryCode(adminId,code){const hash=tokenHash(String(code||'').replace(/[^a-fA-F0-9]/g,'').toLowerCase()),row=db.prepare('SELECT id FROM admin_recovery_codes WHERE admin_id=? AND code_hash=? AND used_at IS NULL').get(adminId,hash);if(!row)return false;db.prepare('UPDATE admin_recovery_codes SET used_at=? WHERE id=?').run(iso(),row.id);return true}
app.post('/api/admin/login', rateLimitLogin, async (req,res,next)=>{try{const identifier=String(req.body.identifier||req.body.mobile||'').trim(),normalizedMobile=normalizeMobile(identifier),mobile=/^09\d{9}$/.test(normalizedMobile)?normalizedMobile:'',username=/^[A-Za-z][A-Za-z0-9._-]{2,31}$/.test(identifier)?identifier.toLowerCase():'',password=String(req.body.password||'');if((!mobile&&!username)||password.length<8||password.length>128)return res.status(400).json({error:'شماره موبایل، نام کاربری یا رمز عبور معتبر نیست.'});const admin=mobile?db.prepare('SELECT * FROM admins WHERE mobile=? LIMIT 1').get(mobile):db.prepare('SELECT * FROM admins WHERE lower(username)=? LIMIT 1').get(username),valid=await (async()=>{const hash=admin&&admin.password_hash||DUMMY_PASSWORD_HASH;const match=await bcryptPool.compare(password,hash);return !!(admin&&admin.status==='active'&&match)})();if(!valid){logAudit({action:'LOGIN_FAILED',entityType:'admin',entityId:admin?.id||null,details:{identifier:mobile||username},ip:clientIp(req)});await new Promise(resolve=>setTimeout(resolve,280));return res.status(401).json({error:'شماره موبایل، نام کاربری یا رمز عبور اشتباه است.'})}await clearDistributedLimit('admin-login',req.loginRateKey,loginAttempts);const mfa=adminMfaStatus(admin.id);if(mfa.enabled){const methods=[...(mfa.totp?['totp']:[]),...(mfa.passkeys?['passkey']:[]),...(mfa.recoveryCodes?['recovery']:[])],challenge=createAdminLoginChallenge(req,admin,methods);logAudit({adminId:admin.id,action:'ADMIN_MFA_CHALLENGE_STARTED',entityType:'admin',entityId:admin.id,details:{methods},ip:clientIp(req)});return res.status(202).json({ok:true,mfaRequired:true,admin:{name:admin.name,username:admin.username},...challenge})}const setupRequired=adminNeedsMfa(admin),session=issueAdminSession(req,res,admin,!setupRequired,setupRequired?'password_pending_mfa':'password');logAudit({adminId:admin.id,action:setupRequired?'ADMIN_MFA_SETUP_REQUIRED':'LOGIN_SUCCESS',entityType:'admin',entityId:admin.id,details:{setupRequired},ip:clientIp(req)});res.json({admin:adminPayload(admin),csrfToken:session.csrfToken,mfaSetupRequired:setupRequired})}catch(error){next(error)}});
app.post('/api/admin/mfa/login/totp',async(req,res,next)=>{try{const challenge=pendingAdminChallenge(req.body.challengeToken);if(!challenge)return res.status(400).json({error:'درخواست MFA منقضی یا نامعتبر است.'});const totp=db.prepare('SELECT * FROM admin_totp WHERE admin_id=? AND enabled=1').get(challenge.admin_id),secret=totp?decryptSecret(totp.secret_encrypted)?.secret:null,counter=secret?verifyTotp(secret,req.body.code,totp.last_used_step):null,recoveryOk=!counter&&verifyRecoveryCode(challenge.admin_id,req.body.code);if(!counter&&!recoveryOk){failAdminChallenge(challenge);return res.status(400).json({error:challenge.attempts+1>=challenge.max_attempts?'تعداد تلاش MFA تمام شد؛ دوباره وارد شوید.':'کد تأیید صحیح نیست.'})}if(counter)db.prepare('UPDATE admin_totp SET last_used_step=? WHERE admin_id=?').run(counter,challenge.admin_id);db.prepare('UPDATE admin_auth_challenges SET consumed_at=? WHERE id=?').run(iso(),challenge.id);const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(challenge.admin_id),session=issueAdminSession(req,res,admin,true,recoveryOk?'recovery_code':'password+totp');logAudit({adminId:admin.id,action:'LOGIN_SUCCESS_MFA',entityType:'admin',entityId:admin.id,details:{method:recoveryOk?'recovery':'totp'},ip:clientIp(req)});res.json({admin:adminPayload(admin),csrfToken:session.csrfToken})}catch(error){next(error)}});
app.post('/api/admin/mfa/login/passkey/options',async(req,res,next)=>{try{const challenge=pendingAdminChallenge(req.body.challengeToken);if(!challenge)return res.status(400).json({error:'درخواست MFA منقضی یا نامعتبر است.'});const credentials=db.prepare('SELECT credential_id,transports FROM admin_passkeys WHERE admin_id=?').all(challenge.admin_id),ctx=webauthnContext(req),options=await generateAuthenticationOptions({rpID:ctx.rpID,allowCredentials:credentials.map(item=>({id:item.credential_id,transports:jsonDetails(item.transports)||undefined})),userVerification:'required',timeout:60000});db.prepare('UPDATE admin_auth_challenges SET challenge=?,payload=? WHERE id=?').run(options.challenge,JSON.stringify({methods:['passkey'],origin:ctx.origin,rpID:ctx.rpID}),challenge.id);res.json(options)}catch(error){next(error)}});
app.post('/api/admin/mfa/login/passkey/verify',async(req,res,next)=>{let challenge;try{challenge=pendingAdminChallenge(req.body.challengeToken);if(!challenge||!challenge.challenge)return res.status(400).json({error:'درخواست Passkey منقضی است.'});const credential=db.prepare('SELECT * FROM admin_passkeys WHERE admin_id=? AND credential_id=?').get(challenge.admin_id,req.body.response?.id);if(!credential)return res.status(404).json({error:'Passkey شناخته نشد.'});const payload=jsonDetails(challenge.payload)||{},verification=await verifyAuthenticationResponse({response:req.body.response,expectedChallenge:challenge.challenge,expectedOrigin:payload.origin,expectedRPID:payload.rpID,credential:{id:credential.credential_id,publicKey:new Uint8Array(credential.public_key),counter:Number(credential.counter),transports:jsonDetails(credential.transports)||undefined},requireUserVerification:true});if(!verification.verified)return res.status(400).json({error:'اعتبار Passkey تأیید نشد.'});db.transaction(()=>{db.prepare('UPDATE admin_passkeys SET counter=?,last_used_at=? WHERE id=?').run(verification.authenticationInfo.newCounter,iso(),credential.id);db.prepare('UPDATE admin_auth_challenges SET consumed_at=? WHERE id=?').run(iso(),challenge.id)})();const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(challenge.admin_id),session=issueAdminSession(req,res,admin,true,'password+passkey');logAudit({adminId:admin.id,action:'LOGIN_SUCCESS_MFA',entityType:'admin',entityId:admin.id,details:{method:'passkey',passkeyId:credential.id},ip:clientIp(req)});res.json({admin:adminPayload(admin),csrfToken:session.csrfToken})}catch(error){failAdminChallenge(challenge);return res.status(400).json({error:challenge&&challenge.attempts+1>=challenge.max_attempts?'تعداد تلاش MFA تمام شد؛ دوباره وارد شوید.':error.message||'تأیید Passkey ناموفق بود.'})}});

app.use('/api/admin', adminAuth, csrfGuard);
app.use('/api/admin',(req,res,next)=>{if(adminNeedsMfa(req.admin)&&!req.admin.mfa_verified&&!req.path.startsWith('/mfa')&&req.path!=='/me'&&req.path!=='/logout')return res.status(403).json({error:'برای ادامه، Owner باید TOTP یا Passkey را فعال کند.',mfaSetupRequired:true});next()});
app.use('/api/admin', (req, res, next) => {
  const startedAt = Date.now(), method = req.method, route = req.originalUrl.split('?')[0];
  res.on('finish', () => {
    try {
      logAudit({ adminId: req.admin.id, action: 'ADMIN_API_REQUEST', entityType: 'admin_request', entityId: null,
        details: { method, route, status: res.statusCode, durationMs: Date.now() - startedAt }, ip: clientIp(req) });
    } catch (error) { console.error('Audit request logging failed:', error.message); }
  });
  next();
});

app.get('/api/admin/me', (req, res) => {
  res.json({
    admin: adminPayload(req.admin),
    csrfToken: req.admin.csrf_token,
    mfaSetupRequired: adminNeedsMfa(req.admin) && !req.admin.mfa_verified
  });
});

app.get('/api/admin/mfa/status',(req,res)=>{const status=adminMfaStatus(req.admin.id),passkeys=db.prepare('SELECT id,name,device_type,backed_up,created_at,last_used_at FROM admin_passkeys WHERE admin_id=? ORDER BY created_at DESC').all(req.admin.id);res.json({status,passkeys,required:adminNeedsMfa(req.admin),sessionVerified:!!req.admin.mfa_verified})});
app.post('/api/admin/mfa/totp/setup',async(req,res,next)=>{try{
  const existing=db.prepare('SELECT * FROM admin_totp WHERE admin_id=?').get(req.admin.id);
  if(existing?.enabled){const admin=db.prepare('SELECT password_hash FROM admins WHERE id=?').get(req.admin.id),valid=admin&&await bcryptPool.compare(String(req.body.currentPassword||''),admin.password_hash);if(!valid)return res.status(400).json({error:'برای تنظیم مجدد TOTP رمز فعلی صحیح را وارد کنید.'})}
  const secret=base32Encode(crypto.randomBytes(20)),issuer='SmartJournal',label=encodeURIComponent(`${issuer}:${req.admin.username||req.admin.mobile}`),uri=`otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`,qrDataUrl=await QRCode.toDataURL(uri,{margin:1,width:240,errorCorrectionLevel:'M'}),now=iso(),encrypted=encryptSecret({secret});
  if(existing?.enabled)db.prepare('UPDATE admin_totp SET pending_secret_encrypted=?,pending_created_at=? WHERE admin_id=?').run(encrypted,now,req.admin.id);
  else db.prepare(`INSERT INTO admin_totp (admin_id,secret_encrypted,enabled,created_at,verified_at,last_used_step,pending_secret_encrypted,pending_created_at) VALUES (?,?,0,?,NULL,NULL,NULL,NULL) ON CONFLICT(admin_id) DO UPDATE SET secret_encrypted=excluded.secret_encrypted,enabled=0,created_at=excluded.created_at,verified_at=NULL,last_used_step=NULL,pending_secret_encrypted=NULL,pending_created_at=NULL`).run(req.admin.id,encrypted,now);
  logAudit({adminId:req.admin.id,action:existing?.enabled?'ADMIN_TOTP_ROTATION_STARTED':'ADMIN_TOTP_SETUP_STARTED',entityType:'admin',entityId:req.admin.id,details:{rotation:!!existing?.enabled},ip:clientIp(req)});res.json({ok:true,secret,uri,qrDataUrl,rotation:!!existing?.enabled})
}catch(error){next(error)}});
app.post('/api/admin/mfa/totp/verify',(req,res)=>{const row=db.prepare('SELECT * FROM admin_totp WHERE admin_id=?').get(req.admin.id),rotating=!!row?.pending_secret_encrypted,encrypted=rotating?row.pending_secret_encrypted:row?.secret_encrypted,secret=encrypted?decryptSecret(encrypted)?.secret:null,counter=secret?verifyTotp(secret,req.body.code,rotating?null:row.last_used_step):null;if(!counter)return res.status(400).json({error:'کد TOTP صحیح نیست.'});const before=adminMfaStatus(req.admin.id),now=iso();db.transaction(()=>{if(rotating)db.prepare('UPDATE admin_totp SET secret_encrypted=pending_secret_encrypted,pending_secret_encrypted=NULL,pending_created_at=NULL,enabled=1,verified_at=?,last_used_step=? WHERE admin_id=?').run(now,counter,req.admin.id);else db.prepare('UPDATE admin_totp SET enabled=1,verified_at=?,last_used_step=? WHERE admin_id=?').run(now,counter,req.admin.id);db.prepare("UPDATE admins SET mfa_enforced_at=?,mfa_required=CASE WHEN role='owner' THEN 1 ELSE mfa_required END WHERE id=?").run(now,req.admin.id);db.prepare('UPDATE admin_sessions SET mfa_verified=1,auth_method=\'password+totp_setup\' WHERE id=?').run(req.admin.session_id)})();const recoveryCodes=before.recoveryCodes?null:generateRecoveryCodes(req.admin.id);logAudit({adminId:req.admin.id,action:rotating?'ADMIN_TOTP_ROTATED':'ADMIN_TOTP_ENABLED',entityType:'admin',entityId:req.admin.id,details:{recoveryCodesGenerated:!!recoveryCodes},ip:clientIp(req)});res.json({ok:true,recoveryCodes,rotated:rotating})});
app.delete('/api/admin/mfa/totp',async(req,res,next)=>{try{const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.id),valid=await bcryptPool.compare(String(req.body.currentPassword||''),admin.password_hash);if(!valid)return res.status(400).json({error:'رمز فعلی صحیح نیست.'});const status=adminMfaStatus(admin.id);if(adminNeedsMfa(admin)&&status.passkeys<1)return res.status(400).json({error:'قبل از حذف TOTP حداقل یک Passkey فعال لازم است.'});db.prepare('DELETE FROM admin_totp WHERE admin_id=?').run(admin.id);logAudit({adminId:admin.id,action:'ADMIN_TOTP_DISABLED',entityType:'admin',entityId:admin.id,ip:clientIp(req)});res.json({ok:true})}catch(error){next(error)}});
app.post('/api/admin/mfa/passkeys/register/options',async(req,res,next)=>{try{const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.id),ctx=webauthnContext(req),existing=db.prepare('SELECT credential_id,transports FROM admin_passkeys WHERE admin_id=?').all(admin.id),options=await generateRegistrationOptions({rpName:ctx.rpName,rpID:ctx.rpID,userID:Buffer.from(admin.id),userName:admin.username||admin.mobile,userDisplayName:admin.name,attestationType:'none',excludeCredentials:existing.map(item=>({id:item.credential_id,transports:jsonDetails(item.transports)||undefined})),authenticatorSelection:{residentKey:'preferred',userVerification:'required'},timeout:60000}),rawToken=secureToken(28),now=iso();db.prepare(`INSERT INTO admin_auth_challenges (id,admin_id,challenge_hash,challenge,purpose,payload,created_at,expires_at,ip,user_agent) VALUES (?,?,?,?, 'passkey_register',?,?,?,?,?)`).run(id('amfa'),admin.id,tokenHash(rawToken),options.challenge,JSON.stringify({origin:ctx.origin,rpID:ctx.rpID,name:String(req.body.name||'Passkey اصلی').slice(0,80)}),now,new Date(Date.now()+5*60000).toISOString(),clientIp(req),String(req.get('user-agent')||''));res.json({...options,registrationToken:rawToken})}catch(error){next(error)}});
app.post('/api/admin/mfa/passkeys/register/verify',async(req,res)=>{try{const challenge=pendingAdminChallenge(req.body.registrationToken,'passkey_register');if(!challenge||challenge.admin_id!==req.admin.id)return res.status(400).json({error:'درخواست ثبت Passkey منقضی است.'});const payload=jsonDetails(challenge.payload)||{},verification=await verifyRegistrationResponse({response:req.body.response,expectedChallenge:challenge.challenge,expectedOrigin:payload.origin,expectedRPID:payload.rpID,requireUserVerification:true});if(!verification.verified||!verification.registrationInfo)return res.status(400).json({error:'Passkey تأیید نشد.'});const info=verification.registrationInfo,credential=info.credential,now=iso(),passkeyId=id('passkey'),before=adminMfaStatus(req.admin.id);db.transaction(()=>{db.prepare(`INSERT INTO admin_passkeys (id,admin_id,credential_id,public_key,counter,transports,device_type,backed_up,name,created_at,last_used_at) VALUES (?,?,?,?,?,?,?,?,?,?,NULL)`).run(passkeyId,req.admin.id,credential.id,Buffer.from(credential.publicKey),Number(credential.counter||0),JSON.stringify(credential.transports||req.body.response?.response?.transports||[]),info.credentialDeviceType,info.credentialBackedUp?1:0,payload.name||'Passkey',now);db.prepare('UPDATE admin_auth_challenges SET consumed_at=? WHERE id=?').run(now,challenge.id);db.prepare("UPDATE admins SET mfa_enforced_at=?,mfa_required=CASE WHEN role='owner' THEN 1 ELSE mfa_required END WHERE id=?").run(now,req.admin.id);db.prepare("UPDATE admin_sessions SET mfa_verified=1,auth_method='password+passkey_setup' WHERE id=?").run(req.admin.session_id)})();const recoveryCodes=before.recoveryCodes?null:generateRecoveryCodes(req.admin.id);logAudit({adminId:req.admin.id,action:'ADMIN_PASSKEY_REGISTERED',entityType:'admin_passkey',entityId:passkeyId,details:{deviceType:info.credentialDeviceType,backedUp:info.credentialBackedUp},ip:clientIp(req)});res.json({ok:true,id:passkeyId,recoveryCodes})}catch(error){res.status(400).json({error:error.message||'ثبت Passkey ناموفق بود.'})}});
app.delete('/api/admin/mfa/passkeys/:id',async(req,res,next)=>{try{const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.id),passkey=db.prepare('SELECT * FROM admin_passkeys WHERE id=? AND admin_id=?').get(req.params.id,admin.id);if(!passkey)return res.status(404).json({error:'Passkey پیدا نشد.'});if(!await bcryptPool.compare(String(req.body.currentPassword||''),admin.password_hash))return res.status(400).json({error:'رمز فعلی صحیح نیست.'});const status=adminMfaStatus(admin.id);if(adminNeedsMfa(admin)&&!status.totp&&status.passkeys<=1)return res.status(400).json({error:'حداقل یک روش MFA باید فعال باقی بماند.'});db.prepare('DELETE FROM admin_passkeys WHERE id=?').run(passkey.id);logAudit({adminId:admin.id,action:'ADMIN_PASSKEY_REMOVED',entityType:'admin_passkey',entityId:passkey.id,ip:clientIp(req)});res.json({ok:true})}catch(error){next(error)}});
app.post('/api/admin/mfa/recovery-codes/regenerate',async(req,res,next)=>{try{const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.id);if(!await bcryptPool.compare(String(req.body.currentPassword||''),admin.password_hash))return res.status(400).json({error:'رمز فعلی صحیح نیست.'});if(!adminMfaStatus(admin.id).enabled)return res.status(400).json({error:'ابتدا یک روش MFA فعال کنید.'});const codes=generateRecoveryCodes(admin.id);logAudit({adminId:admin.id,action:'ADMIN_MFA_RECOVERY_CODES_REGENERATED',entityType:'admin',entityId:admin.id,ip:clientIp(req)});res.json({ok:true,recoveryCodes:codes})}catch(error){next(error)}});

app.patch('/api/admin/profile', async (req, res, next) => {
  try {
    const current = db.prepare('SELECT * FROM admins WHERE id=?').get(req.admin.id);
    const currentPassword = String(req.body.currentPassword || ''), newPassword = String(req.body.newPassword || '');
    const name = String(req.body.name ?? current.name).trim(), username=String(req.body.username??current.username).trim().toLowerCase(), mobile = normalizeMobile(req.body.mobile ?? current.mobile);
    if (!await bcryptPool.compare(currentPassword, current.password_hash)) return res.status(400).json({ error: 'رمز عبور فعلی صحیح نیست.' });
    if (name.length < 3 || name.length > 100) return res.status(400).json({ error: 'نام مدیر باید بین ۳ تا ۱۰۰ کاراکتر باشد.' });
    if (!/^[a-z][a-z0-9._-]{2,31}$/.test(username)) return res.status(400).json({error:'نام کاربری باید ۳ تا ۳۲ کاراکتر انگلیسی معتبر باشد.'});
    if (!/^09\d{9}$/.test(mobile)) return res.status(400).json({ error: 'شماره موبایل مدیر معتبر نیست.' });
    if (newPassword && (newPassword.length < 10 || newPassword.length > 128)) return res.status(400).json({ error: 'رمز عبور جدید باید حداقل ۱۰ کاراکتر باشد.' });
    const duplicate = db.prepare('SELECT id FROM admins WHERE (mobile=? OR lower(username)=?) AND id!=?').get(mobile,username,current.id);
    if (duplicate) return res.status(409).json({ error: 'شماره موبایل یا نام کاربری برای مدیر دیگری ثبت شده است.' });
    const passwordHash = newPassword ? await bcryptPool.hash(newPassword, 12) : current.password_hash;
    const tx = db.transaction(() => {
      db.prepare('UPDATE admins SET name=?,username=?,mobile=?,password_hash=? WHERE id=?').run(name,username,mobile,passwordHash,current.id);
      db.prepare('DELETE FROM admin_sessions WHERE admin_id=? AND id!=?').run(current.id,req.admin.session_id);
    });
    tx();
    logAudit({ adminId: current.id, action: 'ADMIN_PROFILE_UPDATED', entityType: 'admin', entityId: current.id,
      details: { nameChanged:name!==current.name, usernameChanged:username!==current.username, mobileChanged:mobile!==current.mobile, passwordChanged:!!newPassword, otherSessionsRevoked:true }, ip: clientIp(req) });
    res.json({ ok:true, admin:adminPayload({ ...current,name,username,mobile }) });
  } catch (error) { next(error); }
});

app.post('/api/admin/logout', (req, res) => {
  db.prepare('DELETE FROM admin_sessions WHERE id=?').run(req.admin.session_id);
  redisStore.sessionDelete('admin',tokenHash(req.rawSessionToken));
  logAudit({ adminId: req.admin.id, action: 'LOGOUT', entityType: 'admin', entityId: req.admin.id, details: 'خروج از پنل مدیریت', ip: clientIp(req) });
  res.clearCookie(COOKIE_NAME, { path: '/' });
  res.json({ ok: true });
});

app.get('/api/admin/dashboard', allowPermissions('dashboard'), (req, res) => {
  const now = iso();
  const todayStart = new Date(); todayStart.setUTCHours(0, 0, 0, 0);
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const last30 = new Date(Date.now() - 30 * 86400000).toISOString();
  const last7 = new Date(Date.now() - 7 * 86400000).toISOString();
  const last24 = new Date(Date.now() - 86400000).toISOString();
  const metrics = {
    usersTotal: db.prepare('SELECT COUNT(*) AS v FROM users WHERE deleted_at IS NULL').get().v,
    usersToday: db.prepare('SELECT COUNT(*) AS v FROM users WHERE deleted_at IS NULL AND created_at>=?').get(todayStart.toISOString()).v,
    usersThisMonth: db.prepare('SELECT COUNT(*) AS v FROM users WHERE deleted_at IS NULL AND created_at>=?').get(monthStart.toISOString()).v,
    usersNew30: db.prepare('SELECT COUNT(*) AS v FROM users WHERE deleted_at IS NULL AND created_at>=?').get(last30).v,
    usersActive7: db.prepare("SELECT COUNT(*) AS v FROM users WHERE deleted_at IS NULL AND status='active' AND last_seen_at>=?").get(last7).v,
    subscriptionsActive: db.prepare("SELECT COUNT(*) AS v FROM subscriptions WHERE status='active' AND (expires_at IS NULL OR expires_at>?)").get(now).v,
    mrr: db.prepare(`SELECT COALESCE(SUM(p.price_monthly),0) AS v FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.status='active' AND (s.expires_at IS NULL OR s.expires_at>?)`).get(now).v,
    smsMonth: db.prepare('SELECT COUNT(*) AS v FROM sms_logs WHERE created_at>=?').get(monthStart.toISOString()).v,
    smsCostMonth: db.prepare('SELECT COALESCE(SUM(cost),0) AS v FROM sms_logs WHERE created_at>=?').get(monthStart.toISOString()).v,
    otpMonth: db.prepare("SELECT COUNT(*) AS v FROM sms_logs WHERE type='otp' AND created_at>=?").get(monthStart.toISOString()).v,
    otpCostMonth: db.prepare("SELECT COALESCE(SUM(cost),0) AS v FROM sms_logs WHERE type='otp' AND created_at>=?").get(monthStart.toISOString()).v,
    storageBytes: db.prepare('SELECT COALESCE(SUM(storage_bytes),0) AS v FROM users WHERE deleted_at IS NULL').get().v,
    tradesTotal: db.prepare('SELECT COALESCE(SUM(trades_count),0) AS v FROM users WHERE deleted_at IS NULL').get().v,
    loginErrors24h: db.prepare("SELECT COUNT(*) AS v FROM audit_logs WHERE action='LOGIN_FAILED' AND created_at>=?").get(last24).v,
    performanceErrors: db.prepare("SELECT COUNT(*) AS v FROM system_errors WHERE status='open' AND severity IN ('critical','error')").get().v,
    systemErrors24h: db.prepare('SELECT COUNT(*) AS v FROM system_errors WHERE occurred_at>=?').get(last24).v,
    openErrors: db.prepare("SELECT COUNT(*) AS v FROM system_errors WHERE status='open'").get().v
  };
  const growth = db.prepare(DATABASE_ENGINE==='postgres'?`
    WITH RECURSIVE months(n,start) AS (
      SELECT 0,(date_trunc('month',CURRENT_DATE)-INTERVAL '5 months')
      UNION ALL SELECT n+1,start+INTERVAL '1 month' FROM months WHERE n<5
    )
    SELECT to_char(m.start,'YYYY-MM') AS month,COUNT(u.id) AS users
    FROM months m LEFT JOIN users u ON u.deleted_at IS NULL
      AND u.created_at::timestamptz>=m.start AND u.created_at::timestamptz<m.start+INTERVAL '1 month'
    GROUP BY m.start ORDER BY m.start
  `:`
    WITH RECURSIVE months(n, start) AS (
      SELECT 0, date('now','start of month','-5 months')
      UNION ALL SELECT n+1, date(start,'+1 month') FROM months WHERE n<5
    )
    SELECT strftime('%Y-%m',m.start) AS month,
           COUNT(u.id) AS users
    FROM months m LEFT JOIN users u
      ON u.deleted_at IS NULL AND date(u.created_at)>=m.start AND date(u.created_at)<date(m.start,'+1 month')
    GROUP BY m.start ORDER BY m.start
  `).all();
  const plans = db.prepare(`SELECT p.id,p.name_fa,p.color,COUNT(s.id) AS count
    FROM plans p LEFT JOIN subscriptions s ON s.plan_id=p.id AND s.status IN ('active','trial')
    GROUP BY p.id ORDER BY count DESC`).all();
  const recentErrors = db.prepare(`SELECT id,severity,source,message,status,occurred_at FROM system_errors ORDER BY occurred_at DESC LIMIT 6`).all();
  const recentAudit = db.prepare(`SELECT l.id,l.action,l.entity_type,l.details,l.created_at,a.name AS admin_name
    FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id ORDER BY l.created_at DESC LIMIT 7`).all().map(row => ({ ...row, details: jsonDetails(row.details) }));
  const dbStartedAt = process.hrtime.bigint();
  let databaseStatus = 'connected', databaseLatencyMs = 0;
  try {
    db.prepare('SELECT 1 AS ok').get();
    databaseLatencyMs = Number(process.hrtime.bigint() - dbStartedAt) / 1e6;
  } catch (_) {
    databaseStatus = 'disconnected';
  }
  let databaseBytes = 0;
  try { databaseBytes = fs.statSync(DB_PATH).size; } catch (_) {}
  const health = {
    serverStatus: 'online',
    databaseStatus,
    databaseLatencyMs: Math.round(databaseLatencyMs * 100) / 100,
    databaseBytes,
    databaseEngine: DATABASE_ENGINE,
    journalMode: String(db.pragma('journal_mode', { simple: true }) || 'unknown').toUpperCase(),
    uptimeSeconds: Math.floor(process.uptime()),
    memoryBytes: process.memoryUsage().rss,
    checkedAt: iso()
  };
  const financialVisible = hasAdminPermission(req.admin, 'billing.view');
  const securityVisible = hasAdminPermission(req.admin, 'security.view');
  if (!financialVisible) {
    delete metrics.subscriptionsActive; delete metrics.mrr; delete metrics.smsCostMonth; delete metrics.otpCostMonth;
  }
  if (!securityVisible) {
    delete metrics.loginErrors24h; delete metrics.performanceErrors; delete metrics.systemErrors24h; delete metrics.openErrors;
  }
  res.json({ metrics, health, growth, plans: financialVisible ? plans : [], recentErrors: securityVisible ? recentErrors : [], recentAudit: securityVisible ? recentAudit : [] });
});

app.get('/api/admin/users', allowPermissions('users.view','users.security'), (req, res) => {
  const page = parsePositiveInt(req.query.page, 1, 100000);
  const limit = parsePositiveInt(req.query.limit, 15, 50);
  const search = String(req.query.search || '').trim();
  const status = ['active', 'suspended', 'pending', 'limited'].includes(req.query.status) ? req.query.status : '';
  const plan = ['free', 'pro', 'organization'].includes(req.query.plan) ? req.query.plan : '';
  const where = ['u.deleted_at IS NULL'];
  const params = {};
  if (search) { where.push("(u.name LIKE @search ESCAPE '\\' OR u.mobile LIKE @search ESCAPE '\\')"); params.search = safeLike(search); }
  if (status === 'limited') where.push("u.access_mode='limited'");
  else if (status) { where.push("u.status=@status AND u.access_mode='normal'"); params.status = status; }
  if (plan) { where.push('p.name=@plan'); params.plan = plan; }
  const clause = `WHERE ${where.join(' AND ')}`;
  const total = db.prepare(`SELECT COUNT(*) AS count FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id LEFT JOIN plans p ON p.id=s.plan_id ${clause}`).get(params).count;
  const rows = db.prepare(`SELECT u.*,CASE WHEN u.access_mode='limited' THEN 'limited' ELSE u.status END AS effective_status,
    p.name AS plan,p.name_fa AS plan_fa,p.color AS plan_color,s.status AS subscription_status,s.expires_at,
    (SELECT COUNT(*) FROM user_sessions us WHERE us.user_id=u.id AND us.revoked_at IS NULL AND us.expires_at>@now) AS active_sessions
    FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id LEFT JOIN plans p ON p.id=s.plan_id
    ${clause} ORDER BY u.created_at DESC LIMIT @limit OFFSET @offset`)
.all({ ...params, now: iso(), limit, offset: (page - 1) * limit });
  res.json({ rows, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } });
});

app.get('/api/admin/users/:id', allowPermissions('users.view','users.security'), (req, res) => {
  const user = db.prepare(`SELECT u.*,CASE WHEN u.access_mode='limited' THEN 'limited' ELSE u.status END AS effective_status,
    p.name AS plan,p.name_fa AS plan_fa,p.price_monthly,p.max_storage_bytes,s.status AS subscription_status,s.started_at,s.expires_at,s.auto_renew
    FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id LEFT JOIN plans p ON p.id=s.plan_id WHERE u.id=? AND u.deleted_at IS NULL`).get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });
  const sms = db.prepare('SELECT * FROM sms_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 8').all(user.id);
  const sessions = db.prepare(`SELECT id,device,ip,created_at,last_seen_at,expires_at FROM user_sessions
    WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY last_seen_at DESC`).all(user.id, iso());
  const recovery = db.prepare(`SELECT id,status,created_at,expires_at,completed_at FROM account_recovery_requests
    WHERE user_id=? ORDER BY created_at DESC LIMIT 5`).all(user.id);
  const devices = db.prepare("SELECT id,label,first_ip,last_ip,trusted_at,trusted_until,last_seen_at,status FROM user_trusted_devices WHERE user_id=? ORDER BY last_seen_at DESC LIMIT 20").all(user.id);
  const securityEvents = db.prepare('SELECT id,event_type,severity,title,details,ip,device_id,created_at FROM user_security_events WHERE user_id=? ORDER BY created_at DESC LIMIT 20').all(user.id).map(row=>({...row,details:jsonDetails(row.details)}));
  const journal = {
    accounts: db.prepare('SELECT COUNT(*) count FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL').get(user.id).count,
    trades: db.prepare('SELECT COUNT(*) count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(user.id).count,
    mediaFiles: db.prepare("SELECT COUNT(*) count FROM media_files WHERE user_id=? AND status='active'").get(user.id).count,
    lastSyncAt: db.prepare('SELECT MAX(updated_at) value FROM journal_sync_versions WHERE user_id=?').get(user.id).value
  };
  if (!hasAdminPermission(req.admin, 'billing.view')) {
    delete user.price_monthly;
    sms.forEach(item => { delete item.cost; });
  }
  res.json({ user, sms, sessions, recovery, journal, devices, securityEvents });
});

app.patch('/api/admin/users/:id/status', allowPermissions('users.manage'), (req, res) => {
  const status = String(req.body.status || '');
  if (!['active', 'suspended', 'pending', 'limited'].includes(status)) return res.status(400).json({ error: 'وضعیت انتخاب‌شده معتبر نیست.' });
  const user = db.prepare("SELECT id,name,mobile,status,access_mode FROM users WHERE id=? AND deleted_at IS NULL").get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });
  const previous = user.access_mode === 'limited' ? 'limited' : user.status;
  if (status === 'limited') {
    let limitedUntil = req.body.limitedUntil ? new Date(req.body.limitedUntil) : new Date(Date.now() + 7 * 86400000);
    if (Number.isNaN(limitedUntil.getTime()) || limitedUntil <= new Date()) return res.status(400).json({ error: 'تاریخ پایان محدودیت باید در آینده باشد.' });
    if (limitedUntil.getTime() > Date.now() + 366 * 86400000) return res.status(400).json({ error: 'مدت محدودیت نمی‌تواند بیشتر از یک سال باشد.' });
    const reason = String(req.body.reason || 'محدودیت موقت توسط مدیر').trim().slice(0, 300);
    db.prepare("UPDATE users SET status='active',access_mode='limited',limited_until=?,restriction_reason=? WHERE id=?").run(limitedUntil.toISOString(), reason, user.id);
  } else {
    db.prepare("UPDATE users SET status=?,access_mode='normal',limited_until=NULL,restriction_reason=NULL WHERE id=?").run(status, user.id);
    if (status === 'suspended') db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(iso(), user.id);
  }
  logAudit({ adminId: req.admin.id, action: 'USER_STATUS_UPDATED', entityType: 'user', entityId: user.id, details: { user: user.name, from: previous, to: status, reason: req.body.reason || null }, ip: clientIp(req) });
  res.json({ ok: true, status });
});

app.patch('/api/admin/users/:id/security',allowPermissions('users.security'),(req,res)=>{const user=db.prepare("SELECT * FROM users WHERE id=? AND deleted_at IS NULL").get(req.params.id);if(!user)return res.status(404).json({error:'کاربر پیدا نشد.'});const securityLevel=['normal','sensitive'].includes(req.body.securityLevel)?req.body.securityLevel:user.security_level,require2fa=req.body.require2fa===undefined?user.require_2fa:req.body.require2fa?1:0;db.prepare('UPDATE users SET security_level=?,require_2fa=?,updated_at=? WHERE id=?').run(securityLevel,require2fa,iso(),user.id);if(require2fa&&!user.require_2fa)db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(iso(),user.id);logAudit({adminId:req.admin.id,action:'USER_AUTH_SECURITY_UPDATED',entityType:'user',entityId:user.id,details:{securityLevel,require2fa:!!require2fa,sessionsRevoked:require2fa&&!user.require_2fa},ip:clientIp(req)});res.json({ok:true,securityLevel,require2fa:!!require2fa})});

app.post('/api/admin/users/:id/force-logout', allowPermissions('users.manage','users.security'), (req, res) => {
  const user = db.prepare("SELECT id,name FROM users WHERE id=? AND deleted_at IS NULL").get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });
  const result = db.prepare('UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(iso(), user.id);
  logAudit({ adminId: req.admin.id, action: 'USER_FORCE_LOGOUT', entityType: 'user', entityId: user.id, details: { user: user.name, revokedSessions: result.changes }, ip: clientIp(req) });
  res.json({ ok: true, revokedSessions: result.changes });
});

app.post('/api/admin/users/:id/recovery', allowPermissions('users.manage','users.security'), (req, res) => {
  const user = db.prepare("SELECT id,name,mobile FROM users WHERE id=? AND deleted_at IS NULL").get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });
  const now = iso(), expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(), rawToken = secureToken(24);
  const tx = db.transaction(() => {
    db.prepare("UPDATE account_recovery_requests SET status='cancelled' WHERE user_id=? AND status='pending'").run(user.id);
    db.prepare(`INSERT INTO account_recovery_requests (id,user_id,token_hash,status,created_at,expires_at,created_by_admin_id)
      VALUES (?,?,?,'pending',?,?,?)`).run(id('rec'), user.id, tokenHash(rawToken), now, expiresAt, req.admin.id);
  });
  tx();
  logAudit({ adminId: req.admin.id, action: 'USER_RECOVERY_STARTED', entityType: 'user', entityId: user.id, details: { user: user.name, mobile: user.mobile.slice(0, 4) + '***' + user.mobile.slice(-4), expiresAt }, ip: clientIp(req) });
  res.json({ ok: true, expiresAt, delivery: 'queued', maskedMobile: user.mobile.slice(0, 4) + '***' + user.mobile.slice(-4) });
});

function fulfillUserDeletion(user,adminId){const deletedAt=iso(),pseudonym=`deleted_${crypto.createHash('sha256').update(`${user.id}:${user.mobile}`).digest('hex').slice(0,24)}`,subjectHash=crypto.createHash('sha256').update(`deletion:${user.id}:${user.mobile}`).digest('hex'),media=db.prepare("SELECT storage_key FROM media_files WHERE user_id=? AND status!='deleted'").all(user.id);db.transaction(()=>{db.prepare('DELETE FROM journal_media_refs WHERE user_id=?').run(user.id);db.prepare('DELETE FROM journal_sync_versions WHERE user_id=?').run(user.id);db.prepare('DELETE FROM journal_preferences WHERE user_id=?').run(user.id);db.prepare('DELETE FROM journal_trades WHERE user_id=?').run(user.id);db.prepare('DELETE FROM journal_accounts WHERE user_id=?').run(user.id);db.prepare('DELETE FROM media_files WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_sessions WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_trusted_devices WHERE user_id=?').run(user.id);db.prepare('DELETE FROM account_recovery_requests WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_otp_challenges WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_activity_logs WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_security_events WHERE user_id=?').run(user.id);db.prepare('DELETE FROM user_contacts WHERE user_id=?').run(user.id);db.prepare("UPDATE sms_logs SET user_id=NULL,mobile='[deleted]',request_ip=NULL WHERE user_id=? OR mobile=?").run(user.id,user.mobile);db.prepare("UPDATE subscriptions SET status='cancelled',auto_renew=0,updated_at=? WHERE user_id=?").run(deletedAt,user.id);db.prepare("UPDATE privacy_requests SET status=CASE WHEN request_type='deletion' AND status IN ('pending','in_progress') THEN 'completed' ELSE status END,completed_at=CASE WHEN request_type='deletion' AND status IN ('pending','in_progress') THEN ? ELSE completed_at END,result_summary=CASE WHEN request_type='deletion' AND status IN ('pending','in_progress') THEN 'داده عملیاتی حذف و رکورد مالی/رضایت با شناسه مستعار نگهداری شد.' ELSE result_summary END,handled_by_admin_id=COALESCE(handled_by_admin_id,?),updated_at=? WHERE user_id=?").run(deletedAt,adminId,deletedAt,user.id);db.prepare("UPDATE audit_logs SET details=replace(details,?,'[REDACTED]') WHERE details LIKE ?").run(user.mobile,`%${user.mobile}%`);db.prepare(`UPDATE users SET name='کاربر حذف‌شده',mobile=?,password_hash=NULL,status='suspended',access_mode='normal',limited_until=NULL,restriction_reason=NULL,last_login_ip=NULL,storage_bytes=0,trades_count=0,sms_count=0,deleted_at=?,deletion_requested_at=COALESCE(deletion_requested_at,?),updated_at=? WHERE id=?`).run(pseudonym,deletedAt,deletedAt,deletedAt,user.id);db.prepare(`INSERT INTO data_deletion_tombstones (subject_hash,original_user_id,requested_at,fulfilled_at,expires_at,reason) VALUES (?,?,?,?,?,'user_request') ON CONFLICT(subject_hash) DO UPDATE SET original_user_id=excluded.original_user_id,requested_at=excluded.requested_at,fulfilled_at=excluded.fulfilled_at,expires_at=excluded.expires_at,reason=excluded.reason`).run(subjectHash,user.id,user.deletion_requested_at||deletedAt,deletedAt,new Date(Date.now()+5*365*86400000).toISOString())})();media.forEach(file=>removeStoredFile(file.storage_key));return {deletedAt,filesDeleted:media.length,subjectHash}}

app.delete('/api/admin/users/:id', allowPermissions('users.delete'), (req, res) => {
  const user = db.prepare("SELECT id,name,mobile,deletion_requested_at FROM users WHERE id=? AND deleted_at IS NULL").get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });
  if (!req.body.userRequested) return res.status(400).json({ error: 'حذف فقط پس از ثبت درخواست صریح کاربر مجاز است.' });
  if (normalizeMobile(req.body.confirmMobile) !== user.mobile) return res.status(400).json({ error: 'شماره موبایل تأیید با حساب کاربر مطابقت ندارد.' });
  const result=fulfillUserDeletion(user,req.admin.id);
  logAudit({ adminId: req.admin.id, action: 'USER_ACCOUNT_DELETED', entityType: 'user', entityId: user.id, details: { requestedAt: user.deletion_requested_at || result.deletedAt, deletedAt:result.deletedAt,operationalDataErased:true,financialAndConsentEvidencePseudonymized:true,filesDeleted:result.filesDeleted }, ip: clientIp(req) });
  res.json({ ok: true,...result });
});

app.get('/api/admin/privacy/requests',allowPermissions('users.security'),(req,res)=>{const status=['pending','in_progress','completed','rejected','cancelled'].includes(req.query.status)?req.query.status:'',where=status?'WHERE r.status=?':'',rows=db.prepare(`SELECT r.*,u.name user_name,u.mobile user_mobile,u.deleted_at FROM privacy_requests r JOIN users u ON u.id=r.user_id ${where} ORDER BY CASE r.status WHEN 'pending' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END,r.requested_at DESC LIMIT 300`).all(...(status?[status]:[]));res.json({rows})});
app.patch('/api/admin/privacy/requests/:id',allowPermissions('users.security'),(req,res)=>{const request=db.prepare('SELECT * FROM privacy_requests WHERE id=?').get(req.params.id);if(!request)return res.status(404).json({error:'درخواست حریم خصوصی پیدا نشد.'});const status=['in_progress','rejected'].includes(req.body.status)?req.body.status:'';if(!status)return res.status(400).json({error:'وضعیت درخواست معتبر نیست؛ تکمیل حذف از عملیات حذف کاربر انجام می‌شود.'});const reason=String(req.body.reason||'').trim();if(status==='rejected'&&reason.length<10)return res.status(400).json({error:'دلیل قانونی رد درخواست باید حداقل ۱۰ کاراکتر باشد.'});const now=iso();db.prepare('UPDATE privacy_requests SET status=?,rejection_reason=?,handled_by_admin_id=?,updated_at=? WHERE id=?').run(status,status==='rejected'?reason:null,req.admin.id,now,request.id);logAudit({adminId:req.admin.id,action:'PRIVACY_REQUEST_UPDATED',entityType:'privacy_request',entityId:request.id,details:{from:request.status,to:status,requestType:request.request_type,reason:status==='rejected'?reason:null},ip:clientIp(req)});res.json({ok:true,status,updatedAt:now})});

/* ==================== ADMIN JOURNAL MANAGEMENT ENDPOINTS ==================== */
app.get('/api/admin/journal/stats', allowPermissions('users.view'), (req, res) => {
  const totalAccounts = db.prepare("SELECT COUNT(*) AS count FROM journal_accounts WHERE deleted_at IS NULL").get().count;
  const totalTrades = db.prepare("SELECT COUNT(*) AS count FROM journal_trades WHERE deleted_at IS NULL").get().count;
  const activeTraders = db.prepare("SELECT COUNT(DISTINCT user_id) AS count FROM journal_accounts WHERE deleted_at IS NULL").get().count;
  
  const profitTrades = db.prepare("SELECT COUNT(*) AS count FROM journal_trades WHERE result_type='profit' AND deleted_at IS NULL").get().count;
  const lossTrades = db.prepare("SELECT COUNT(*) AS count FROM journal_trades WHERE result_type='loss' AND deleted_at IS NULL").get().count;
  const winRate = (profitTrades + lossTrades) > 0 ? Number(((profitTrades / (profitTrades + lossTrades)) * 100).toFixed(1)) : 0;
  
  const totalPnl = db.prepare("SELECT COALESCE(SUM(amount),0) AS total FROM journal_trades WHERE deleted_at IS NULL").get().total;

  const topSymbols = db.prepare(`
    SELECT symbol, COUNT(*) AS count,
           SUM(CASE WHEN result_type='profit' THEN 1 ELSE 0 END) AS profit_count,
           COALESCE(SUM(amount), 0) as total_amount
    FROM journal_trades
    WHERE deleted_at IS NULL AND symbol IS NOT NULL AND symbol != ''
    GROUP BY symbol
    ORDER BY count DESC
    LIMIT 8
  `).all().map(s => ({
    symbol: s.symbol,
    count: s.count,
    profitCount: s.profit_count,
    winRate: s.count > 0 ? Number(((s.profit_count / s.count) * 100).toFixed(1)) : 0,
    totalAmount: Number(Number(s.total_amount).toFixed(2))
  }));

  const recentTrades = db.prepare(`
    SELECT t.id, t.user_id, t.account_id, t.symbol, t.direction, t.result_type, t.amount, t.entry_at, t.created_at, t.payload,
           u.name AS user_name, u.mobile AS user_mobile,
           a.name AS account_name
    FROM journal_trades t
    LEFT JOIN users u ON u.id = t.user_id
    LEFT JOIN journal_accounts a ON a.id = t.account_id AND a.user_id = t.user_id
    WHERE t.deleted_at IS NULL
    ORDER BY t.created_at DESC
    LIMIT 10
  `).all().map(t => ({
    ...t,
    payload: parsePayload(t.payload)
  }));

  res.json({
    totalAccounts,
    totalTrades,
    activeTraders,
    profitTrades,
    lossTrades,
    winRate,
    totalPnl: Number(Number(totalPnl).toFixed(2)),
    topSymbols,
    recentTrades
  });
});

app.get('/api/admin/journal/accounts', allowPermissions('users.view'), (req, res) => {
  const page = parsePositiveInt(req.query.page, 1, 100000);
  const limit = parsePositiveInt(req.query.limit, 20, 100);
  const search = String(req.query.search || '').trim();
  const userId = req.query.userId ? String(req.query.userId).trim() : '';

  const where = ['a.deleted_at IS NULL'];
  const params = {};

  if (userId) { where.push('a.user_id = @userId'); params.userId = userId; }
  if (search) {
    where.push("(a.name LIKE @search ESCAPE '\\' OR u.name LIKE @search ESCAPE '\\' OR u.mobile LIKE @search ESCAPE '\\')");
    params.search = safeLike(search);
  }

  const clause = `WHERE ${where.join(' AND ')}`;
  const total = db.prepare(`SELECT COUNT(*) AS count FROM journal_accounts a LEFT JOIN users u ON u.id=a.user_id ${clause}`).get(params).count;

  const rows = db.prepare(`
    SELECT a.*, u.name AS user_name, u.mobile AS user_mobile,
           (SELECT COUNT(*) FROM journal_trades t WHERE t.account_id = a.id AND t.user_id = a.user_id AND t.deleted_at IS NULL) AS trades_count,
           (SELECT COALESCE(SUM(t.amount),0) FROM journal_trades t WHERE t.account_id = a.id AND t.user_id = a.user_id AND t.deleted_at IS NULL) AS net_pnl
    FROM journal_accounts a
    LEFT JOIN users u ON u.id = a.user_id
    ${clause}
    ORDER BY a.created_at DESC
    LIMIT @limit OFFSET @offset
  `).all({ ...params, limit, offset: (page - 1) * limit }).map(r => ({
    ...r,
    payload: parsePayload(r.payload)
  }));

  res.json({ rows, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } });
});

app.get('/api/admin/journal/trades', allowPermissions('users.view'), (req, res) => {
  const page = parsePositiveInt(req.query.page, 1, 100000);
  const limit = parsePositiveInt(req.query.limit, 20, 100);
  const search = String(req.query.search || '').trim();
  const userId = req.query.userId ? String(req.query.userId).trim() : '';
  const accountId = req.query.accountId ? String(req.query.accountId).trim() : '';
  const resultType = ['profit', 'loss'].includes(req.query.resultType) ? req.query.resultType : '';
  const direction = ['buy', 'sell'].includes(req.query.direction) ? req.query.direction : '';

  const where = ['t.deleted_at IS NULL'];
  const params = {};

  if (userId) { where.push('t.user_id = @userId'); params.userId = userId; }
  if (accountId) { where.push('t.account_id = @accountId'); params.accountId = accountId; }
  if (resultType) { where.push('t.result_type = @resultType'); params.resultType = resultType; }
  if (direction) { where.push('t.direction = @direction'); params.direction = direction; }
  if (search) {
    where.push("(t.symbol LIKE @search ESCAPE '\\' OR t.payload LIKE @search ESCAPE '\\' OR u.name LIKE @search ESCAPE '\\' OR u.mobile LIKE @search ESCAPE '\\')");
    params.search = safeLike(search);
  }

  const clause = `WHERE ${where.join(' AND ')}`;
  const total = db.prepare(`SELECT COUNT(*) AS count FROM journal_trades t LEFT JOIN users u ON u.id=t.user_id ${clause}`).get(params).count;

  const rows = db.prepare(`
    SELECT t.*, u.name AS user_name, u.mobile AS user_mobile, a.name AS account_name
    FROM journal_trades t
    LEFT JOIN users u ON u.id = t.user_id
    LEFT JOIN journal_accounts a ON a.id = t.account_id AND a.user_id = t.user_id
    ${clause}
    ORDER BY t.entry_at DESC, t.created_at DESC
    LIMIT @limit OFFSET @offset
  `).all({ ...params, limit, offset: (page - 1) * limit }).map(r => ({
    ...r,
    payload: parsePayload(r.payload)
  }));

  res.json({ rows, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } });
});

app.get('/api/admin/journal/trades/:id', allowPermissions('users.view'), (req, res) => {
  const trade = db.prepare(`
    SELECT t.*, u.name AS user_name, u.mobile AS user_mobile, a.name AS account_name
    FROM journal_trades t
    LEFT JOIN users u ON u.id = t.user_id
    LEFT JOIN journal_accounts a ON a.id = t.account_id AND a.user_id = t.user_id
    WHERE t.id = ? AND t.deleted_at IS NULL
  `).get(req.params.id);

  if (!trade) return res.status(404).json({ error: 'معامله پیدا نشد یا حذف شده است.' });

  const payload = parsePayload(trade.payload);
  const media = db.prepare("SELECT * FROM media_files WHERE user_id=? AND trade_ref=? AND status='active'").all(trade.user_id, trade.id);

  res.json({ trade: { ...trade, payload }, media });
});

app.delete('/api/admin/journal/trades/:id', allowPermissions('users.manage'), (req, res) => {
  const trade = db.prepare('SELECT * FROM journal_trades WHERE id=? AND deleted_at IS NULL').get(req.params.id);
  if (!trade) return res.status(404).json({ error: 'معامله پیدا نشد.' });

  const now = iso();
  db.transaction(() => {
    db.prepare('UPDATE journal_trades SET deleted_at=?, updated_at=? WHERE id=?').run(now, now, trade.id);
    const count = db.prepare('SELECT COUNT(*) count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(trade.user_id).count;
    db.prepare('UPDATE users SET trades_count=?, updated_at=? WHERE id=?').run(count, now, trade.user_id);
    bumpJournalVersion(trade.user_id, 'pa-trades', now);
  })();

  logAudit({ adminId: req.admin.id, action: 'ADMIN_DELETE_TRADE', entityType: 'journal_trade', entityId: trade.id, details: { userId: trade.user_id, symbol: trade.symbol, amount: trade.amount }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.delete('/api/admin/journal/accounts/:id', allowPermissions('users.manage'), (req, res) => {
  const account = db.prepare('SELECT * FROM journal_accounts WHERE id=? AND deleted_at IS NULL').get(req.params.id);
  if (!account) return res.status(404).json({ error: 'حساب پیدا نشد.' });

  const now = iso();
  db.transaction(() => {
    db.prepare('UPDATE journal_accounts SET deleted_at=?, updated_at=? WHERE id=?').run(now, now, account.id);
    db.prepare('UPDATE journal_trades SET deleted_at=?, updated_at=? WHERE account_id=? AND user_id=? AND deleted_at IS NULL').run(now, now, account.id, account.user_id);
    const count = db.prepare('SELECT COUNT(*) count FROM journal_trades WHERE user_id=? AND deleted_at IS NULL').get(account.user_id).count;
    db.prepare('UPDATE users SET trades_count=?, updated_at=? WHERE id=?').run(count, now, account.user_id);
    bumpJournalVersion(account.user_id, 'pa-accounts', now);
    bumpJournalVersion(account.user_id, 'pa-trades', now);
  })();

  logAudit({ adminId: req.admin.id, action: 'ADMIN_DELETE_ACCOUNT', entityType: 'journal_account', entityId: account.id, details: { userId: account.user_id, name: account.name }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.get('/api/admin/users/:id/journal', allowPermissions('users.view'), (req, res) => {
  const user = db.prepare('SELECT id, name, mobile, status, created_at FROM users WHERE id=? AND deleted_at IS NULL').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر پیدا نشد.' });

  const accounts = db.prepare('SELECT * FROM journal_accounts WHERE user_id=? AND deleted_at IS NULL ORDER BY created_at ASC').all(user.id).map(a => ({ ...a, payload: parsePayload(a.payload) }));
  const trades = db.prepare('SELECT * FROM journal_trades WHERE user_id=? AND deleted_at IS NULL ORDER BY entry_at DESC, created_at DESC').all(user.id).map(t => ({ ...t, payload: parsePayload(t.payload) }));
  const preferences = db.prepare('SELECT key, value FROM journal_preferences WHERE user_id=?').all(user.id);

  res.json({ user, accounts, trades, preferences });
});

app.post('/api/admin/users/:id/journal/login-as', allowPermissions('users.manage'), (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id=? AND deleted_at IS NULL AND status='active'").get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر فعال برای ورود به ژورنال یافت نشد.' });

  const sessionToken = secureToken(36);
  const csrfToken = secureToken(24);
  const now = iso();
  const expiresAt = new Date(Date.now() + 2 * 3600000).toISOString();
  const sessionId = id('uses');

  db.prepare(`
    INSERT INTO user_sessions (id, user_id, token_hash, csrf_token, device, ip, user_agent, auth_method, mfa_verified, created_at, last_seen_at, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'admin_login_as', 1, ?, ?, ?)
  `).run(sessionId, user.id, tokenHash(sessionToken), csrfToken, `مدیریت (${req.admin.name})`, clientIp(req), req.get('user-agent') || 'Admin', now, now, expiresAt);

  res.cookie(USER_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: 'strict',
    path: '/',
    maxAge: 2 * 3600000
  });

  logAudit({
    adminId: req.admin.id,
    action: 'ADMIN_LOGIN_AS_USER_JOURNAL',
    entityType: 'user',
    entityId: user.id,
    details: { userName: user.name, userMobile: user.mobile },
    ip: clientIp(req)
  });

  res.json({
    ok: true,
    redirectUrl: '/index.html#journal',
    user: { id: user.id, name: user.name, mobile: user.mobile }
  });
});


function contactInput(body,current={}){const name=String(body.name??current.name??'').trim(),mobile=normalizeMobile(body.mobile??current.mobile),tags=Array.isArray(body.tags)?body.tags.map(tag=>String(tag).trim()).filter(Boolean).slice(0,20):String(body.tags??current.tags??'').split(',').map(tag=>tag.trim()).filter(Boolean).slice(0,20),note=String(body.note??current.note??'').trim(),smsConsent=body.smsConsent===undefined?!!current.sms_consent:!!body.smsConsent;if(name.length<2||name.length>120||!/^09\d{9}$/.test(mobile)||note.length>2000||tags.some(tag=>tag.length>40))return{error:'نام، شماره موبایل، برچسب یا یادداشت معتبر نیست.'};return{name,mobile,tags,smsConsent,note}}
app.get('/api/admin/contacts', allowPermissions('users.view','users.security'), (req,res)=>{const page=parsePositiveInt(req.query.page,1,100000),limit=parsePositiveInt(req.query.limit,20,100),search=String(req.query.search||'').trim(),source=['registered','manual','import'].includes(req.query.source)?req.query.source:'',consent=req.query.consent==='1'?1:req.query.consent==='0'?0:null,where=[],params={};if(search){where.push("(c.name LIKE @search ESCAPE '\\' OR c.mobile LIKE @search ESCAPE '\\' OR c.tags LIKE @search ESCAPE '\\')");params.search=safeLike(search)}if(source){where.push('c.source=@source');params.source=source}if(consent!==null){where.push('c.sms_consent=@consent');params.consent=consent}const clause=where.length?`WHERE ${where.join(' AND ')}`:'',total=db.prepare(`SELECT COUNT(*) count FROM user_contacts c ${clause}`).get(params).count,rows=db.prepare(`SELECT c.*,u.status AS user_status,u.created_at AS user_created_at FROM user_contacts c LEFT JOIN users u ON u.id=c.user_id ${clause} ORDER BY c.updated_at DESC LIMIT @limit OFFSET @offset`).all({...params,limit,offset:(page-1)*limit}).map(row=>({...row,tags:String(row.tags||'').split(',').filter(Boolean)}));const metrics=db.prepare(`SELECT COUNT(*) total,SUM(CASE WHEN source='registered' THEN 1 ELSE 0 END) registered,SUM(CASE WHEN source='manual' THEN 1 ELSE 0 END) manual,SUM(CASE WHEN source='import' THEN 1 ELSE 0 END) imported,SUM(sms_consent) consented FROM user_contacts`).get();res.json({rows,metrics,pagination:{page,limit,total,pages:Math.max(1,Math.ceil(total/limit))}})});
app.get('/api/admin/contacts/export', allowPermissions('users.view'), (req,res)=>{const rows=db.prepare('SELECT name,mobile,tags,note,sms_consent,source,created_at,updated_at FROM user_contacts ORDER BY updated_at DESC').all(),csv=['name,mobile,tags,note,sms_consent,source,created_at,updated_at',...rows.map(row=>[row.name,row.mobile,row.tags||'',row.note||'',row.sms_consent,row.source,row.created_at,row.updated_at].map(value=>`"${String(value??'').replace(/"/g,'""')}"`).join(','))].join('\n');res.setHeader('Content-Disposition','attachment; filename="pa-user-contacts.csv"');res.type('text/csv').send('\uFEFF'+csv)});
app.post('/api/admin/contacts', allowPermissions('users.manage'), (req,res)=>{const input=contactInput(req.body);if(input.error)return res.status(400).json({error:input.error});if(db.prepare('SELECT 1 FROM user_contacts WHERE mobile=?').get(input.mobile))return res.status(409).json({error:'این شماره قبلاً در دفترچه ذخیره شده است.'});const contactId=id('contact'),now=iso();db.prepare(`INSERT INTO user_contacts (id,user_id,name,mobile,tags,note,sms_consent,source,created_at,updated_at,updated_by_admin_id) VALUES (?,NULL,?,?,?,?,?,'manual',?,?,?)`).run(contactId,input.name,input.mobile,input.tags.join(','),input.note||null,input.smsConsent?1:0,now,now,req.admin.id);recordMarketingConsent({contactId,mobile:input.mobile,granted:input.smsConsent,policyVersion:currentLegalDocument('privacy')?.version||'1.0.0',source:'admin_attested',ip:clientIp(req),userAgent:req.get('user-agent'),adminId:req.admin.id});logAudit({adminId:req.admin.id,action:'USER_CONTACT_CREATED',entityType:'user_contact',entityId:contactId,details:{name:input.name,mobile:input.mobile,source:'manual'},ip:clientIp(req)});res.status(201).json({ok:true,id:contactId})});
app.patch('/api/admin/contacts/:id', allowPermissions('users.manage'), (req,res)=>{const contact=db.prepare('SELECT * FROM user_contacts WHERE id=?').get(req.params.id);if(!contact)return res.status(404).json({error:'شماره ذخیره‌شده پیدا نشد.'});const input=contactInput(req.body,contact);if(input.error)return res.status(400).json({error:input.error});if(db.prepare('SELECT 1 FROM user_contacts WHERE mobile=? AND id!=?').get(input.mobile,contact.id))return res.status(409).json({error:'این شماره قبلاً ذخیره شده است.'});if(contact.user_id&&db.prepare('SELECT 1 FROM users WHERE mobile=? AND id!=?').get(input.mobile,contact.user_id))return res.status(409).json({error:'این شماره متعلق به کاربر دیگری است.'});const now=iso(),tx=db.transaction(()=>{db.prepare('UPDATE user_contacts SET name=?,mobile=?,tags=?,note=?,sms_consent=?,updated_at=?,updated_by_admin_id=? WHERE id=?').run(input.name,input.mobile,input.tags.join(','),input.note||null,input.smsConsent?1:0,now,req.admin.id,contact.id);if(contact.user_id)db.prepare('UPDATE users SET name=?,mobile=? WHERE id=?').run(input.name,input.mobile,contact.user_id)});tx();if(!!contact.sms_consent!==input.smsConsent)recordMarketingConsent({userId:contact.user_id||null,contactId:contact.id,mobile:input.mobile,granted:input.smsConsent,policyVersion:currentLegalDocument('privacy')?.version||'1.0.0',source:'admin_attested',ip:clientIp(req),userAgent:req.get('user-agent'),adminId:req.admin.id});logAudit({adminId:req.admin.id,action:'USER_CONTACT_UPDATED',entityType:'user_contact',entityId:contact.id,details:{fromMobile:contact.mobile,toMobile:input.mobile,linkedUser:!!contact.user_id,smsConsent:input.smsConsent},ip:clientIp(req)});res.json({ok:true})});
app.delete('/api/admin/contacts/:id', allowPermissions('users.manage'), (req,res)=>{const contact=db.prepare('SELECT * FROM user_contacts WHERE id=?').get(req.params.id);if(!contact)return res.status(404).json({error:'شماره ذخیره‌شده پیدا نشد.'});if(contact.user_id)return res.status(400).json({error:'شماره کاربر ثبت‌نام‌شده حذف نمی‌شود؛ فقط قابل ویرایش است.'});db.prepare('DELETE FROM user_contacts WHERE id=?').run(contact.id);logAudit({adminId:req.admin.id,action:'USER_CONTACT_DELETED',entityType:'user_contact',entityId:contact.id,details:{mobile:contact.mobile,source:contact.source},ip:clientIp(req)});res.json({ok:true})});
app.post('/api/admin/contacts/sync', allowPermissions('users.manage'), (req,res)=>{syncUserContacts();const count=db.prepare("SELECT COUNT(*) count FROM user_contacts WHERE source='registered'").get().count;logAudit({adminId:req.admin.id,action:'USER_CONTACTS_SYNCED',entityType:'user_contact',details:{registeredContacts:count},ip:clientIp(req)});res.json({ok:true,count})});
app.post('/api/admin/contacts/import', allowPermissions('users.manage'), (req,res)=>{const rows=Array.isArray(req.body.rows)?req.body.rows.slice(0,2000):null;if(!rows)return res.status(400).json({error:'فایل ورودی معتبر نیست.'});let created=0,updated=0,failed=0;const find=db.prepare('SELECT * FROM user_contacts WHERE mobile=?'),insert=db.prepare(`INSERT INTO user_contacts (id,user_id,name,mobile,tags,note,sms_consent,source,created_at,updated_at,updated_by_admin_id) VALUES (?,NULL,?,?,?,?,?,'import',?,?,?)`),update=db.prepare('UPDATE user_contacts SET name=?,tags=?,note=?,sms_consent=?,updated_at=?,updated_by_admin_id=? WHERE id=?');db.transaction(()=>rows.forEach(row=>{const input=contactInput(row);if(input.error){failed++;return}const existing=find.get(input.mobile),now=iso();if(existing){update.run(input.name,input.tags.join(','),input.note||null,input.smsConsent?1:0,now,req.admin.id,existing.id);recordMarketingConsent({userId:existing.user_id||null,contactId:existing.id,mobile:input.mobile,granted:input.smsConsent,policyVersion:currentLegalDocument('privacy')?.version||'1.0.0',source:'import_attested',ip:clientIp(req),userAgent:req.get('user-agent'),adminId:req.admin.id});updated++}else{const contactId=id('contact');insert.run(contactId,input.name,input.mobile,input.tags.join(','),input.note||null,input.smsConsent?1:0,now,now,req.admin.id);recordMarketingConsent({contactId,mobile:input.mobile,granted:input.smsConsent,policyVersion:currentLegalDocument('privacy')?.version||'1.0.0',source:'import_attested',ip:clientIp(req),userAgent:req.get('user-agent'),adminId:req.admin.id});created++}}))();logAudit({adminId:req.admin.id,action:'USER_CONTACTS_IMPORTED',entityType:'user_contact',details:{created,updated,failed,total:rows.length},ip:clientIp(req)});res.json({ok:true,created,updated,failed})});

app.get('/api/admin/support/requests',allowPermissions('users.view','users.security'),(req,res)=>{const status=['open','in_progress','resolved','closed','spam'].includes(req.query.status)?req.query.status:'',priority=['low','normal','high','urgent'].includes(req.query.priority)?req.query.priority:'',search=String(req.query.search||'').trim(),where=[],params={};if(status){where.push('r.status=@status');params.status=status}if(priority){where.push('r.priority=@priority');params.priority=priority}if(search){where.push("(r.public_reference LIKE @search ESCAPE '\\' OR r.name LIKE @search ESCAPE '\\' OR r.mobile LIKE @search ESCAPE '\\' OR r.email LIKE @search ESCAPE '\\' OR r.subject LIKE @search ESCAPE '\\')");params.search=safeLike(search)}const clause=where.length?`WHERE ${where.join(' AND ')}`:'',rows=db.prepare(`SELECT r.id,r.user_id,r.name,r.mobile,r.email,r.category,r.subject,r.message,r.status,r.priority,r.public_reference,r.admin_note,r.created_at,r.updated_at,r.resolved_at,a.name assigned_admin_name,h.name handled_by_name,(SELECT m.message FROM support_messages m WHERE m.request_id=r.id AND m.is_internal=0 ORDER BY m.created_at DESC LIMIT 1) AS last_message,(SELECT COUNT(*) FROM support_messages m WHERE m.request_id=r.id AND m.author_type='user' AND m.read_at IS NULL) AS unread_count,(SELECT COUNT(*) FROM support_messages m WHERE m.request_id=r.id) AS message_count FROM support_requests r LEFT JOIN admins a ON a.id=r.assigned_admin_id LEFT JOIN admins h ON h.id=r.handled_by_admin_id ${clause} ORDER BY CASE WHEN (SELECT COUNT(*) FROM support_messages m WHERE m.request_id=r.id AND m.author_type='user' AND m.read_at IS NULL)>0 THEN 0 ELSE 1 END,CASE r.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END,CASE r.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,r.updated_at DESC LIMIT 300`).all(params),metrics=db.prepare(`SELECT COUNT(*) total,SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) open,SUM(CASE WHEN status='in_progress' THEN 1 ELSE 0 END) in_progress,SUM(CASE WHEN status='resolved' THEN 1 ELSE 0 END) resolved,SUM(CASE WHEN priority IN ('high','urgent') AND status IN ('open','in_progress') THEN 1 ELSE 0 END) priority,(SELECT COUNT(*) FROM support_messages WHERE author_type='user' AND read_at IS NULL) unread FROM support_requests`).get();res.json({rows,metrics})});
app.get('/api/admin/support/requests/:id',allowPermissions('users.view','users.security'),(req,res)=>{const item=db.prepare(`SELECT r.*,a.name assigned_admin_name,h.name handled_by_name FROM support_requests r LEFT JOIN admins a ON a.id=r.assigned_admin_id LEFT JOIN admins h ON h.id=r.handled_by_admin_id WHERE r.id=?`).get(req.params.id);if(!item)return res.status(404).json({error:'درخواست پشتیبانی پیدا نشد.'});db.prepare("UPDATE support_messages SET read_at=COALESCE(read_at,?) WHERE request_id=? AND author_type='user'").run(iso(),item.id);res.json({item,messages:supportMessages(item.id,true)})});
app.post('/api/admin/support/requests/:id/messages',allowPermissions('users.manage','users.security'),(req,res)=>{const item=db.prepare('SELECT * FROM support_requests WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'درخواست پشتیبانی پیدا نشد.'});const message=String(req.body.message||'').trim(),isInternal=!!req.body.isInternal,status=['open','in_progress','resolved','closed'].includes(req.body.status)?req.body.status:(isInternal?item.status:'in_progress');if(message.length<2||message.length>4000)return res.status(400).json({error:'متن پاسخ باید بین ۲ تا ۴۰۰۰ کاراکتر باشد.'});const now=iso(),resolvedAt=['resolved','closed'].includes(status)?item.resolved_at||now:null;db.transaction(()=>{db.prepare(`INSERT INTO support_messages (id,request_id,author_type,user_id,admin_id,message,is_internal,created_at,read_at) VALUES (?,?,'admin',NULL,?,?,?, ?,NULL)`).run(id('support_message'),item.id,req.admin.id,message,isInternal?1:0,now);db.prepare('UPDATE support_requests SET status=?,assigned_admin_id=COALESCE(assigned_admin_id,?),handled_by_admin_id=?,updated_at=?,resolved_at=? WHERE id=?').run(status,req.admin.id,req.admin.id,now,resolvedAt,item.id)})();logAudit({adminId:req.admin.id,action:isInternal?'SUPPORT_INTERNAL_NOTE_ADDED':'SUPPORT_REPLY_SENT',entityType:'support_request',entityId:item.id,details:{reference:item.public_reference,status,isInternal},ip:clientIp(req)});res.status(201).json({ok:true,status,updatedAt:now})});
app.patch('/api/admin/support/requests/:id',allowPermissions('users.manage','users.security'),(req,res)=>{const item=db.prepare('SELECT * FROM support_requests WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'درخواست پشتیبانی پیدا نشد.'});const status=['open','in_progress','resolved','closed','spam'].includes(req.body.status)?req.body.status:item.status,priority=['low','normal','high','urgent'].includes(req.body.priority)?req.body.priority:item.priority,note=String(req.body.adminNote??item.admin_note??'').trim();if(note.length>4000)return res.status(400).json({error:'یادداشت داخلی بیش از حد طولانی است.'});const now=iso(),resolvedAt=['resolved','closed'].includes(status)?item.resolved_at||now:null;db.prepare('UPDATE support_requests SET status=?,priority=?,admin_note=?,assigned_admin_id=COALESCE(assigned_admin_id,?),handled_by_admin_id=?,updated_at=?,resolved_at=? WHERE id=?').run(status,priority,note||null,req.admin.id,req.admin.id,now,resolvedAt,item.id);logAudit({adminId:req.admin.id,action:'SUPPORT_REQUEST_UPDATED',entityType:'support_request',entityId:item.id,details:{reference:item.public_reference,fromStatus:item.status,toStatus:status,fromPriority:item.priority,toPriority:priority},ip:clientIp(req)});res.json({ok:true,status,priority,updatedAt:now})});

function planInput(body,current={}){
  const name=String(body.name??current.name??'').trim().toLowerCase(),nameFa=String(body.nameFa??current.name_fa??'').trim(),priceMonthly=Math.round(Number(body.priceMonthly??current.price_monthly??0)),maxTrades=Number(body.maxTrades??current.max_trades??100),maxStorageBytes=Math.round(Number(body.maxStorageBytes??current.max_storage_bytes??104857600)),maxSmsMonthly=Number(body.maxSmsMonthly??current.max_sms_monthly??5),durationDays=Number(body.durationDays??current.duration_days??30),color=String(body.color??current.color??'#22d3ee').trim(),tagline=String(body.tagline??current.tagline??'').trim(),badgeLabel=String(body.badgeLabel??current.badge_label??'').trim(),ctaLabel=String(body.ctaLabel??current.cta_label??'شروع رایگان').trim(),sortOrder=Number(body.sortOrder??current.sort_order??0),isRecommended=body.isRecommended===undefined?!!current.is_recommended:!!body.isRecommended,isActive=body.isActive===undefined?current.is_active!==0:!!body.isActive,discountPercent=Math.round(Number(body.discountPercent??current.discount_percent??0)),discountPriceRaw=body.discountPrice===undefined?(current.discount_price??null):body.discountPrice,discountPrice=discountPriceRaw===null||discountPriceRaw===''?null:Math.round(Number(discountPriceRaw)),discountLabel=String(body.discountLabel??current.discount_label??'').trim(),discountUntilRaw=body.discountUntil===undefined?(current.discount_until??''):body.discountUntil,discountUntil=String(discountUntilRaw||'').trim();
  if(!/^[a-z0-9][a-z0-9-]{1,39}$/.test(name)||nameFa.length<2||nameFa.length>80)return{error:'شناسه انگلیسی یا نام فارسی پلن معتبر نیست.'};
  if(!Number.isInteger(priceMonthly)||priceMonthly<0||priceMonthly>1000000000)return{error:'قیمت ماهانه معتبر نیست.'};
  if(!Number.isInteger(maxTrades)||maxTrades<10||maxTrades>1000000)return{error:'محدودیت تعداد معامله معتبر نیست.'};
  if(!Number.isFinite(maxStorageBytes)||maxStorageBytes<50*1024*1024||maxStorageBytes>100*1024*1024*1024)return{error:'حجم فضای تصاویر باید بین ۵۰ مگابایت تا ۱۰۰ گیگابایت باشد.'};
  if(!Number.isInteger(maxSmsMonthly)||maxSmsMonthly<1||maxSmsMonthly>10000)return{error:'سقف پیامک معتبر نیست.'};
  if(!Number.isInteger(durationDays)||durationDays<0||durationDays>3650)return{error:'مدت دسترسی پلن باید صفر (نامحدود) یا بین ۱ تا ۳۶۵۰ روز باشد.'};
  if(!Number.isInteger(discountPercent)||discountPercent<0||discountPercent>95)return{error:'درصد تخفیف باید عددی بین ۰ تا ۹۵ باشد.'};
  if(discountPrice!==null&&(!Number.isInteger(discountPrice)||discountPrice<0||discountPrice>1000000000))return{error:'قیمت با تخفیف معتبر نیست.'};
  if(discountPrice!==null&&priceMonthly>0&&discountPrice>=priceMonthly)return{error:'قیمت با تخفیف باید کمتر از قیمت اصلی باشد.'};
  if(discountLabel.length>60)return{error:'متن تخفیف حداکثر ۶۰ نویسه است.'};
  if(discountUntil&&Number.isNaN(Date.parse(discountUntil)))return{error:'تاریخ پایان تخفیف معتبر نیست.'};
  if(!/^#[0-9a-f]{6}$/i.test(color)||tagline.length>240||badgeLabel.length>80||ctaLabel.length<2||ctaLabel.length>80||!Number.isInteger(sortOrder)||sortOrder<0||sortOrder>10000)return{error:'متن معرفی، نشان، دکمه، رنگ یا ترتیب پلن معتبر نیست.'};
  let features=null;
  if(Array.isArray(body.features)){
    if(body.features.length>30)return{error:'برای هر پلن حداکثر ۳۰ قابلیت قابل تعریف است.'};
    features=body.features.map((feature,index)=>({featureKey:String(feature.featureKey||`feature-${index+1}`).trim().toLowerCase(),label:String(feature.label||'').trim(),description:String(feature.description||'').trim(),isEnabled:feature.isEnabled!==false,sortOrder:(index+1)*10}));
    if(features.some(feature=>!/^[a-z0-9][a-z0-9_-]{1,49}$/.test(feature.featureKey)||feature.label.length<2||feature.label.length>160||feature.description.length>500)||new Set(features.map(feature=>feature.featureKey)).size!==features.length)return{error:'کلید، عنوان یا توضیح قابلیت‌های پلن معتبر نیست.'};
  }
  let journalSections=null;
  if(Array.isArray(body.journalSections)){
    journalSections=body.journalSections.map((section,index)=>({sectionKey:String(typeof section==='string'?section:section.sectionKey||section.section_key||'').trim(),isEnabled:typeof section==='string'?true:section.isEnabled!==false,sortOrder:(index+1)*10}));
    if(journalSections.some(section=>!JOURNAL_SECTION_KEYS.has(section.sectionKey))||new Set(journalSections.map(section=>section.sectionKey)).size!==journalSections.length)return{error:'یکی از بخش‌های دسترسی ژورنال معتبر یا یکتا نیست.'};
  }
  return{name,nameFa,priceMonthly,maxTrades,maxStorageBytes,maxSmsMonthly,durationDays,color,tagline,badgeLabel,ctaLabel,sortOrder,isRecommended,isActive,discountPercent,discountPrice,discountLabel,discountUntil:discountUntil?new Date(discountUntil).toISOString():null,features,journalSections};
}
function replacePlanFeatures(planId,features,now){
  if(!features)return;
  db.prepare('DELETE FROM plan_features WHERE plan_id=?').run(planId);
  const insert=db.prepare('INSERT INTO plan_features (id,plan_id,feature_key,label,description,is_enabled,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
  features.forEach(feature=>insert.run(id('plan_feature'),planId,feature.featureKey,feature.label,feature.description||null,feature.isEnabled?1:0,feature.sortOrder,now,now));
}
function replacePlanJournalSections(planId,sections,now){
  if(!sections)return;
  db.prepare('DELETE FROM plan_journal_sections WHERE plan_id=?').run(planId);
  const selected=new Map(sections.map(section=>[section.sectionKey,section])),insert=db.prepare('INSERT INTO plan_journal_sections (id,plan_id,section_key,is_enabled,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');
  JOURNAL_SECTION_DEFINITIONS.forEach(([sectionKey],index)=>{const section=selected.get(sectionKey);insert.run(id('plan_section'),planId,sectionKey,section?.isEnabled?1:0,section?.sortOrder||((index+1)*10),now,now)});
}
function adminPlans(){
  const rows=db.prepare(`SELECT p.*,COUNT(s.id) AS subscribers,SUM(CASE WHEN s.status='active' THEN 1 ELSE 0 END) AS active_subscribers FROM plans p LEFT JOIN subscriptions s ON s.plan_id=p.id GROUP BY p.id ORDER BY p.sort_order,p.price_monthly,p.id`).all(),features=db.prepare('SELECT * FROM plan_features ORDER BY sort_order,id').all(),sections=db.prepare('SELECT * FROM plan_journal_sections ORDER BY sort_order,id').all(),byPlan={},sectionsByPlan={},labels=new Map(JOURNAL_SECTION_DEFINITIONS);
  features.forEach(feature=>(byPlan[feature.plan_id]||(byPlan[feature.plan_id]=[])).push({...feature,is_enabled:!!feature.is_enabled}));sections.forEach(section=>(sectionsByPlan[section.plan_id]||(sectionsByPlan[section.plan_id]=[])).push({...section,label:labels.get(section.section_key)||section.section_key,is_enabled:!!section.is_enabled}));
  return rows.map(plan=>({...withPricing(plan),is_active:!!plan.is_active,is_recommended:!!plan.is_recommended,duration_days:Number(plan.duration_days||0),features:byPlan[plan.id]||[],journal_sections:sectionsByPlan[plan.id]||[]}));
}
app.get('/api/admin/plans', allowPermissions('billing.view'), (req,res)=>res.json({rows:adminPlans()}));
app.post('/api/admin/plans', allowPermissions('billing.manage'), (req,res)=>{
  const input=planInput(req.body);if(input.error)return res.status(400).json({error:input.error});
  if(db.prepare('SELECT 1 FROM plans WHERE name=?').get(input.name))return res.status(409).json({error:'این شناسه پلن قبلاً استفاده شده است.'});
  const planId=id('plan'),now=iso();db.transaction(()=>{if(input.isRecommended)db.prepare('UPDATE plans SET is_recommended=0').run();db.prepare(`INSERT INTO plans (id,name,name_fa,price_monthly,max_trades,max_storage_bytes,max_sms_monthly,color,tagline,badge_label,cta_label,is_recommended,sort_order,duration_days,discount_percent,discount_price,discount_label,discount_until,is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(planId,input.name,input.nameFa,input.priceMonthly,input.maxTrades,input.maxStorageBytes,input.maxSmsMonthly,input.color,input.tagline||null,input.badgeLabel||null,input.ctaLabel,input.isRecommended?1:0,input.sortOrder,input.durationDays,input.discountPercent,input.discountPrice,input.discountLabel||null,input.discountUntil,input.isActive?1:0);replacePlanFeatures(planId,input.features||[],now);replacePlanJournalSections(planId,input.journalSections||JOURNAL_SECTION_DEFINITIONS.map(([sectionKey])=>({sectionKey,isEnabled:sectionKey==='dashboard'})),now)})();
  logAudit({adminId:req.admin.id,action:'PLAN_CREATED',entityType:'plan',entityId:planId,details:{name:input.name,nameFa:input.nameFa,features:input.features?.length||0,journalSections:input.journalSections?.filter(item=>item.isEnabled).map(item=>item.sectionKey)||[],durationDays:input.durationDays,isActive:input.isActive},ip:clientIp(req)});res.status(201).json({ok:true,id:planId});
});
app.patch('/api/admin/plans/:id', allowPermissions('billing.manage'), (req,res)=>{
  const plan=db.prepare('SELECT * FROM plans WHERE id=?').get(req.params.id);if(!plan)return res.status(404).json({error:'پلن پیدا نشد.'});
  const input=planInput(req.body,plan);if(input.error)return res.status(400).json({error:input.error});
  if(db.prepare('SELECT 1 FROM plans WHERE name=? AND id!=?').get(input.name,plan.id))return res.status(409).json({error:'این شناسه پلن قبلاً استفاده شده است.'});
  const activeSubscribers=Number(db.prepare("SELECT COUNT(*) count FROM subscriptions WHERE plan_id=? AND status='active'").get(plan.id).count||0);if(!input.isActive&&activeSubscribers)return res.status(409).json({error:'پلن دارای اشتراک فعال است و پیش از غیرفعال‌سازی باید مشترکان منتقل شوند.'});
  const now=iso();db.transaction(()=>{if(input.isRecommended)db.prepare('UPDATE plans SET is_recommended=0 WHERE id!=?').run(plan.id);db.prepare(`UPDATE plans SET name=?,name_fa=?,price_monthly=?,max_trades=?,max_storage_bytes=?,max_sms_monthly=?,color=?,tagline=?,badge_label=?,cta_label=?,is_recommended=?,sort_order=?,duration_days=?,discount_percent=?,discount_price=?,discount_label=?,discount_until=?,is_active=? WHERE id=?`).run(input.name,input.nameFa,input.priceMonthly,input.maxTrades,input.maxStorageBytes,input.maxSmsMonthly,input.color,input.tagline||null,input.badgeLabel||null,input.ctaLabel,input.isRecommended?1:0,input.sortOrder,input.durationDays,input.discountPercent,input.discountPrice,input.discountLabel||null,input.discountUntil,input.isActive?1:0,plan.id);replacePlanFeatures(plan.id,input.features,now);replacePlanJournalSections(plan.id,input.journalSections,now)})();
  logAudit({adminId:req.admin.id,action:'PLAN_UPDATED',entityType:'plan',entityId:plan.id,details:{from:{name:plan.name,price:plan.price_monthly,active:!!plan.is_active,discountPercent:plan.discount_percent||0,discountPrice:plan.discount_price||null},to:{name:input.name,price:input.priceMonthly,active:input.isActive,durationDays:input.durationDays,discountPercent:input.discountPercent,discountPrice:input.discountPrice,discountUntil:input.discountUntil},features:input.features?.length,journalSections:input.journalSections?.filter(item=>item.isEnabled).map(item=>item.sectionKey)},ip:clientIp(req)});res.json({ok:true});
});
app.delete('/api/admin/plans/:id',allowPermissions('billing.manage'),(req,res)=>{
  const plan=db.prepare('SELECT * FROM plans WHERE id=?').get(req.params.id);if(!plan)return res.status(404).json({error:'پلن پیدا نشد.'});if(plan.id==='plan_free')return res.status(400).json({error:'پلن پایه رایگان قابل حذف نیست.'});
  const subscribers=Number(db.prepare('SELECT COUNT(*) count FROM subscriptions WHERE plan_id=?').get(plan.id).count||0);if(subscribers)return res.status(409).json({error:'پلنی که سابقه اشتراک دارد حذف نمی‌شود؛ می‌توانید آن را غیرفعال کنید.'});
  db.prepare('DELETE FROM plans WHERE id=?').run(plan.id);logAudit({adminId:req.admin.id,action:'PLAN_DELETED',entityType:'plan',entityId:plan.id,details:{name:plan.name,nameFa:plan.name_fa},ip:clientIp(req)});res.json({ok:true});
});

function faqInput(body,current={}){
  const category=String(body.category??current.category??'product'),question=String(body.question??current.question??'').trim(),answer=String(body.answer??current.answer??'').trim(),status=String(body.status??current.status??'draft'),isFeatured=body.isFeatured===undefined?!!current.is_featured:!!body.isFeatured,sortOrder=Number(body.sortOrder??current.sort_order??0);
  if(!['why','product','security','pricing','privacy','support'].includes(category)||question.length<8||question.length>240||answer.length<20||answer.length>3000||!['draft','published','archived'].includes(status)||!Number.isInteger(sortOrder)||sortOrder<0||sortOrder>10000)return{error:'دسته‌بندی، سؤال، پاسخ، وضعیت یا ترتیب معتبر نیست.'};return{category,question,answer,status,isFeatured,sortOrder};
}
app.get('/api/admin/marketing/faqs',allowPermissions('content.manage'),(req,res)=>{const rows=db.prepare('SELECT * FROM marketing_faqs ORDER BY CASE status WHEN \'published\' THEN 0 WHEN \'draft\' THEN 1 ELSE 2 END,sort_order,created_at').all().map(item=>({...item,is_featured:!!item.is_featured}));res.json({rows})});
app.post('/api/admin/marketing/faqs',allowPermissions('content.manage'),(req,res)=>{const input=faqInput(req.body);if(input.error)return res.status(400).json({error:input.error});const faqId=id('marketing_faq'),now=iso();db.prepare('INSERT INTO marketing_faqs (id,category,question,answer,status,is_featured,sort_order,created_at,updated_at,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?)').run(faqId,input.category,input.question,input.answer,input.status,input.isFeatured?1:0,input.sortOrder,now,now,req.admin.id);logAudit({adminId:req.admin.id,action:'MARKETING_FAQ_CREATED',entityType:'marketing_faq',entityId:faqId,details:{category:input.category,status:input.status,question:input.question},ip:clientIp(req)});res.status(201).json({ok:true,id:faqId})});
app.patch('/api/admin/marketing/faqs/:id',allowPermissions('content.manage'),(req,res)=>{const item=db.prepare('SELECT * FROM marketing_faqs WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'سؤال پیدا نشد.'});const input=faqInput(req.body,item);if(input.error)return res.status(400).json({error:input.error});const now=iso();db.prepare('UPDATE marketing_faqs SET category=?,question=?,answer=?,status=?,is_featured=?,sort_order=?,updated_at=?,updated_by_admin_id=? WHERE id=?').run(input.category,input.question,input.answer,input.status,input.isFeatured?1:0,input.sortOrder,now,req.admin.id,item.id);logAudit({adminId:req.admin.id,action:'MARKETING_FAQ_UPDATED',entityType:'marketing_faq',entityId:item.id,details:{fromStatus:item.status,toStatus:input.status,question:input.question},ip:clientIp(req)});res.json({ok:true})});
app.delete('/api/admin/marketing/faqs/:id',allowPermissions('content.manage'),(req,res)=>{const item=db.prepare('SELECT * FROM marketing_faqs WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'سؤال پیدا نشد.'});db.prepare('DELETE FROM marketing_faqs WHERE id=?').run(item.id);logAudit({adminId:req.admin.id,action:'MARKETING_FAQ_DELETED',entityType:'marketing_faq',entityId:item.id,details:{question:item.question,status:item.status},ip:clientIp(req)});res.json({ok:true})});

app.get('/api/admin/coupons', allowPermissions('billing.view'), (req, res) => {
  const rows = db.prepare('SELECT * FROM coupons ORDER BY created_at DESC').all();
  res.json({ rows });
});

app.post('/api/admin/coupons', allowPermissions('billing.manage'), (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const discountType = req.body.discountType === 'fixed' ? 'fixed' : 'percent';
  const value = Number(req.body.value);
  const maxUses = req.body.maxUses ? Number(req.body.maxUses) : null;
  const startsAt = req.body.startsAt ? new Date(req.body.startsAt) : new Date();
  const expiresAt = req.body.expiresAt ? new Date(req.body.expiresAt) : null;
  if (!/^[A-Z0-9_-]{4,24}$/.test(code)) return res.status(400).json({ error: 'کد تخفیف باید ۴ تا ۲۴ کاراکتر انگلیسی باشد.' });
  if (!Number.isFinite(value) || value <= 0 || (discountType === 'percent' && value > 100)) return res.status(400).json({ error: 'مقدار تخفیف معتبر نیست.' });
  if (maxUses !== null && (!Number.isInteger(maxUses) || maxUses < 1 || maxUses > 1000000)) return res.status(400).json({ error: 'ظرفیت مصرف کد تخفیف معتبر نیست.' });
  if (Number.isNaN(startsAt.getTime()) || (expiresAt && (Number.isNaN(expiresAt.getTime()) || expiresAt <= startsAt))) return res.status(400).json({ error: 'بازه زمانی کد تخفیف معتبر نیست.' });
  try {
    const couponId = id('coupon');
    db.prepare(`INSERT INTO coupons (id,code,discount_type,value,max_uses,used_count,starts_at,expires_at,is_active,created_at)
      VALUES (?,?,?,?,?,0,?,?,1,?)`).run(couponId, code, discountType, Math.round(value), maxUses && Math.round(maxUses), startsAt.toISOString(), expiresAt && expiresAt.toISOString(), iso());
    logAudit({ adminId: req.admin.id, action: 'COUPON_CREATED', entityType: 'coupon', entityId: couponId, details: { code, discountType, value }, ip: clientIp(req) });
    res.status(201).json({ ok: true, id: couponId });
  } catch (error) {
    if (String(error.message).includes('UNIQUE')) return res.status(409).json({ error: 'این کد تخفیف قبلاً ساخته شده است.' });
    throw error;
  }
});

app.patch('/api/admin/coupons/:id', allowPermissions('billing.manage'), (req, res) => {
  const coupon = db.prepare('SELECT * FROM coupons WHERE id=?').get(req.params.id);
  if (!coupon) return res.status(404).json({ error: 'کد تخفیف پیدا نشد.' });
  const isActive = req.body.isActive === undefined ? coupon.is_active : req.body.isActive ? 1 : 0;
  db.prepare('UPDATE coupons SET is_active=? WHERE id=?').run(isActive, coupon.id);
  logAudit({ adminId: req.admin.id, action: 'COUPON_STATUS_UPDATED', entityType: 'coupon', entityId: coupon.id, details: { code: coupon.code, isActive: !!isActive }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.get('/api/admin/payments', allowPermissions('billing.view'), (req, res) => {
  const page = parsePositiveInt(req.query.page, 1, 100000), limit = parsePositiveInt(req.query.limit, 15, 50);
  const search = String(req.query.search || '').trim();
  const statuses = ['paid','pending','failed','refunded','partially_refunded'];
  const status = statuses.includes(req.query.status) ? req.query.status : '';
  const where = [], params = {};
  if (search) { where.push("(u.name LIKE @search ESCAPE '\\' OR u.mobile LIKE @search ESCAPE '\\' OR pay.invoice_number LIKE @search ESCAPE '\\')"); params.search = safeLike(search); }
  if (status) { where.push('pay.status=@status'); params.status = status; }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS count FROM payments pay JOIN users u ON u.id=pay.user_id ${clause}`).get(params).count;
  const rows = db.prepare(`SELECT pay.*,u.name AS user_name,u.mobile,p.name_fa AS plan_fa,p.color AS plan_color
    FROM payments pay JOIN users u ON u.id=pay.user_id LEFT JOIN subscriptions s ON s.id=pay.subscription_id LEFT JOIN plans p ON p.id=s.plan_id
    ${clause} ORDER BY pay.created_at DESC LIMIT @limit OFFSET @offset`).all({ ...params, limit, offset: (page - 1) * limit });
  res.json({ rows, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } });
});

app.get('/api/admin/payments/:id/invoice', allowPermissions('billing.view'), (req, res) => {
  const row = db.prepare(`SELECT pay.*,u.name AS user_name,u.mobile,p.name_fa AS plan_fa,s.started_at,s.expires_at,c.code AS coupon_code
    FROM payments pay JOIN users u ON u.id=pay.user_id LEFT JOIN subscriptions s ON s.id=pay.subscription_id LEFT JOIN plans p ON p.id=s.plan_id LEFT JOIN coupons c ON c.id=s.coupon_id WHERE pay.id=?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'فاکتور پیدا نشد.' });
  res.json({ invoice: row });
});

app.post('/api/admin/payments/:id/refund', allowPermissions('billing.refund'), (req, res) => {
  const payment = db.prepare('SELECT * FROM payments WHERE id=?').get(req.params.id);
  if (!payment) return res.status(404).json({ error: 'پرداخت پیدا نشد.' });
  if (!['paid','partially_refunded'].includes(payment.status)) return res.status(400).json({ error: 'این پرداخت قابل بازپرداخت نیست.' });
  const refundable = payment.amount - payment.refunded_amount;
  const amount = req.body.amount ? Number(req.body.amount) : refundable;
  if (!Number.isFinite(amount) || amount <= 0 || amount > refundable) return res.status(400).json({ error: 'مبلغ بازپرداخت معتبر نیست.' });
  const refundedAmount = payment.refunded_amount + Math.round(amount), status = refundedAmount >= payment.amount ? 'refunded' : 'partially_refunded';
  db.prepare('UPDATE payments SET refunded_amount=?,status=?,refunded_at=? WHERE id=?').run(refundedAmount, status, iso(), payment.id);
  logAudit({ adminId: req.admin.id, action: 'PAYMENT_REFUNDED', entityType: 'payment', entityId: payment.id, details: { invoice: payment.invoice_number, amount: Math.round(amount), status }, ip: clientIp(req) });
  res.json({ ok: true, refundedAmount, status });
});

app.get('/api/admin/subscriptions', allowPermissions('billing.view'), (req, res) => {
  const page = parsePositiveInt(req.query.page, 1, 100000);
  const limit = parsePositiveInt(req.query.limit, 15, 50);
  const search = String(req.query.search || '').trim();
  const status = ['active', 'expired', 'cancelled', 'trial'].includes(req.query.status) ? req.query.status : '';
  const plan = ['free', 'pro', 'organization'].includes(req.query.plan) ? req.query.plan : '';
  const where = [], params = {};
  if (search) { where.push("(u.name LIKE @search ESCAPE '\\' OR u.mobile LIKE @search ESCAPE '\\')"); params.search = safeLike(search); }
  if (status) { where.push('s.status=@status'); params.status = status; }
  if (plan) { where.push('p.name=@plan'); params.plan = plan; }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS count FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN plans p ON p.id=s.plan_id ${clause}`).get(params).count;
  const rows = db.prepare(`SELECT s.*,u.name AS user_name,u.mobile,u.status AS user_status,p.name AS plan,p.name_fa AS plan_fa,p.price_monthly,p.color AS plan_color,
    c.code AS coupon_code,(SELECT pay.status FROM payments pay WHERE pay.subscription_id=s.id ORDER BY pay.created_at DESC LIMIT 1) AS payment_status
    FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN plans p ON p.id=s.plan_id LEFT JOIN coupons c ON c.id=s.coupon_id
    ${clause} ORDER BY s.updated_at DESC LIMIT @limit OFFSET @offset`).all({ ...params, limit, offset: (page - 1) * limit });
  res.json({ rows, pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) } });
});

app.get('/api/admin/subscriptions/:id', allowPermissions('billing.view'), (req, res) => {
  const row = db.prepare(`SELECT s.*,u.name AS user_name,u.mobile,u.status AS user_status,p.name AS plan,p.name_fa AS plan_fa,p.price_monthly,p.color AS plan_color,c.code AS coupon_code,
    (SELECT pay.status FROM payments pay WHERE pay.subscription_id=s.id ORDER BY pay.created_at DESC LIMIT 1) AS payment_status
    FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN plans p ON p.id=s.plan_id LEFT JOIN coupons c ON c.id=s.coupon_id WHERE s.id=?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'اشتراک پیدا نشد.' });
  res.json({ row });
});

app.patch('/api/admin/subscriptions/:id', allowPermissions('billing.manage'), (req, res) => {
  const current = db.prepare(`SELECT s.*,u.name AS user_name,p.name_fa AS plan_fa FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN plans p ON p.id=s.plan_id WHERE s.id=?`).get(req.params.id);
  if (!current) return res.status(404).json({ error: 'اشتراک پیدا نشد.' });
  const planId = String(req.body.planId || current.plan_id);
  const status = String(req.body.status || current.status);
  const startedAtDate = req.body.startedAt ? new Date(req.body.startedAt) : new Date(current.started_at);
  let expiresAtDate = req.body.expiresAt ? new Date(req.body.expiresAt) : current.expires_at ? new Date(current.expires_at) : null;
  let autoRenew = req.body.autoRenew === undefined ? current.auto_renew : req.body.autoRenew ? 1 : 0;
  if (!['active', 'expired', 'cancelled', 'trial'].includes(status)) return res.status(400).json({ error: 'وضعیت اشتراک معتبر نیست.' });
  if (Number.isNaN(startedAtDate.getTime()) || (expiresAtDate && (Number.isNaN(expiresAtDate.getTime()) || expiresAtDate <= startedAtDate))) return res.status(400).json({ error: 'تاریخ شروع و پایان اشتراک معتبر نیست.' });
  const plan = db.prepare('SELECT id,name_fa,price_monthly,duration_days,discount_percent,discount_price,discount_label,discount_until FROM plans WHERE id=? AND is_active=1').get(planId);
  if (!plan) return res.status(400).json({ error: 'پلن انتخاب‌شده معتبر نیست.' });
  if(req.body.applyPlanDuration)expiresAtDate=Number(plan.duration_days||0)>0?new Date(startedAtDate.getTime()+Number(plan.duration_days)*86400000):null;
  const couponCode = String(req.body.couponCode || '').trim().toUpperCase();
  let coupon = null, discountAmount = 0;
  if (couponCode) {
    coupon = db.prepare(`SELECT * FROM coupons WHERE code=? AND is_active=1 AND starts_at<=? AND (expires_at IS NULL OR expires_at>?)
      AND (max_uses IS NULL OR used_count<max_uses)`).get(couponCode, iso(), iso());
    if (!coupon) return res.status(400).json({ error: 'کد تخفیف معتبر، فعال یا دارای ظرفیت نیست.' });
    const basePrice = payablePrice(plan);
    discountAmount = coupon.discount_type === 'percent' ? Math.round(basePrice * coupon.value / 100) : Math.min(basePrice, coupon.value);
  }
  if (status === 'cancelled') autoRenew = 0;
  const tx = db.transaction(() => {
    db.prepare('UPDATE subscriptions SET plan_id=?,status=?,started_at=?,expires_at=?,auto_renew=?,coupon_id=?,discount_amount=?,updated_at=? WHERE id=?')
      .run(plan.id, status, startedAtDate.toISOString(), expiresAtDate && expiresAtDate.toISOString(), autoRenew, coupon && coupon.id, discountAmount, iso(), current.id);
    if (coupon && current.coupon_id !== coupon.id) db.prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=?').run(coupon.id);
  });
  tx();
  const action = status === 'active' && current.status !== 'active' ? 'SUBSCRIPTION_MANUALLY_ACTIVATED' : status === 'cancelled' ? 'SUBSCRIPTION_CANCELLED' : 'SUBSCRIPTION_UPDATED';
  logAudit({ adminId: req.admin.id, action, entityType: 'subscription', entityId: current.id, details: { user: current.user_name, fromPlan: current.plan_fa, toPlan: plan.name_fa, fromStatus: current.status, toStatus: status, coupon: couponCode || null, discountAmount }, ip: clientIp(req) });
  res.json({ ok: true, discountAmount });
});

app.get('/api/admin/usage', allowPermissions('resources.view','resources.security'), (req, res) => {
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const settings = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  const windowStart = new Date(Date.now() - Number(settings.rate_window_minutes) * 60000).toISOString();
  const sms = db.prepare(`SELECT COUNT(*) AS total,
    SUM(CASE WHEN status!='failed' THEN 1 ELSE 0 END) AS sent,
    SUM(CASE WHEN status='delivered' THEN 1 ELSE 0 END) AS delivered,
    SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed,
    SUM(CASE WHEN is_suspicious=1 THEN 1 ELSE 0 END) AS suspicious,
    COALESCE(SUM(cost),0) AS cost
    FROM sms_logs WHERE created_at>=?`).get(monthStart.toISOString());
  const storage = db.prepare(`SELECT COALESCE(SUM(storage_bytes),0) AS total,COALESCE(AVG(storage_bytes),0) AS average,MAX(storage_bytes) AS largest FROM users WHERE deleted_at IS NULL`).get();
  const topStorage = db.prepare(`SELECT u.id,u.name,u.mobile,u.storage_bytes,p.name_fa AS plan_fa,p.max_storage_bytes,p.color
    FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id LEFT JOIN plans p ON p.id=s.plan_id WHERE u.deleted_at IS NULL ORDER BY u.storage_bytes DESC LIMIT 10`).all();
  const smsLogs = db.prepare(`SELECT l.*,u.name AS user_name FROM sms_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT 40`).all();
  const failedSms = db.prepare(`SELECT l.*,u.name AS user_name FROM sms_logs l LEFT JOIN users u ON u.id=l.user_id WHERE l.status='failed' ORDER BY l.created_at DESC LIMIT 30`).all();
  const suspiciousRequests = db.prepare(`SELECT l.*,u.name AS user_name FROM sms_logs l LEFT JOIN users u ON u.id=l.user_id
    WHERE l.is_suspicious=1 ORDER BY l.created_at DESC LIMIT 30`).all();
  const mobileRateUsage = db.prepare(`SELECT mobile,COUNT(*) AS request_count,MAX(created_at) AS last_request_at,
    SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed_count FROM sms_logs WHERE created_at>=? GROUP BY mobile ORDER BY request_count DESC LIMIT 12`).all(windowStart);
  const ipRateUsage = db.prepare(`SELECT request_ip,COUNT(*) AS request_count,MAX(created_at) AS last_request_at,
    COUNT(DISTINCT mobile) AS mobile_count,SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed_count
    FROM sms_logs WHERE created_at>=? AND request_ip IS NOT NULL GROUP BY request_ip ORDER BY request_count DESC LIMIT 12`).all(windowStart);
  const providers = db.prepare(`SELECT p.*,
    (SELECT COUNT(*) FROM sms_logs l WHERE l.provider=p.name AND l.created_at>=?) AS month_total,
    (SELECT COUNT(*) FROM sms_logs l WHERE l.provider=p.name AND l.created_at>=? AND l.status='failed') AS month_failed,
    (SELECT COALESCE(SUM(l.cost),0) FROM sms_logs l WHERE l.provider=p.name AND l.created_at>=?) AS month_cost
    FROM sms_providers p ORDER BY p.is_primary DESC,p.priority,p.name`).all(monthStart.toISOString(), monthStart.toISOString(), monthStart.toISOString()).map(sanitizeSmsProvider);
  const providerBalance = providers.filter(provider => provider.is_enabled).reduce((sum, provider) => sum + Number(provider.balance || 0), 0);
  res.json({ sms, settings, providers, providerBalance, storage, topStorage, smsLogs, failedSms, suspiciousRequests,
    rateUsage: { windowStart, mobiles: mobileRateUsage, ips: ipRateUsage } });
});

app.patch('/api/admin/sms/settings', allowPermissions('resources.manage'), (req, res) => {
  const current = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  const otpTemplate = String(req.body.otpTemplate ?? current.otp_template).trim();
  const mobileLimit = Number(req.body.mobileLimit ?? current.mobile_limit_count);
  const ipLimit = Number(req.body.ipLimit ?? current.ip_limit_count);
  const rateWindowMinutes = Number(req.body.rateWindowMinutes ?? current.rate_window_minutes);
  const autoFailover = req.body.autoFailover === undefined ? current.auto_failover : req.body.autoFailover ? 1 : 0;
  if (otpTemplate.length < 10 || otpTemplate.length > 500 || !otpTemplate.includes('{code}')) {
    return res.status(400).json({ error: 'متن OTP باید بین ۱۰ تا ۵۰۰ کاراکتر و شامل {code} باشد.' });
  }
  if (!Number.isInteger(mobileLimit) || mobileLimit < 1 || mobileLimit > 50) return res.status(400).json({ error: 'محدودیت هر شماره باید بین ۱ تا ۵۰ باشد.' });
  if (!Number.isInteger(ipLimit) || ipLimit < 1 || ipLimit > 200) return res.status(400).json({ error: 'محدودیت هر IP باید بین ۱ تا ۲۰۰ باشد.' });
  if (!Number.isInteger(rateWindowMinutes) || rateWindowMinutes < 1 || rateWindowMinutes > 1440) return res.status(400).json({ error: 'بازه محدودسازی باید بین ۱ دقیقه تا ۲۴ ساعت باشد.' });
  db.prepare(`UPDATE sms_settings SET otp_template=?,mobile_limit_count=?,ip_limit_count=?,rate_window_minutes=?,auto_failover=?,updated_at=? WHERE id='default'`)
    .run(otpTemplate, mobileLimit, ipLimit, rateWindowMinutes, autoFailover, iso());
  logAudit({ adminId: req.admin.id, action: 'SMS_SETTINGS_UPDATED', entityType: 'sms_settings', entityId: 'default',
    details: { mobileLimit, ipLimit, rateWindowMinutes, autoFailover: !!autoFailover, templateLength: otpTemplate.length }, ip: clientIp(req) });
  res.json({ ok: true });
});

function privateNetworkAddress(address){const ip=String(address||'').toLowerCase().replace(/^\[|\]$/g,'');if(net.isIP(ip)===4){const part=ip.split('.').map(Number);return part[0]===0||part[0]===10||part[0]===127||(part[0]===100&&part[1]>=64&&part[1]<=127)||(part[0]===169&&part[1]===254)||(part[0]===172&&part[1]>=16&&part[1]<=31)||(part[0]===192&&part[1]===168)||(part[0]===198&&(part[1]===18||part[1]===19))||part[0]>=224}if(net.isIP(ip)===6){if(ip==='::'||ip==='::1'||ip.startsWith('fc')||ip.startsWith('fd')||/^fe[89ab]/.test(ip)||ip.startsWith('ff'))return true;const mapped=ip.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);return mapped?privateNetworkAddress(mapped[1]):false}return true}
async function validateWebhookTarget(config){let target;try{target=new URL(String(config?.url||''))}catch{return 'آدرس Webhook معتبر نیست.'}if(!IS_PROD&&target.protocol==='http:'&&['localhost','127.0.0.1','::1'].includes(target.hostname.replace(/^\[|\]$/g,'')))return null;if(target.protocol!=='https:')return 'Webhook در Production باید HTTPS باشد.';const hostname=target.hostname.replace(/^\[|\]$/g,'').toLowerCase();if(hostname==='localhost'||hostname.endsWith('.localhost')||hostname.endsWith('.local')||hostname.endsWith('.internal')||(net.isIP(hostname)&&privateNetworkAddress(hostname)))return 'Webhook نمی‌تواند به شبکه داخلی یا loopback متصل شود.';try{const records=await dns.lookup(hostname,{all:true,verbatim:true});if(!records.length||records.some(record=>privateNetworkAddress(record.address)))return 'دامنه Webhook به آدرس خصوصی یا غیرمجاز resolve می‌شود.'}catch{return 'دامنه Webhook قابل resolve نیست.'}return null}

async function deliverSafeWebhook(config,credentials,payload){let target;try{target=new URL(String(config?.url||''))}catch{throw new Error('آدرس Webhook معتبر نیست.')}const hostname=target.hostname.replace(/^\[|\]$/g,''),localDev=!IS_PROD&&target.protocol==='http:'&&['localhost','127.0.0.1','::1'].includes(hostname);if(!localDev&&target.protocol!=='https:')throw new Error('Webhook در Production باید HTTPS باشد.');let address=hostname,family=net.isIP(hostname)||undefined;if(!localDev){const records=await dns.lookup(hostname,{all:true,verbatim:true});if(!records.length||records.some(record=>privateNetworkAddress(record.address)))throw new Error('دامنه Webhook به شبکه خصوصی یا آدرس غیرمجاز resolve می‌شود.');address=records[0].address;family=records[0].family}const data=Buffer.from(JSON.stringify(payload)),transport=target.protocol==='https:'?https:http;return await new Promise((resolve,reject)=>{const request=transport.request({protocol:target.protocol,hostname:address,family,port:target.port||undefined,path:`${target.pathname}${target.search}`,method:'POST',servername:target.protocol==='https:'?hostname:undefined,rejectUnauthorized:true,headers:{host:target.host,'content-type':'application/json','content-length':String(data.length),...(credentials.bearerToken?{authorization:`Bearer ${credentials.bearerToken}`}:{})}},response=>{let size=0,body='';response.setEncoding('utf8');response.on('data',chunk=>{size+=Buffer.byteLength(chunk);if(size>1048576){request.destroy(new Error('پاسخ Webhook بیش از حد مجاز است.'));return}body+=chunk});response.on('end',()=>{if(response.statusCode<200||response.statusCode>=300)return reject(new Error(`WEBHOOK_${response.statusCode}`));resolve(body)})});request.setTimeout(10000,()=>request.destroy(new Error('WEBHOOK_TIMEOUT')));request.on('error',reject);request.end(data)})}


function smsProviderInput(body,current={}){const providerType=String(body.providerType??current.provider_type??'generic_webhook'),name=String(body.name??current.name??'').trim(),providerKey=String(body.providerKey??current.provider_key??'').trim().toLowerCase(),config={...(jsonDetails(current.config_json)||{}),...(body.config||{})};if(!['kavenegar','melipayamak','generic_webhook'].includes(providerType)||name.length<2||name.length>80||!/^[a-z0-9_-]{2,40}$/.test(providerKey))return {error:'نوع، نام یا کلید ارائه‌دهنده معتبر نیست.'};if(providerType==='generic_webhook'&&(!config.url||(!/^https:\/\//i.test(config.url)&&!( !IS_PROD&&/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//i.test(config.url)))))return {error:'Webhook باید URL امن HTTPS باشد.'};if(providerType==='melipayamak'&&!config.sender&&!config.template&&!config.bodyId)return {error:'برای ملی‌پیامک یا «کد متن الگو (bodyId)» را وارد کنید (روش درست برای کد ورود) یا شماره خط اختصاصی را.'};if(providerType==='kavenegar'&&!config.template&&!config.sender)return {error:'برای کاوه‌نگار template یا sender را تنظیم کنید.'};let credentials=null;if(body.credentials&&Object.values(body.credentials).some(value=>String(value||'').trim())){credentials=Object.fromEntries(Object.entries(body.credentials).map(([key,value])=>[key,String(value||'').trim()]));if(providerType==='kavenegar'&&!credentials.apiKey)return {error:'API Key کاوه‌نگار لازم است.'};if(providerType==='melipayamak'&&(!credentials.username||!credentials.password))return {error:'نام کاربری و رمز ملی‌پیامک لازم است.'}}return {providerType,name,providerKey,config,credentials}}
app.post('/api/admin/sms/providers', allowPermissions('resources.manage'), async(req,res)=>{const input=smsProviderInput(req.body);if(input.error)return res.status(400).json({error:input.error});if(input.providerType==='generic_webhook'){const targetError=await validateWebhookTarget(input.config);if(targetError)return res.status(400).json({error:targetError})}if(db.prepare('SELECT 1 FROM sms_providers WHERE provider_key=? OR name=?').get(input.providerKey,input.name))return res.status(409).json({error:'نام یا کلید ارائه‌دهنده تکراری است.'});if(!input.credentials)return res.status(400).json({error:'اطلاعات اتصال ارائه‌دهنده لازم است.'});const providerId=id('sms_provider'),now=iso(),priority=Number.isInteger(Number(req.body.priority))?Number(req.body.priority):10;db.prepare(`INSERT INTO sms_providers (id,provider_key,provider_type,name,config_json,credentials_encrypted,balance,unit_cost,status,is_enabled,is_primary,priority,last_checked_at,updated_at) VALUES (?,?,?,?,?,?,0,?,'healthy',?,0,?,?,?)`).run(providerId,input.providerKey,input.providerType,input.name,JSON.stringify(input.config),encryptSecret(input.credentials),Number(req.body.unitCost||0),req.body.isEnabled===false?0:1,priority,now,now);logAudit({adminId:req.admin.id,action:'SMS_PROVIDER_CONFIGURED',entityType:'sms_provider',entityId:providerId,details:{providerType:input.providerType,name:input.name,credentialsChanged:true},ip:clientIp(req)});res.status(201).json({ok:true,id:providerId})});
app.patch('/api/admin/sms/providers/:id', allowPermissions('resources.manage'), async(req, res) => {const provider=db.prepare('SELECT * FROM sms_providers WHERE id=?').get(req.params.id);if(!provider)return res.status(404).json({error:'ارائه‌دهنده پیامک پیدا نشد.'});const input=smsProviderInput(req.body,provider);if(input.error)return res.status(400).json({error:input.error});if(input.providerType==='generic_webhook'){const targetError=await validateWebhookTarget(input.config);if(targetError)return res.status(400).json({error:targetError})}const credentials=input.credentials?encryptSecret(input.credentials):provider.credentials_encrypted,makePrimary=!!req.body.makePrimary,isEnabled=req.body.isEnabled===undefined?provider.is_enabled:req.body.isEnabled?1:0,priority=Number.isInteger(Number(req.body.priority))?Number(req.body.priority):provider.priority,unitCost=Number.isFinite(Number(req.body.unitCost))?Math.max(0,Number(req.body.unitCost)):provider.unit_cost;if((makePrimary||isEnabled)&&!credentials)return res.status(400).json({error:'ابتدا اطلاعات اتصال ارائه‌دهنده را ذخیره کنید.'});if(!isEnabled&&provider.is_primary)return res.status(400).json({error:'ابتدا یک ارائه‌دهنده دیگر را اصلی کنید.'});db.transaction(()=>{db.prepare('UPDATE sms_providers SET provider_key=?,provider_type=?,name=?,config_json=?,credentials_encrypted=?,unit_cost=?,is_enabled=?,priority=?,updated_at=? WHERE id=?').run(input.providerKey,input.providerType,input.name,JSON.stringify(input.config),credentials,unitCost,isEnabled,priority,iso(),provider.id);if(makePrimary){db.prepare('UPDATE sms_providers SET is_primary=0,updated_at=? WHERE is_primary=1').run(iso());db.prepare('UPDATE sms_providers SET is_primary=1,is_enabled=1,status=CASE WHEN status=\'down\' THEN \'degraded\' ELSE status END,updated_at=? WHERE id=?').run(iso(),provider.id)}})();logAudit({adminId:req.admin.id,action:makePrimary?'SMS_PROVIDER_SWITCHED':'SMS_PROVIDER_CONFIGURED',entityType:'sms_provider',entityId:provider.id,details:{providerType:input.providerType,name:input.name,credentialsChanged:!!input.credentials,makePrimary,isEnabled:!!isEnabled},ip:clientIp(req)});res.json({ok:true,configured:!!credentials})});
app.post('/api/admin/sms/providers/:id/test', allowPermissions('resources.manage'), async(req,res,next)=>{try{const provider=db.prepare('SELECT * FROM sms_providers WHERE id=?').get(req.params.id),mobile=normalizeMobile(req.body.mobile);if(!provider)return res.status(404).json({error:'ارائه‌دهنده پیدا نشد.'});if(!/^09\d{9}$/.test(mobile))return res.status(400).json({error:'شماره تست معتبر نیست.'});const code=String(crypto.randomInt(100000,1000000));await deliverWithProvider(provider,mobile,`پیام تست SmartJournal — کد ${code}`,code);db.prepare("UPDATE sms_providers SET status='healthy',last_checked_at=?,updated_at=? WHERE id=?").run(iso(),iso(),provider.id);logAudit({adminId:req.admin.id,action:'SMS_PROVIDER_TESTED',entityType:'sms_provider',entityId:provider.id,details:{mobile:`${mobile.slice(0,4)}***${mobile.slice(-4)}`,success:true},ip:clientIp(req)});res.json({ok:true})}catch(error){next(Object.assign(error,{status:502}))}});
app.post('/api/admin/sms/providers/failover', allowPermissions('resources.manage'), (req, res) => {
  const current = db.prepare('SELECT * FROM sms_providers WHERE is_primary=1 LIMIT 1').get();
  const fallback = db.prepare(`SELECT * FROM sms_providers WHERE is_enabled=1 AND status!='down' AND id!=? ORDER BY CASE status WHEN 'healthy' THEN 0 ELSE 1 END,priority LIMIT 1`).get(current ? current.id : '');
  if (!fallback) return res.status(409).json({ error: 'ارائه‌دهنده جایگزین سالمی در دسترس نیست.' });
  const tx = db.transaction(() => {
    db.prepare('UPDATE sms_providers SET is_primary=0,updated_at=? WHERE is_primary=1').run(iso());
    db.prepare('UPDATE sms_providers SET is_primary=1,updated_at=? WHERE id=?').run(iso(), fallback.id);
  });
  tx();
  logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_SWITCHED', entityType: 'sms_provider', entityId: fallback.id,
    details: { from: current && current.name, to: fallback.name, reason: 'manual_failover' }, ip: clientIp(req) });
  res.json({ ok: true, provider: { id: fallback.id, name: fallback.name } });
});

app.get('/api/admin/files/overview', allowPermissions('resources.view','resources.security'), (req, res) => {
  const rawSettings = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
  const allowedMimeTypes = parseAllowedMimeTypes(rawSettings.allowed_mime_types);
  const settings = { ...rawSettings, allowed_mime_types: allowedMimeTypes };
  const metrics = db.prepare(`SELECT
    COUNT(*) AS total_files,COALESCE(SUM(size_bytes),0) AS total_bytes,
    SUM(CASE WHEN trade_ref IS NULL THEN 1 ELSE 0 END) AS orphan_files,
    COALESCE(SUM(CASE WHEN trade_ref IS NULL THEN size_bytes ELSE 0 END),0) AS orphan_bytes,
    SUM(CASE WHEN scan_status='suspicious' THEN 1 ELSE 0 END) AS suspicious_files,
    SUM(CASE WHEN status='quarantined' THEN 1 ELSE 0 END) AS quarantined_files,
    SUM(CASE WHEN size_bytes>? THEN 1 ELSE 0 END) AS oversized_files
    FROM media_files WHERE status!='deleted'`).get(rawSettings.max_file_size_bytes);
  metrics.reported_user_bytes = db.prepare('SELECT COALESCE(SUM(storage_bytes),0) AS total FROM users WHERE deleted_at IS NULL').get().total;
  if (allowedMimeTypes.length) {
    const placeholders = allowedMimeTypes.map(() => '?').join(',');
    metrics.invalid_format_files = db.prepare(`SELECT COUNT(*) AS count FROM media_files WHERE status!='deleted' AND mime_type NOT IN (${placeholders})`).get(...allowedMimeTypes).count;
  } else metrics.invalid_format_files = metrics.total_files;
  const cutoff = new Date(Date.now() - Number(rawSettings.orphan_retention_days) * 86400000).toISOString();
  metrics.cleanup_eligible = db.prepare("SELECT COUNT(*) AS count FROM media_files WHERE status!='deleted' AND trade_ref IS NULL AND COALESCE(orphaned_at,uploaded_at)<=?").get(cutoff).count;
  const orphanedFiles = db.prepare(`SELECT f.*,u.name AS user_name,u.mobile FROM media_files f LEFT JOIN users u ON u.id=f.user_id
    WHERE f.status!='deleted' AND f.trade_ref IS NULL ORDER BY COALESCE(f.orphaned_at,f.uploaded_at) ASC LIMIT 100`).all();
  const suspiciousFiles = db.prepare(`SELECT f.*,u.name AS user_name,u.mobile FROM media_files f LEFT JOIN users u ON u.id=f.user_id
    WHERE f.status!='deleted' AND (f.scan_status='suspicious' OR f.status='quarantined') ORDER BY f.uploaded_at DESC LIMIT 100`).all();
  const recentFiles = db.prepare(`SELECT f.*,u.name AS user_name,u.mobile FROM media_files f LEFT JOIN users u ON u.id=f.user_id
    WHERE f.status!='deleted' ORDER BY f.uploaded_at DESC LIMIT 40`).all();
  const formatStats = db.prepare(`SELECT mime_type,COUNT(*) AS file_count,COALESCE(SUM(size_bytes),0) AS total_bytes
    FROM media_files WHERE status!='deleted' GROUP BY mime_type ORDER BY file_count DESC`).all();
  const plans = db.prepare('SELECT id,name,name_fa,max_storage_bytes,color,max_trades,max_sms_monthly,price_monthly FROM plans WHERE is_active=1 ORDER BY price_monthly').all();
  res.json({ settings, metrics, orphanedFiles, suspiciousFiles, recentFiles, formatStats, plans });
});

app.patch('/api/admin/files/settings', allowPermissions('resources.manage'), (req, res) => {
  const allowedOptions = ['image/jpeg','image/png','image/webp','image/gif'];
  const allowedMimeTypes = Array.isArray(req.body.allowedMimeTypes) ? [...new Set(req.body.allowedMimeTypes.map(String))] : [];
  const maxFileSizeBytes = Number(req.body.maxFileSizeBytes);
  const orphanRetentionDays = Number(req.body.orphanRetentionDays);
  const autoCleanup = req.body.autoCleanup ? 1 : 0;
  if (!allowedMimeTypes.length || allowedMimeTypes.some(type => !allowedOptions.includes(type))) return res.status(400).json({ error: 'حداقل یک فرمت تصویر معتبر انتخاب کنید.' });
  if (!Number.isInteger(maxFileSizeBytes) || maxFileSizeBytes < 512 * 1024 || maxFileSizeBytes > 100 * 1024 * 1024) return res.status(400).json({ error: 'حداکثر حجم هر فایل باید بین ۵۰۰ کیلوبایت تا ۱۰۰ مگابایت باشد.' });
  if (!Number.isInteger(orphanRetentionDays) || orphanRetentionDays < 1 || orphanRetentionDays > 365) return res.status(400).json({ error: 'مهلت نگهداری فایل رهاشده باید بین ۱ تا ۳۶۵ روز باشد.' });
  db.prepare(`UPDATE file_settings SET allowed_mime_types=?,max_file_size_bytes=?,orphan_retention_days=?,auto_cleanup=?,updated_at=? WHERE id='default'`)
    .run(JSON.stringify(allowedMimeTypes), maxFileSizeBytes, orphanRetentionDays, autoCleanup, iso());
  logAudit({ adminId: req.admin.id, action: 'FILE_SETTINGS_UPDATED', entityType: 'file_settings', entityId: 'default',
    details: { allowedMimeTypes, maxFileSizeBytes, orphanRetentionDays, autoCleanup: !!autoCleanup }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.post('/api/admin/files/cleanup', allowPermissions('resources.manage'), (req, res) => {
  const settings = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
  const olderThanDays = Number(req.body.olderThanDays ?? settings.orphan_retention_days);
  if (!Number.isInteger(olderThanDays) || olderThanDays < 1 || olderThanDays > 365) return res.status(400).json({ error: 'بازه پاک‌سازی معتبر نیست.' });
  const cutoff = new Date(Date.now() - olderThanDays * 86400000).toISOString();
  const requestedIds = Array.isArray(req.body.fileIds) ? [...new Set(req.body.fileIds.map(String))].slice(0, 500) : [];
  let sql = "SELECT * FROM media_files WHERE status!='deleted' AND trade_ref IS NULL AND COALESCE(orphaned_at,uploaded_at)<=?";
  const params = [cutoff];
  if (requestedIds.length) { sql += ` AND id IN (${requestedIds.map(() => '?').join(',')})`; params.push(...requestedIds); }
  const files = db.prepare(sql).all(...params);
  const deletedAt = iso();
  const perUser = new Map();
  files.forEach(file => { if (file.user_id) perUser.set(file.user_id, (perUser.get(file.user_id) || 0) + Number(file.size_bytes)); });
  const tx = db.transaction(() => {
    const update = db.prepare("UPDATE media_files SET status='deleted',deleted_at=?,reviewed_at=?,reviewed_by_admin_id=? WHERE id=?");
    files.forEach(file => update.run(deletedAt, deletedAt, req.admin.id, file.id));
    const updateUser = db.prepare('UPDATE users SET storage_bytes=MAX(0,storage_bytes-?) WHERE id=?');
    perUser.forEach((size, userId) => updateUser.run(size, userId));
  });
  tx();
  let physicalDeleted = 0;
  files.forEach(file => { if (removeStoredFile(file.storage_key)) physicalDeleted += 1; });
  const deletedBytes = files.reduce((sum, file) => sum + Number(file.size_bytes), 0);
  logAudit({ adminId: req.admin.id, action: 'ORPHAN_FILES_CLEANED', entityType: 'media_file', entityId: null,
    details: { count: files.length, deletedBytes, physicalDeleted, olderThanDays }, ip: clientIp(req) });
  res.json({ ok: true, deletedCount: files.length, deletedBytes, physicalDeleted });
});

app.patch('/api/admin/files/:id/review', allowPermissions('resources.manage','resources.security'), (req, res) => {
  const file = db.prepare("SELECT * FROM media_files WHERE id=? AND status!='deleted'").get(req.params.id);
  if (!file) return res.status(404).json({ error: 'فایل پیدا نشد.' });
  const action = String(req.body.action || '');
  if (!['mark_safe','quarantine','delete'].includes(action)) return res.status(400).json({ error: 'عملیات بررسی فایل معتبر نیست.' });
  const reviewedAt = iso();
  const tx = db.transaction(() => {
    if (action === 'mark_safe') db.prepare("UPDATE media_files SET status='active',scan_status='safe',scan_reason=NULL,reviewed_at=?,reviewed_by_admin_id=? WHERE id=?").run(reviewedAt, req.admin.id, file.id);
    if (action === 'quarantine') db.prepare("UPDATE media_files SET status='quarantined',scan_status='suspicious',reviewed_at=?,reviewed_by_admin_id=? WHERE id=?").run(reviewedAt, req.admin.id, file.id);
    if (action === 'delete') {
      db.prepare("UPDATE media_files SET status='deleted',deleted_at=?,reviewed_at=?,reviewed_by_admin_id=? WHERE id=?").run(reviewedAt, reviewedAt, req.admin.id, file.id);
      if (file.user_id) db.prepare('UPDATE users SET storage_bytes=MAX(0,storage_bytes-?) WHERE id=?').run(file.size_bytes, file.user_id);
    }
  });
  tx();
  const physicalDeleted = action === 'delete' ? removeStoredFile(file.storage_key) : false;
  logAudit({ adminId: req.admin.id, action: action === 'delete' ? 'FILE_DELETED' : 'FILE_REVIEWED', entityType: 'media_file', entityId: file.id,
    details: { file: file.original_name, action, size: file.size_bytes, physicalDeleted }, ip: clientIp(req) });
  res.json({ ok: true, action });
});

app.get('/api/admin/auth-security/settings',allowPermissions('security.view','settings.view'),(req,res)=>{const settings=authSecuritySettings();res.json({settings:{maxDevices:Number(settings.max_devices),trustedDeviceDays:Number(settings.trusted_device_days),otpTtlSeconds:Number(settings.otp_ttl_seconds),otpMaxAttempts:Number(settings.otp_max_attempts),captchaFailureThreshold:Number(settings.captcha_failure_threshold),turnstileSiteKey:settings.turnstile_site_key||'',turnstileConfigured:!!settings.turnstile_secret_encrypted,newDeviceOtp:!!settings.new_device_otp,notifyNewLogin:!!settings.notify_new_login}})});
app.patch('/api/admin/auth-security/settings',allowPermissions('security.manage','settings.manage'),(req,res)=>{const current=authSecuritySettings(),maxDevices=Number(req.body.maxDevices??current.max_devices),trustedDays=Number(req.body.trustedDeviceDays??current.trusted_device_days),otpTtl=Number(req.body.otpTtlSeconds??current.otp_ttl_seconds),otpAttempts=Number(req.body.otpMaxAttempts??current.otp_max_attempts),captchaThreshold=Number(req.body.captchaFailureThreshold??current.captcha_failure_threshold),siteKey=String(req.body.turnstileSiteKey??current.turnstile_site_key??'').trim(),secret=String(req.body.turnstileSecret||'').trim(),secretEncrypted=secret?encryptSecret({secret}):current.turnstile_secret_encrypted;if(!Number.isInteger(maxDevices)||maxDevices<1||maxDevices>20||!Number.isInteger(trustedDays)||trustedDays<1||trustedDays>365||!Number.isInteger(otpTtl)||otpTtl<60||otpTtl>600||!Number.isInteger(otpAttempts)||otpAttempts<3||otpAttempts>10||!Number.isInteger(captchaThreshold)||captchaThreshold<2||captchaThreshold>10)return res.status(400).json({error:'سیاست امنیت احراز هویت معتبر نیست.'});db.prepare(`UPDATE auth_security_settings SET max_devices=?,trusted_device_days=?,otp_ttl_seconds=?,otp_max_attempts=?,captcha_failure_threshold=?,turnstile_site_key=?,turnstile_secret_encrypted=?,new_device_otp=?,notify_new_login=?,updated_at=?,updated_by_admin_id=? WHERE id='default'`).run(maxDevices,trustedDays,otpTtl,otpAttempts,captchaThreshold,siteKey||null,secretEncrypted,req.body.newDeviceOtp===undefined?current.new_device_otp:req.body.newDeviceOtp?1:0,req.body.notifyNewLogin===undefined?current.notify_new_login:req.body.notifyNewLogin?1:0,iso(),req.admin.id);logAudit({adminId:req.admin.id,action:'AUTH_SECURITY_SETTINGS_UPDATED',entityType:'auth_security_settings',entityId:'default',details:{maxDevices,trustedDays,otpTtl,otpAttempts,captchaThreshold,turnstileSecretChanged:!!secret},ip:clientIp(req)});res.json({ok:true})});

app.get('/api/admin/admins', allowRoles('owner'), (req, res) => {
  const rows = db.prepare(`SELECT a.id,a.name,a.username,a.mobile,a.role,a.status,a.created_at,a.last_login_at,
    (SELECT COUNT(*) FROM admin_sessions s WHERE s.admin_id=a.id AND s.expires_at>?) AS active_sessions
    FROM admins a ORDER BY CASE a.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END,a.created_at`).all(iso())
    .map(admin => ({ ...admin, permissions: permissionsFor(admin.role) }));
  res.json({ rows, roles: ['owner', ...MANAGED_ROLES] });
});

app.post('/api/admin/admins', allowRoles('owner'), async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim(), username=String(req.body.username||'').trim().toLowerCase(), mobile = normalizeMobile(req.body.mobile), password = String(req.body.password || ''), role = String(req.body.role || '');
    if (name.length < 3 || name.length > 100) return res.status(400).json({ error: 'نام مدیر باید بین ۳ تا ۱۰۰ کاراکتر باشد.' });
    if (!/^[a-z][a-z0-9._-]{2,31}$/.test(username)) return res.status(400).json({error:'نام کاربری باید ۳ تا ۳۲ کاراکتر انگلیسی معتبر باشد.'});
    if (!/^09\d{9}$/.test(mobile)) return res.status(400).json({ error: 'شماره موبایل مدیر معتبر نیست.' });
    if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'رمز عبور مدیر باید حداقل ۱۰ کاراکتر باشد.' });
    if (!['owner', ...MANAGED_ROLES].includes(role)) return res.status(400).json({ error: 'نقش مدیر معتبر نیست.' });
    if (db.prepare('SELECT 1 FROM admins WHERE mobile=? OR lower(username)=?').get(mobile,username)) return res.status(409).json({ error: 'شماره موبایل یا نام کاربری قبلاً ثبت شده است.' });
    const adminId = id('adm');
    db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required) VALUES (?,?,?,?,?,?,'active',?,?)`)
      .run(adminId, name, username, mobile, await bcryptPool.hash(password, 12), role, iso(), role==='owner'?1:0);
    logAudit({ adminId: req.admin.id, action: 'ADMIN_CREATED', entityType: 'admin', entityId: adminId, details: { name, username, mobile, role }, ip: clientIp(req) });
    res.status(201).json({ ok: true, id: adminId });
  } catch (error) { next(error); }
});

app.patch('/api/admin/admins/:id', allowRoles('owner'), async (req, res, next) => {
  try {
    const target = db.prepare('SELECT * FROM admins WHERE id=?').get(req.params.id);
    if (!target) return res.status(404).json({ error: 'مدیر پیدا نشد.' });
    const role = req.body.role === undefined ? target.role : String(req.body.role);
    const status = req.body.status === undefined ? target.status : String(req.body.status);
    const name = req.body.name === undefined ? target.name : String(req.body.name).trim();
    const username = req.body.username === undefined ? target.username : String(req.body.username).trim().toLowerCase();
    const mobile = req.body.mobile === undefined ? target.mobile : normalizeMobile(req.body.mobile);
    const newPassword = String(req.body.newPassword || '');
    if (!['owner', ...MANAGED_ROLES].includes(role) || !['active','disabled'].includes(status) || name.length < 3 || name.length > 100 || !/^[a-z][a-z0-9._-]{2,31}$/.test(username) || !/^09\d{9}$/.test(mobile)) return res.status(400).json({ error: 'اطلاعات نقش، نام، موبایل یا وضعیت مدیر معتبر نیست.' });
    if (newPassword && (newPassword.length < 10 || newPassword.length > 128)) return res.status(400).json({ error:'رمز جدید مدیر باید حداقل ۱۰ کاراکتر باشد.' });
    if (db.prepare('SELECT 1 FROM admins WHERE (mobile=? OR lower(username)=?) AND id!=?').get(mobile,username,target.id)) return res.status(409).json({error:'این شماره موبایل برای مدیر دیگری ثبت شده است.'});
    if (target.id === req.admin.id && (role !== target.role || status !== 'active')) return res.status(400).json({ error: 'نمی‌توانید نقش یا وضعیت حساب فعال خودتان را تغییر دهید.' });
    if (target.role === 'owner' && (role !== 'owner' || status !== 'active')) {
      const activeOwners = db.prepare("SELECT COUNT(*) AS count FROM admins WHERE role='owner' AND status='active'").get().count;
      if (activeOwners <= 1) return res.status(400).json({ error: 'حداقل یک Owner فعال باید باقی بماند.' });
    }
    const passwordHash = newPassword ? await bcryptPool.hash(newPassword,12) : target.password_hash;
    const securityChanged=role!==target.role||status!==target.status||mobile!==target.mobile||!!newPassword;
    const tx = db.transaction(() => {
      db.prepare('UPDATE admins SET name=?,username=?,mobile=?,password_hash=?,role=?,status=?,mfa_required=? WHERE id=?').run(name,username,mobile,passwordHash,role,status,role==='owner'?1:target.mfa_required,target.id);
      if (securityChanged) db.prepare('DELETE FROM admin_sessions WHERE admin_id=?').run(target.id);
    });
    tx();
    logAudit({ adminId: req.admin.id, action: 'ADMIN_ACCESS_UPDATED', entityType: 'admin', entityId: target.id,
      details: { name, usernameChanged:username!==target.username, mobileChanged:mobile!==target.mobile, passwordReset:!!newPassword, fromRole: target.role, toRole: role, fromStatus: target.status, toStatus: status, sessionsRevoked:securityChanged }, ip: clientIp(req) });
    res.json({ ok: true });
  } catch(error){next(error)}
});

app.get('/api/admin/role-permissions', allowRoles('owner'), (req, res) => {
  const rows = db.prepare('SELECT role,permission,enabled,updated_at FROM role_permissions ORDER BY role,permission').all();
  const matrix = Object.fromEntries(MANAGED_ROLES.map(role => [role, Object.fromEntries(PERMISSION_KEYS.map(permission => [permission, false]))]));
  rows.forEach(row => { if (matrix[row.role] && PERMISSION_KEYS.includes(row.permission)) matrix[row.role][row.permission] = !!row.enabled; });
  res.json({ roles: MANAGED_ROLES, permissions: PERMISSION_KEYS, matrix, defaults: DEFAULT_ROLE_PERMISSIONS });
});

app.patch('/api/admin/role-permissions/:role', allowRoles('owner'), (req, res) => {
  const role = String(req.params.role || ''), selected = Array.isArray(req.body.permissions) ? [...new Set(req.body.permissions.map(String))] : null;
  if (!MANAGED_ROLES.includes(role)) return res.status(400).json({ error: 'نقش قابل ویرایش نیست.' });
  if (!selected || selected.some(permission => !PERMISSION_KEYS.includes(permission))) return res.status(400).json({ error: 'فهرست مجوزها معتبر نیست.' });
  const dependencies = { 'users.manage':'users.view','users.security':'users.view','users.delete':'users.view','billing.manage':'billing.view','billing.refund':'billing.view','resources.manage':'resources.view','resources.security':'resources.view','security.manage':'security.view','settings.manage':'settings.view','content.manage':'content.view' };
  selected.slice().forEach(permission => { const required=dependencies[permission];if(required&&!selected.includes(required))selected.push(required); });
  const before = permissionsFor(role), now = iso();
  const update = db.prepare(`INSERT INTO role_permissions (role,permission,enabled,updated_at,updated_by_admin_id) VALUES (?,?,?,?,?)
    ON CONFLICT(role,permission) DO UPDATE SET enabled=excluded.enabled,updated_at=excluded.updated_at,updated_by_admin_id=excluded.updated_by_admin_id`);
  const tx = db.transaction(() => {
    PERMISSION_KEYS.forEach(permission => update.run(role,permission,selected.includes(permission)?1:0,now,req.admin.id));
    db.prepare(`DELETE FROM admin_sessions WHERE admin_id IN (SELECT id FROM admins WHERE role=?)`).run(role);
  });
  tx();
  logAudit({ adminId:req.admin.id, action:'ROLE_PERMISSIONS_UPDATED', entityType:'admin_role', entityId:role,
    details:{ role, before, after:selected, affectedAdmins:db.prepare('SELECT COUNT(*) count FROM admins WHERE role=?').get(role).count, sessionsRevoked:true }, ip:clientIp(req) });
  res.json({ ok:true, role, permissions:selected });
});

app.get('/api/admin/legal/documents',allowPermissions('content.view'),(req,res)=>{const rows=db.prepare(`SELECT d.*,a.name created_by_name FROM legal_documents d LEFT JOIN admins a ON a.id=d.created_by_admin_id ORDER BY d.document_type,d.created_at DESC`).all(),current={};for(const type of LEGAL_TYPES){const document=currentLegalDocument(type);if(document)current[type]=document}res.json({types:LEGAL_TYPES.map(type=>({type,title:LEGAL_TITLES[type]})),current,versions:rows,identityComplete:!!process.env.LEGAL_OPERATOR_NAME&&!!process.env.LEGAL_OPERATOR_REGISTRATION&&!!process.env.LEGAL_OPERATOR_ADDRESS,productionBlocked:IS_PROD&&(!process.env.LEGAL_OPERATOR_NAME||!process.env.LEGAL_OPERATOR_REGISTRATION||!process.env.LEGAL_OPERATOR_ADDRESS)})});
app.post('/api/admin/legal/documents/:type',allowPermissions('content.manage'),(req,res)=>{const type=LEGAL_TYPES.includes(req.params.type)?req.params.type:'';if(!type)return res.status(404).json({error:'نوع سند حقوقی معتبر نیست.'});const version=String(req.body.version||'').trim(),title=String(req.body.title||LEGAL_TITLES[type]).trim(),content=String(req.body.content||'').trim(),effective=new Date(req.body.effectiveAt||Date.now()),publish=req.body.publish!==false,identityComplete=!!process.env.LEGAL_OPERATOR_NAME&&!!process.env.LEGAL_OPERATOR_REGISTRATION&&!!process.env.LEGAL_OPERATOR_ADDRESS;if(!/^\d+\.\d+\.\d+$/.test(version))return res.status(400).json({error:'نسخه سند باید Semantic Version مانند 1.1.0 باشد.'});if(title.length<5||title.length>160||content.length<500||content.length>50000)return res.status(400).json({error:'عنوان یا متن سند حقوقی معتبر نیست؛ متن باید حداقل ۵۰۰ کاراکتر باشد.'});if(Number.isNaN(effective.getTime()))return res.status(400).json({error:'تاریخ اجرای سند معتبر نیست.'});if(IS_PROD&&publish&&!identityComplete)return res.status(409).json({error:'انتشار Production تا تکمیل LEGAL_OPERATOR_NAME، LEGAL_OPERATOR_REGISTRATION و LEGAL_OPERATOR_ADDRESS مسدود است.'});if(db.prepare('SELECT 1 FROM legal_documents WHERE document_type=? AND version=?').get(type,version))return res.status(409).json({error:'این نسخه قبلاً ثبت شده و اسناد ثبت‌شده تغییرناپذیرند؛ نسخه جدید بسازید.'});const now=iso(),documentId=id('legal'),hash=crypto.createHash('sha256').update(content).digest('hex'),status=publish?'published':'draft';db.prepare(`INSERT INTO legal_documents (id,document_type,version,title,content,content_sha256,status,effective_at,created_at,published_at,created_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(documentId,type,version,title,content,hash,status,effective.toISOString(),now,publish?now:null,req.admin.id);if(type==='terms'||type==='privacy')db.prepare(`UPDATE system_settings SET ${type==='terms'?'terms_text':'privacy_text'}=?,updated_at=?,updated_by_admin_id=? WHERE id='default'`).run(content,now,req.admin.id);logAudit({adminId:req.admin.id,action:'LEGAL_DOCUMENT_VERSION_CREATED',entityType:'legal_document',entityId:documentId,details:{type,version,status,effectiveAt:effective.toISOString(),sha256:hash},ip:clientIp(req)});res.status(201).json({ok:true,id:documentId,type,version,status,sha256:hash})});

app.get('/api/admin/system/settings', allowPermissions('settings.view','content.view'), (req, res) => {
  const settings = db.prepare("SELECT s.*,a.name AS updated_by_name FROM system_settings s LEFT JOIN admins a ON a.id=s.updated_by_admin_id WHERE s.id='default'").get();
  const smsSettings = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  const fileSettings = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
  const plans = db.prepare('SELECT * FROM plans WHERE is_active=1 ORDER BY price_monthly').all();
  const announcements = db.prepare(`SELECT n.*,creator.name AS created_by_name,editor.name AS updated_by_name FROM announcements n
    LEFT JOIN admins creator ON creator.id=n.created_by_admin_id LEFT JOIN admins editor ON editor.id=n.updated_by_admin_id
    ORDER BY CASE n.status WHEN 'published' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,n.updated_at DESC LIMIT 200`).all();
  if (!hasAdminPermission(req.admin, 'settings.view')) {
    return res.json({ settings: { id: settings.id, terms_text: settings.terms_text, privacy_text: settings.privacy_text, guide_text: settings.guide_text,
      app_version: settings.app_version, updated_at: settings.updated_at, updated_by_name: settings.updated_by_name }, announcements, plans: [], smsSettings: null, fileSettings: null });
  }
  if (!hasAdminPermission(req.admin,'content.view')) {
    const operationalSettings={...settings};delete operationalSettings.terms_text;delete operationalSettings.privacy_text;delete operationalSettings.guide_text;
    return res.json({settings:operationalSettings,smsSettings,fileSettings:{...fileSettings,allowed_mime_types:parseAllowedMimeTypes(fileSettings.allowed_mime_types)},plans,announcements:[]});
  }
  res.json({ settings, smsSettings, fileSettings: { ...fileSettings, allowed_mime_types: parseAllowedMimeTypes(fileSettings.allowed_mime_types) }, plans, announcements });
});

app.patch('/api/admin/system/settings', allowPermissions('settings.manage'), (req, res) => {
  const current = db.prepare("SELECT * FROM system_settings WHERE id='default'").get();
  const smsCurrent = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  const fileCurrent = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
  const signupEnabled = req.body.signupEnabled === undefined ? current.signup_enabled : req.body.signupEnabled ? 1 : 0;
  const maintenanceMode = req.body.maintenanceMode === undefined ? current.maintenance_mode : req.body.maintenanceMode ? 1 : 0;
  const maintenanceMessage = String(req.body.maintenanceMessage ?? current.maintenance_message ?? '').trim();
  const canManageContent = hasAdminPermission(req.admin,'content.manage');
  const termsText = String(canManageContent ? (req.body.termsText ?? current.terms_text) : current.terms_text).trim();
  const privacyText = String(canManageContent ? (req.body.privacyText ?? current.privacy_text) : current.privacy_text).trim();
  const guideText = String(canManageContent ? (req.body.guideText ?? current.guide_text) : current.guide_text).trim();
  const appVersion = String(req.body.appVersion ?? current.app_version).trim();
  const otpMobileLimit = Number(req.body.otpMobileLimit ?? smsCurrent.mobile_limit_count);
  const otpIpLimit = Number(req.body.otpIpLimit ?? smsCurrent.ip_limit_count);
  const otpWindowMinutes = Number(req.body.otpWindowMinutes ?? smsCurrent.rate_window_minutes);
  const maxImageSizeBytes = Number(req.body.maxImageSizeBytes ?? fileCurrent.max_file_size_bytes);
  if (maintenanceMessage && (maintenanceMessage.length < 5 || maintenanceMessage.length > 500)) return res.status(400).json({ error: 'پیام حالت تعمیرات باید بین ۵ تا ۵۰۰ کاراکتر باشد.' });
  if (termsText.length < 50 || termsText.length > 30000) return res.status(400).json({ error: 'متن قوانین باید بین ۵۰ تا ۳۰٬۰۰۰ کاراکتر باشد.' });
  if (privacyText.length < 50 || privacyText.length > 30000) return res.status(400).json({ error: 'متن حریم خصوصی باید بین ۵۰ تا ۳۰٬۰۰۰ کاراکتر باشد.' });
  if (guideText.length < 50 || guideText.length > 30000) return res.status(400).json({ error: 'متن راهنما باید بین ۵۰ تا ۳۰٬۰۰۰ کاراکتر باشد.' });
  if (!/^[0-9A-Za-z][0-9A-Za-z._+-]{0,31}$/.test(appVersion)) return res.status(400).json({ error: 'نسخه برنامه معتبر نیست؛ مانند 1.2.0 وارد کنید.' });
  if (!Number.isInteger(otpMobileLimit) || otpMobileLimit < 1 || otpMobileLimit > 50) return res.status(400).json({ error: 'محدودیت OTP هر شماره باید بین ۱ تا ۵۰ باشد.' });
  if (!Number.isInteger(otpIpLimit) || otpIpLimit < 1 || otpIpLimit > 200) return res.status(400).json({ error: 'محدودیت OTP هر IP باید بین ۱ تا ۲۰۰ باشد.' });
  if (!Number.isInteger(otpWindowMinutes) || otpWindowMinutes < 1 || otpWindowMinutes > 1440) return res.status(400).json({ error: 'بازه محدودیت OTP باید بین ۱ دقیقه تا ۲۴ ساعت باشد.' });
  if (!Number.isInteger(maxImageSizeBytes) || maxImageSizeBytes < 512 * 1024 || maxImageSizeBytes > 100 * 1024 * 1024) return res.status(400).json({ error: 'حجم تصویر باید بین ۵۰۰ کیلوبایت تا ۱۰۰ مگابایت باشد.' });
  const updatedAt = iso();
  const tx = db.transaction(() => {
    db.prepare(`UPDATE system_settings SET signup_enabled=?,maintenance_mode=?,maintenance_message=?,terms_text=?,privacy_text=?,guide_text=?,app_version=?,updated_at=?,updated_by_admin_id=? WHERE id='default'`)
      .run(signupEnabled, maintenanceMode, maintenanceMessage || null, termsText, privacyText, guideText, appVersion, updatedAt, req.admin.id);
    db.prepare("UPDATE sms_settings SET mobile_limit_count=?,ip_limit_count=?,rate_window_minutes=?,updated_at=? WHERE id='default'")
      .run(otpMobileLimit, otpIpLimit, otpWindowMinutes, updatedAt);
    db.prepare("UPDATE file_settings SET max_file_size_bytes=?,updated_at=? WHERE id='default'").run(maxImageSizeBytes, updatedAt);
  });
  tx();
  logAudit({ adminId: req.admin.id, action: 'SYSTEM_SETTINGS_UPDATED', entityType: 'system_settings', entityId: 'default', details: {
    signupEnabled: [!!current.signup_enabled, !!signupEnabled], maintenanceMode: [!!current.maintenance_mode, !!maintenanceMode],
    appVersion: [current.app_version, appVersion], termsLength: termsText.length, privacyLength: privacyText.length, guideLength: guideText.length,
    otpMobileLimit, otpIpLimit, otpWindowMinutes, maxImageSizeBytes
  }, ip: clientIp(req) });
  res.json({ ok: true, updatedAt });
});

app.patch('/api/admin/system/content', allowPermissions('content.manage'), (req, res) => {
  const current = db.prepare("SELECT * FROM system_settings WHERE id='default'").get();
  const termsText = String(req.body.termsText ?? current.terms_text).trim();
  const privacyText = String(req.body.privacyText ?? current.privacy_text).trim();
  const guideText = String(req.body.guideText ?? current.guide_text).trim();
  if ([termsText, privacyText, guideText].some(text => text.length < 50 || text.length > 30000)) return res.status(400).json({ error: 'هر متن محتوایی باید بین ۵۰ تا ۳۰٬۰۰۰ کاراکتر باشد.' });
  const updatedAt = iso();
  db.prepare("UPDATE system_settings SET terms_text=?,privacy_text=?,guide_text=?,updated_at=?,updated_by_admin_id=? WHERE id='default'")
    .run(termsText, privacyText, guideText, updatedAt, req.admin.id);
  logAudit({ adminId: req.admin.id, action: 'SYSTEM_CONTENT_UPDATED', entityType: 'system_settings', entityId: 'default',
    details: { termsLength: termsText.length, privacyLength: privacyText.length, guideLength: guideText.length }, ip: clientIp(req) });
  res.json({ ok: true, updatedAt });
});

function announcementInput(body, current = {}) {
  const title = String(body.title ?? current.title ?? '').trim();
  const content = String(body.body ?? current.body ?? '').trim();
  const tone = ['info','success','warning','critical'].includes(body.tone) ? body.tone : current.tone || 'info';
  const audience = ['all','free','pro','organization'].includes(body.audience) ? body.audience : current.audience || 'all';
  const status = ['draft','published','archived'].includes(body.status) ? body.status : current.status || 'draft';
  const startsAt = body.startsAt ? new Date(body.startsAt) : current.starts_at ? new Date(current.starts_at) : new Date();
  const expiresAt = body.expiresAt ? new Date(body.expiresAt) : body.expiresAt === null ? null : current.expires_at ? new Date(current.expires_at) : null;
  if (title.length < 5 || title.length > 120) return { error: 'عنوان اعلان باید بین ۵ تا ۱۲۰ کاراکتر باشد.' };
  if (content.length < 10 || content.length > 2000) return { error: 'متن اعلان باید بین ۱۰ تا ۲۰۰۰ کاراکتر باشد.' };
  if (Number.isNaN(startsAt.getTime()) || (expiresAt && (Number.isNaN(expiresAt.getTime()) || expiresAt <= startsAt))) return { error: 'بازه انتشار اعلان معتبر نیست.' };
  return { title, body: content, tone, audience, status, startsAt: startsAt.toISOString(), expiresAt: expiresAt && expiresAt.toISOString() };
}

app.post('/api/admin/announcements', allowPermissions('content.manage'), (req, res) => {
  const input = announcementInput(req.body);
  if (input.error) return res.status(400).json({ error: input.error });
  const announcementId = id('announcement'), now = iso();
  db.prepare(`INSERT INTO announcements (id,title,body,tone,audience,status,starts_at,expires_at,created_at,updated_at,created_by_admin_id,updated_by_admin_id)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(announcementId, input.title, input.body, input.tone, input.audience, input.status, input.startsAt, input.expiresAt, now, now, req.admin.id, req.admin.id);
  logAudit({ adminId: req.admin.id, action: 'ANNOUNCEMENT_CREATED', entityType: 'announcement', entityId: announcementId,
    details: { title: input.title, status: input.status, audience: input.audience }, ip: clientIp(req) });
  res.status(201).json({ ok: true, id: announcementId });
});

app.patch('/api/admin/announcements/:id', allowPermissions('content.manage'), (req, res) => {
  const current = db.prepare('SELECT * FROM announcements WHERE id=?').get(req.params.id);
  if (!current) return res.status(404).json({ error: 'اعلان پیدا نشد.' });
  const input = announcementInput(req.body, current);
  if (input.error) return res.status(400).json({ error: input.error });
  db.prepare(`UPDATE announcements SET title=?,body=?,tone=?,audience=?,status=?,starts_at=?,expires_at=?,updated_at=?,updated_by_admin_id=? WHERE id=?`)
    .run(input.title, input.body, input.tone, input.audience, input.status, input.startsAt, input.expiresAt, iso(), req.admin.id, current.id);
  logAudit({ adminId: req.admin.id, action: 'ANNOUNCEMENT_UPDATED', entityType: 'announcement', entityId: current.id,
    details: { title: input.title, fromStatus: current.status, toStatus: input.status, audience: input.audience }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.delete('/api/admin/announcements/:id', allowPermissions('content.manage'), (req, res) => {
  const current = db.prepare('SELECT * FROM announcements WHERE id=?').get(req.params.id);
  if (!current) return res.status(404).json({ error: 'اعلان پیدا نشد.' });
  db.prepare("UPDATE announcements SET status='archived',updated_at=?,updated_by_admin_id=? WHERE id=?").run(iso(), req.admin.id, current.id);
  logAudit({ adminId: req.admin.id, action: 'ANNOUNCEMENT_ARCHIVED', entityType: 'announcement', entityId: current.id,
    details: { title: current.title, fromStatus: current.status }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.get('/api/admin/security/overview', allowPermissions('security.view'), (req, res) => {
  const now = iso(), last24 = new Date(Date.now() - 86400000).toISOString(), last7 = new Date(Date.now() - 7 * 86400000).toISOString();
  db.prepare("UPDATE security_blocks SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?").run(now);
  const errorMetrics = db.prepare(`SELECT COUNT(*) AS total,
    COALESCE(SUM(CASE WHEN source LIKE '%DB%' OR source LIKE '%SQLITE%' OR message LIKE '%database%' THEN 1 ELSE 0 END),0) AS database_errors,
    COALESCE(SUM(CASE WHEN source LIKE '%API%' THEN 1 ELSE 0 END),0) AS api_errors,
    COALESCE(SUM(CASE WHEN severity IN ('critical','error') AND status='open' THEN 1 ELSE 0 END),0) AS open_high
    FROM system_errors WHERE occurred_at>=?`).get(last24);
  const failedLogins24h = db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action IN ('LOGIN_FAILED','LOGIN_BLOCKED') AND created_at>=?").get(last24).count;
  const metrics = {
    ...errorMetrics,
    failed_logins_24h: failedLogins24h,
    active_blocks: db.prepare("SELECT COUNT(*) AS count FROM security_blocks WHERE status='active' AND (expires_at IS NULL OR expires_at>?)").get(now).count,
    open_alerts: db.prepare("SELECT COUNT(*) AS count FROM security_alerts WHERE status!='resolved'").get().count,
    critical_alerts: db.prepare("SELECT COUNT(*) AS count FROM security_alerts WHERE status!='resolved' AND severity='critical'").get().count,
    audited_requests_24h: db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='ADMIN_API_REQUEST' AND created_at>=?").get(last24).count
  };
  const errors = db.prepare(`SELECT * FROM system_errors WHERE occurred_at>=? ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'error' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,occurred_at DESC LIMIT 100`).all(last7);
  const failedLogins = db.prepare(`SELECT l.*,a.name AS admin_name FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id
    WHERE l.action IN ('LOGIN_FAILED','LOGIN_BLOCKED') ORDER BY l.created_at DESC LIMIT 100`).all().map(row => ({ ...row, details: jsonDetails(row.details) }));
  const blocks = db.prepare(`SELECT b.*,creator.name AS created_by_name,revoker.name AS revoked_by_name FROM security_blocks b
    LEFT JOIN admins creator ON creator.id=b.created_by_admin_id LEFT JOIN admins revoker ON revoker.id=b.revoked_by_admin_id
    ORDER BY CASE b.status WHEN 'active' THEN 0 WHEN 'expired' THEN 1 ELSE 2 END,b.created_at DESC LIMIT 200`).all();
  const limitedUsers = db.prepare(`SELECT id,name,mobile,status,access_mode,limited_until,restriction_reason,last_seen_at FROM users
    WHERE deleted_at IS NULL AND (status='suspended' OR access_mode='limited') ORDER BY COALESCE(limited_until,last_seen_at) DESC LIMIT 100`).all();
  const alerts = db.prepare(`SELECT s.*,a.name AS resolved_by_name FROM security_alerts s LEFT JOIN admins a ON a.id=s.resolved_by_admin_id
    ORDER BY CASE s.status WHEN 'open' THEN 0 WHEN 'acknowledged' THEN 1 ELSE 2 END,CASE s.severity WHEN 'critical' THEN 0 WHEN 'error' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,s.detected_at DESC LIMIT 200`).all()
    .map(row => ({ ...row, details: jsonDetails(row.details) }));
  const importantActions = ['USER_STATUS_UPDATED','USER_FORCE_LOGOUT','USER_RECOVERY_STARTED','USER_ACCOUNT_DELETED','SUBSCRIPTION_UPDATED','SUBSCRIPTION_MANUALLY_ACTIVATED','SUBSCRIPTION_CANCELLED','PLAN_LIMITS_UPDATED','COUPON_CREATED','COUPON_STATUS_UPDATED','PAYMENT_REFUNDED','SMS_SETTINGS_UPDATED','SMS_PROVIDER_SWITCHED','FILE_SETTINGS_UPDATED','ORPHAN_FILES_CLEANED','ORPHAN_FILES_AUTO_CLEANED','FILE_REVIEWED','FILE_DELETED','ERROR_RESOLVED','SECURITY_BLOCK_CREATED','SECURITY_BLOCK_REVOKED','SECURITY_ALERT_UPDATED','SYSTEM_SETTINGS_UPDATED','SYSTEM_CONTENT_UPDATED','ANNOUNCEMENT_CREATED','ANNOUNCEMENT_UPDATED','ANNOUNCEMENT_ARCHIVED','ADMIN_CREATED','ADMIN_ACCESS_UPDATED','ADMIN_PROFILE_UPDATED','ROLE_PERMISSIONS_UPDATED','CMS_PAGE_CREATED','CMS_PAGE_UPDATED','CMS_SECTION_CREATED','CMS_SECTION_UPDATED','CMS_SECTION_ARCHIVED','CMS_PAGE_DUPLICATED','CMS_SECTION_DUPLICATED','CMS_REVISION_RESTORED','CMS_MENU_CREATED','CMS_MENU_UPDATED','CMS_MENU_ARCHIVED','USER_CONTACT_CREATED','USER_CONTACT_UPDATED','USER_CONTACT_DELETED','USER_CONTACTS_SYNCED','USER_CONTACTS_IMPORTED'];
  const placeholders = importantActions.map(() => '?').join(',');
  const adminActivity = db.prepare(`SELECT l.*,a.name AS admin_name,a.mobile AS admin_mobile FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id
    WHERE l.action IN (${placeholders}) ORDER BY l.created_at DESC LIMIT 120`).all(...importantActions).map(row => ({ ...row, details: jsonDetails(row.details) }));
  const changeReports = db.prepare(`SELECT l.*,a.name AS admin_name FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id
    WHERE l.action LIKE '%UPDATED' OR l.action LIKE '%DELETED' OR l.action LIKE '%CLEANED' OR l.action LIKE '%REFUNDED' OR l.action LIKE '%CANCELLED' OR l.action LIKE '%ARCHIVED'
    ORDER BY l.created_at DESC LIMIT 120`).all().map(row => ({ ...row, details: jsonDetails(row.details) }));
  const accessAudit = db.prepare(`SELECT l.*,a.name AS admin_name FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id
    WHERE l.action='ADMIN_API_REQUEST' ORDER BY l.created_at DESC LIMIT 120`).all().map(row => ({ ...row, details: jsonDetails(row.details) }));
  const indicators = {
    suspicious_sms_24h: db.prepare('SELECT COUNT(*) AS count FROM sms_logs WHERE is_suspicious=1 AND created_at>=?').get(last24).count,
    suspicious_files: db.prepare("SELECT COUNT(*) AS count FROM media_files WHERE status!='deleted' AND scan_status='suspicious'").get().count,
    storage_pressure_users: db.prepare(`SELECT COUNT(*) AS count FROM users u JOIN subscriptions s ON s.user_id=u.id JOIN plans p ON p.id=s.plan_id
      WHERE u.deleted_at IS NULL AND u.storage_bytes>=p.max_storage_bytes*.85`).get().count,
    failed_logins_24h: failedLogins24h
  };
  res.json({ metrics, errors, failedLogins, blocks, limitedUsers, alerts, adminActivity, changeReports, accessAudit, indicators });
});

app.post('/api/admin/security/blocks', allowPermissions('security.manage'), (req, res) => {
  const blockType = req.body.blockType === 'mobile' ? 'mobile' : req.body.blockType === 'ip' ? 'ip' : '';
  const rawValue = String(req.body.value || '').trim();
  const blockValue = blockType === 'mobile' ? normalizeMobile(rawValue) : rawValue;
  const reason = String(req.body.reason || '').trim().slice(0, 300);
  const expiresAt = req.body.expiresAt ? new Date(req.body.expiresAt) : null;
  if (!blockType || (blockType === 'mobile' ? !/^09\d{9}$/.test(blockValue) : !net.isIP(blockValue))) return res.status(400).json({ error: 'شماره موبایل یا IP معتبر نیست.' });
  if (reason.length < 5) return res.status(400).json({ error: 'دلیل محدودسازی را با حداقل ۵ کاراکتر وارد کنید.' });
  if (expiresAt && (Number.isNaN(expiresAt.getTime()) || expiresAt <= new Date())) return res.status(400).json({ error: 'زمان پایان محدودیت معتبر نیست.' });
  const exists = db.prepare("SELECT id FROM security_blocks WHERE block_type=? AND block_value=? AND status='active' AND (expires_at IS NULL OR expires_at>?)").get(blockType, blockValue, iso());
  if (exists) return res.status(409).json({ error: 'این مورد هم‌اکنون محدود شده است.' });
  const blockId = id('block');
  db.prepare(`INSERT INTO security_blocks (id,block_type,block_value,reason,source,status,expires_at,created_at,created_by_admin_id)
    VALUES (?,?,?,?,?,'active',?,?,?)`).run(blockId, blockType, blockValue, reason, 'manual', expiresAt && expiresAt.toISOString(), iso(), req.admin.id);
  logAudit({ adminId: req.admin.id, action: 'SECURITY_BLOCK_CREATED', entityType: 'security_block', entityId: blockId,
    details: { blockType, blockValue, reason, expiresAt: expiresAt && expiresAt.toISOString() }, ip: clientIp(req) });
  res.status(201).json({ ok: true, id: blockId });
});

app.patch('/api/admin/security/blocks/:id', allowPermissions('security.manage'), (req, res) => {
  const block = db.prepare('SELECT * FROM security_blocks WHERE id=?').get(req.params.id);
  if (!block) return res.status(404).json({ error: 'محدودیت امنیتی پیدا نشد.' });
  if (block.status !== 'active') return res.status(400).json({ error: 'این محدودیت فعال نیست.' });
  db.prepare("UPDATE security_blocks SET status='revoked',revoked_at=?,revoked_by_admin_id=? WHERE id=?").run(iso(), req.admin.id, block.id);
  logAudit({ adminId: req.admin.id, action: 'SECURITY_BLOCK_REVOKED', entityType: 'security_block', entityId: block.id,
    details: { blockType: block.block_type, blockValue: block.block_value, reason: block.reason }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.patch('/api/admin/security/alerts/:id', allowPermissions('security.manage'), (req, res) => {
  const alert = db.prepare('SELECT * FROM security_alerts WHERE id=?').get(req.params.id);
  if (!alert) return res.status(404).json({ error: 'هشدار امنیتی پیدا نشد.' });
  const status = String(req.body.status || '');
  if (!['acknowledged','resolved'].includes(status)) return res.status(400).json({ error: 'وضعیت هشدار معتبر نیست.' });
  const now = iso();
  db.prepare(`UPDATE security_alerts SET status=?,acknowledged_at=COALESCE(acknowledged_at,?),resolved_at=?,resolved_by_admin_id=? WHERE id=?`)
    .run(status, now, status === 'resolved' ? now : null, status === 'resolved' ? req.admin.id : null, alert.id);
  logAudit({ adminId: req.admin.id, action: 'SECURITY_ALERT_UPDATED', entityType: 'security_alert', entityId: alert.id,
    details: { title: alert.title, from: alert.status, to: status }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.get('/api/admin/errors', allowPermissions('security.view'), (req, res) => {
  const status = ['open', 'resolved', 'ignored'].includes(req.query.status) ? req.query.status : '';
  const severity = ['critical', 'error', 'warning', 'info'].includes(req.query.severity) ? req.query.severity : '';
  const where = [], params = {};
  if (status) { where.push('status=@status'); params.status = status; }
  if (severity) { where.push('severity=@severity'); params.severity = severity; }
  const rows = db.prepare(`SELECT * FROM system_errors ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY occurred_at DESC LIMIT 200`).all(params);
  res.json({ rows });
});

app.patch('/api/admin/errors/:id', allowPermissions('security.manage'), (req, res) => {
  const status = String(req.body.status || '');
  if (!['open', 'resolved', 'ignored'].includes(status)) return res.status(400).json({ error: 'وضعیت خطا معتبر نیست.' });
  const error = db.prepare('SELECT * FROM system_errors WHERE id=?').get(req.params.id);
  if (!error) return res.status(404).json({ error: 'خطا پیدا نشد.' });
  db.prepare('UPDATE system_errors SET status=?,resolved_at=? WHERE id=?').run(status, status === 'resolved' ? iso() : null, error.id);
  logAudit({ adminId: req.admin.id, action: status === 'resolved' ? 'ERROR_RESOLVED' : 'ERROR_STATUS_UPDATED', entityType: 'system_error', entityId: error.id, details: { source: error.source, status }, ip: clientIp(req) });
  res.json({ ok: true });
});

app.get('/api/admin/audit', allowPermissions('security.view'), (req, res) => {
  const rows = db.prepare(`SELECT l.*,a.name AS admin_name,a.mobile AS admin_mobile FROM audit_logs l LEFT JOIN admins a ON a.id=l.admin_id ORDER BY l.created_at DESC LIMIT 300`).all()
    .map(row => ({ ...row, details: jsonDetails(row.details) }));
  res.json({ rows });
});

function cmsDate(value,currentValue=null){if(value===undefined)return currentValue||null;if(value===null||value==='')return null;const date=new Date(value);return Number.isNaN(date.getTime())?undefined:date.toISOString()}
function cmsSafeUrl(value=''){const url=String(value||'').trim();return !url||/^(\/|#|https?:\/\/|mailto:|tel:)/i.test(url)?url:null}
function recordCmsRevision(entityType,row,adminId){
  if(!row)return;const version=db.prepare('SELECT COALESCE(MAX(version),0)+1 version FROM cms_revisions WHERE entity_type=? AND entity_id=?').get(entityType,row.id).version;
  db.prepare('INSERT INTO cms_revisions (id,entity_type,entity_id,version,snapshot,created_at,created_by_admin_id) VALUES (?,?,?,?,?,?,?)').run(id('cms_rev'),entityType,row.id,version,JSON.stringify(row),iso(),adminId||null);
}
function cmsPageInput(body, current = {}) {
  const title = String(body.title ?? current.title ?? '').trim(), slug = String(body.slug ?? current.slug ?? '').trim().toLowerCase();
  const metaDescription = String(body.metaDescription ?? current.meta_description ?? '').trim(), status = String(body.status ?? current.status ?? 'draft');
  const seoTitle=String(body.seoTitle??current.seo_title??'').trim(),seoKeywords=String(body.seoKeywords??current.seo_keywords??'').trim();
  const ogImage=cmsSafeUrl(body.ogImage??current.og_image??''),canonicalUrl=cmsSafeUrl(body.canonicalUrl??current.canonical_url??'');
  const publishAt=cmsDate(body.publishAt,current.publish_at),unpublishAt=cmsDate(body.unpublishAt,current.unpublish_at);
  if (title.length < 2 || title.length > 160) return { error:'عنوان صفحه باید بین ۲ تا ۱۶۰ کاراکتر باشد.' };
  if (!/^[a-z0-9][a-z0-9-]{0,79}$/.test(slug)) return { error:'شناسه صفحه فقط می‌تواند شامل حروف انگلیسی کوچک، عدد و خط تیره باشد.' };
  if (metaDescription.length > 500 || seoTitle.length>180 || seoKeywords.length>500 || !['draft','published','archived'].includes(status)) return { error:'اطلاعات یا SEO صفحه معتبر نیست.' };
  if(ogImage===null||canonicalUrl===null||publishAt===undefined||unpublishAt===undefined||(publishAt&&unpublishAt&&unpublishAt<=publishAt))return {error:'آدرس تصویر/Canonical یا زمان‌بندی انتشار معتبر نیست.'};
  return { title,slug,metaDescription,seoTitle,seoKeywords,ogImage,canonicalUrl,publishAt,unpublishAt,status };
}
function cmsSectionInput(body, current = {}) {
  const sectionKey = String(body.sectionKey ?? current.section_key ?? '').trim().toLowerCase();
  const sectionType = String(body.sectionType ?? current.section_type ?? 'content');
  const title = String(body.title ?? current.title ?? '').trim(), content = String(body.body ?? current.body ?? '').trim();
  const buttonLabel = String(body.buttonLabel ?? current.button_label ?? '').trim(), buttonUrl = cmsSafeUrl(body.buttonUrl ?? current.button_url ?? '');
  const imageUrl=cmsSafeUrl(body.imageUrl??current.image_url??''),imageAlt=String(body.imageAlt??current.image_alt??'').trim();
  const publishAt=cmsDate(body.publishAt,current.publish_at),unpublishAt=cmsDate(body.unpublishAt,current.unpublish_at);
  const sortOrder = Number(body.sortOrder ?? current.sort_order ?? 0), status = String(body.status ?? current.status ?? 'published');
  if (!/^[a-z0-9][a-z0-9_-]{0,79}$/.test(sectionKey)) return { error:'کلید سکشن معتبر نیست.' };
  if (!['hero','content','feature','cta','footer','form','custom'].includes(sectionType) || !['draft','published','archived'].includes(status)) return { error:'نوع یا وضعیت سکشن معتبر نیست.' };
  if (title.length > 300 || content.length > 50000 || buttonLabel.length > 120 || imageAlt.length>300) return { error:'طول محتوای سکشن بیش از حد مجاز است.' };
  if (!Number.isInteger(sortOrder) || sortOrder < -10000 || sortOrder > 10000) return { error:'ترتیب نمایش معتبر نیست.' };
  if (buttonUrl===null||imageUrl===null||publishAt===undefined||unpublishAt===undefined||(publishAt&&unpublishAt&&unpublishAt<=publishAt)) return { error:'لینک، تصویر یا زمان‌بندی سکشن معتبر نیست.' };
  return { sectionKey,sectionType,title,body:content,buttonLabel,buttonUrl,imageUrl,imageAlt,publishAt,unpublishAt,sortOrder,status };
}

app.get('/api/admin/cms/pages', allowPermissions('cms.manage'), (req, res) => {
  const rows = db.prepare(`SELECT p.*,a.name AS updated_by_name,(SELECT COUNT(*) FROM cms_sections s WHERE s.page_id=p.id AND s.status!='archived') AS section_count
    FROM cms_pages p LEFT JOIN admins a ON a.id=p.updated_by_admin_id ORDER BY CASE p.status WHEN 'published' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,p.updated_at DESC`).all();
  res.json({ rows });
});
app.post('/api/admin/cms/pages', allowPermissions('cms.manage'), (req, res) => {
  const input = cmsPageInput(req.body); if (input.error) return res.status(400).json({ error:input.error });
  if (db.prepare('SELECT 1 FROM cms_pages WHERE slug=?').get(input.slug)) return res.status(409).json({ error:'این شناسه صفحه قبلاً استفاده شده است.' });
  const pageId=id('cms_page'),now=iso();
  db.prepare(`INSERT INTO cms_pages (id,slug,title,meta_description,seo_title,seo_keywords,og_image,canonical_url,publish_at,unpublish_at,status,created_at,updated_at,created_by_admin_id,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(pageId,input.slug,input.title,input.metaDescription||null,input.seoTitle||null,input.seoKeywords||null,input.ogImage||null,input.canonicalUrl||null,input.publishAt,input.unpublishAt,input.status,now,now,req.admin.id,req.admin.id);
  recordCmsRevision('page',db.prepare('SELECT * FROM cms_pages WHERE id=?').get(pageId),req.admin.id);
  logAudit({adminId:req.admin.id,action:'CMS_PAGE_CREATED',entityType:'cms_page',entityId:pageId,details:input,ip:clientIp(req)});
  res.status(201).json({ok:true,id:pageId});
});
app.patch('/api/admin/cms/pages/:id', allowPermissions('cms.manage'), (req, res) => {
  const page=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(req.params.id);if(!page)return res.status(404).json({error:'صفحه پیدا نشد.'});
  const input=cmsPageInput(req.body,page);if(input.error)return res.status(400).json({error:input.error});
  if(db.prepare('SELECT 1 FROM cms_pages WHERE slug=? AND id!=?').get(input.slug,page.id))return res.status(409).json({error:'این شناسه صفحه قبلاً استفاده شده است.'});
  recordCmsRevision('page',page,req.admin.id);
  db.prepare('UPDATE cms_pages SET slug=?,title=?,meta_description=?,seo_title=?,seo_keywords=?,og_image=?,canonical_url=?,publish_at=?,unpublish_at=?,status=?,updated_at=?,updated_by_admin_id=? WHERE id=?')
    .run(input.slug,input.title,input.metaDescription||null,input.seoTitle||null,input.seoKeywords||null,input.ogImage||null,input.canonicalUrl||null,input.publishAt,input.unpublishAt,input.status,iso(),req.admin.id,page.id);
  logAudit({adminId:req.admin.id,action:'CMS_PAGE_UPDATED',entityType:'cms_page',entityId:page.id,details:{fromStatus:page.status,toStatus:input.status,slug:input.slug,title:input.title},ip:clientIp(req)});
  res.json({ok:true});
});
app.get('/api/admin/cms/pages/:id/sections', allowPermissions('cms.manage'), (req, res) => {
  const page=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(req.params.id);if(!page)return res.status(404).json({error:'صفحه پیدا نشد.'});
  const sections=db.prepare("SELECT * FROM cms_sections WHERE page_id=? AND status!='archived' ORDER BY sort_order,created_at").all(page.id);
  res.json({page,sections});
});
app.post('/api/admin/cms/pages/:id/sections', allowPermissions('cms.manage'), (req, res) => {
  const page=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(req.params.id);if(!page)return res.status(404).json({error:'صفحه پیدا نشد.'});
  const input=cmsSectionInput(req.body);if(input.error)return res.status(400).json({error:input.error});
  if(db.prepare('SELECT 1 FROM cms_sections WHERE page_id=? AND section_key=?').get(page.id,input.sectionKey))return res.status(409).json({error:'این کلید سکشن در صفحه وجود دارد.'});
  const sectionId=id('cms_section'),now=iso();
  db.prepare(`INSERT INTO cms_sections (id,page_id,section_key,section_type,title,body,button_label,button_url,image_url,image_alt,publish_at,unpublish_at,sort_order,status,created_at,updated_at,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(sectionId,page.id,input.sectionKey,input.sectionType,input.title||null,input.body||null,input.buttonLabel||null,input.buttonUrl||null,input.imageUrl||null,input.imageAlt||null,input.publishAt,input.unpublishAt,input.sortOrder,input.status,now,now,req.admin.id);
  recordCmsRevision('section',db.prepare('SELECT * FROM cms_sections WHERE id=?').get(sectionId),req.admin.id);
  db.prepare('UPDATE cms_pages SET updated_at=?,updated_by_admin_id=? WHERE id=?').run(now,req.admin.id,page.id);
  logAudit({adminId:req.admin.id,action:'CMS_SECTION_CREATED',entityType:'cms_section',entityId:sectionId,details:{pageId:page.id,sectionKey:input.sectionKey,status:input.status},ip:clientIp(req)});
  res.status(201).json({ok:true,id:sectionId});
});
app.patch('/api/admin/cms/sections/:id', allowPermissions('cms.manage'), (req, res) => {
  const section=db.prepare('SELECT * FROM cms_sections WHERE id=?').get(req.params.id);if(!section)return res.status(404).json({error:'سکشن پیدا نشد.'});
  const input=cmsSectionInput(req.body,section);if(input.error)return res.status(400).json({error:input.error});
  if(db.prepare('SELECT 1 FROM cms_sections WHERE page_id=? AND section_key=? AND id!=?').get(section.page_id,input.sectionKey,section.id))return res.status(409).json({error:'این کلید سکشن در صفحه وجود دارد.'});
  const now=iso();recordCmsRevision('section',section,req.admin.id);db.prepare(`UPDATE cms_sections SET section_key=?,section_type=?,title=?,body=?,button_label=?,button_url=?,image_url=?,image_alt=?,publish_at=?,unpublish_at=?,sort_order=?,status=?,updated_at=?,updated_by_admin_id=? WHERE id=?`)
    .run(input.sectionKey,input.sectionType,input.title||null,input.body||null,input.buttonLabel||null,input.buttonUrl||null,input.imageUrl||null,input.imageAlt||null,input.publishAt,input.unpublishAt,input.sortOrder,input.status,now,req.admin.id,section.id);
  db.prepare('UPDATE cms_pages SET updated_at=?,updated_by_admin_id=? WHERE id=?').run(now,req.admin.id,section.page_id);
  logAudit({adminId:req.admin.id,action:'CMS_SECTION_UPDATED',entityType:'cms_section',entityId:section.id,details:{pageId:section.page_id,sectionKey:input.sectionKey,fromStatus:section.status,toStatus:input.status},ip:clientIp(req)});
  res.json({ok:true});
});
app.delete('/api/admin/cms/sections/:id', allowPermissions('cms.manage'), (req, res) => {
  const section=db.prepare('SELECT * FROM cms_sections WHERE id=?').get(req.params.id);if(!section)return res.status(404).json({error:'سکشن پیدا نشد.'});
  const now=iso();recordCmsRevision('section',section,req.admin.id);db.prepare("UPDATE cms_sections SET status='archived',updated_at=?,updated_by_admin_id=? WHERE id=?").run(now,req.admin.id,section.id);
  db.prepare('UPDATE cms_pages SET updated_at=?,updated_by_admin_id=? WHERE id=?').run(now,req.admin.id,section.page_id);
  logAudit({adminId:req.admin.id,action:'CMS_SECTION_ARCHIVED',entityType:'cms_section',entityId:section.id,details:{pageId:section.page_id,sectionKey:section.section_key},ip:clientIp(req)});
  res.json({ok:true});
});

app.post('/api/admin/cms/pages/:id/duplicate', allowPermissions('cms.manage'), (req,res)=>{
  const page=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(req.params.id);if(!page)return res.status(404).json({error:'صفحه پیدا نشد.'});
  let slug=`${page.slug}-copy`,counter=2;while(db.prepare('SELECT 1 FROM cms_pages WHERE slug=?').get(slug))slug=`${page.slug}-copy-${counter++}`;
  const pageId=id('cms_page'),now=iso();db.prepare(`INSERT INTO cms_pages (id,slug,title,meta_description,seo_title,seo_keywords,og_image,canonical_url,publish_at,unpublish_at,status,created_at,updated_at,created_by_admin_id,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,NULL,NULL,'draft',?,?,?,?)`)
    .run(pageId,slug,`${page.title} — کپی`,page.meta_description,page.seo_title,page.seo_keywords,page.og_image,null,now,now,req.admin.id,req.admin.id);
  const sections=db.prepare("SELECT * FROM cms_sections WHERE page_id=? AND status!='archived'").all(page.id),insert=db.prepare(`INSERT INTO cms_sections (id,page_id,section_key,section_type,title,body,button_label,button_url,image_url,image_alt,publish_at,unpublish_at,sort_order,status,created_at,updated_at,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,NULL,NULL,?,'draft',?,?,?)`);
  db.transaction(()=>sections.forEach(section=>insert.run(id('cms_section'),pageId,section.section_key,section.section_type,section.title,section.body,section.button_label,section.button_url,section.image_url,section.image_alt,section.sort_order,now,now,req.admin.id)))();
  recordCmsRevision('page',db.prepare('SELECT * FROM cms_pages WHERE id=?').get(pageId),req.admin.id);logAudit({adminId:req.admin.id,action:'CMS_PAGE_DUPLICATED',entityType:'cms_page',entityId:pageId,details:{sourcePageId:page.id,slug,sections:sections.length},ip:clientIp(req)});res.status(201).json({ok:true,id:pageId});
});
app.post('/api/admin/cms/sections/:id/duplicate', allowPermissions('cms.manage'), (req,res)=>{
  const section=db.prepare('SELECT * FROM cms_sections WHERE id=?').get(req.params.id);if(!section)return res.status(404).json({error:'سکشن پیدا نشد.'});let key=`${section.section_key}_copy`,counter=2;while(db.prepare('SELECT 1 FROM cms_sections WHERE page_id=? AND section_key=?').get(section.page_id,key))key=`${section.section_key}_copy_${counter++}`;
  const sectionId=id('cms_section'),now=iso();db.prepare(`INSERT INTO cms_sections (id,page_id,section_key,section_type,title,body,button_label,button_url,image_url,image_alt,publish_at,unpublish_at,sort_order,status,created_at,updated_at,updated_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,NULL,NULL,?,'draft',?,?,?)`)
    .run(sectionId,section.page_id,key,section.section_type,section.title,section.body,section.button_label,section.button_url,section.image_url,section.image_alt,section.sort_order+1,now,now,req.admin.id);recordCmsRevision('section',db.prepare('SELECT * FROM cms_sections WHERE id=?').get(sectionId),req.admin.id);logAudit({adminId:req.admin.id,action:'CMS_SECTION_DUPLICATED',entityType:'cms_section',entityId:sectionId,details:{sourceSectionId:section.id,pageId:section.page_id},ip:clientIp(req)});res.status(201).json({ok:true,id:sectionId});
});
app.get('/api/admin/cms/revisions/:entityType/:entityId', allowPermissions('cms.manage'), (req,res)=>{
  if(!['page','section'].includes(req.params.entityType))return res.status(400).json({error:'نوع تاریخچه معتبر نیست.'});const rows=db.prepare(`SELECT r.id,r.entity_type,r.entity_id,r.version,r.snapshot,r.created_at,a.name AS admin_name FROM cms_revisions r LEFT JOIN admins a ON a.id=r.created_by_admin_id WHERE r.entity_type=? AND r.entity_id=? ORDER BY r.version DESC LIMIT 100`).all(req.params.entityType,req.params.entityId).map(row=>({...row,snapshot:jsonDetails(row.snapshot)}));res.json({rows});
});
app.post('/api/admin/cms/revisions/:id/restore', allowPermissions('cms.manage'), (req,res)=>{
  const revision=db.prepare('SELECT * FROM cms_revisions WHERE id=?').get(req.params.id);if(!revision)return res.status(404).json({error:'نسخه محتوا پیدا نشد.'});const snapshot=jsonDetails(revision.snapshot),now=iso();
  if(revision.entity_type==='page'){const current=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(revision.entity_id);if(!current)return res.status(404).json({error:'صفحه اصلی این نسخه پیدا نشد.'});recordCmsRevision('page',current,req.admin.id);db.prepare(`UPDATE cms_pages SET slug=?,title=?,meta_description=?,seo_title=?,seo_keywords=?,og_image=?,canonical_url=?,publish_at=?,unpublish_at=?,status=?,updated_at=?,updated_by_admin_id=? WHERE id=?`).run(snapshot.slug,snapshot.title,snapshot.meta_description,snapshot.seo_title,snapshot.seo_keywords,snapshot.og_image,snapshot.canonical_url,snapshot.publish_at,snapshot.unpublish_at,snapshot.status,now,req.admin.id,current.id)}else{const current=db.prepare('SELECT * FROM cms_sections WHERE id=?').get(revision.entity_id);if(!current)return res.status(404).json({error:'سکشن اصلی این نسخه پیدا نشد.'});recordCmsRevision('section',current,req.admin.id);db.prepare(`UPDATE cms_sections SET section_key=?,section_type=?,title=?,body=?,button_label=?,button_url=?,image_url=?,image_alt=?,publish_at=?,unpublish_at=?,sort_order=?,status=?,updated_at=?,updated_by_admin_id=? WHERE id=?`).run(snapshot.section_key,snapshot.section_type,snapshot.title,snapshot.body,snapshot.button_label,snapshot.button_url,snapshot.image_url,snapshot.image_alt,snapshot.publish_at,snapshot.unpublish_at,snapshot.sort_order,snapshot.status,now,req.admin.id,current.id)}
  logAudit({adminId:req.admin.id,action:'CMS_REVISION_RESTORED',entityType:`cms_${revision.entity_type}`,entityId:revision.entity_id,details:{version:revision.version,revisionId:revision.id},ip:clientIp(req)});res.json({ok:true});
});
app.get('/api/admin/cms/menus', allowPermissions('cms.manage'), (req,res)=>{const rows=db.prepare("SELECT * FROM cms_menu_items WHERE status!='archived' ORDER BY menu_key,sort_order,created_at").all();res.json({rows})});
app.post('/api/admin/cms/menus', allowPermissions('cms.manage'), (req,res)=>{const label=String(req.body.label||'').trim(),url=cmsSafeUrl(req.body.url),menuKey=String(req.body.menuKey||'header').trim().toLowerCase(),sortOrder=Number(req.body.sortOrder||0),status=['draft','published'].includes(req.body.status)?req.body.status:'published';if(label.length<1||label.length>120||url===null||!url||!/^[a-z0-9_-]{2,40}$/.test(menuKey)||!Number.isInteger(sortOrder))return res.status(400).json({error:'اطلاعات آیتم منو معتبر نیست.'});const menuId=id('cms_menu'),now=iso();db.prepare(`INSERT INTO cms_menu_items (id,menu_key,label,url,parent_id,sort_order,status,created_at,updated_at,updated_by_admin_id) VALUES (?,?,?,?,NULL,?,?,?,?,?)`).run(menuId,menuKey,label,url,sortOrder,status,now,now,req.admin.id);logAudit({adminId:req.admin.id,action:'CMS_MENU_CREATED',entityType:'cms_menu_item',entityId:menuId,details:{menuKey,label,url},ip:clientIp(req)});res.status(201).json({ok:true,id:menuId})});
app.patch('/api/admin/cms/menus/:id', allowPermissions('cms.manage'), (req,res)=>{const item=db.prepare('SELECT * FROM cms_menu_items WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'آیتم منو پیدا نشد.'});const label=String(req.body.label??item.label).trim(),url=cmsSafeUrl(req.body.url??item.url),menuKey=String(req.body.menuKey??item.menu_key).trim().toLowerCase(),sortOrder=Number(req.body.sortOrder??item.sort_order),status=['draft','published','archived'].includes(req.body.status)?req.body.status:item.status;if(!label||url===null||!url||!/^[a-z0-9_-]{2,40}$/.test(menuKey)||!Number.isInteger(sortOrder))return res.status(400).json({error:'اطلاعات آیتم منو معتبر نیست.'});db.prepare('UPDATE cms_menu_items SET menu_key=?,label=?,url=?,sort_order=?,status=?,updated_at=?,updated_by_admin_id=? WHERE id=?').run(menuKey,label,url,sortOrder,status,iso(),req.admin.id,item.id);logAudit({adminId:req.admin.id,action:'CMS_MENU_UPDATED',entityType:'cms_menu_item',entityId:item.id,details:{menuKey,label,url,status},ip:clientIp(req)});res.json({ok:true})});
app.delete('/api/admin/cms/menus/:id', allowPermissions('cms.manage'), (req,res)=>{const result=db.prepare("UPDATE cms_menu_items SET status='archived',updated_at=?,updated_by_admin_id=? WHERE id=?").run(iso(),req.admin.id,req.params.id);if(!result.changes)return res.status(404).json({error:'آیتم منو پیدا نشد.'});logAudit({adminId:req.admin.id,action:'CMS_MENU_ARCHIVED',entityType:'cms_menu_item',entityId:req.params.id,details:{},ip:clientIp(req)});res.json({ok:true})});
app.post('/api/admin/cms/pages/:id/preview-token', allowPermissions('cms.manage'), (req,res)=>{const page=db.prepare('SELECT id FROM cms_pages WHERE id=?').get(req.params.id);if(!page)return res.status(404).json({error:'صفحه پیدا نشد.'});const token=secureToken(30),expiresAt=new Date(Date.now()+30*60000).toISOString();db.prepare('DELETE FROM cms_preview_tokens WHERE expires_at<=?').run(iso());db.prepare('INSERT INTO cms_preview_tokens (token_hash,page_id,expires_at,created_at,created_by_admin_id) VALUES (?,?,?,?,?)').run(tokenHash(token),page.id,expiresAt,iso(),req.admin.id);res.json({ok:true,url:`/cms-preview/${token}`,expiresAt})});

app.get('/api/public/cms-menus/:key', (req,res)=>{const key=String(req.params.key||'header').toLowerCase();const rows=db.prepare("SELECT id,label,url,parent_id,sort_order FROM cms_menu_items WHERE menu_key=? AND status='published' ORDER BY sort_order,created_at").all(key);res.json({key,rows})});
app.get('/cms-preview/:token', (req,res)=>{const token=db.prepare('SELECT * FROM cms_preview_tokens WHERE token_hash=? AND expires_at>?').get(tokenHash(String(req.params.token||'')),iso());if(!token)return res.status(404).type('html').send('<h1>لینک پیش‌نمایش منقضی یا نامعتبر است.</h1>');const page=db.prepare('SELECT * FROM cms_pages WHERE id=?').get(token.page_id),sections=db.prepare("SELECT * FROM cms_sections WHERE page_id=? AND status!='archived' ORDER BY sort_order,created_at").all(page.id);const cards=sections.map(section=>`<section><small>${escapeHtml(section.section_key)} · ${escapeHtml(section.status)}</small>${section.image_url?`<img src="${escapeHtml(section.image_url)}" alt="${escapeHtml(section.image_alt||'')}">`:''}<h2>${escapeHtml(section.title||'')}</h2><p>${escapeHtml(section.body||'').replace(/\n/g,'<br>')}</p>${section.button_label?`<a href="#">${escapeHtml(section.button_label)}</a>`:''}</section>`).join('');res.type('html').send(`<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>پیش‌نمایش ${escapeHtml(page.title)}</title><style>body{margin:0;padding:30px;background:#080c13;color:#eef3f9;font-family:Tahoma}.note{padding:12px;border:1px solid #775f1e;color:#fbbf24;background:#1d1809}main{max-width:980px;margin:auto}section{margin:14px 0;padding:28px;border:1px solid #26364b;border-radius:18px;background:#101925}small{color:#22d3ee}p{color:#9aa9bb;line-height:2}img{max-width:100%;max-height:420px;border-radius:12px}a{display:inline-block;padding:10px 15px;border-radius:9px;color:#04252d;background:#22d3ee;text-decoration:none}</style><main><div class="note">پیش‌نمایش امن — شامل محتوای پیش‌نویس؛ اعتبار لینک ۳۰ دقیقه</div>${cards}</main></html>`)});

app.get('/api/public/cms/:slug', async(req, res, next) => {try{const slug=String(req.params.slug||'').toLowerCase(),cached=await redisStore.cacheGet('public-cms',slug);if(cached){res.setHeader('X-Cache','HIT');return res.json(cached)}const page=db.prepare("SELECT id,slug,title,meta_description,seo_title,seo_keywords,og_image,canonical_url,status,updated_at FROM cms_pages WHERE slug=? AND status='published' AND (publish_at IS NULL OR publish_at<=?) AND (unpublish_at IS NULL OR unpublish_at>?)").get(slug,iso(),iso());if(!page)return res.status(404).json({error:'صفحه منتشرشده پیدا نشد.'});const sections=db.prepare("SELECT id,section_key,section_type,title,body,button_label,button_url,image_url,image_alt,sort_order,updated_at FROM cms_sections WHERE page_id=? AND status='published' AND (publish_at IS NULL OR publish_at<=?) AND (unpublish_at IS NULL OR unpublish_at>?) ORDER BY sort_order,created_at").all(page.id,iso(),iso()),payload={page,sections};await redisStore.cacheSet('public-cms',slug,payload,60);res.setHeader('Cache-Control','public, max-age=60, stale-while-revalidate=300');res.setHeader('X-Cache','MISS');res.json(payload)}catch(error){next(error)}});

app.get('/api/public/plans',(req,res)=>{res.setHeader('Cache-Control','public, max-age=60, stale-while-revalidate=300');res.json({currency:'TOMAN',billingPeriod:'month',rows:publicPlans()})});
app.get('/api/public/faqs',(req,res)=>{res.setHeader('Cache-Control','public, max-age=60, stale-while-revalidate=300');res.json({rows:publicFaqs()})});
app.get('/api/public/marketing',(req,res)=>{res.setHeader('Cache-Control','public, max-age=300, stale-while-revalidate=900');res.json({faqs:FAQS,guides:GUIDES})});
app.post('/api/public/support',async(req,res,next)=>{try{res.setHeader('Cache-Control','no-store');const ip=clientIp(req),limit=await distributedLimit('public-support',tokenHash(ip||'unknown'),5,60*60*1000,supportAttempts);if(limit.limited){res.setHeader('Retry-After',String(Math.max(1,Math.ceil(limit.resetMs/1000))));return res.status(429).json({error:'تعداد درخواست‌های پشتیبانی بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.'})}if(String(req.body.website||'').trim())return res.status(202).json({ok:true,reference:`SJ-${Date.now().toString(36).toUpperCase()}`});const name=String(req.body.name||'').trim(),rawMobile=String(req.body.mobile||'').trim(),mobile=rawMobile?normalizeMobile(rawMobile):'',email=String(req.body.email||'').trim().toLowerCase(),category=['general','account','technical','billing','privacy','security'].includes(req.body.category)?req.body.category:'general',subject=String(req.body.subject||'').trim(),message=String(req.body.message||'').trim();if(name.length<2||name.length>120||mobile&&!/^09\d{9}$/.test(mobile)||email&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)||email.length>180||!mobile&&!email||subject.length<4||subject.length>160||message.length<20||message.length>4000)return res.status(400).json({error:'نام، راه تماس، موضوع یا شرح درخواست کامل و معتبر نیست.'});let reference;do{reference=`SJ-${new Date().getUTCFullYear().toString().slice(-2)}${crypto.randomBytes(4).toString('hex').toUpperCase()}`}while(db.prepare('SELECT 1 FROM support_requests WHERE public_reference=?').get(reference));const requestId=id('support'),now=iso(),ipHash=crypto.createHmac('sha256',APP_ENCRYPTION_KEY).update(ip||'unknown').digest('hex');db.transaction(()=>{db.prepare(`INSERT INTO support_requests (id,user_id,name,mobile,email,category,subject,message,status,priority,public_reference,request_ip_hash,user_agent,created_at,updated_at) VALUES (?,NULL,?,?,?,?,?,?,'open','normal',?,?,?,?,?)`).run(requestId,name,mobile||null,email||null,category,subject,message,reference,ipHash,String(req.get('user-agent')||'').slice(0,500),now,now);db.prepare(`INSERT INTO support_messages (id,request_id,author_type,user_id,admin_id,message,is_internal,created_at,read_at) VALUES (?,?,'user',NULL,NULL,?,0,?,NULL)`).run(id('support_message'),requestId,message,now)})();recordSecurityAlert({category:'api',severity:'info',title:'درخواست پشتیبانی عمومی ثبت شد',details:{requestId,reference,category}});res.status(202).json({ok:true,reference,message:'درخواست پشتیبانی ثبت شد.'})}catch(error){next(error)}});
app.post('/api/public/events',async(req,res,next)=>{try{const allowed=new Set(['header_enter','hero_start','hero_demo','pricing_free','pricing_pro','pricing_organization','pricing_compare','quick_start_guide','guides','final_start','demo_trade','demo_risk','demo_mind']),eventName=String(req.body.event||'').trim(),pagePath=String(req.body.path||'/').slice(0,200),session=String(req.body.sessionId||'').slice(0,100);if(!allowed.has(eventName)||!pagePath.startsWith('/'))return res.status(400).json({error:'رخداد معتبر نیست.'});const limit=await distributedLimit('marketing-events',tokenHash(clientIp(req)||'unknown'),120,60*60*1000,marketingEventAttempts);if(limit.limited)return res.status(204).end();const sessionHash=session?crypto.createHmac('sha256',APP_ENCRYPTION_KEY).update(session).digest('hex'):null,metadata=req.body.metadata&&typeof req.body.metadata==='object'?JSON.stringify(Object.fromEntries(Object.entries(req.body.metadata).slice(0,8).map(([key,value])=>[String(key).slice(0,40),String(value).slice(0,100)]))):null;db.prepare('INSERT INTO marketing_events (id,event_name,page_path,session_hash,metadata,created_at) VALUES (?,?,?,?,?,?)').run(id('mevent'),eventName,pagePath,sessionHash,metadata,iso());res.status(204).end()}catch(error){next(error)}});

const CLEAN_MARKETING_SLUGS=new Set(['pricing','faq','about','contact','quick-start','guides']);
app.get(['/home','/help'],(req,res)=>res.redirect(301,req.path==='/home'?'/':'/guides'));
app.get('/content/:slug',(req,res,next)=>{const slug=String(req.params.slug||'').toLowerCase();if(slug==='home')return res.redirect(301,'/');if(slug==='help')return res.redirect(301,'/guides');if(CLEAN_MARKETING_SLUGS.has(slug))return res.redirect(301,`/${slug}`);next()});
/* /favicon.ico — مرورگرها و خزنده‌ها این مسیر ثابت را می‌خواهند؛ بدون آن
   هر بازدید یک ۴۰۴ اضافه در لاگ می‌ساخت. لوگوی PNG ۱۹۲ سرو می‌شود. */
app.get('/favicon.ico',(req,res)=>{res.setHeader('Cache-Control','public, max-age=86400');res.type('image/png');res.sendFile(path.join(__dirname,'public','media','smartjournal-logo-192.png'))});
app.get('/robots.txt',(req,res)=>{const origin=publicOrigin(req);res.setHeader('Cache-Control','public, max-age=300');res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api\nDisallow: /internal\nDisallow: /cms-preview\nDisallow: /journal\nSitemap: ${origin}/sitemap.xml\n`)});
app.get('/sitemap.xml',(req,res)=>{const origin=publicOrigin(req),today=new Date().toISOString().slice(0,10),cms=db.prepare("SELECT slug,updated_at FROM cms_pages WHERE status='published' AND (publish_at IS NULL OR publish_at<=?) AND (unpublish_at IS NULL OR unpublish_at>?)").all(iso(),iso()),updated=new Map(cms.map(page=>[page.slug,String(page.updated_at||today).slice(0,10)])),urls=[['/',updated.get('home')||today],...['pricing','faq','about','contact','quick-start','guides'].map(slug=>[`/${slug}`,updated.get(slug)||today]),...GUIDES.map(guide=>[`/guides/${guide.slug}`,updated.get('guides')||today]),...LEGAL_TYPES.map(type=>[`/legal/${type}`,today])];const xml=urls.map(([url,lastmod])=>`  <url><loc>${escapeHtml(`${origin}${url}`)}</loc><lastmod>${escapeHtml(lastmod)}</lastmod></url>`).join('\n');res.setHeader('Cache-Control','public, max-age=300, stale-while-revalidate=900');res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${xml}\n</urlset>`) });

/* index.html حدود ۲ مگابایت است و در هر درخواست از دیسک خوانده می‌شد؛ روی Node
   تک‌نخی این event loop را قفل می‌کند. یک بار می‌خوانیم و با mtime تازه نگه
   می‌داریم تا در حالت توسعه هم تغییرات بلافاصله دیده شود. */
const htmlTemplateCache = new Map();
function readHtmlTemplate(filePath){
  const stat = fs.statSync(filePath);
  const cached = htmlTemplateCache.get(filePath);
  if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) return cached.text;
  const text = fs.readFileSync(filePath, 'utf8');
  htmlTemplateCache.set(filePath, { text, mtimeMs: stat.mtimeMs, size: stat.size });
  return text;
}


/* فشرده‌سازی ۲ مگابایت HTML در هر درخواست حدود ۴۵ms CPU می‌برد و روی Node
   تک‌نخی event loop را قفل می‌کند. خروجی نهایی (خام + gzip + brotli) یک بار
   ساخته و نگه داشته می‌شود. کلید = فایل + محتوای تزریق‌شده، با سقف مشخص تا
   حافظه نشت نکند. با تغییر فایل، mtime کش را باطل می‌کند. */
const HTML_CACHE_LIMIT = Number(process.env.HTML_CACHE_ENTRIES || 40);
const htmlResponseCache = new Map();
function sendHtmlCached(req, res, filePath, injected) {
  const stat = fs.statSync(filePath);
  const key = `${filePath}|${stat.mtimeMs}|${injected}`;
  let entry = htmlResponseCache.get(key);
  if (entry) {
    htmlResponseCache.delete(key);           // LRU: تازه‌ترین‌ها آخر صف
    htmlResponseCache.set(key, entry);
  } else {
    const html = readHtmlTemplate(filePath).replace('<!-- PA_SERVER_SEO -->', injected);
    const raw = Buffer.from(html, 'utf8');
    entry = {
      raw,
      gzip: zlib.gzipSync(raw, { level: 6 }),
      brotli: zlib.brotliCompressSync(raw, {
        params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5 },
      }),
      etag: '"' + crypto.createHash('sha1').update(raw).digest('base64').slice(0, 27) + '"',
    };
    htmlResponseCache.set(key, entry);
    while (htmlResponseCache.size > HTML_CACHE_LIMIT) {
      htmlResponseCache.delete(htmlResponseCache.keys().next().value);
    }
  }
  const accept = String(req.headers['accept-encoding'] || '');
  const encoding = /\bbr\b/.test(accept) ? 'br' : (/\bgzip\b/.test(accept) ? 'gzip' : 'identity');
  /* ETag باید برای هر نوع فشرده‌سازی متفاوت باشد، وگرنه یک پروکسی مشترک ممکن
     است بدنه gzip را به کلاینتی بدهد که identity خواسته است. */
  const etag = `${entry.etag.slice(0, -1)}-${encoding}"`;
  res.setHeader('ETag', etag);
  res.setHeader('Vary', 'Accept-Encoding');
  res.type('html');
  if (req.headers['if-none-match'] === etag) return res.status(304).end();
  const body = encoding === 'br' ? entry.brotli : (encoding === 'gzip' ? entry.gzip : entry.raw);
  if (encoding !== 'identity') res.setHeader('Content-Encoding', encoding);
  return res.end(req.method === 'HEAD' ? undefined : body);
}

/* کف اندازهٔ متن روی موبایل — روی هر صفحه‌ای که index.html را سرو می‌کند
   (صفحهٔ اصلی و ژورنال) تزریق می‌شود؛ صفحات مارکتینگ آن را از shared-fonts
   می‌گیرند. اندازه‌گیری با مرورگر: صفحهٔ اصلی ۵۲ متن زیر ۱۱ پیکسل داشت. */
const MOBILE_TYPE_TAG = require('./shared-mobile-type').styleTag();

/* ---------------------------------------------------------------------------
   Chunkهای ژورنال (خروجی scripts/split-landing-bundle.js)

   قبلاً کل برنامهٔ React داخل index.html بود و صفحهٔ اصلی ۱.۷ مگابایت وزن
   داشت. حالا باندل فایل جداگانه با hash محتوا در /app است:
     • صفحهٔ اصلی فقط ~۱۴۰ کیلوبایت HTML می‌گیرد و باندل را نمی‌گیرد.
     • /journal با modulepreload از همان ابتدای HTML شروع به گرفتن باندل می‌کند.
     • فایل hashدار = کش یک‌ساله immutable، بدون خطر نسخهٔ کهنه.
--------------------------------------------------------------------------- */
const APP_CHUNK_DIR = path.join(__dirname, 'public', 'app');
const APP_CHUNK_NAME = /^journal-(?:app|auth)\.[0-9a-f]{8}\.js$/;
let chunkCache = { mtimeMs: 0, manifest: null };
function journalChunks(){
  try{
    const file = path.join(APP_CHUNK_DIR, 'chunks.json');
    const stat = fs.statSync(file);
    if(chunkCache.mtimeMs !== stat.mtimeMs){
      chunkCache = { mtimeMs: stat.mtimeMs, manifest: JSON.parse(fs.readFileSync(file,'utf8')) };
    }
    return chunkCache.manifest;
  }catch{ return null; }
}
/* روی /journal باندل قطعاً لازم است: زودتر از اجرای لودر شروع به دانلود کند. */
function journalPreloadTags(){
  const chunks = journalChunks();
  if(!chunks) return '';
  let tags = '';
  if(chunks.app) tags += `<link rel="modulepreload" href="${escapeHtml(chunks.app)}">`;
  if(chunks.auth) tags += `<link rel="preload" as="script" href="${escapeHtml(chunks.auth)}">`;
  return tags;
}
app.use('/app', (req,res,next)=>{
  if(req.method!=='GET' && req.method!=='HEAD') return next();
  const name = path.basename(req.path);
  if(!APP_CHUNK_NAME.test(name)) return next();
  const file = path.join(APP_CHUNK_DIR, name);
  if(!fs.existsSync(file)) return next();
  res.setHeader('Cache-Control','public, max-age=31536000, immutable');
  res.setHeader('Vary','Accept-Encoding');
  res.setHeader('Content-Type','application/javascript; charset=utf-8');
  /* نسخه‌های فشردهٔ از پیش ساخته‌شده: فشرده‌سازی ۱.۵ مگابایت در هر درخواست
     روی Node تک‌نخی گران است، پس یک بار در زمان build انجام شده. */
  const accept = String(req.headers['accept-encoding']||'');
  const variant = /\bbr\b/.test(accept) && fs.existsSync(file+'.br') ? ['br', file+'.br']
    : (/\bgzip\b/.test(accept) && fs.existsSync(file+'.gz') ? ['gzip', file+'.gz'] : null);
  if(variant){
    res.setHeader('Content-Encoding', variant[0]);
    return res.sendFile(variant[1], { headers:{ 'Content-Type':'application/javascript; charset=utf-8' } }, err=>{ if(err) next(err) });
  }
  return res.sendFile(file, err=>{ if(err) next(err) });
});
/* پولیش هدر موبایلِ صفحهٔ اصلی (درخواست کاربر): فایل JS سبکی که خودش CSS
   می‌دهد؛ در head تزریق می‌شود تا فایل ساخته‌شدهٔ index.html دست نخورد. */
const HEADER_POLISH_TAG = '<script src="/landing-header-polish.js" defer></script>';

/* prefetch باندل ژورنال روی صفحهٔ اصلی: بعد از load و در زمان بیکاری مرورگر
   انجام می‌شود تا کلیک «ورود به ژورنال» آنی باشد. اگر پهنای باند کاربران
   برایتان گران است، با JOURNAL_PREFETCH=off کاملاً خاموش می‌شود (آن وقت باندل
   فقط با نشانهٔ قصد کاربر — hover یا لمس دکمهٔ ورود — گرفته می‌شود). */
const PREFETCH_TAG = String(process.env.JOURNAL_PREFETCH||'').toLowerCase()==='off'
  ? '<script>window.__PA_NO_PREFETCH=true</script>' : '';
app.get('/',(req,res,next)=>{try{const context=marketingContext(req),meta={title:'ژورنال معاملاتی حرفه‌ای فارسی',description:'SmartJournal؛ ژورنال معاملاتی فارسی برای ثبت معامله، تحلیل عملکرد و ریسک، روانشناسی، تصاویر قبل و بعد و بازبینی منظم.'},head=seoHead({meta,origin:context.origin,path:'/',schema:[productSchema(context.origin,context.plans),faqSchema(context.faqs),organizationSchema(context.origin),webSiteSchema(context.origin)],verification:context.verification});cachePublicHtml(res);sendHtmlCached(req,res,path.join(__dirname,'public','index.html'),head+PREFETCH_TAG+MOBILE_TYPE_TAG+HEADER_POLISH_TAG)}catch(error){next(error)}});

/* نام کاربر وارد‌شده را برای اپ تزریق می‌کند تا کاربر جدید با نام نمونه سلام نشود. */
function journalBootScript(req){
  try{
    const rawToken=req.cookies?.[USER_COOKIE_NAME];
    if(!rawToken)return '';
    const row=db.prepare(`SELECT u.name FROM user_sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>? AND u.deleted_at IS NULL LIMIT 1`)
      .get(tokenHash(rawToken),iso());
    if(!row||!row.name)return '';
    return '<script>window.__PA_USER_NAME__='+JSON.stringify(String(row.name))+';</script>';
  }catch(_){return ''}
}

app.get('/journal',(req,res,next)=>{try{const head='<meta name="robots" content="noindex,nofollow"><link rel="canonical" href="'+escapeHtml(publicOrigin(req)+'/')+'">';res.setHeader('X-Robots-Tag','noindex, nofollow');res.setHeader('Cache-Control','no-cache');sendHtmlCached(req,res,path.join(__dirname,'public','index.html'),head+journalPreloadTags()+MOBILE_TYPE_TAG+HEADER_POLISH_TAG+journalBootScript(req))}catch(error){next(error)}});
app.get(['/pricing','/faq','/about','/contact','/quick-start','/guides'],(req,res,next)=>{try{cachePublicHtml(res);res.type('html').send(renderMarketingPage(req.path.slice(1),marketingContext(req)))}catch(error){next(error)}});
app.get('/guides/:slug',(req,res,next)=>{try{const html=renderGuidePage(String(req.params.slug||'').toLowerCase(),marketingContext(req));if(!html)return next();cachePublicHtml(res);res.type('html').send(html)}catch(error){next(error)}});

app.get('/content/:slug', (req, res) => {
  const page=db.prepare("SELECT id,slug,title,meta_description,seo_title,seo_keywords,og_image,canonical_url,updated_at FROM cms_pages WHERE slug=? AND status='published' AND (publish_at IS NULL OR publish_at<=?) AND (unpublish_at IS NULL OR unpublish_at>?)").get(String(req.params.slug||'').toLowerCase(),iso(),iso());
  if(!page)return res.status(404).type('html').send('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>صفحه پیدا نشد</title><body style="font-family:Tahoma;background:#080c13;color:#fff;padding:40px"><h1>صفحه پیدا نشد</h1><a href="/" style="color:#22d3ee">بازگشت به سایت</a></body></html>');
  const sections=db.prepare("SELECT section_key,section_type,title,body,button_label,button_url,image_url,image_alt,status FROM cms_sections WHERE page_id=? AND status='published' AND (publish_at IS NULL OR publish_at<=?) AND (unpublish_at IS NULL OR unpublish_at>?) ORDER BY sort_order,created_at").all(page.id,iso(),iso());
  const sectionHtml=sections.map(section=>`<section class="section ${escapeHtml(section.section_type)}" data-section="${escapeHtml(section.section_key)}"><small>${escapeHtml(section.section_key)}</small>${section.image_url?`<img src="${escapeHtml(section.image_url)}" alt="${escapeHtml(section.image_alt||'')}">`:''}${section.title?`<h2>${escapeHtml(section.title)}</h2>`:''}${section.body?`<p>${escapeHtml(section.body).replace(/\n/g,'<br>')}</p>`:''}${section.button_label?`<a class="button" href="${escapeHtml(section.button_url||'/')}">${escapeHtml(section.button_label)}</a>`:''}</section>`).join('');
  res.type('html').send(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${escapeHtml(page.meta_description||'')}"><meta name="keywords" content="${escapeHtml(page.seo_keywords||'')}">${page.og_image?`<meta property="og:image" content="${escapeHtml(page.og_image)}">`:''}${page.canonical_url?`<link rel="canonical" href="${escapeHtml(page.canonical_url)}">`:''}<title>${escapeHtml(page.seo_title||page.title)} — SmartJournal</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;color:#edf4fa;background:radial-gradient(circle at 85% 0,rgba(34,211,238,.1),transparent 30%),#080c13;font-family:Tahoma,Arial,sans-serif}.nav{display:flex;align-items:center;justify-content:space-between;padding:18px max(20px,calc((100vw - 1040px)/2));border-bottom:1px solid #1d2a3c}.nav b{color:#79e7f2}.nav a{color:#8798ae;text-decoration:none}.main{width:min(1040px,calc(100% - 32px));margin:42px auto 80px}.hero{padding:48px;border:1px solid #24334a;border-radius:24px;background:linear-gradient(145deg,#111b2a,#0a111b)}.hero h2{font-size:clamp(28px,5vw,52px)}.section{margin-top:14px;padding:28px;border:1px solid #202e42;border-radius:18px;background:#0e1724}.section small{color:#22d3ee;font:11px monospace}.section h2{margin:12px 0 8px;font-size:clamp(20px,3vw,31px)}.section p{margin:0;color:#9aa9bb;line-height:2}.section img{display:block;max-width:100%;max-height:480px;margin:14px 0;border-radius:14px;object-fit:cover}.button{display:inline-flex;margin-top:18px;padding:12px 18px;border-radius:11px;color:#06232b;background:#22d3ee;text-decoration:none;font-weight:800}@media(max-width:600px){.hero,.section{padding:22px}}</style></head><body><nav class="nav"><b>SMARTJOURNAL</b><a href="/">بازگشت به ژورنال</a></nav><main class="main">${sectionHtml}</main></body></html>`);
});

app.get('/api/public/config', async(req, res, next) => {try{const audience = ['free','pro','organization'].includes(req.query.audience) ? req.query.audience : 'all',cached=await redisStore.cacheGet('public-config',audience);if(cached){res.setHeader('X-Cache','HIT');return res.json(cached)}const settings = db.prepare("SELECT signup_enabled,maintenance_mode,maintenance_message,app_version,updated_at FROM system_settings WHERE id='default'").get(),announcements = db.prepare(`SELECT id,title,body,tone,audience,starts_at,expires_at FROM announcements
    WHERE status='published' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?) AND (audience='all' OR audience=?)
    ORDER BY starts_at DESC LIMIT 10`).all(iso(), iso(), audience),payload={ signupEnabled: !!settings.signup_enabled, maintenanceMode: !!settings.maintenance_mode,maintenanceMessage: settings.maintenance_message, appVersion: settings.app_version, announcements, updatedAt: settings.updated_at };await redisStore.cacheSet('public-config',audience,payload,30);res.setHeader('X-Cache','MISS');res.json(payload)}catch(error){next(error)}});

app.get('/api/public/legal',(req,res)=>{const documents={};for(const type of LEGAL_TYPES){const document=currentLegalDocument(type);if(document)documents[type]=legalDocumentSummary(document)}res.json({jurisdiction:'IR',documents})});
app.get('/api/public/legal/:type',(req,res)=>{if(req.params.type==='guide'){const row=db.prepare("SELECT guide_text,app_version,updated_at FROM system_settings WHERE id='default'").get();return res.json({type:'guide',version:row.app_version,title:'راهنمای استفاده',text:row.guide_text,effectiveAt:row.updated_at})}const type=LEGAL_TYPES.includes(req.params.type)?req.params.type:'';if(!type)return res.status(404).json({error:'سند حقوقی پیدا نشد.'});const version=String(req.query.version||''),document=version?db.prepare("SELECT id,document_type,version,title,content,content_sha256,effective_at,published_at FROM legal_documents WHERE document_type=? AND version=? AND published_at IS NOT NULL").get(type,version):currentLegalDocument(type);if(!document)return res.status(404).json({error:'نسخه منتشرشده سند حقوقی پیدا نشد.'});res.setHeader('Cache-Control','public, max-age=300');res.json({type:document.document_type,version:document.version,title:document.title,text:document.content,sha256:document.content_sha256,effectiveAt:document.effective_at,publishedAt:document.published_at})});
app.get('/legal/:type',(req,res)=>{const type=LEGAL_TYPES.includes(req.params.type)?req.params.type:'',document=type&&currentLegalDocument(type);if(!document)return res.status(404).type('html').send('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>سند پیدا نشد</title><body><h1>نسخه منتشرشده سند پیدا نشد.</h1></body></html>');res.type('html').send(`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(document.title)} — SmartJournal</title><meta name="description" content="${escapeHtml(document.title)} — نسخهٔ ${escapeHtml(String(document.version||''))} اسناد حقوقی SmartJournal، ژورنال معاملاتی فارسی."><link rel="canonical" href="${escapeHtml(publicOrigin(req))}/legal/${escapeHtml(type)}"><link rel="icon" type="image/webp" sizes="192x192" href="/media/smartjournal-logo-192.webp">${require('./shared-fonts').headTag()}<style>*{box-sizing:border-box}body{margin:0;color:#e8f0f6;background:#080c13;font-family:'Vazirmatn',Tahoma,Arial,sans-serif;line-height:2}.skip{position:fixed;top:-80px;right:16px;z-index:5;padding:10px;color:#041114;background:#67e8f9}.skip:focus{top:12px}nav{padding:18px max(20px,calc((100% - 900px)/2));border-bottom:1px solid #26364b}nav a{color:#67e8f9}main{width:min(900px,calc(100% - 32px));margin:36px auto 80px;padding:clamp(20px,5vw,48px);border:1px solid #26364b;border-radius:20px;background:#101925}h1{line-height:1.5}.meta{color:#9eb0c2}.content{color:#d5dfe8}.content h2{margin:2rem 0 .5rem;color:#f2f7fb;font-size:1.25rem}.content p{margin:.35rem 0 1rem}.content .bullet{padding-right:1rem}nav{display:flex;align-items:center;flex-wrap:wrap;gap:14px}nav a{display:inline-flex;align-items:center;gap:9px;min-height:44px}nav img{width:34px;height:34px;border-radius:10px;object-fit:cover}a:focus-visible,main:focus-visible{outline:3px solid #fbbf24;outline-offset:4px}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}</style></head><body><a class="skip" href="#legal-content">رفتن به متن سند</a><nav aria-label="اسناد حقوقی و مسیر بازگشت"><a href="/"><img src="/media/smartjournal-logo-192.webp" width="34" height="34" alt="لوگوی SmartJournal">بازگشت به SmartJournal</a>${LEGAL_TYPES.map(item=>`<a href="/legal/${item}"${item===type?' aria-current="page"':''}>${escapeHtml(LEGAL_TITLES[item])}</a>`).join('')}</nav><main id="legal-content" tabindex="-1"><h1>${escapeHtml(document.title)}</h1><p class="meta">نسخه ${escapeHtml(document.version)} · تاریخ اجرا ${escapeHtml(document.effective_at.slice(0,10))}</p><article class="content">${legalDocumentHtml(document)}</article></main></body></html>`)});

async function readiness(){const checks={database:false,localStorage:false,redis:true,queue:true,objectStorage:true};try{checks.database=db.prepare('SELECT 1 ok').get().ok===1}catch{}try{fs.accessSync(UPLOAD_DIR,fs.constants.R_OK|fs.constants.W_OK);checks.localStorage=true}catch{}const [redisState,queueState,storageState]=await Promise.all([redisStore.health(),smsQueue.health(),storage.health()]);checks.redis=redisState.ready;checks.queue=queueState.ready;checks.objectStorage=storageState.ready;Object.entries(checks).forEach(([dependency,ready])=>setReadiness(dependency,ready));return {ready:Object.values(checks).every(Boolean),checks,dependencies:{database:{ready:checks.database,engine:DATABASE_ENGINE,schema:db.schema||null},redis:redisState,queue:queueState,objectStorage:storageState}}}
app.get('/api/health/live',(req,res)=>res.json({status:'ok',service:'pa-journal',version:require('./package.json').version,time:iso(),uptimeSeconds:Math.round(process.uptime())}));
app.get(['/api/health','/api/health/ready'],async(req,res,next)=>{try{const state=await readiness();res.status(state.ready?200:503).json({status:state.ready?'ready':'not_ready',service:'pa-journal',version:require('./package.json').version,checks:state.checks,dependencies:state.dependencies,time:iso()})}catch(error){next(error)}});
app.get('/internal/metrics',async(req,res)=>{const expected=configuredSecret('METRICS_TOKEN'),provided=String(req.get('authorization')||'').replace(/^Bearer\s+/i,''),authorized=!IS_PROD&&!expected||expected&&provided.length===expected.length&&crypto.timingSafeEqual(Buffer.from(provided),Buffer.from(expected));if(!authorized)return res.status(401).type('text').send('Unauthorized');res.setHeader('Content-Type',metricsContentType);res.send(await metrics())});
function internalWorkerAuthorized(req){const expected=configuredSecret('INTERNAL_WORKER_TOKEN'),provided=String(req.get('authorization')||'').replace(/^Bearer\s+/i,'');return expected.length>=24&&provided.length===expected.length&&crypto.timingSafeEqual(Buffer.from(provided),Buffer.from(expected))}
app.post('/internal/jobs/sms',async(req,res,next)=>{if(!smsQueue.enabled)return res.status(404).json({error:'Queue is disabled.'});if(!internalWorkerAuthorized(req))return res.status(401).json({error:'Unauthorized'});try{const payload=decryptSecret(req.body?.payload),jobId=String(req.body?.jobId||''),queuedAt=new Date(payload?.queuedAt).getTime();if(!payload||payload.jobId!==jobId||!/^smsjob_[A-Za-z0-9-]+$/.test(jobId)||!/^09\d{9}$/.test(String(payload.mobile||''))||typeof payload.message!=='string'||payload.message.length<1||payload.message.length>1000||!Number.isFinite(queuedAt)||Date.now()-queuedAt>3600000)throw Object.assign(new Error('Invalid or expired SMS job payload.'),{status:400});const existing=db.prepare("SELECT result_json FROM queue_deliveries WHERE job_id=? AND queue_name='sms' AND status='completed'").get(jobId);if(existing)return res.json(JSON.parse(existing.result_json));const now=iso();db.prepare(`INSERT INTO queue_deliveries (job_id,queue_name,status,attempts,started_at,updated_at) VALUES (?,'sms','processing',1,?,?) ON CONFLICT(job_id) DO UPDATE SET status='processing',attempts=queue_deliveries.attempts+1,updated_at=excluded.updated_at`).run(jobId,now,now);try{const result=await deliverSmsDirect({userId:payload.userId||null,mobile:payload.mobile,type:String(payload.type||'otp').slice(0,30),message:payload.message,code:payload.code||null,ip:String(payload.ip||'').slice(0,100)}),completed=iso();db.prepare("UPDATE queue_deliveries SET status='completed',result_json=?,completed_at=?,updated_at=? WHERE job_id=?").run(JSON.stringify(result),completed,completed,jobId);res.json(result)}catch(error){db.prepare("UPDATE queue_deliveries SET status='failed',updated_at=? WHERE job_id=?").run(iso(),jobId);throw error}}catch(error){next(error)}});
app.post('/internal/jobs/media',async(req,res,next)=>{if(!smsQueue.enabled)return res.status(404).json({error:'Queue is disabled.'});if(!internalWorkerAuthorized(req))return res.status(401).json({error:'Unauthorized'});const fileId=String(req.body?.fileId||''),jobId=String(req.body?.jobId||'');try{if(!/^file_[A-Za-z0-9-]+$/.test(fileId)||jobId!==`media_${fileId}`)throw Object.assign(new Error('Invalid media job.'),{status:400});const completed=db.prepare("SELECT result_json FROM queue_deliveries WHERE job_id=? AND queue_name='media' AND status='completed'").get(jobId);if(completed)return res.json(JSON.parse(completed.result_json));const file=db.prepare("SELECT * FROM media_files WHERE id=? AND status='active'").get(fileId);if(!file)throw Object.assign(new Error('Media file not found.'),{status:404});const target=path.resolve(UPLOAD_DIR,String(file.storage_key));if((target!==UPLOAD_DIR&&!target.startsWith(`${UPLOAD_DIR}${path.sep}`))||!fs.existsSync(target))throw Object.assign(new Error('Media staging file is unavailable.'),{status:404});const now=iso();db.prepare(`INSERT INTO queue_deliveries (job_id,queue_name,status,attempts,started_at,updated_at) VALUES (?,'media','processing',1,?,?) ON CONFLICT(job_id) DO UPDATE SET status='processing',attempts=queue_deliveries.attempts+1,updated_at=excluded.updated_at`).run(jobId,now,now);const content=fs.readFileSync(target),actualMime=imageMime(content),checksum=crypto.createHash('sha256').update(content).digest('hex');if(actualMime!==file.mime_type||checksum!==file.checksum_sha256||content.length!==Number(file.size_bytes)){const failedAt=iso();db.transaction(()=>{db.prepare("UPDATE media_files SET scan_status='suspicious',status='quarantined',reviewed_at=? WHERE id=?").run(failedAt,file.id);db.prepare("UPDATE queue_deliveries SET status='failed',updated_at=? WHERE job_id=?").run(failedAt,jobId)})();throw Object.assign(new Error('Media integrity verification failed.'),{status:422})}try{const uploaded=await storage.uploadFile(file.storage_key,target,file.mime_type,file.checksum_sha256),result={ok:true,fileId,storage:uploaded.backend},finished=iso();db.transaction(()=>{db.prepare("UPDATE media_files SET scan_status='safe',reviewed_at=? WHERE id=?").run(finished,file.id);db.prepare("UPDATE queue_deliveries SET status='completed',result_json=?,completed_at=?,updated_at=? WHERE job_id=?").run(JSON.stringify(result),finished,finished,jobId)})();if(uploaded.backend==='s3'&&storage.backend==='s3'&&process.env.S3_KEEP_LOCAL_COPY!=='true')fs.rmSync(target,{force:true});res.json(result)}catch(error){db.prepare("UPDATE queue_deliveries SET status='failed',updated_at=? WHERE job_id=?").run(iso(),jobId);throw error}}catch(error){next(error)}});

app.post('/internal/jobs/maintenance',(req,res,next)=>{if(!smsQueue.enabled)return res.status(404).json({error:'Queue is disabled.'});if(!internalWorkerAuthorized(req))return res.status(401).json({error:'Unauthorized'});try{cleanupExpiredSessions();runAutomaticFileCleanup();db.prepare("DELETE FROM queue_deliveries WHERE updated_at<?").run(new Date(Date.now()-30*86400000).toISOString());res.json({ok:true,completedAt:iso()})}catch(error){next(error)}});

/* ---- کارت‌به‌کارت: شماره کارت، ثبت فیش و تایید/رد از پنل مدیریت ---- */
require('./bank-payments').install({
  app, db, logAudit, id, iso, clientIp, userAuth, allowPermissions,
  dataUrlParts, imageMime, UPLOAD_DIR,
});

/* درگاه پیامک: وضعیت، فعال/غیرفعال، حذف، حالت آزمایشی و تست کامل OTP از پنل */
try{require('./sms-gateway').install({app,db,id,iso,clientIp,logAudit,allowPermissions,
  encryptSecret,decryptSecret,deliverWithProvider,IS_PROD,logger})}
catch(error){logger.warn({event:'sms_gateway_setup_failed',err:String(error&&error.message)},'sms gateway setup skipped')}

/* محتوای سایت: متن‌های قابل‌ویرایش + نظرات کاربران */
try{require('./site-content').install({app,db,id,iso,
  clean:(v,m)=>String(v==null?'':v).replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,m),
  logAudit,clientIp,allowPermissions})}
catch(error){logger.warn({event:'site_content_setup_failed',err:String(error&&error.message)},'site content setup skipped')}

/* فایل دمویی mock-api.js حاوی دادهٔ نمایشی قدیمی است و نباید سرو شود */
app.use('/admin', (req, res, next) => {
  if (String(req.path || '').toLowerCase() === '/mock-api.js') return res.status(404).type('text').send('Not Found');
  next();
});
const adminStatic = express.static(path.join(__dirname, 'public', 'admin'), { maxAge: IS_PROD ? '1h' : 0, etag: true, redirect:false });
app.use('/admin', adminStatic);
app.get(['/admin', '/admin/', '/admin/*path'], (req, res) => {
  res.setHeader('Cache-Control','no-store');
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'));
});
/* ---------------------------------------------------------------------------
   Service Worker — مهر نسخه در لحظهٔ سرو تزریق می‌شود.

   باگ قبلی: نام کش داخل فایل ثابت بود، پس مرورگرِ کاربر تا ابد JS قدیمی را
   اجرا می‌کرد و هیچ به‌روزرسانی‌ای به دستش نمی‌رسید. حالا مهر از زمان تغییر
   فایل‌های کلیدی ساخته می‌شود؛ هر آپلود جدید ⇒ نام کش جدید ⇒ کش قبلی پاک.
   خودِ فایل SW هم هرگز کش نمی‌شود.
--------------------------------------------------------------------------- */
const SW_FILE = path.join(__dirname, 'public', 'service-worker.js');
const SW_WATCH = ['public/journal-cloud.js','public/journal-cloud-auth.js','public/journal-ux-runtime.js',
  'public/journal-plan-support.js','public/support-widget.js','public/journal-card-payment.js','public/landing-header-polish.js','public/index.html','public/service-worker.js',
  'public/app/chunks.json'];
let swCache = { stamp:null, body:null };
function swBuildStamp(){
  let acc = 0;
  for(const rel of SW_WATCH){
    try { acc = (acc * 31 + fs.statSync(path.join(__dirname, rel)).mtimeMs) >>> 0; } catch {}
  }
  return String(acc.toString(36)) + '-' + String(require('./package.json').version || '0').replace(/[^0-9a-z.]/gi,'');
}
app.get('/service-worker.js', (req,res)=>{
  try{
    const stamp = swBuildStamp();
    if(swCache.stamp !== stamp){
      const raw = fs.readFileSync(SW_FILE,'utf8');
      swCache = { stamp, body: raw.replace(/const BUILD = '[^']*';/, `const BUILD = '${stamp}';`) };
    }
    res.setHeader('Content-Type','application/javascript; charset=utf-8');
    res.setHeader('Cache-Control','no-store, must-revalidate');
    res.setHeader('Service-Worker-Allowed','/');
    return res.send(swCache.body);
  }catch(error){
    logger.warn({event:'service_worker_serve_failed',err:String(error&&error.message)},'service worker fallback');
    return res.status(404).end();
  }
});

app.use(express.static(path.join(__dirname, 'public'), {
  index:false,
  etag:true,
  lastModified:true,
  maxAge:0,
  setHeaders(res,filePath){
    if(/\.(?:avif|webp|png|jpe?g|svg|ico)$/i.test(filePath))res.setHeader('Cache-Control',IS_PROD?'public, max-age=2592000, stale-while-revalidate=86400':'no-cache');
    else if(/\.woff2?$/i.test(filePath))res.setHeader('Cache-Control',IS_PROD?'public, max-age=2592000':'no-cache');
    /* JS/CSS با no-cache سرو می‌شوند: مرورگر با ETag اعتبارسنجی می‌کند (۳۰۴ سبک)
       ولی هرگز نسخهٔ کهنه را بدون پرسیدن اجرا نمی‌کند. قبلاً max-age=86400 بود
       و همین باعث می‌شد رفع‌باگ‌ها تا یک روز به کاربر نرسند. */
    else if(/\.(?:css|js)$/i.test(filePath))res.setHeader('Cache-Control','no-cache');
    else if(/\.html$/i.test(filePath))res.setHeader('Cache-Control','no-cache');
  }
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'مسیر API پیدا نشد.' }));
app.use((req,res)=>{const context=marketingContext(req);res.status(404);if(req.accepts('html'))return res.type('html').send(renderNotFound({...context,path:req.path}));res.json({error:'صفحه یا مسیر درخواستی پیدا نشد.'})});
setupSentryErrorHandler(app);
app.use((error, req, res, next) => {
  captureError(error,{source:'ADMIN_API',requestId:req.id,route:req.originalUrl,method:req.method});
  try {
    recordSystemError({ source: 'ADMIN_API', message: error.message || 'Unknown server error', stack: error.stack });
    recordSecurityAlert({ category: 'api', severity: 'error', title: 'خطای داخلی API مدیریت', details: { route: req.originalUrl, method: req.method, message: error.message } });
  } catch {}
  if (res.headersSent) return next(error);
  const status=Number.isInteger(error.status)&&error.status>=400&&error.status<=599?error.status:500;
  res.status(status).json({ error: IS_PROD&&status>=500 ? 'خطای داخلی سرور رخ داد.' : error.message });
});

try{const _missing=['terms','privacy','disclaimer'].filter(t=>!currentLegalDocument(t));
if(_missing.length)logger.warn({event:'legal_documents_unpublished',missing:_missing},
'اسناد حقوقی منتشر نشده‌اند؛ ثبت‌نام کاربران قفل است. اجرا کنید: node scripts/publish-legal.js --name "..." --registration "..." --address "..."');}catch(_){}
if(IS_PROD && !COOKIE_SECURE)logger.warn({event:'insecure_cookies'},'COOKIE_SECURE=false — کوکی بدون HTTPS ارسال می‌شود. فقط برای تست موقت با IP؛ بعد از نصب دامنه و SSL حذفش کنید.');
const server=app.listen(PORT, HOST, () => logger.info({event:'server_started',host:HOST,port:PORT,adminPath:'/admin',databaseEngine:DATABASE_ENGINE,databaseSchema:db.schema||null},'SmartJournal platform started'));
let shuttingDown=false;function shutdown(signal){if(shuttingDown)return;shuttingDown=true;logger.info({event:'shutdown_started',signal},'Graceful shutdown started');server.close(async error=>{if(error){captureError(error,{source:'SHUTDOWN'});process.exitCode=1}clearInterval(fileCleanupTimer);await Promise.allSettled([redisStore.close(),smsQueue.close()]);try{db.close()}catch{}logger.info({event:'shutdown_completed'},'Graceful shutdown completed');process.exit(process.exitCode||0)});setTimeout(()=>{logger.error({event:'shutdown_forced'},'Graceful shutdown timed out');process.exit(1)},15000).unref()}
process.on('SIGTERM',()=>shutdown('SIGTERM'));process.on('SIGINT',()=>shutdown('SIGINT'));process.on('unhandledRejection',error=>captureError(error instanceof Error?error:new Error(String(error)),{source:'UNHANDLED_REJECTION'}));process.on('uncaughtException',error=>{captureError(error,{source:'UNCAUGHT_EXCEPTION'});shutdown('UNCAUGHT_EXCEPTION')});
