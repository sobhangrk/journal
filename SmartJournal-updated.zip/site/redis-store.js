'use strict';
const fs=require('node:fs');
const IORedis=require('ioredis');
const {logger}=require('./observability');
const enabled=!!process.env.REDIS_URL&&String(process.env.REDIS_ENABLED||'true')!=='false';
let client=null;
function getClient(){if(!enabled)return null;if(!client){const password=process.env.REDIS_PASSWORD||(process.env.REDIS_PASSWORD_FILE?fs.readFileSync(process.env.REDIS_PASSWORD_FILE,'utf8').trim():undefined);client=new IORedis(process.env.REDIS_URL,{password,lazyConnect:true,maxRetriesPerRequest:2,enableOfflineQueue:false,connectTimeout:Number(process.env.REDIS_CONNECT_TIMEOUT_MS||2000),commandTimeout:Number(process.env.REDIS_COMMAND_TIMEOUT_MS||1500),tls:process.env.REDIS_TLS==='true'?{}:undefined});client.on('ready',()=>logger.info({event:'redis_ready'},'Redis store ready'));client.on('error',error=>logger.error({event:'redis_error',err:error},'Redis store error'))}return client}
async function command(operation,fallback=null){if(!enabled)return fallback;try{const redis=getClient();if(redis.status==='wait')await redis.connect();return await operation(redis)}catch(error){logger.warn({event:'redis_operation_failed',err:error},'Redis operation failed; using safe fallback');return fallback}}
function key(value){return `${process.env.REDIS_KEY_PREFIX||'pa'}:${value}`}
async function fixedWindowRateLimit(scope,identity,limit,windowMs){const redisKey=key(`rate:${scope}:${identity}`),result=await command(async redis=>{const values=await redis.multi().incr(redisKey).pttl(redisKey).exec();let count=Number(values[0][1]),ttl=Number(values[1][1]);if(count===1||ttl<0){await redis.pexpire(redisKey,windowMs);ttl=windowMs}return {count,remaining:Math.max(0,limit-count),resetMs:ttl,limited:count>limit,source:'redis'}},null);return result}
async function resetRateLimit(scope,identity){return command(redis=>redis.del(key(`rate:${scope}:${identity}`)),0)}
async function cacheGet(namespace,id){const raw=await command(redis=>redis.get(key(`cache:${namespace}:${id}`)),null);if(raw===null)return null;try{return JSON.parse(raw)}catch{return null}}
async function cacheSet(namespace,id,value,ttlSeconds=60){return command(redis=>redis.set(key(`cache:${namespace}:${id}`),JSON.stringify(value),'EX',Math.max(1,ttlSeconds)),null)}
async function cacheDelete(namespace,id){return command(redis=>redis.del(key(`cache:${namespace}:${id}`)),0)}
async function sessionSet(type,tokenHash,value,ttlSeconds){return command(redis=>redis.set(key(`session:${type}:${tokenHash}`),JSON.stringify(value),'EX',Math.max(1,ttlSeconds)),null)}
async function sessionGet(type,tokenHash){const raw=await command(redis=>redis.get(key(`session:${type}:${tokenHash}`)),null);if(raw===null)return null;try{return JSON.parse(raw)}catch{return null}}
async function sessionDelete(type,tokenHash){return command(redis=>redis.del(key(`session:${type}:${tokenHash}`)),0)}
async function health(){if(!enabled)return {enabled:false,ready:true};const pong=await command(redis=>redis.ping(),null);return {enabled:true,ready:pong==='PONG'}}
async function close(){if(client)await client.quit().catch(()=>client.disconnect())}
module.exports={enabled,fixedWindowRateLimit,resetRateLimit,cacheGet,cacheSet,cacheDelete,sessionSet,sessionGet,sessionDelete,health,close};
