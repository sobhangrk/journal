'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {Worker}=require('node:worker_threads');

const HEADER_BYTES=16,STATE=0,LENGTH=1,REQUEST_ID=2;
const IDLE=0,REQUEST=1,RESPONSE=2,READY=3,INIT_ERROR=4,CLOSE=5;

function readSecret(name,fileName){if(process.env[name])return process.env[name];const file=process.env[fileName];return file?fs.readFileSync(file,'utf8').trim():undefined}
function connectionConfigFromEnv(){
  const password=readSecret('PGPASSWORD','PGPASSWORD_FILE');
  const config=process.env.DATABASE_URL?{connectionString:process.env.DATABASE_URL}:{host:process.env.PGHOST||'postgres',port:Number(process.env.PGPORT||5432),database:process.env.PGDATABASE||'pa_journal',user:process.env.PGUSER||'pa_journal',password};
  if(process.env.PGSSL==='true')config.ssl={rejectUnauthorized:process.env.PGSSL_REJECT_UNAUTHORIZED!=='false'};
  config.application_name=process.env.PGAPPNAME||'pa-journal-runtime';
  config.connectionTimeoutMillis=Math.max(1000,Number(process.env.PG_CONNECT_TIMEOUT_MS||10000));
  config.statement_timeout=Math.max(1000,Number(process.env.PG_STATEMENT_TIMEOUT_MS||30000));
  return config;
}
function safeSchema(value=process.env.PA_PG_SCHEMA||'pa_journal'){const schema=String(value);if(!/^[a-z][a-z0-9_]{0,62}$/.test(schema))throw new Error('PA_PG_SCHEMA must be a safe PostgreSQL identifier.');return schema}
function encode(value){return JSON.stringify(value,(key,item)=>{if(item&&item.type==='Buffer'&&Array.isArray(item.data))return {__paBuffer:Buffer.from(item.data).toString('base64')};if(Buffer.isBuffer(item))return {__paBuffer:item.toString('base64')};return item})}
function decode(value){return JSON.parse(value,(key,item)=>item&&typeof item==='object'&&typeof item.__paBuffer==='string'?Buffer.from(item.__paBuffer,'base64'):item)}
function replaceOutsideQuotes(sql,onToken){let output='',quote=null;for(let i=0;i<sql.length;i++){const char=sql[i];if(quote){output+=char;if(char===quote){if(sql[i+1]===quote){output+=sql[++i]}else quote=null}continue}if(char==="'"||char==='"'||char==='`'){quote=char;output+=char;continue}const token=onToken(sql,i);if(token){output+=token.text;i=token.end-1}else output+=char}return output}
function postgresSql(raw){let sql=String(raw).trim();
  if(/^SELECT\s+sql\s+FROM\s+sqlite_master/i.test(sql))return "SELECT 'content_manager' AS sql";
  const tableInfo=sql.match(/^PRAGMA\s+table_info\s*\(\s*["'`]?([a-zA-Z0-9_]+)["'`]?\s*\)\s*;?$/i);if(tableInfo)return `SELECT column_name AS name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name='${tableInfo[1]}' ORDER BY ordinal_position`;
  if(/^PRAGMA\b/i.test(sql))return 'SELECT 1 AS ok';
  sql=sql.replace(/\bBLOB\b/gi,'BYTEA').replace(/\bREAL\b/gi,'DOUBLE PRECISION').replace(/\bINTEGER\b/gi,'BIGINT');
  sql=sql.replace(/\bMAX\(\s*0\s*,\s*storage_bytes\s*-\s*\?\s*\)/gi,'GREATEST(0,storage_bytes-?)');
  sql=sql.replace(/rowid\s*%\s*19/gi,'mod(abs(hashtext(id)),19)').replace(/rowid\s*%\s*31/gi,'mod(abs(hashtext(id)),31)').replace(/rowid\s*%\s*45/gi,'mod(abs(hashtext(id)),45)');
  const ignore=/^INSERT\s+OR\s+IGNORE\s+/i.test(sql);if(ignore){sql=sql.replace(/^INSERT\s+OR\s+IGNORE\s+/i,'INSERT ');sql=sql.replace(/;\s*$/,'')+' ON CONFLICT DO NOTHING'}
  return sql;
}
function compile(rawSql,args){let sql=postgresSql(rawSql),params=[];const named=args.length===1&&args[0]&&typeof args[0]==='object'&&!Array.isArray(args[0])&&!Buffer.isBuffer(args[0])?args[0]:null,indexByName=new Map();let positional=0;
  sql=replaceOutsideQuotes(sql,(source,index)=>{if(source[index]==='?'&&!named){positional++;params.push(args[positional-1]);return {text:`$${positional}`,end:index+1}}if(named&&['@',':','$'].includes(source[index])&&/[A-Za-z_]/.test(source[index+1]||'')){let end=index+2;while(/[A-Za-z0-9_]/.test(source[end]||''))end++;const name=source.slice(index+1,end);if(!indexByName.has(name)){indexByName.set(name,indexByName.size+1);params.push(named[name])}return {text:`$${indexByName.get(name)}`,end}}return null});
  return {sql,params};
}
class PostgresStatement{constructor(database,sql){this.database=database;this.sql=sql}run(...args){const result=this.database._query(this.sql,args);return {changes:Number(result.rowCount||0),lastInsertRowid:0}}get(...args){const result=this.database._query(this.sql,args);return result.rows[0]}all(...args){return this.database._query(this.sql,args).rows}iterate(...args){return this.all(...args)[Symbol.iterator]()}}
class PostgresSyncDatabase{
  constructor(options={}){this.dialect='postgres';this.schema=safeSchema(options.schema);this.timeout=Math.max(1000,Number(options.timeout||process.env.PG_SYNC_TIMEOUT_MS||30000));this.capacity=Math.max(4*1024*1024,Number(process.env.PG_SYNC_BUFFER_BYTES||64*1024*1024));this.buffer=new SharedArrayBuffer(HEADER_BYTES+this.capacity);this.header=new Int32Array(this.buffer,0,4);this.bytes=new Uint8Array(this.buffer,HEADER_BYTES);this.requestId=0;this.transactionDepth=0;this.closed=false;this.worker=new Worker(path.join(__dirname,'postgres-sync-worker.js'),{workerData:{buffer:this.buffer,capacity:this.capacity,schema:this.schema,config:options.config||connectionConfigFromEnv(),embeddedTest:options.embeddedTest??process.env.POSTGRES_EMBEDDED_TEST==='true'}});this.worker.unref();this.worker.on('error',error=>{if(!this.closed)process.nextTick(()=>{throw error})});this.worker.on('exit',code=>{if(!this.closed&&code!==0)process.nextTick(()=>{throw new Error(`PostgreSQL bridge worker exited with code ${code}.`)})});this._awaitStartup()}
  _waitWhile(expected){const deadline=Date.now()+this.timeout;while(Atomics.load(this.header,STATE)===expected){const remaining=deadline-Date.now();if(remaining<=0){const error=Object.assign(new Error(`PostgreSQL bridge timed out after ${this.timeout}ms`),{code:'PG_BRIDGE_TIMEOUT'});this.worker.terminate();throw error}Atomics.wait(this.header,STATE,expected,remaining)}}
  _payload(){const length=Atomics.load(this.header,LENGTH);if(length<0||length>this.capacity)throw new Error('Invalid PostgreSQL bridge response length.');return decode(Buffer.from(this.bytes.subarray(0,length)).toString('utf8'))}
  _awaitStartup(){this._waitWhile(IDLE);const state=Atomics.load(this.header,STATE),payload=this._payload();Atomics.store(this.header,STATE,IDLE);Atomics.notify(this.header,STATE);if(state!==READY)throw Object.assign(new Error(payload?.error?.message||'PostgreSQL runtime failed to initialize.'),payload?.error||{})}
  _request(payload){if(this.closed)throw new Error('PostgreSQL database bridge is closed.');const encoded=Buffer.from(encode(payload));if(encoded.length>this.capacity)throw new Error(`PostgreSQL bridge request exceeds ${this.capacity} bytes.`);this.bytes.fill(0,0,encoded.length);this.bytes.set(encoded,0);Atomics.store(this.header,LENGTH,encoded.length);Atomics.store(this.header,REQUEST_ID,++this.requestId);Atomics.store(this.header,STATE,REQUEST);Atomics.notify(this.header,STATE);this._waitWhile(REQUEST);const state=Atomics.load(this.header,STATE),response=this._payload();Atomics.store(this.header,STATE,IDLE);Atomics.notify(this.header,STATE);if(state!==RESPONSE)throw new Error('PostgreSQL bridge entered an invalid state.');if(!response.ok){const error=Object.assign(new Error(response.error?.message||'PostgreSQL query failed.'),response.error||{});error.sql=payload.sql;throw error}return response.result}
  _query(rawSql,args=[]){const {sql,params}=compile(rawSql,args);return this._request({type:'query',sql,params})}
  prepare(sql){return new PostgresStatement(this,sql)}
  exec(sql){this._request({type:'query',sql:postgresSql(sql),params:[]});return this}
  pragma(name,options={}){const key=String(name).split('=')[0].trim().toLowerCase();if(key==='journal_mode')return options.simple?'postgresql':[{journal_mode:'postgresql'}];if(key==='integrity_check')return options.simple?'ok':[{integrity_check:'ok'}];if(key==='foreign_keys')return options.simple?1:[{foreign_keys:1}];return options.simple?null:[]}
  transaction(fn){const database=this;return function(...args){if(database.transactionDepth){return fn(...args)}database._request({type:'begin'});database.transactionDepth++;try{const value=fn(...args);if(value&&typeof value.then==='function')throw new Error('Async callback is not supported inside the synchronous database transaction bridge.');database._request({type:'commit'});return value}catch(error){try{database._request({type:'rollback'})}catch{}throw error}finally{database.transactionDepth--}}}
  close(){if(this.closed)return;this.closed=true;try{Atomics.store(this.header,STATE,CLOSE);Atomics.notify(this.header,STATE)}finally{this.worker.terminate()}}
}
module.exports={PostgresSyncDatabase,connectionConfigFromEnv,postgresSql,compile,safeSchema};
