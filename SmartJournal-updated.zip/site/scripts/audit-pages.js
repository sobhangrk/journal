/**
 * ممیزی کامل سایت — هر صفحه با مرورگر واقعی باز می‌شود و بررسی می‌شود:
 * خطای JS، درخواست ۴۰۴، تصویر شکسته، لینک مرده، فونت، و قابل کلیک بودن.
 */
const puppeteer = require(process.env.PUPPETEER_PATH||'puppeteer');
const B = 'http://127.0.0.1:3000';
const PAGES = ['/', '/pricing', '/faq', '/about', '/contact', '/guides', '/quick-start',
  '/legal/terms', '/legal/privacy', '/legal/cookies', '/legal/disclaimer'];
const findings = [];

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  for (const path of PAGES) {
    const p = await br.newPage(); await p.setViewport({ width: 1440, height: 900 });
    const errs = [], bad = [], consoleErr = [];
    p.on('pageerror', e => errs.push(String(e).slice(0, 160)));
    p.on('console', m => { if (m.type() === 'error') consoleErr.push(m.text().slice(0, 120)); });
    p.on('response', r => { if (r.status() >= 400 && !/\/api\/auth\/me/.test(r.url())) bad.push(r.status() + ' ' + r.url().replace(B, '')); });
    p.on('requestfailed', r => bad.push('FAIL ' + r.url().replace(B, '') + ' ' + (r.failure() || {}).errorText));

    try { await p.goto(B + path, { waitUntil: 'networkidle2', timeout: 45000 }); }
    catch (e) { findings.push([path, 'critical', 'صفحه بارگذاری نشد: ' + e.message.slice(0, 80)]); await p.close(); continue; }
    await new Promise(r => setTimeout(r, 3500));

    const info = await p.evaluate(() => {
      const brokenImgs = [...document.images].filter(i => i.naturalWidth === 0 && i.currentSrc).map(i => i.currentSrc.slice(-60));
      const emptyLinks = [...document.querySelectorAll('a[href]')]
        .filter(a => { const h = a.getAttribute('href'); return h === '#' || h === '' || /SmartJournal-.*\.html/.test(h); })
        .map(a => (a.innerText || '').trim().slice(0, 25) + ' → ' + a.getAttribute('href'));
      const extern = [...document.querySelectorAll('link[href],script[src],img[src]')]
        .map(e => e.href || e.src).filter(u => u && !u.startsWith(location.origin) && !u.startsWith('data:'));
      const bodyFont = getComputedStyle(document.body).fontFamily;
      const h1 = document.querySelector('h1');
      return {
        title: document.title,
        textLen: (document.body.innerText || '').trim().length,
        brokenImgs, emptyLinks: [...new Set(emptyLinks)], extern: [...new Set(extern)],
        vazir: /Vazirmatn/i.test(bodyFont), bodyFont: bodyFont.slice(0, 50),
        h1: h1 ? h1.innerText.trim().slice(0, 50) : null,
        inert: !!document.querySelector('[inert]'),
        lang: document.documentElement.lang, dir: document.documentElement.dir,
        build: (document.querySelector('meta[name=pa-build]') || {}).content || null,
      };
    });

    const tag = (level, msg) => findings.push([path, level, msg]);
    if (errs.length) tag('critical', 'خطای JS: ' + errs.join(' | '));
    const realBad = [...new Set(bad)];
    if (realBad.length) tag('high', 'درخواست ناموفق: ' + realBad.join(' | '));
    if (info.brokenImgs.length) tag('high', 'تصویر شکسته: ' + info.brokenImgs.join(', '));
    if (info.emptyLinks.length) tag('medium', 'لینک مرده: ' + info.emptyLinks.join(' | '));
    if (info.extern.length) tag('medium', 'منبع خارجی (ریسک ایران): ' + info.extern.join(', '));
    if (!info.vazir) tag('medium', 'فونت وزیرمتن اعمال نشده: ' + info.bodyFont);
    if (info.textLen < 300) tag('high', 'محتوای صفحه خیلی کم است: ' + info.textLen + ' کاراکتر');
    if (!info.h1) tag('medium', 'تگ h1 ندارد (SEO)');
    if (info.lang !== 'fa' || info.dir !== 'rtl') tag('medium', `lang/dir اشتباه: ${info.lang}/${info.dir}`);

    console.log(`${path.padEnd(22)} ${String(info.textLen).padStart(6)}ch  h1=${info.h1 ? '✓' : '✗'}  فونت=${info.vazir ? '✓' : '✗'}  خطا=${errs.length}  ۴xx=${realBad.length}`);
    await p.close();
  }

  console.log('\n════════ یافته‌ها ════════');
  if (!findings.length) console.log('  هیچ مشکلی پیدا نشد.');
  const order = { critical: 0, high: 1, medium: 2 };
  findings.sort((a, b) => order[a[1]] - order[b[1]]);
  findings.forEach(([page, level, msg]) => console.log(`  [${level.toUpperCase()}] ${page}\n      ${msg}`));
  await br.close();
})();
