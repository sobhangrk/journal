#!/usr/bin/env node
'use strict';
/* اندازه‌گیری واقعی مصرف حافظه و CPU برای ظرفیت‌سنجی هاست */

const { spawn, execSync } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');

const PORT = 3900;
const B = `http://127.0.0.1:${PORT}`;
const UP = '/tmp/cap-uploads';
fs.rmSync(UP, { recursive: true, force: true });
fs.mkdirSync(UP, { recursive: true });
const DB = path.join('/tmp', `cap-${process.pid}.db`);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rssOf = (pid) => {
  try { return Number(execSync(`ps -o rss= -p ${pid}`).toString().trim()) / 1024; }
  catch { return 0; }
};
const cpuOf = (pid) => {
  try { return execSync(`ps -o %cpu= -p ${pid}`).toString().trim(); } catch { return '?'; }
};

const child = spawn(process.execPath, ['server.js'], {
  cwd: path.resolve(__dirname, '..'),
  env: {
    ...process.env,
    NODE_ENV: 'development', DB_ENGINE: 'sqlite', DATABASE_PATH: DB,
    HOST: '127.0.0.1', PORT: String(PORT), SEED_DEMO_DATA: 'false',
    UPLOAD_DIR: UP, APP_ENCRYPTION_KEY: crypto.randomBytes(32).toString('hex'),
    ADMIN_USERNAME: 'owner', ADMIN_MOBILE: '09120000000', ADMIN_PASSWORD: 'Cap-Test@12345',
    REDIS_ENABLED: 'false', QUEUE_ENABLED: 'false', STORAGE_BACKEND: 'local',
  },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (c) => { logs += c; });
child.stderr.on('data', (c) => { logs += c; });

function cookies(res) {
  const v = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie() : [res.headers.get('set-cookie')].filter(Boolean);
  return v.flatMap((x) => String(x).split(/,(?=\s*[^;,]+=)/)).map((x) => x.trim().split(';')[0]).join('; ');
}

(async () => {
  for (let i = 0; i < 160; i++) {
    try { if ((await fetch(B + '/api/health/live')).ok) break; } catch {}
    if (i === 159) { console.log(logs.slice(-1500)); throw new Error('no boot'); }
    await sleep(200);
  }
  await sleep(2500);

  const idle = rssOf(child.pid);
  console.log('┌─ حافظه ────────────────────────────────────────────');
  console.log(`│  Node در حالت بیکار            ${idle.toFixed(0).padStart(6)} MB`);

  // ---- 1) static page load storm ----
  let peak = idle;
  const track = setInterval(() => { peak = Math.max(peak, rssOf(child.pid)); }, 120);
  const pages = ['/', '/journal', '/pricing', '/faq', '/about', '/admin'];
  const t0 = Date.now();
  for (let round = 0; round < 6; round++) {
    await Promise.all(Array.from({ length: 30 }, (_, i) => fetch(B + pages[i % pages.length]).then(r => r.text())));
  }
  const pageMs = Date.now() - t0;
  const afterPages = rssOf(child.pid);
  console.log(`│  بعد از ۱۸۰ درخواست صفحه       ${afterPages.toFixed(0).padStart(6)} MB   (${pageMs} ms)`);

  // ---- 2) real users + journal writes ----
  const users = [];
  for (let i = 0; i < 12; i++) {
    const mobile = '0913' + String(Date.now() + i).slice(-7);
    const s = await (await fetch(B + '/api/auth/signup', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'کاربر ' + i, mobile, password: 'Cap@12345678', remember: true,
        acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false }),
    })).json();
    const vr = await fetch(B + '/api/auth/signup/verify', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ challengeToken: s.challengeToken, code: s.devCode }),
    });
    const vd = await vr.json();
    users.push({ cookie: cookies(vr), csrf: vd.csrfToken });
  }
  const afterUsers = rssOf(child.pid);
  console.log(`│  بعد از ساخت ۱۲ کاربر واقعی    ${afterUsers.toFixed(0).padStart(6)} MB`);

  // ---- 3) WebP conversions (the CPU/RAM heavy part) ----
  const big = await sharp({ create: { width: 2400, height: 1600, channels: 3, background: { r: 15, g: 30, b: 48 } } })
    .png().toBuffer();
  console.log(`│  (تصویر آزمایشی ${(big.length / 1048576).toFixed(1)} مگابایت، ۲۴۰۰×۱۶۰۰)`);
  const dataUrl = `data:image/png;base64,${big.toString('base64')}`;

  const t1 = Date.now();
  await Promise.all(users.slice(0, 8).map((u) => fetch(B + '/api/journal/media', {
    method: 'POST',
    headers: { 'content-type': 'application/json', cookie: u.cookie, 'x-csrf-token': u.csrf },
    body: JSON.stringify({ data: dataUrl }),
  }).then(r => r.text())));
  const convMs = Date.now() - t1;
  const afterWebp = rssOf(child.pid);
  peak = Math.max(peak, afterWebp);
  console.log(`│  بعد از ۸ تبدیل WebP همزمان    ${afterWebp.toFixed(0).padStart(6)} MB   (${convMs} ms → ${Math.round(convMs / 8)} ms هر تصویر)`);

  await sleep(4000);
  if (global.gc) global.gc();
  const settled = rssOf(child.pid);
  clearInterval(track);
  console.log(`│  اوج مشاهده‌شده                ${peak.toFixed(0).padStart(6)} MB`);
  console.log(`│  بعد از آرام شدن                ${settled.toFixed(0).padStart(6)} MB`);
  console.log('└────────────────────────────────────────────────────');

  // ---- 4) disk footprint ----
  const dbSize = fs.existsSync(DB) ? fs.statSync(DB).size : 0;
  const upSize = Number(execSync(`du -sb ${UP} | cut -f1`).toString().trim());
  const stored = execSync(`find ${UP} -type f | wc -l`).toString().trim();
  console.log('\n┌─ دیسک ─────────────────────────────────────────────');
  console.log(`│  دیتابیس با ۱۲ کاربر            ${(dbSize / 1024).toFixed(0).padStart(6)} KB`);
  console.log(`│  → تقریباً هر کاربر             ${(dbSize / 12 / 1024).toFixed(1).padStart(6)} KB (بدون معامله)`);
  console.log(`│  ${stored} تصویر ذخیره‌شده             ${(upSize / 1024).toFixed(0).padStart(6)} KB`);
  console.log(`│  → هر تصویر بعد از WebP         ${(upSize / Math.max(1, Number(stored)) / 1024).toFixed(0).padStart(6)} KB (از ${(big.length / 1024).toFixed(0)} KB)`);
  console.log('└────────────────────────────────────────────────────');

  // ---- 5) response times ----
  const timed = async (p, n = 20) => {
    const s = Date.now();
    for (let i = 0; i < n; i++) await fetch(B + p).then(r => r.text());
    return (Date.now() - s) / n;
  };
  console.log('\n┌─ زمان پاسخ (میانگین) ──────────────────────────────');
  for (const p of ['/', '/pricing', '/api/public/plans']) {
    console.log(`│  ${p.padEnd(22)} ${(await timed(p)).toFixed(1).padStart(6)} ms`);
  }
  console.log('└────────────────────────────────────────────────────');

  console.log('\n  CPU پروسه هنگام اندازه‌گیری:', cpuOf(child.pid) + '%');
  console.log('  هسته‌های در دسترس:', require('node:os').cpus().length);
  console.log('  حافظه کل ماشین:', (require('node:os').totalmem() / 1073741824).toFixed(1), 'GB');

  child.kill('SIGTERM');
  await sleep(600);
  fs.rmSync(UP, { recursive: true, force: true });
  [DB, DB + '-wal', DB + '-shm'].forEach(f => fs.rmSync(f, { force: true }));
})().catch(async (e) => {
  console.error('✗', e.message);
  child.kill('SIGKILL');
  process.exit(1);
});
