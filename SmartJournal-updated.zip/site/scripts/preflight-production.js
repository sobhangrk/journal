'use strict';
const fs=require('node:fs');
const path=require('node:path');
const checks=[];
function check(name,pass,message,critical=true){checks.push({name,pass:!!pass,message,critical})}
function secret(name){if(process.env[name])return String(process.env[name]);const file=process.env[`${name}_FILE`];if(file)try{return fs.readFileSync(file,'utf8').trim()}catch{return ''}return ''}
const env=process.env,username=String(env.ADMIN_USERNAME||''),mobile=String(env.ADMIN_MOBILE||''),password=String(env.ADMIN_PASSWORD||''),encryption=secret('APP_ENCRYPTION_KEY'),rpId=String(env.WEBAUTHN_RP_ID||'').toLowerCase(),originRaw=String(env.WEBAUTHN_ORIGIN||'');
check('NODE_ENV',env.NODE_ENV==='production','NODE_ENV باید production باشد.');
check('Owner mobile',/^09\d{9}$/.test(mobile),'ADMIN_MOBILE باید شماره معتبر ایرانی باشد.');
check('Owner username',/^[a-z][a-z0-9._-]{2,31}$/.test(username),'ADMIN_USERNAME باید ۳ تا ۳۲ کاراکتر انگلیسی معتبر باشد.');
check('Owner password',password.length>=12&&/[A-Za-z]/.test(password)&&/\d/.test(password)&&/[^A-Za-z0-9]/.test(password)&&!/change|admin@12345|password/i.test(password),'ADMIN_PASSWORD باید حداقل ۱۲ کاراکتر و شامل حرف، عدد و نماد غیرپیش‌فرض باشد.');
check('Encryption key',Buffer.byteLength(encryption,'utf8')>=32,'APP_ENCRYPTION_KEY باید حداقل ۳۲ بایت تصادفی باشد.');
const backupKey=secret('BACKUP_ENCRYPTION_KEY'),metricsToken=secret('METRICS_TOKEN');
check('Backup encryption key',Buffer.byteLength(backupKey,'utf8')>=32&&backupKey!==encryption,'BACKUP_ENCRYPTION_KEY باید حداقل ۳۲ بایت و متفاوت از کلید برنامه باشد.');
check('Metrics token',metricsToken.length>=24&&!/change_this/i.test(metricsToken),'METRICS_TOKEN باید حداقل ۲۴ کاراکتر تصادفی و غیرپیش‌فرض باشد.');
check('Sentry DSN',!!env.SENTRY_DSN,'SENTRY_DSN هنوز تنظیم نشده است؛ Error Tracking خارجی غیرفعال خواهد بود.',false);
const redisEnabled=env.REDIS_ENABLED!=='false'&&!!env.REDIS_URL,queueEnabled=env.QUEUE_ENABLED==='true',storageBackend=String(env.STORAGE_BACKEND||'local').toLowerCase(),workerToken=secret('INTERNAL_WORKER_TOKEN');
let redisUrl=null;try{redisUrl=new URL(env.REDIS_URL||'')}catch{}
check('Redis',redisEnabled&&redisUrl&&['redis:','rediss:'].includes(redisUrl.protocol)&&!/change_me/i.test(env.REDIS_URL||''),'REDIS_URL معتبر برای rate limit، session/cache و queue الزامی است.');
check('Queue enabled',queueEnabled,'QUEUE_ENABLED باید برای SMS، image processing و maintenance فعال باشد.');
check('Queue Redis',!queueEnabled||redisEnabled,'با QUEUE_ENABLED=true باید Redis فعال باشد.');
check('Worker token',!queueEnabled||workerToken.length>=24&&!/change_this/i.test(workerToken),'INTERNAL_WORKER_TOKEN باید حداقل ۲۴ کاراکتر تصادفی و غیرپیش‌فرض باشد.');
check('Object storage backend',['s3','hybrid'].includes(storageBackend),'STORAGE_BACKEND در Production باید s3 یا hybrid باشد.');
check('S3 bucket',!['s3','hybrid'].includes(storageBackend)||!!env.S3_BUCKET,'S3_BUCKET برای object storage الزامی است.');
check('S3 credentials',!['s3','hybrid'].includes(storageBackend)||(!env.S3_ENDPOINT||!!env.S3_ACCESS_KEY_ID&&!!secret('S3_SECRET_ACCESS_KEY')),'برای فضای S3-compatible سفارشی، credentialها باید تنظیم شوند.');
const backupRemoteBucket=String(env.BACKUP_REMOTE_S3_BUCKET||'');
check('Remote encrypted backup',!!backupRemoteBucket&&backupRemoteBucket!==String(env.S3_BUCKET||''),'BACKUP_REMOTE_S3_BUCKET باید تنظیم و از bucket رسانه جدا باشد.');
const dbEngine=String(env.DB_ENGINE||'').toLowerCase(),databaseUrl=String(env.DATABASE_URL||'');let parsedDatabaseUrl=null;try{parsedDatabaseUrl=new URL(databaseUrl)}catch{}
const pgDiscrete=!!env.PGHOST&&!!env.PGDATABASE&&!!env.PGUSER&&!!secret('PGPASSWORD'),pgUrl=parsedDatabaseUrl&&['postgres:','postgresql:'].includes(parsedDatabaseUrl.protocol)&&!!parsedDatabaseUrl.hostname&&!!parsedDatabaseUrl.pathname.slice(1);
check('PostgreSQL primary runtime',dbEngine==='postgres'&&(pgUrl||pgDiscrete),'DB_ENGINE=postgres و DATABASE_URL یا PGHOST/PGDATABASE/PGUSER/PGPASSWORD معتبر الزامی است.');
check('PostgreSQL schema',/^[a-z][a-z0-9_]{0,62}$/.test(String(env.PA_PG_SCHEMA||'pa_journal')),'PA_PG_SCHEMA معتبر نیست.');
check('SQLite rollback guard',env.ALLOW_SQLITE_PRODUCTION!=='true','ALLOW_SQLITE_PRODUCTION در انتشار عادی نباید فعال باشد.');
check('PostgreSQL test driver disabled',env.POSTGRES_EMBEDDED_TEST!=='true','POSTGRES_EMBEDDED_TEST فقط برای smoke است و در Production نباید فعال باشد.');
check('CDN',/^https:\/\//.test(String(env.STATIC_ASSET_BASE_URL||''))&&!/example\.com/i.test(String(env.STATIC_ASSET_BASE_URL||'')),'STATIC_ASSET_BASE_URL برای CDN فایل‌های ثابت تنظیم نشده است.',false);
const alertmanagerPath=path.resolve(env.ALERTMANAGER_CONFIG||path.join(__dirname,'..','deploy','alertmanager.yml'));let alertmanager='';try{alertmanager=fs.readFileSync(alertmanagerPath,'utf8')}catch{}
check('Outage email alert',!!alertmanager&&!/example\.com|CHANGE_THIS/i.test(alertmanager),'گیرنده و SMTP واقعی Alertmanager باید جای placeholderها قرار گیرد.');
check('External uptime',env.EXTERNAL_UPTIME_MONITOR_CONFIRMED==='true','پس از ساخت check خارجی برای live و ready، EXTERNAL_UPTIME_MONITOR_CONFIRMED=true را تنظیم کنید.');
check('Legal operator identity',String(env.LEGAL_OPERATOR_NAME||'').trim().length>=3&&!/[\[\]]/.test(String(env.LEGAL_OPERATOR_NAME||'')),'LEGAL_OPERATOR_NAME باید نام واقعی ارائه‌دهنده قانونی باشد.');
check('Legal registration',String(env.LEGAL_OPERATOR_REGISTRATION||'').trim().length>=3,'LEGAL_OPERATOR_REGISTRATION باید شناسه ملی/ثبت واقعی باشد.');
check('Legal address',String(env.LEGAL_OPERATOR_ADDRESS||'').trim().length>=10,'LEGAL_OPERATOR_ADDRESS باید نشانی قانونی واقعی باشد.');
check('Legal review approval',env.LEGAL_REVIEW_APPROVED==='true','پس از بازبینی و تأیید مشاور حقوقی ایران، LEGAL_REVIEW_APPROVED=true تنظیم شود.');
check('Demo data',env.SEED_DEMO_DATA==='false','SEED_DEMO_DATA باید صریحاً false باشد.');
check('WebAuthn RP ID',!!rpId&&!rpId.includes('://')&&!rpId.includes('/')&&rpId!=='localhost','WEBAUTHN_RP_ID باید hostname عمومی بدون protocol باشد.');
let origin=null;try{origin=new URL(originRaw)}catch{}
check('WebAuthn HTTPS origin',origin&&origin.protocol==='https:'&&origin.origin===originRaw.replace(/\/$/,''),'WEBAUTHN_ORIGIN باید origin دقیق HTTPS و بدون path باشد.');
check('WebAuthn RP match',origin&&rpId&&(origin.hostname===rpId||origin.hostname.endsWith('.'+rpId)),'hostname مبدأ WebAuthn باید برابر یا زیردامنه RP ID باشد.');
let publicBase=null;try{publicBase=new URL(String(env.PUBLIC_BASE_URL||''))}catch{}
check('Public canonical origin',publicBase&&publicBase.protocol==='https:'&&publicBase.origin===String(env.PUBLIC_BASE_URL||'').replace(/\/$/,''),'PUBLIC_BASE_URL باید origin دقیق HTTPS و بدون path باشد.');
const supportEmail=String(env.SUPPORT_EMAIL||'').trim(),supportDomain=(supportEmail.split('@')[1]||'').toLowerCase();
check('Support email',/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(supportEmail)&&!/(^|\.)example\.|\.(test|invalid|localhost)$/.test(supportDomain),'SUPPORT_EMAIL باید صندوق واقعی و تأییدشده پشتیبانی باشد.');
check('Search Console verification',!!String(env.GOOGLE_SITE_VERIFICATION||env.BING_SITE_VERIFICATION||'').trim(),'حداقل یک token برای Google Search Console یا Bing Webmaster تنظیم نشده است.',false);
const turnstileSite=String(env.TURNSTILE_SITE_KEY||''),turnstileSecret=String(env.TURNSTILE_SECRET_KEY||'');
check('Turnstile pair',(!turnstileSite&&!turnstileSecret)||(!!turnstileSite&&!!turnstileSecret),'Site Key و Secret ترنستایل باید با هم تنظیم شوند؛ امکان تنظیم بعدی از پنل نیز وجود دارد.',false);
const dbPath=path.resolve(env.DATABASE_PATH||'/app/data/admin.db'),uploadPath=path.resolve(env.UPLOAD_DIR||'/app/data/uploads');
check('Persistent upload path',!uploadPath.includes('/tmp/')&&!uploadPath.includes('node_modules'),`UPLOAD_DIR باید روی Volume پایدار باشد: ${uploadPath}`);
check('PostgreSQL encrypted backup confirmed',env.POSTGRES_BACKUP_CONFIRMED==='true','پس از اجرای موفق backup رمزنگاری‌شده PostgreSQL و restore drill، POSTGRES_BACKUP_CONFIRMED=true تنظیم شود.');
/* سرعت صفحهٔ اصلی: باندل ژورنال باید جدا شده باشد (PERFORMANCE-SPLIT.md).
   اگر build:index دوباره اجرا شده و build:split فراموش شده باشد، صفحهٔ اصلی
   دوباره ۱.۷ مگابایت می‌شود و LCP موبایل خراب می‌شود. */
let landingKb=0,chunksOk=false,landingInlineApp=true;
try{
  const landingPath=path.join(__dirname,'..','public','index.html');
  const landingHtml=fs.readFileSync(landingPath,'utf8');
  landingKb=Math.round(Buffer.byteLength(landingHtml)/1024);
  landingInlineApp=landingHtml.includes('createRoot');
  const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'..','public','app','chunks.json'),'utf8'));
  chunksOk=['app','auth'].every(key=>fs.existsSync(path.join(__dirname,'..','public',String(manifest[key]||'').replace(/^\//,''))))
    && landingHtml.includes(manifest.app) && landingHtml.includes(manifest.auth);
}catch{}
check('Landing bundle split',!landingInlineApp&&chunksOk&&landingKb>0&&landingKb<=Number(env.LANDING_LIMIT_KB||250),
  `صفحهٔ اصلی ${landingKb}KB است یا chunkهای /app کامل نیستند. اجرا کنید: npm run build:split && npm run smoke:split`);
const existingDb=fs.existsSync(dbPath);check('Legacy SQLite cutover backup',!existingDb||fs.existsSync(dbPath+'.preflight-backup')||env.PREFLIGHT_BACKUP_CONFIRMED==='true','در صورت وجود SQLite قدیمی، بک‌آپ و cutover آن را با PREFLIGHT_BACKUP_CONFIRMED=true تأیید کنید.',false);
console.log('\nSmartJournal production preflight\n');for(const item of checks){const label=item.pass?'PASS':item.critical?'FAIL':'WARN';console.log(`${item.pass?'✓':item.critical?'✗':'!'} [${label}] ${item.name}${item.pass?'':' — '+item.message}`)}const failed=checks.filter(item=>item.critical&&!item.pass);console.log(`\n${checks.filter(item=>item.pass).length}/${checks.length} checks passed; ${failed.length} critical failure(s).`);if(failed.length)process.exitCode=1;
