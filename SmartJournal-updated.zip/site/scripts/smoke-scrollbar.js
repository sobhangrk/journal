/**
 * smoke-scrollbar.js — رگرسیون «نوار اسکرول سفیدِ ویندوزی»
 *
 * کاربر عکس فرستاد: نوار اسکرول اصلی صفحه سفید و با دو فلش بود، کنار
 * طراحی تیره‌ی سایت زشت می‌زد.
 *
 * دو علت:
 *   ۱) همه‌ی قوانین ::-webkit-scrollbar داخل `.pa-app` محدود بودند، پس
 *      اسکرولِ خودِ سند استایل نداشت.
 *   ۲) <meta name="color-scheme" content="dark light"> ⇒ روی ویندوزِ تم روشن
 *      مرورگر اسکرول‌بار بومی روشن می‌کشید.
 *
 * این تست به حرف CSS اعتماد نمی‌کند؛ با مرورگر واقعی از نوار اسکرول عکس
 * می‌گیرد و روشنایی پیکسل‌هایش را اندازه می‌گیرد.
 */
const puppeteer = require('puppeteer');
const fs = require('fs');
const B = process.env.BASE || 'http://127.0.0.1:3000';
const S = [];
const ok = (n, c, x = '') => { S.push([c, n]); console.log((c ? '  ✓' : '  ✗') + ' ' + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

/** میانگین روشنایی نوار عمودیِ سمتِ اسکرول‌بار در یک PNG */
function scrollbarBrightness(pngPath, side /* 'left' | 'right' */, width, height) {
  const { execSync } = require('child_process');
  const out = execSync(
    `python3 -c "
from PIL import Image
im = Image.open('${pngPath}').convert('RGB')
w,h = im.size
strip = 12
box = (0,0,strip,h) if '${side}'=='left' else (w-strip,0,w,h)
px = list(im.crop(box).getdata())
vals = [ (r+g+b)/3 for r,g,b in px ]
vals.sort()
mid = vals[len(vals)//2]
print(round(sum(vals)/len(vals),1), round(mid,1), round(max(vals),1))
"`).toString().trim();
  const [avg, median, max] = out.split(/\s+/).map(Number);
  return { avg, median, max };
}

(async () => {
  const br = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-device-scale-factor=1'],
  });

  for (const [name, url] of [['ژورنال / لندینگ', '/'], ['پنل مدیریت', '/admin'], ['صفحه قیمت‌ها', '/pricing']]) {
    console.log(`\n── ${name} (${url}) ──`);
    const p = await br.newPage();
    await p.setViewport({ width: 900, height: 700 });
    await p.goto(B + url, { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(2500);

    const info = await p.evaluate(() => {
      const cs = getComputedStyle(document.documentElement);
      const meta = document.querySelector('meta[name="color-scheme"]');
      // مطمئن شویم صفحه واقعاً اسکرول دارد
      const scrollable = document.documentElement.scrollHeight > innerHeight + 40;
      return {
        colorScheme: cs.colorScheme,
        meta: meta ? meta.content : null,
        scrollbarWidth: cs.scrollbarWidth,
        scrollbarColor: cs.scrollbarColor,
        scrollable,
        dir: document.documentElement.dir || getComputedStyle(document.body).direction,
        styleTag: !!document.getElementById('pa-shared-scrollbar'),
      };
    });

    ok('color-scheme روی dark است', info.colorScheme === 'dark', 'مقدار: ' + info.colorScheme);
    ok('متای color-scheme دیگر light را پیشنهاد نمی‌دهد', !info.meta || !/light/.test(info.meta), 'meta: ' + info.meta);
    /* در پنل مدیریت همین قوانین داخل admin.css هستند نه در تگ <style>؛
       پس به‌جای وجود تگ، اعمال‌شدن واقعی قانون را چک می‌کنیم. */
    ok('قوانین اسکرول‌بار روی صفحه اعمال شده',
       info.styleTag || (info.scrollbarColor && info.scrollbarColor !== 'auto'),
       'scrollbar-color: ' + info.scrollbarColor);
    ok('اسکرول‌بار باریک فایرفاکس تنظیم شده', info.scrollbarWidth === 'thin', info.scrollbarWidth);

    if (!info.scrollable) {
      await p.evaluate(() => {
        const d = document.createElement('div');
        d.style.height = '3000px'; d.id = 'force-scroll';
        document.body.appendChild(d);
      });
      await wait(400);
    }

    const shot = `/tmp/scrollbar-${url.replace(/\W+/g, '') || 'home'}.png`;
    await p.screenshot({ path: shot });
    const side = info.dir === 'rtl' ? 'left' : 'right';
    const b = scrollbarBrightness(shot, side, 900, 700);
    // نوار سفید ویندوزی حدود ۲۴۰ روشنایی دارد؛ تم تیره باید خیلی کمتر باشد
    ok('نوار اسکرول تیره است (نه سفیدِ ویندوزی)', b.max < 150,
       `روشنایی — میانگین ${b.avg} · میانه ${b.median} · بیشینه ${b.max} (سفید ≈ ۲۴۰)`);
    await p.close();
  }

  await br.close();
  const pass = S.filter(x => x[0]).length;
  console.log(`\n  ${pass}/${S.length} تست موفق`);
  process.exit(pass === S.length ? 0 : 1);
})().catch(e => { console.error('ERR', e); process.exit(1); });
