/**
 * smoke-mobile-layout.js — رگرسیون چیدمان موبایل و عناصر شناور
 *
 * چرا این تست دوباره نوشته شد؟
 *   تست قبلی (smoke:float) فقط یک فهرست ثابت از پنج انتخابگر را می‌سنجید،
 *   برای همین ۹ از ۹ سبز می‌شد در حالی که کاربر روی گوشی‌اش همپوشانی می‌دید.
 *   چیزهایی که نمی‌دید:
 *     • نوار «ثبت معامله جدید» (.pa-form-actions-bar)
 *     • دکمهٔ گرد + که از نوار پایین بیرون می‌زند (فرزندِ یک عنصر fixed)
 *     • پوشیده‌شدن محتوای واقعی صفحه زیر عناصر شناور
 *
 * حالا هیچ فهرست ثابتی وجود ندارد: کل DOM اسکن می‌شود.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const ov = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);

const COLLECT = () => {
  const vis = el => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) < .05) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    return r;
  };
  const label = el => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') +
    (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.') : '');
  const clipped = el => {
    let p = el.parentElement;
    while (p && p !== document.body) {
      const c = getComputedStyle(p);
      if (/auto|scroll|hidden/.test(c.overflowY) || /auto|scroll|hidden/.test(c.overflowX)) return true;
      p = p.parentElement;
    }
    return false;
  };

  const floaters = [], roots = [];
  document.querySelectorAll('body *').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
    const r = vis(el); if (!r) return;
    let par = el.parentElement, nested = false;
    while (par && par !== document.body) { const pc = getComputedStyle(par); if (pc.position === 'fixed' || pc.position === 'sticky') { nested = true; break } par = par.parentElement }
    if (nested) return;
    roots.push(el);
    floaters.push({ name: label(el), owner: label(el), rect: [r.left, r.top, r.width, r.height].map(Math.round) });
  });
  roots.forEach(root => {
    const rr = root.getBoundingClientRect();
    root.querySelectorAll('*').forEach(ch => {
      if (clipped(ch)) return;
      const r = vis(ch); if (!r) return;
      const out = r.left < rr.left - 6 || r.top < rr.top - 6 || r.right > rr.right + 6 || r.bottom > rr.bottom + 6;
      if (!out) return;
      floaters.push({ name: label(root) + ' ▸ ' + label(ch), owner: label(root), rect: [r.left, r.top, r.width, r.height].map(Math.round) });
    });
  });

  const covered = [];
  document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) return;
    let f = el; while (f && f !== document.body) { const c = getComputedStyle(f); if (c.position === 'fixed' || c.position === 'sticky') return; f = f.parentElement }
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (!hit || hit === el || el.contains(hit) || hit.contains(el)) return;
    covered.push({ el: label(el), txt: (el.innerText || el.value || '').replace(/\s+/g, ' ').trim().slice(0, 26) });
  });

  const small = [];
  document.querySelectorAll('.pa-mobile-nav > button, .pa-auth-userbar button, .pa-support-launcher, .pa-ux-help').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.width < 40 || r.height < 40) small.push(label(el) + ' ' + Math.round(r.width) + '×' + Math.round(r.height));
  });

  const bar = document.querySelector('.pa-accounts-bar');
  const navIcons = [...document.querySelectorAll('.pa-mobile-nav > button > span')];
  return {
    floaters, covered, small,
    accountsBarH: bar && vis(bar) ? Math.round(bar.getBoundingClientRect().height) : 0,
    navTotal: navIcons.length,
    navSvg: navIcons.filter(s => s.querySelector('svg')).length
  };
};

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };

  /* ── ۱) Service Worker: مهر نسخه باید با هر تغییر کد عوض شود ── */
  console.log('\n── تحویل به‌روزرسانی (Service Worker) ──');
  const swText = await (await fetch(B + '/service-worker.js')).text();
  const swHead = await fetch(B + '/service-worker.js');
  const stamp1 = (swText.match(/const BUILD = '([^']*)'/) || [])[1] || '';
  ok('نام کش از مهر نسخه ساخته می‌شود (نه ثابت)', /^[0-9a-z]+-[0-9.]+$/.test(stamp1), stamp1);
  ok('خود فایل SW کش نمی‌شود', /no-store/.test(swHead.headers.get('cache-control') || ''), swHead.headers.get('cache-control'));
  /* داخلِ همان شاخه باید اول fetch بیاید بعد caches — نه برعکس */
  const codeBranch = (swText.split('CODE.includes(url.pathname)')[1] || '').slice(0, 400);
  const iFetch = codeBranch.indexOf('fetch(request)');
  const iCache = codeBranch.indexOf('caches.match');
  ok('کد برنامه «اول شبکه» سرو می‌شود (نه اول کش)',
    iFetch >= 0 && (iCache === -1 || iFetch < iCache),
    iFetch < 0 ? 'شاخهٔ CODE پیدا نشد' : 'fetch@' + iFetch + ' · caches@' + iCache);
  const jsHead = await fetch(B + '/journal-ux-runtime.js');
  ok('فایل‌های JS با no-cache سرو می‌شوند', /no-cache/.test(jsHead.headers.get('cache-control') || ''), jsHead.headers.get('cache-control'));
  require('fs').utimesSync(require('path').join(__dirname, '..', 'public', 'journal-ux-runtime.js'), new Date(), new Date());
  await wait(250);
  const stamp2 = ((await (await fetch(B + '/service-worker.js')).text()).match(/const BUILD = '([^']*)'/) || [])[1] || '';
  ok('با تغییر یک فایل JS، مهر نسخه عوض می‌شود', stamp1 !== stamp2 && !!stamp2, stamp1 + ' → ' + stamp2);

  /* ── ۲) چیدمان ── */
  const mobile = '0993' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'کاربر چیدمان', mobile, password: 'Lay@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  if (!s1.data.challengeToken) { console.log('✗ ساخت کاربر آزمایشی ناموفق:', s1.status, JSON.stringify(s1.data).slice(0, 200)); process.exit(1); }
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const VIEWS = [['موبایل کوچک', 320, 640], ['موبایل', 360, 740], ['موبایل بزرگ', 390, 844], ['تبلت', 768, 1024], ['دسکتاپ', 1366, 768]];

  for (const [vname, w, h] of VIEWS) {
    console.log(`\n── ${vname} ${w}×${h} ──`);
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: w < 500, hasTouch: w < 500 });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(4500);

    for (const tab of ['داشبورد', 'معامله جدید']) {
      if (tab === 'معامله جدید') {
        await p.evaluate(() => {
          const m = [...document.querySelectorAll('.pa-mobile-nav button')].find(x => /ثبت/.test(x.innerText || ''));
          if (m) return m.click();
          const t = [...document.querySelectorAll('.pa-header .pa-tab')].find(x => /معامله جدید|ثبت/.test((x.getAttribute('title') || '') + (x.textContent || '')));
          if (t) t.click();
        });
        await wait(1800);
      }
      await p.evaluate(() => window.scrollTo(0, 0)); await wait(400);
      const top = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await wait(700);
      const bot = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, 0)); await wait(300);

      const clash = [];
      for (let i = 0; i < top.floaters.length; i++) for (let j = i + 1; j < top.floaters.length; j++) {
        const a = top.floaters[i], b = top.floaters[j];
        if (a.owner === b.owner) continue;
        // حباب اشتراک عمداً روی بخشِ خالیِ نوار حساب‌ها (سمت چپ) لنگر انداخته؛
        // تداخلش با چیپ‌ها و متن‌ها در probe-sub-top (۱۳۶ بررسی) سنجیده می‌شود.
        const dockPair =
          (a.name.startsWith('div.pa-accounts-bar') && b.name.includes('ctcu-fab')) ||
          (b.name.startsWith('div.pa-accounts-bar') && a.name.includes('ctcu-fab'));
        if (dockPair) continue;
        if (ov(a.rect, b.rect)) clash.push(a.name + ' ✕ ' + b.name);
      }
      ok(`${tab}: هیچ دو عنصر شناوری روی هم نیست`, clash.length === 0, clash.join(' | ') || `${top.floaters.length} عنصر شناور`);

      const botKeys = new Set(bot.covered.map(c => c.el + '|' + c.txt));
      const stuck = top.covered.filter(c => botKeys.has(c.el + '|' + c.txt));
      ok(`${tab}: هیچ دکمه/فیلدی برای همیشه زیر عناصر شناور نمانده`, stuck.length === 0,
        stuck.map(c => c.el + ' «' + c.txt + '»').join(' | ') || 'همه دسترس‌پذیر');

      ok(`${tab}: هدف لمسی همه ≥۴۰ پیکسل`, top.small.length === 0, top.small.join(' | ') || 'اوکی');

      if (w < 500 && tab === 'داشبورد') {
        ok('موبایل: نوار حساب‌ها یک ردیف است (≤۷۲ پیکسل)', top.accountsBarH > 0 && top.accountsBarH <= 72, top.accountsBarH + 'px');
        ok('موبایل: ایکون‌های نوار پایین برداری و یکدست‌اند', top.navTotal > 0 && top.navSvg === top.navTotal, top.navSvg + '/' + top.navTotal + ' SVG');
      }
    }
    await p.close();
  }
  const br2 = br;

  /* ── ۳) همهٔ تب‌های ژورنال روی موبایل ── */
  console.log('\n── همهٔ تب‌ها روی موبایل ۳۹۰×۸۴۴ ──');
  {
    const p = await br2.newPage();
    await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(5000);
    const tabs = await p.evaluate(() => [...document.querySelectorAll('.pa-header .pa-tab')]
      .map((t, i) => ({ i, label: (t.getAttribute('title') || t.getAttribute('aria-label') || t.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 20) })));
    ok('تب‌های ژورنال پیدا شدند', tabs.length >= 8, tabs.length + ' تب');
    for (const t of tabs) {
      await p.evaluate(i => { const el = document.querySelectorAll('.pa-header .pa-tab')[i]; if (el) el.click(); }, t.i);
      await wait(1500);
      await p.evaluate(() => window.scrollTo(0, 0)); await wait(350);
      const top = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await wait(650);
      const bot = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, 0)); await wait(250);

      const cl = [];
      for (let i = 0; i < top.floaters.length; i++) for (let j = i + 1; j < top.floaters.length; j++) {
        const a2 = top.floaters[i], b2 = top.floaters[j];
        if (a2.owner === b2.owner) continue;
        if (ov(a2.rect, b2.rect)) cl.push(a2.name + ' ✕ ' + b2.name);
      }
      const botKeys = new Set(bot.covered.map(c => c.el + '|' + c.txt));
      const stuck = top.covered.filter(c => botKeys.has(c.el + '|' + c.txt));
      const problems = [];
      if (cl.length) problems.push('همپوشانی: ' + cl.join(' | '));
      if (stuck.length) problems.push('دسترس‌ناپذیر: ' + stuck.map(c => c.el + ' «' + c.txt + '»').join(' | '));
      if (top.small.length) problems.push('هدف کوچک: ' + top.small.join(' | '));
      ok(`تب «${t.label}» سالم است`, problems.length === 0, problems.join(' · ') || 'اوکی');
    }
    await p.close();
  }
  await br2.close();

  const pass = R.filter(r => r[0]).length;
  console.log(`\n${pass}/${R.length} تست موفق`);
  process.exit(pass === R.length ? 0 : 1);
})();
