'use strict';
/**
 * smoke-mt5-sections.js — رگرسیون «Buy/Sell برعکس ثبت می‌شود» (گزارش MT5)
 *
 * ریشهٔ باگ: نام بخش‌های گزارش MT5 («Positions»، «Orders»، «Deals») در یک
 * ردیفِ تک‌سلولی نوشته شده، ولی پارسر پیش از تقسیم‌بندی همهٔ ردیف‌های با
 * کمتر از سه سلول را دور می‌ریخت. بخش‌ها بی‌نام می‌ماندند و انتخاب‌گر به‌جای
 * «Positions» جدول «Deals» را برمی‌داشت. در Deals، دیلِ خروجِ یک پوزیشن
 * «sell» نوعش «buy» است ⇒ جهت وارونه، زمانِ ورود = زمان بسته‌شدن، و کامنت
 * دیل («[sl 4053.51]») به‌عنوان ستاپ ثبت می‌شد.
 *
 * این تست هر سه را با فایل نمونهٔ واقعی (بی‌نام‌شده) می‌سنجد.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const SRC = fs.readFileSync(path.join(ROOT, 'src-html', 'index.combined.html'), 'utf8');
const FILE = process.env.MT5_FILE || path.join(ROOT, 'seed', 'samples', 'mt5-positions-deals-sample.html');
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

function grab(name) {
  const start = SRC.indexOf('\nfunction ' + name + '(');
  if (start < 0) throw new Error('تابع پیدا نشد: ' + name);
  return SRC.slice(start + 1, SRC.indexOf('\n}\n', start) + 3);
}
function grabConst(name, end) {
  const start = SRC.indexOf('\nconst ' + name + ' = ');
  if (start < 0) throw new Error('ثابت پیدا نشد: ' + name);
  return SRC.slice(start + 1, SRC.indexOf(end, start) + end.length);
}

const code = [
  grabConst('paImportFields', '}];'),
  grabConst('PA_SESSION_DEFS', '}];'),
  grabConst('PA_IMPORT_TZ_OPTIONS', '}];'),
  'const paZoneCache = {};',
  ...['paDigits', 'paKey', 'paNumber', 'paDate', 'paZoneParts', 'paZoneOffsetMinutes', 'paNaiveToInstant',
    'paHeaderScore', 'paTableFromMatrix', 'paSplitReportSections', 'paPickReportSection', 'paSectionHeader',
    'paDealsLedger', 'paApplyDealCharges', 'paMergeEntryCharges', 'paGuessMap', 'paDirection', 'paResultSign',
    'paBuildImportedTrade'].map(grab),
  'const xl = { pre: {}, post: {} };function Lu(){ return "id" + Math.random().toString(36).slice(2) }',
  'globalThis.paImportFields = paImportFields;',
].join('\n');
const ctx = { console, Intl, Date, Number, String, Math, Object, Array, isNaN, JSON, Set, Map };
vm.createContext(ctx);
vm.runInContext(code, ctx, { filename: 'mt5.js' });

/* ماتریس را دقیقاً مثل مرورگر می‌سازیم — با نگه‌داشتن ردیف‌های تک‌سلولی */
const raw = fs.readFileSync(FILE);
const text = raw[0] === 0xff || raw[1] === 0x00 ? raw.toString('utf16le') : raw.toString('utf8');
const all = [...text.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
  .map(m => [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
    .map(c => c[1].replace(/<[^>]+>/g, '').replace(/&nbsp;|\u00a0/g, ' ').replace(/\s+/g, ' ').trim()));

/* حقیقت مرجع: خودِ جدول Positions فایل */
const posStart = all.findIndex(r => r.length === 1 && /^Positions$/i.test(r[0]));
const posHeader = all[posStart + 1];
const positions = [];
for (let i = posStart + 2; i < all.length; i++) {
  if (all[i].length !== posHeader.length + 1) break;
  positions.push({ open: all[i][0], ticket: all[i][1], symbol: all[i][2], type: all[i][3], pnl: Number(all[i][13].replace(/[\s,]/g, '')) });
}
console.log(`\n── فایل نمونه: ${path.basename(FILE)} · ${positions.length} پوزیشن ──`);

/* ── ۱) انتخاب بخش درست ─────────────────────────────────────────────── */
const sections = ctx.paSplitReportSections(all);
ok('هر سه بخش گزارش شناسایی شد', sections.length >= 2, sections.map(s => (s.name || '؟') + ':' + (s.rows.length - 1)).join(' · '));
ok('نام بخش‌ها حفظ می‌شود (ردیف تک‌سلولی حذف نمی‌شود)', sections.some(s => /position/i.test(s.name || '')), sections.map(s => s.name).join(', '));
const picked = ctx.paPickReportSection(sections);
ok('بخش «Positions» انتخاب می‌شود، نه «Deals»', /position/i.test(picked.name || '') || picked.header.some(h => ctx.paKey(h) === 'position'), picked.name);

/* حتی اگر نام‌ها را عمداً پاک کنیم، از روی سرستون‌ها باز هم Positions برنده است */
const nameless = sections.map(s => ({ ...s, name: '' }));
ok('بدون نام هم از روی سرستون‌ها Positions تشخیص داده می‌شود',
  ctx.paPickReportSection(nameless).header.some(h => ctx.paKey(h) === 'position'));

/* ── ۲) ساخت معاملات از بخش انتخاب‌شده ──────────────────────────────── */
const table = ctx.paApplyDealCharges(ctx.paTableFromMatrix(picked.rows, 'MetaTrader HTML — ' + picked.name), sections);
const map = ctx.paGuessMap(table.columns, table.rows);
const built = table.rows.map(row => ctx.paBuildImportedTrade(row, map, { accountId: 'acc', format: 'MetaTrader HTML', timezone: 'local' }));
const trades = built.filter(b => b.trade).map(b => b.trade);
ok('تعداد معاملات با تعداد پوزیشن‌های فایل برابر است', trades.length === positions.length, `${trades.length} از ${positions.length}`);

/* ── ۳) جهت Buy/Sell دقیقاً همان چیزی است که در فایل نوشته ──────────── */
let dirBad = 0, timeBad = 0, setupBad = 0;
const details = [];
trades.forEach(trade => {
  const want = positions.find(p => p.ticket === String(trade.importMeta.ticket));
  if (!want) return;
  if (String(trade.direction).toLowerCase() !== want.type.toLowerCase()) {
    dirBad++; if (details.length < 4) details.push(`${want.ticket} فایل=${want.type} برنامه=${trade.direction}`);
  }
  const openStamp = want.open.replace(/\D/g, '').slice(0, 14);
  const tradeStamp = new Date(trade.entryDate).toISOString().replace(/\D/g, '').slice(0, 14);
  if (openStamp !== tradeStamp) { timeBad++; if (details.length < 6) details.push(`${want.ticket} زمان فایل=${want.open}`); }
  if (String(trade.setupName || '').trim()) setupBad++;
});
ok('هیچ معامله‌ای وارونه (Buy↔Sell) ثبت نمی‌شود', dirBad === 0, dirBad ? details.join(' | ') : `${trades.length} معامله بررسی شد`);
ok('زمان ثبت‌شده «زمان ورود» است، نه زمان بسته‌شدن', timeBad === 0, timeBad ? details.join(' | ') : 'همه درست');
ok('برای واردات متاتریدر هیچ ستاپ/استراتژی نوشته نمی‌شود', setupBad === 0, setupBad ? setupBad + ' معامله ستاپ گرفته' : 'همه خالی');

/* هر دو جهت واقعاً وجود دارد (تست بی‌معنی نباشد) */
const dirs = [...new Set(trades.map(t => t.direction))].sort();
ok('نمونه هم buy دارد هم sell', dirs.length === 2, dirs.join(','));

/* ── ۴) کمیسیون/سواپ از Deals هنوز وصل می‌شود ───────────────────────── */
ok('کمیسیون واقعی از جدول Deals خوانده می‌شود', trades.some(t => Number(t.commission) > 0),
  'بیشینه: ' + Math.max(...trades.map(t => Number(t.commission) || 0)).toFixed(2));

/* ── ۵) جمع سود/زیان با فایل می‌خواند ───────────────────────────────── */
const appNet = trades.reduce((sum, t) => sum + (t.resultType === 'loss' ? -t.amount : t.amount), 0);
const fileNet = positions.reduce((sum, p) => sum + p.pnl, 0);
ok('جمع سود/زیان با ستون Profit فایل یکی است', Math.abs(appNet - fileNet) < 0.05, `${appNet.toFixed(2)} · ${fileNet.toFixed(2)}`);

/* ── ۶) اگر فقط Deals در فایل باشد، وارونگی دستی جبران می‌شود ───────── */
const dealsSection = sections.find(s => /deal/i.test(s.name || '') || s.header.some(h => ctx.paKey(h) === 'direction'));
if (dealsSection) {
  const dTable = ctx.paMergeEntryCharges(ctx.paTableFromMatrix(dealsSection.rows, 'MetaTrader HTML — Deals'));
  const dMap = ctx.paGuessMap(dTable.columns, dTable.rows);
  const dTrades = dTable.rows.map(row => ctx.paBuildImportedTrade(row, dMap, { accountId: 'acc', format: 'MetaTrader HTML', timezone: 'local' }))
    .filter(b => b.trade).map(b => b.trade);
  const byPnl = new Map(positions.map(p => [p.pnl.toFixed(2), p.type.toLowerCase()]));
  let flipBad = 0, seen = 0;
  dTrades.forEach(t => {
    const signed = (t.resultType === 'loss' ? -t.amount : t.amount).toFixed(2);
    const want = byPnl.get(signed);
    if (!want) return;
    seen++;
    if (String(t.direction).toLowerCase() !== want) flipBad++;
  });
  ok('حالت جایگزین (فقط Deals) هم جهت را وارونه نمی‌کند', seen > 0 && flipBad === 0, `${seen - flipBad}/${seen}`);
}

const bad = R.filter(([c]) => !c).length;
console.log(`\n${R.length - bad}/${R.length} آزمون جهت و بخش‌های گزارش MetaTrader پاس شد.`);
process.exit(bad ? 1 : 0);
