#!/bin/bash
# ============================================================================
#   SmartJournal — وصل کردن دامنه و فعال کردن HTTPS
#
#   روی سرور:   bash setup-domain.sh smartjournal.ir
#               bash setup-domain.sh smartjournal.ir --email me@gmail.com
#               bash setup-domain.sh smartjournal.ir --no-www     (بدون www)
#               bash setup-domain.sh smartjournal.ir --dry-run    (فقط بررسی)
#               bash setup-domain.sh smartjournal.ir --skip-dns-check
#
#   چه می‌کند:
#     ۱) بررسی می‌کند دامنه واقعاً به IP همین سرور اشاره کند
#     ۲) کانفیگ Nginx را با نام دامنه بازنویسی می‌کند
#     ۳) گواهی رایگان Let's Encrypt می‌گیرد (certbot) + تمدید خودکار
#     ۴) .env را اصلاح می‌کند: PUBLIC_BASE_URL / WEBAUTHN / حذف COOKIE_SECURE=false
#     ۵) سرویس را ری‌استارت و همه چیز را تست می‌کند
#
#   ✅ اگر گواهی گرفته نشد، سایت روی HTTP سالم می‌ماند (rollback خودکار)
# ============================================================================
set -u

APP_DIR="/opt/smartjournal"
NGINX_SITE="/etc/nginx/sites-available/smartjournal"
STAMP="$(date +%Y%m%d-%H%M%S)"

c_ok=$'\033[1;32m'; c_no=$'\033[1;31m'; c_hi=$'\033[1;36m'; c_wr=$'\033[1;33m'; c_off=$'\033[0m'
say()  { echo; echo "${c_hi}▶ $*${c_off}"; }
ok()   { echo "  ${c_ok}✓${c_off} $*"; }
warn() { echo "  ${c_wr}!${c_off} $*"; }
die()  { echo; echo "${c_no}✗ $*${c_off}"; exit 1; }

DOMAIN=""; EMAIL=""; WITH_WWW=1; DRY=0; SKIP_DNS=0
while [ $# -gt 0 ]; do
  case "$1" in
    --email)  EMAIL="${2:-}"; shift 2 ;;
    --no-www) WITH_WWW=0; shift ;;
    --dry-run) DRY=1; shift ;;
    --skip-dns-check) SKIP_DNS=1; shift ;;
    -*) die "گزینه ناشناخته: $1" ;;
    *) DOMAIN="$1"; shift ;;
  esac
done

echo "==============================================="
echo "  وصل کردن دامنه به SmartJournal — $(date '+%Y-%m-%d %H:%M')"
echo "==============================================="

[ -n "$DOMAIN" ] || die "نام دامنه را بدهید:  bash setup-domain.sh yourdomain.ir"
DOMAIN="$(echo "$DOMAIN" | tr 'A-Z' 'a-z' | sed -e 's#^https\?://##' -e 's#/.*$##' -e 's/^www\.//')"
echo "$DOMAIN" | grep -Eq '^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$' || die "نام دامنه معتبر نیست: $DOMAIN"
ok "دامنه: $DOMAIN"

[ "$(id -u)" -eq 0 ] || die "با root اجرا کنید:  sudo bash $0 $DOMAIN"
[ -d "$APP_DIR" ] || die "$APP_DIR پیدا نشد. اول quick-install.sh را اجرا کنید."
[ -f "$APP_DIR/.env" ] || die "$APP_DIR/.env پیدا نشد."

# ------------------------------------------------------ ۱) بررسی DNS -------
say "بررسی DNS"
command -v dig >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y -qq dnsutils >/dev/null 2>&1
SERVER_IP="$(curl -s --max-time 10 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
ok "IP این سرور: $SERVER_IP"

if [ "$SKIP_DNS" -eq 1 ]; then
  warn "بررسی DNS رد شد (--skip-dns-check)"
fi
resolve() { [ "$SKIP_DNS" -eq 1 ] && { echo "$SERVER_IP"; return; }; dig +short A "$1" @8.8.8.8 2>/dev/null | grep -E '^[0-9.]+$' | tail -1; }
DOMAIN_IP="$(resolve "$DOMAIN")"
WWW_IP="$(resolve "www.$DOMAIN")"

if [ -z "$DOMAIN_IP" ]; then
  warn "هیچ رکورد A برای $DOMAIN پیدا نشد."
  echo "     در پنل DNS دامنه این دو رکورد را بسازید و ۱۰ دقیقه صبر کنید:"
  echo "         A    @      $SERVER_IP"
  echo "         A    www    $SERVER_IP"
  die "تا وقتی DNS ست نشده، گواهی SSL صادر نمی‌شود."
fi
if [ "$DOMAIN_IP" = "$SERVER_IP" ]; then
  ok "$DOMAIN → $DOMAIN_IP (درست)"
else
  warn "$DOMAIN → $DOMAIN_IP  ولی IP این سرور $SERVER_IP است"
  die "رکورد A را اصلاح کنید یا منتظر بمانید تا DNS پخش شود (تا ۲۴ ساعت)."
fi
if [ "$WITH_WWW" -eq 1 ]; then
  if [ "$WWW_IP" = "$SERVER_IP" ]; then ok "www.$DOMAIN → $WWW_IP (درست)"
  else warn "www.$DOMAIN تنظیم نشده؛ بدون www ادامه می‌دهیم"; WITH_WWW=0; fi
fi

if [ "$DRY" -eq 1 ]; then echo; ok "حالت بررسی — هیچ تغییری اعمال نشد."; exit 0; fi

# --------------------------------------------------- ۲) کانفیگ Nginx -------
say "تنظیم Nginx"
NAMES="$DOMAIN"; [ "$WITH_WWW" -eq 1 ] && NAMES="$DOMAIN www.$DOMAIN"
[ -f "$NGINX_SITE" ] && cp -a "$NGINX_SITE" "${NGINX_SITE}.bak-${STAMP}" && ok "پشتیبان: ${NGINX_SITE}.bak-${STAMP}"

cat > "$NGINX_SITE" <<NGINX
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name ${NAMES} _;
    client_max_body_size 12M;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 120s;
    }
}
NGINX
ln -sf "$NGINX_SITE" /etc/nginx/sites-enabled/smartjournal
rm -f /etc/nginx/sites-enabled/default
if nginx -t >/dev/null 2>&1; then
  systemctl reload nginx 2>/dev/null || systemctl restart nginx 2>/dev/null || true
  systemctl is-active --quiet nginx && ok "Nginx روی $NAMES پاسخ می‌دهد" || warn "Nginx بالا نیست: systemctl status nginx" 
else nginx -t; cp -a "${NGINX_SITE}.bak-${STAMP}" "$NGINX_SITE" 2>/dev/null; systemctl reload nginx; die "کانفیگ Nginx مشکل داشت؛ نسخه قبلی برگشت."; fi

# ------------------------------------------------------- ۳) گواهی SSL ------
say "گرفتن گواهی HTTPS از Let's Encrypt"
if ! command -v certbot >/dev/null 2>&1; then
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq certbot python3-certbot-nginx >/dev/null 2>&1
fi
CERTBOT_READY=1
command -v certbot >/dev/null 2>&1 || { CERTBOT_READY=0; warn "certbot نصب نشد؛ فعلاً بدون HTTPS ادامه می‌دهیم"; }
[ "$CERTBOT_READY" -eq 1 ] && ok "certbot آماده است"

ufw allow 80/tcp  >/dev/null 2>&1
ufw allow 443/tcp >/dev/null 2>&1

CB_ARGS="--nginx --non-interactive --agree-tos --redirect -d $DOMAIN"
[ "$WITH_WWW" -eq 1 ] && CB_ARGS="$CB_ARGS -d www.$DOMAIN"
if [ -n "$EMAIL" ]; then CB_ARGS="$CB_ARGS -m $EMAIL"; else CB_ARGS="$CB_ARGS --register-unsafely-without-email"; fi

SSL_OK=0
if [ "$CERTBOT_READY" -eq 1 ] && certbot $CB_ARGS; then
  SSL_OK=1; ok "گواهی صادر و روی Nginx نصب شد"
  systemctl enable --now certbot.timer >/dev/null 2>&1 && ok "تمدید خودکار هر ۹۰ روز فعال شد"
else
  warn "صدور گواهی ناموفق بود — سایت روی HTTP سالم می‌ماند."
  echo "     شایع‌ترین دلایل:"
  echo "       • DNS هنوز کامل پخش نشده (کمی بعد دوباره اجرا کنید)"
  echo "       • پورت ۸۰ از بیرون بسته است (ufw / فایروال دیتاسنتر)"
  echo "       • دامنه هنوز در IRNIC فعال نشده"
fi

# ---------------------------------------------------------- ۴) .env -------
say "به‌روزرسانی تنظیمات برنامه"
cp -a "$APP_DIR/.env" "/root/env-backup-${STAMP}" && ok "پشتیبان .env: /root/env-backup-${STAMP}"
SCHEME="http"; [ "$SSL_OK" -eq 1 ] && SCHEME="https"

setenv() {  # setenv KEY VALUE
  local key="$1" value="$2"
  if grep -q "^${key}=" "$APP_DIR/.env"; then
    sed -i "s#^${key}=.*#${key}=${value}#" "$APP_DIR/.env"
  else
    printf '%s=%s\n' "$key" "$value" >> "$APP_DIR/.env"
  fi
}
setenv PUBLIC_BASE_URL "${SCHEME}://${DOMAIN}"
setenv WEBAUTHN_RP_ID  "${DOMAIN}"
setenv WEBAUTHN_ORIGIN "${SCHEME}://${DOMAIN}"
ok "PUBLIC_BASE_URL=${SCHEME}://${DOMAIN}"

if [ "$SSL_OK" -eq 1 ]; then
  if grep -q '^COOKIE_SECURE=false' "$APP_DIR/.env"; then
    sed -i '/^COOKIE_SECURE=false/d' "$APP_DIR/.env"
    ok "COOKIE_SECURE=false حذف شد — کوکی‌ها دوباره امن شدند"
  fi
else
  warn "چون HTTPS فعال نشد، COOKIE_SECURE=false دست‌نخورده ماند (لازم است تا ورود کار کند)"
fi
chown smartjournal:smartjournal "$APP_DIR/.env" 2>/dev/null

# ------------------------------------------------------ ۵) راه‌اندازی ------
say "راه‌اندازی دوباره سرویس"
if systemctl list-unit-files 2>/dev/null | grep -q '^smartjournal\.service'; then
  systemctl restart smartjournal
  sleep 6
  systemctl is-active --quiet smartjournal || { journalctl -u smartjournal -n 25 --no-pager; die "سرویس بالا نیامد."; }
  ok "سرویس فعال است"
else
  warn "سرویس smartjournal پیدا نشد — خودتان برنامه را ری‌استارت کنید"
fi

say "تست نهایی"
for path in / /journal /admin /pricing; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 -H "Host: ${DOMAIN}" "http://127.0.0.1${path}")
  [ "$code" = "200" ] && ok "${path} → ${code}" || warn "${path} → ${code}"
done
if [ "$SSL_OK" -eq 1 ]; then
  ext=$(curl -s -o /dev/null -w '%{http_code}' --max-time 25 "https://${DOMAIN}/")
  [ "$ext" = "200" ] && ok "https://${DOMAIN} → ${ext}" || warn "https://${DOMAIN} → ${ext} (چند دقیقه بعد دوباره امتحان کنید)"
  redir=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 "http://${DOMAIN}/")
  [ "$redir" = "301" ] || [ "$redir" = "302" ] && ok "http خودکار به https منتقل می‌شود (${redir})" || warn "ریدایرکت http→https: ${redir}"
fi

echo
echo "==============================================="
if [ "$SSL_OK" -eq 1 ]; then
  echo "  ${c_ok}✅ دامنه با HTTPS وصل شد${c_off}"
  echo "     سایت      : https://${DOMAIN}"
  echo "     ژورنال    : https://${DOMAIN}/journal"
  echo "     پنل مدیریت: https://${DOMAIN}/admin"
else
  echo "  ${c_wr}دامنه وصل شد ولی HTTPS فعال نشد${c_off}"
  echo "     سایت: http://${DOMAIN}"
  echo "     بعد از درست شدن DNS دوباره اجرا کنید: bash $0 $DOMAIN"
fi
echo "==============================================="
echo "   نکته: بعد از تغییر آدرس، یک‌بار در مرورگر Ctrl+Shift+R بزنید."
echo
