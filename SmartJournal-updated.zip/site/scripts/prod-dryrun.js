#!/usr/bin/env node
'use strict';
/* اجرای آزمایشی واقعی در حالت production روی PostgreSQL واقعی */
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');

const PORT = 3777;
const B = `http://127.0.0.1:${PORT}`;
fs.mkdirSync('/tmp/prod-uploads', { recursive: true });

const env = {
  ...process.env,
  NODE_ENV: 'production',
  DB_ENGINE: 'postgres',
  DATABASE_URL: 'postgres://sjuser:sjpass2026@127.0.0.1:5432/smartjournal',
  PA_PG_SCHEMA: 'pa_journal',
  HOST: '127.0.0.1',
  PORT: String(PORT),
  ADMIN_NAME: 'مدیر اصلی',
  ADMIN_USERNAME: 'owner',
  ADMIN_MOBILE: '09121112233',
  ADMIN_PASSWORD: 'Str0ng!Pass#2026x',
  APP_ENCRYPTION_KEY: crypto.randomBytes(32).toString('hex'),
  BACKUP_ENCRYPTION_KEY: crypto.randomBytes(32).toString('hex'),
  METRICS_TOKEN: crypto.randomBytes(24).toString('hex'),
  WORKER_TOKEN: crypto.randomBytes(24).toString('hex'),
  PUBLIC_BASE_URL: 'https://smartjournal.ir',
  WEBAUTHN_RP_ID: 'smartjournal.ir',
  WEBAUTHN_ORIGIN: 'https://smartjournal.ir',
  SUPPORT_EMAIL: 'support@smartjournal.ir',
  SEED_DEMO_DATA: 'false',
  REDIS_ENABLED: 'false',
  QUEUE_ENABLED: 'false',
  STORAGE_BACKEND: 'local',
  UPLOAD_DIR: '/tmp/prod-uploads',
  LEGAL_OPERATOR_NAME: 'شرکت نمونه',
  LEGAL_OPERATOR_REGISTRATION: '1234567890',
  LEGAL_OPERATOR_ADDRESS: 'تهران، خیابان نمونه',
};

const child = spawn(process.execPath, ['server.js'], { cwd: __dirname + '/..', env, stdio: ['ignore', 'pipe', 'pipe'] });
let logs = '';
child.stdout.on('data', (c) => { logs += c; });
child.stderr.on('data', (c) => { logs += c; });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  let up = false;
  for (let i = 0; i < 120; i++) {
    if (child.exitCode !== null) break;
    try { if ((await fetch(B + '/api/health/live')).ok) { up = true; break; } } catch {}
    await sleep(250);
  }
  if (!up) {
    console.log('  ✗ سرور در حالت production بالا نیامد');
    console.log(logs.slice(-2500));
    child.kill('SIGKILL');
    process.exit(1);
  }

  const h = await (await fetch(B + '/api/health/ready')).json();
  console.log('  ✓ سرور در حالت production بالا آمد');
  console.log('    health:', h.status, '| engine:', h.dependencies.database.engine,
              '| schema:', h.dependencies.database.schema);

  for (const p of ['/', '/journal', '/admin', '/pricing', '/faq', '/sitemap.xml', '/robots.txt']) {
    const r = await fetch(B + p);
    console.log(`    GET ${p.padEnd(14)} ${r.status}`);
  }

  const a = await fetch(B + '/admin');
  const csp = a.headers.get('content-security-policy') || '';
  console.log('    admin frame-ancestors :', csp.match(/frame-ancestors [^;]*/)?.[0] || '(none)');
  console.log('    X-Frame-Options       :', a.headers.get('x-frame-options') || '(none)');
  console.log('    HSTS                  :', a.headers.get('strict-transport-security') || '(none)');

  const plans = await (await fetch(B + '/api/public/plans')).json();
  console.log('    public plans          :', plans.rows.length);

  // are the card/receipt tables present in the real Postgres schema?
  const { Client } = require(__dirname + '/../node_modules/pg');
  const c = new Client({ connectionString: env.DATABASE_URL });
  await c.connect();
  const t = await c.query(
    `SELECT table_name FROM information_schema.tables
      WHERE table_schema='pa_journal' AND table_name IN ('bank_cards','payment_receipts')
      ORDER BY table_name`);
  console.log('    card tables created   :', t.rows.map((r) => r.table_name).join(', ') || '(none)');
  const cnt = await c.query(`SELECT COUNT(*)::int n FROM pa_journal.plans`);
  console.log('    plans seeded in pg    :', cnt.rows[0].n);
  await c.end();

  child.kill('SIGTERM');
  await sleep(600);
  console.log('\n  اجرای آزمایشی production موفق بود.');
})().catch(async (e) => {
  console.error('  ✗', e.message);
  console.log(logs.slice(-2000));
  child.kill('SIGKILL');
  process.exit(1);
});
