/**
 * smoke-admin-mfa-modal.js — رگرسیون «کادر کد دومرحله‌ای دیده نمی‌شود»
 *
 * باگ واقعی روی سرور کاربر (۱۴۰۵/۰۵/۲۸):
 *   .login-screen  →  z-index:900
 *   .modal-layer   →  z-index:200
 * پس وقتی TOTP فعال بود و مودال «تأیید دومرحله‌ای» باز می‌شد، کارت ورود
 * دقیقاً روی آن می‌افتاد. المنت در DOM بود اما کاربر هیچ کادری نمی‌دید و
 * هیچ کلیکی هم به آن نمی‌رسید ⇒ «پنل باز نمی‌شود».
 *
 * این تست فقط وجود المنت را چک نمی‌کند؛ چک می‌کند که واقعاً روی صفحه
 * دیده شود (elementFromPoint) و کلیک‌پذیر باشد.
 *
 * اجرا:  BASE=http://127.0.0.1:4300 AU=owner AP='...' node scripts/smoke-admin-mfa-modal.js
 */
const puppeteer=require(process.env.PUPPETEER_PATH||'puppeteer');
const crypto=require('crypto');
const B=process.env.BASE||'http://127.0.0.1:4300';
const AU=process.env.AU||'owner',AP=process.env.AP||'Admin@12345';
const S=[];const ok=(n,c,x='')=>{S.push([c,n]);console.log((c?'  ✓':'  ✗')+' '+n+(x?'  — '+x:''))};
const wait=ms=>new Promise(r=>setTimeout(r,ms));

function b32decode(s){const A='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';let bits='';for(const ch of s.replace(/=+$/,'').toUpperCase()){const v=A.indexOf(ch);if(v<0)continue;bits+=v.toString(2).padStart(5,'0')}const out=[];for(let i=0;i+8<=bits.length;i+=8)out.push(parseInt(bits.slice(i,i+8),2));return Buffer.from(out)}
function totp(secret){const key=b32decode(secret),counter=Math.floor(Date.now()/1000/30),buf=Buffer.alloc(8);buf.writeUInt32BE(Math.floor(counter/2**32),0);buf.writeUInt32BE(counter>>>0,4);const h=crypto.createHmac('sha1',key).update(buf).digest(),o=h[h.length-1]&0xf;return String(((h[o]&0x7f)<<24|h[o+1]<<16|h[o+2]<<8|h[o+3])%1e6).padStart(6,'0')}

const visibility=p=>p.evaluate(()=>{
  const el=document.getElementById('adminMfaCode');
  if(!el)return{exists:false};
  const r=el.getBoundingClientRect(),cs=getComputedStyle(el);
  const hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);
  const btn=document.getElementById('verifyAdminTotp'),br=btn&&btn.getBoundingClientRect();
  const btnHit=br?document.elementFromPoint(br.left+br.width/2,br.top+br.height/2):null;
  return{exists:true,
    onScreen:r.width>10&&r.height>10&&r.top>=0&&r.bottom<=innerHeight,
    painted:!!hit&&(hit===el||el.contains(hit)),
    hitTag:hit?hit.tagName+(hit.id?'#'+hit.id:'')+(hit.className?'.'+String(hit.className).trim().split(/\s+/)[0]:''):null,
    buttonClickable:!!btnHit&&(btnHit===btn||btn.contains(btnHit)),
    focused:document.activeElement===el,
    display:cs.display,visibility:cs.visibility,
    modalZ:getComputedStyle(document.getElementById('modalLayer')).zIndex,
    loginZ:getComputedStyle(document.getElementById('loginScreen')).zIndex,
    loginInert:document.getElementById('loginScreen').inert===true};
});

(async()=>{
const br=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await br.newPage();await page.setViewport({width:1280,height:900});
const errs=[];page.on('pageerror',e=>errs.push(String(e).slice(0,200)));
let secret=null;
page.on('response',async r=>{if(/\/api\/admin\/mfa\/totp\/setup/.test(r.url())){try{const j=await r.json();secret=j.secret||null}catch{}}});

const login=async()=>{await page.evaluate(()=>{document.getElementById('loginMobile').value='';document.getElementById('loginPassword').value=''});
  await page.type('#loginMobile',AU);await page.type('#loginPassword',AP);await page.click('#loginSubmit');await wait(2600)};

console.log('\n── ۱) ورود اول و فعال‌سازی TOTP ──');
await page.goto(B+'/admin',{waitUntil:'networkidle2',timeout:60000});await wait(900);
await login();
const enrollVisible=await page.evaluate(()=>{const t=document.getElementById('modalTitle')?.textContent||'';return t.includes('امنیت دومرحله‌ای')});
ok('مودال اجباری ثبت TOTP بعد از ورود owner باز می‌شود',enrollVisible);
await page.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>/TOTP/.test(x.textContent));if(b)b.click()});
await wait(2200);
ok('کلید مخفی TOTP از سرور دریافت شد',!!secret,secret?'len '+secret.length:'');
if(!secret){console.log('  ✗ ادامه ممکن نیست');await br.close();process.exit(1)}
await page.evaluate(c=>{const i=document.getElementById('totpVerifyCode');i.value=c;i.dispatchEvent(new Event('input',{bubbles:true}))},totp(secret));
await page.evaluate(()=>{const b=[...document.querySelectorAll('#modalLayer button')].find(x=>/تأیید و فعال/.test(x.textContent));if(b)b.click()});
await wait(2200);
const recovery=await page.evaluate(()=>document.getElementById('modalLayer').innerText.includes('کدهای بازیابی'));
ok('TOTP فعال شد و کدهای بازیابی نمایش داده شد',recovery);

console.log('\n── ۲) خروج و ورود دوباره با TOTP فعال ──');
const cdp=await page.target().createCDPSession();await cdp.send('Network.clearBrowserCookies');
await page.goto(B+'/admin',{waitUntil:'networkidle2',timeout:60000});await wait(1200);
await login();
const v=await visibility(page);
ok('کادر کد در DOM ساخته می‌شود',!!v.exists);
ok('کادر کد داخل کادر دید کاربر است',!!v.onScreen);
ok('کادر کد واقعاً روی صفحه رسم می‌شود (زیر کارت ورود نمی‌ماند)',!!v.painted,'المنت رویی: '+v.hitTag);
ok('دکمه «تأیید کد» کلیک‌پذیر است',!!v.buttonClickable);
ok('z-index مودال بزرگ‌تر از صفحه ورود است',Number(v.modalZ)>Number(v.loginZ),`modal ${v.modalZ} > login ${v.loginZ}`);
ok('صفحه ورود در حالت inert است',!!v.loginInert);
ok('فوکوس خودکار روی کادر کد',!!v.focused);

console.log('\n── ۳) ورود واقعی با کد شش‌رقمی (تایپ انسانی + Enter) ──');
/* سرور کد تکراری همان بازه ۳۰ ثانیه‌ای را رد می‌کند (ضد بازپخش)؛
   پس تا شروع بازه بعدی صبر می‌کنیم. */
const restMs=(30-(Math.floor(Date.now()/1000)%30))*1000+1200;
console.log('  انتظار برای بازه بعدی TOTP: '+Math.round(restMs/1000)+' ثانیه');
await wait(restMs);
const toasts=[];page.on('console',()=>{});
await page.click('#adminMfaCode');
await page.keyboard.type(totp(secret),{delay:40});
await page.keyboard.press('Enter');
await wait(2600);
const inside=await page.evaluate(()=>({app:!document.getElementById('adminApp').hidden,login:!document.getElementById('loginScreen').hidden,modal:!document.getElementById('modalLayer').hidden,toast:document.getElementById('toastStack')?.innerText.replace(/\s+/g,' ').slice(0,120)||''}));
ok('با زدن Enter وارد پنل می‌شود',inside.app&&!inside.login&&!inside.modal,JSON.stringify(inside));

console.log('\n── ۴) ارقام فارسی در کادر کد ──');
const cdp2=await page.target().createCDPSession();await cdp2.send('Network.clearBrowserCookies');
await page.goto(B+'/admin',{waitUntil:'networkidle2',timeout:60000});await wait(1200);
await login();
await page.evaluate(()=>{const i=document.getElementById('adminMfaCode');i.value='۱۲۳ ۴۵۶';i.dispatchEvent(new Event('input',{bubbles:true}))});
const normalized=await page.evaluate(()=>document.getElementById('adminMfaCode').value);
ok('ارقام فارسی به انگلیسی تبدیل و فاصله حذف می‌شود',normalized==='123456',normalized);

console.log('\n── ۵) موبایل ۳۹۰×۸۴۴ ──');
const m=await br.newPage();await m.setViewport({width:390,height:844,isMobile:true,hasTouch:true});
await m.goto(B+'/admin',{waitUntil:'networkidle2',timeout:60000});await wait(900);
await m.type('#loginMobile',AU);await m.type('#loginPassword',AP);await m.click('#loginSubmit');await wait(2600);
const mv=await visibility(m);
ok('روی موبایل هم کادر کد دیده می‌شود',!!mv.painted,'المنت رویی: '+mv.hitTag);
ok('روی موبایل دکمه تأیید کلیک‌پذیر است',!!mv.buttonClickable);
await m.screenshot({path:'/tmp/mfa-mobile-after-fix.png'});

ok('هیچ خطای JS در صفحه رخ نداد',errs.length===0,errs.join(' | '));
await br.close();
const pass=S.filter(x=>x[0]).length;
console.log(`\n  ${pass}/${S.length} تست موفق`);
process.exit(pass===S.length?0:1);
})().catch(e=>{console.error('ERR',e);process.exit(1)});
