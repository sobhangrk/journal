#!/bin/bash
# ============================================================================
#   SmartJournal — «چرا سایت تغییر نکرده؟»
#
#   اجرا روی سرور:   bash /opt/smartjournal/scripts/why-not-updated.sh
#
#   در ۱۰ ثانیه می‌گوید مشکل کجاست:
#     الف) بسته اصلاً آپلود/نصب نشده  → فایل‌های سرور قدیمی‌اند
#     ب)  سرور به‌روز است ولی مرورگر شما نسخهٔ کهنه را از کش اجرا می‌کند
# ============================================================================
set -u
APP_DIR="${APP_DIR:-/opt/smartjournal}"
PORT="$(grep -oP '^PORT=\K[0-9]+' "$APP_DIR/.env" 2>/dev/null || true)"; PORT="${PORT:-3000}"
LOCAL="http://127.0.0.1:${PORT}"

g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'
okc=0; badc=0
say(){ echo; echo "${c}▶ $*${o}"; }
yes_(){ echo "  ${g}✓${o} $1"; okc=$((okc+1)); }
no_(){ echo "  ${r}✗${o} $1  ${y}$2${o}"; badc=$((badc+1)); }

echo "==============================================="
echo "  چرا سایت تغییر نکرده؟ — $(date '+%Y-%m-%d %H:%M')"
echo "==============================================="
[ -d "$APP_DIR" ] || { echo "${r}✗ $APP_DIR پیدا نشد${o}"; exit 1; }

# ---------------------------------------------- ۱) فایل‌های روی دیسک -------
say "۱) فایل‌های نصب‌شده روی سرور"

check(){ # check "توضیح" فایل الگو
  if grep -q -- "$3" "$APP_DIR/$2" 2>/dev/null; then yes_ "$1"; else no_ "$1" "(در فایل $2 نیست)"; fi
}
check "چیدمان تازهٔ موبایل (pa-dock)"        "public/journal-ux-runtime.js" "pa-dock-b"
check "حباب اشتراک بالای صفحه (pa-sub-top)"  "public/journal-card-payment.js" "pa-sub-top"
check "دکمهٔ باز/بستهٔ کشوی دسکتاپ"          "public/journal-ux-runtime.js" "pa-rail-toggle"
check "پولیش هدر موبایل صفحهٔ اصلی"           "public/landing-header-polish.js" "pa-landing-header-polish"
check "استخر هش bcrypt (ضد یخ‌زدگی ورود)"      "server.js"                    "bcrypt-pool"
check "ورود زمان‌ثابت (ضد افشای شماره‌ها)"     "server.js"                    "DUMMY_PASSWORD_HASH"
check "بسته‌بودن فایل دمویی mock-api"          "server.js"                    "mock-api.js"
check "دیده‌بان خودکار (watchdog)"              "scripts/watchdog.js"          "SMARTJOURNAL-WATCHDOG"
check "اسکیمای سازمان و وب‌سایت (سئو)"         "marketing-pages.js"           "organizationSchema"
check "کنار رفتن دکمه‌ها هنگام اسکرول"        "public/journal-ux-runtime.js" "pa-dock-away"
check "ایکون‌های برداری نوار پایین"           "public/journal-ux-runtime.js" "paintNavIcons"
check "کف خوانایی متن داخل برنامه"            "public/journal-ux-runtime.js" "readabilityPass"
check "Service Worker نسخه‌دار"               "public/service-worker.js"     "const BUILD"
check "تزریق مهر نسخه در سرور"                "server.js"                    "swBuildStamp"
if [ -f "$APP_DIR/shared-mobile-type.js" ]; then yes_ "کف اندازهٔ متن موبایل (فایل مشترک)"; else no_ "کف اندازهٔ متن موبایل (فایل مشترک)" "(shared-mobile-type.js نیست)"; fi

printf "\n  آخرین تغییر journal-ux-runtime.js : %s\n" \
  "$(date -r "$APP_DIR/public/journal-ux-runtime.js" '+%Y-%m-%d %H:%M' 2>/dev/null || echo '؟')"
printf "  آخرین تغییر server.js             : %s\n" \
  "$(date -r "$APP_DIR/server.js" '+%Y-%m-%d %H:%M' 2>/dev/null || echo '؟')"

# ------------------------------------------- ۲) چیزی که سرور واقعاً می‌دهد --
say "۲) چیزی که سرور همین الان به مرورگر می‌دهد"

SVC="$(systemctl is-active smartjournal 2>/dev/null | head -1 | tr -d '\r\n')"; SVC="${SVC:-؟}"
# وضعیت سرویس جدا شمرده می‌شود: اگر اپ جواب بدهد، نبودِ systemd (مثلاً در
# محیط تست) نباید نتیجه را «نصب نشده» اعلام کند.
SVC_BAD=0
if [ "$SVC" = "active" ]; then echo "  ${g}✓${o} سرویس روشن است"
else echo "  ${y}•${o} systemd: $SVC  (اگر خط بعدی سبز است، اپ در حال اجراست)"; SVC_BAD=1; fi

CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$LOCAL/journal")
if [ "$CODE" = "200" ]; then yes_ "اپلیکیشن روی پورت $PORT جواب می‌دهد"; else no_ "اپلیکیشن جواب نداد" "($CODE)"; fi

RUNTIME="$(curl -s --max-time 10 "$LOCAL/journal-ux-runtime.js" || true)"
if echo "$RUNTIME" | grep -q "pa-dock-away"; then yes_ "فایل JS که سرو می‌شود، نسخهٔ جدید است"
else no_ "فایل JS که سرو می‌شود هنوز قدیمی است" "(سرویس را restart کنید)"; fi

JSCC="$(curl -s -o /dev/null -D - --max-time 10 "$LOCAL/journal-ux-runtime.js" 2>/dev/null | grep -i '^cache-control' | tr -d '\r')"
if echo "$JSCC" | grep -qi 'no-cache'; then yes_ "هدر کش JS درست است  ($JSCC)"
else no_ "هدر کش JS هنوز قدیمی است" "($JSCC)"; fi

SW="$(curl -s --max-time 10 "$LOCAL/service-worker.js" || true)"
STAMP="$(echo "$SW" | grep -o "const BUILD = '[^']*'" | head -1 | sed "s/.*'\(.*\)'/\1/")"
if [ -n "$STAMP" ] && [ "$STAMP" != "dev" ]; then yes_ "مهر نسخهٔ Service Worker: $STAMP"
else no_ "مهر نسخهٔ Service Worker تزریق نشده" "(${STAMP:-خالی})"; fi

SWCC="$(curl -s -o /dev/null -D - --max-time 10 "$LOCAL/service-worker.js" 2>/dev/null | grep -i '^cache-control' | tr -d '\r')"
if echo "$SWCC" | grep -qi 'no-store'; then yes_ "فایل SW کش نمی‌شود  ($SWCC)"
else no_ "فایل SW ممکن است کش شود" "($SWCC)"; fi

HOMEP="$(curl -s --max-time 10 "$LOCAL/" || true)"
if echo "$HOMEP" | grep -q "pa-mobile-typography"; then yes_ "کف اندازهٔ متن در صفحهٔ اصلی تزریق می‌شود"
else no_ "کف اندازهٔ متن در صفحهٔ اصلی تزریق نمی‌شود" ""; fi
if echo "$HOMEP" | grep -q "landing-header-polish.js"; then yes_ "اسکریپت هدر موبایل در صفحهٔ اصلی تزریق می‌شود"
else no_ "اسکریپت هدر موبایل در صفحهٔ اصلی تزریق نمی‌شود" "(restart سرویس فراموش شده؟)"; fi

SM="$(curl -s --max-time 10 "$LOCAL/sitemap.xml" || true)"
if echo "$SM" | grep -q "<loc>" && echo "$SM" | grep -q "/guides/"; then yes_ "sitemap.xml سالم است و راهنماها را دارد"
else no_ "sitemap.xml مشکل دارد" "(بررسی کنید: $LOCAL/sitemap.xml)"; fi

# --------------------------------------------------- ۲-ب) نگهداری خودکار ---
if [ -f /etc/cron.d/smartjournal-watchdog ]; then yes_ "زمان‌بند دیده‌بان نصب است (/etc/cron.d)"
else no_ "زمان‌بند دیده‌بان نصب نیست" "(بزنید: bash $APP_DIR/scripts/install-watchdog.sh)"; fi

LIMITS=$(cd "$APP_DIR" && node -e "
const m=require('./db.js');const db=m.db||m;
try{const r=db.prepare(\"SELECT ip_limit_count FROM sms_settings WHERE id='default'\").get();
console.log(r?Number(r.ip_limit_count):0)}catch(e){console.log(0)}
" 2>/dev/null || echo 0)
if [ "${LIMITS:-0}" -gt 12 ] 2>/dev/null; then yes_ "سقف پیامک هر IP بالا رفته است ($LIMITS در ۱۰ دقیقه)"
else no_ "سقف پیامک هر IP هنوز پیش‌فرض است (۱۲)" "(بزنید: node $APP_DIR/scripts/tune-sms-limits.js)"; fi

CLEANUP=$(cd "$APP_DIR" && node -e "
const m=require('./db.js');const db=m.db||m;
try{const r=db.prepare(\"SELECT auto_cleanup FROM file_settings WHERE id='default'\").get();
console.log(r?Number(r.auto_cleanup):0)}catch(e){console.log(0)}
" 2>/dev/null || echo 0)
if [ "${CLEANUP:-0}" = "1" ]; then yes_ "پاکسازی خودکار تصاویر یتیم روشن است"
else no_ "پاکسازی خودکار تصاویر یتیم خاموش است" "(بزنید: node $APP_DIR/scripts/enable-auto-cleanup.js)"; fi

# --------------------------------------------------------- ۳) نتیجه -------
echo
echo "==============================================="
if [ "$badc" -eq 0 ]; then
  echo "${g}✅ سرور کاملاً به‌روز است ($okc از $((okc+badc)))${o}"
  [ "$SVC_BAD" -eq 1 ] && echo "  ${y}(فقط systemd گزارش «$SVC» داد ولی اپ جواب می‌دهد — مشکلی نیست)${o}"
  echo
  echo "  یعنی مشکل از ${y}کش مرورگر شماست${o}، نه از سرور."
  echo
  echo "  ${c}روی گوشی:${o}"
  echo "    سایت را ${y}دو بار${o} پشت سر هم باز کنید."
  echo "    بار اول نسخهٔ جدید نصب می‌شود، بار دوم اجرا می‌شود."
  echo "    (این را با مرورگر واقعی تست کرده‌ایم: دقیقاً ۲ بار.)"
  echo
  echo "  اگر باز هم عوض نشد:"
  echo "    کروم اندروید → ⋮ → Settings → Site settings → All sites"
  echo "                 → smarttradejournal.ir → Clear & reset"
  echo "    آیفون سافاری → تنظیمات → Safari → Advanced → Website Data"
  echo "                 → smarttradejournal.ir → Delete"
else
  echo "${r}✗ سرور به‌روز نیست — $badc مورد قرمز بالا${o}"
  echo
  echo "  یعنی بستهٔ جدید ${y}نصب نشده${o} (یا نصب نیمه‌کاره مانده)."
  echo "  این‌ها را به ترتیب بزنید:"
  echo
  echo "    ls -lh /root/*.zip"
  echo "    md5sum /root/SmartJournal-Platform.zip"
  echo "    cd /root && unzip -o -j SmartJournal-Platform.zip \"scripts/update.sh\" -d /root/ \\"
  echo "      && bash /root/update.sh /root/SmartJournal-Platform.zip"
  echo
  echo "  اگر فایل zip در /root نبود، یعنی هنوز از ویندوز آپلود نشده:"
  echo "    scp SmartJournal-Platform.zip root@185.204.197.128:/root/"
fi
echo "==============================================="
