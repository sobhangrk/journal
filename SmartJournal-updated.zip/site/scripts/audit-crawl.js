'use strict';
/* audit-crawl.js — پیمایش کل سایت عمومی: کد وضعیت، لینک‌های شکسته، منابع گم‌شده */
const BASE = process.env.BASE || 'http://127.0.0.1:3000';
const seen = new Map();
const queue = ['/'];
const external = new Set();
const problems = [];

function abs(href, from) {
  try {
    if (!href || /^(mailto:|tel:|javascript:|data:|#)/i.test(href)) return null;
    const u = new URL(href, BASE + from);
    if (u.origin !== new URL(BASE).origin) { external.add(u.href); return null; }
    return u.pathname + u.search;
  } catch { return null; }
}

(async () => {
  while (queue.length) {
    const path = queue.shift();
    if (seen.has(path)) continue;
    let res, body = '';
    try {
      res = await fetch(BASE + path, { redirect: 'manual' });
      const ct = res.headers.get('content-type') || '';
      if (ct.includes('text/html')) body = await res.text();
    } catch (e) {
      problems.push(['FETCH', path, e.message]);
      seen.set(path, 0);
      continue;
    }
    seen.set(path, res.status);
    if (res.status >= 400) problems.push(['STATUS ' + res.status, path, '']);
    if (!body) continue;

    const links = [...body.matchAll(/<a\b[^>]*href=["']([^"']+)["']/gi)].map(m => m[1]);
    const assets = [...body.matchAll(/(?:src|href)=["']([^"']+\.(?:js|css|png|jpg|jpeg|webp|svg|ico|woff2?|json|webmanifest))["']/gi)].map(m => m[1]);
    for (const href of links) {
      const p = abs(href, path);
      if (p && !seen.has(p) && !queue.includes(p)) queue.push(p);
    }
    for (const a of assets) {
      const p = abs(a, path);
      if (!p || seen.has(p)) continue;
      try {
        const r = await fetch(BASE + p, { method: 'GET' });
        seen.set(p, r.status);
        if (r.status >= 400) problems.push(['ASSET ' + r.status, p, 'در ' + path]);
      } catch (e) { problems.push(['ASSET ERR', p, e.message]); }
    }
    // HTML sanity
    const ids = [...body.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
    const dupes = ids.filter((v, i) => ids.indexOf(v) !== i);
    if (dupes.length) problems.push(['DUP-ID', path, [...new Set(dupes)].slice(0, 6).join(', ')]);
    if (body.includes('<html') && !/lang=/.test(body.slice(0, 500))) problems.push(['NO-LANG', path, '']);
    if (!/<title>[^<]{3,}<\/title>/.test(body)) problems.push(['NO-TITLE', path, '']);
    if (!/name=["']description["']/.test(body)) problems.push(['NO-DESC', path, '']);
    if (/undefined|\[object Object\]|NaN٪|NaN%/.test(body.replace(/undefined/g, m => m))) {
      const hit = body.match(/.{40}(\[object Object\]|NaN%|NaN٪).{40}/);
      if (hit) problems.push(['BAD-RENDER', path, hit[0].replace(/\s+/g, ' ')]);
    }
  }

  console.log('صفحات و منابع بررسی‌شده: ' + seen.size);
  const codes = {};
  for (const [, code] of seen) codes[code] = (codes[code] || 0) + 1;
  console.log('کدها:', JSON.stringify(codes));
  console.log('لینک‌های خارجی:', external.size);
  console.log('\n--- یافته‌ها (' + problems.length + ') ---');
  problems.forEach(p => console.log(p[0] + ' :: ' + p[1] + (p[2] ? ' :: ' + p[2] : '')));
  console.log('\n--- همهٔ مسیرها ---');
  [...seen.entries()].filter(([p]) => !/\.(js|css|png|jpg|jpeg|webp|svg|ico|woff2?|json|webmanifest)$/.test(p))
    .forEach(([p, c]) => console.log(c + ' ' + p));
})();
