#!/usr/bin/env node
'use strict';
/* ============================================================================
   audit-speed.js — «بعد از جداسازی باندل، وقت کجا می‌رود؟»

   صفحهٔ اصلی را روی پروفایل موبایل کند باز می‌کند و گزارش می‌دهد:
     • هر منبع چند بایت روی شبکه بود و چقدر طول کشید،
     • چند درصد از هر CSS/JS اصلاً اجرا/استفاده نشد (Chrome Coverage)،
     • کارهای طولانی روی رشتهٔ اصلی (long tasks) و مجموع زمان CPU،
     • عنصر LCP چیست و کِی رنگ می‌شود.

   اجرا:  node scripts/audit-speed.js [--url=/] [--net=slow|fast]
========================================================================== */
const puppeteer = require('puppeteer');

const arg = (name, fallback) => {
  const hit = process.argv.find(a => a.startsWith(`--${name}=`));
  return hit ? hit.split('=').slice(1).join('=') : fallback;
};
const BASE = process.env.BASE || 'http://127.0.0.1:3000';
const PATHNAME = arg('url', '/');
const PROFILES = {
  slow: { downloadThroughput: (1.6 * 1024 * 1024) / 8, uploadThroughput: (750 * 1024) / 8, latency: 150, cpu: 4 },
  fast: { downloadThroughput: (9 * 1024 * 1024) / 8, uploadThroughput: (2 * 1024 * 1024) / 8, latency: 40, cpu: 2 },
};
const NET = PROFILES[arg('net', 'slow')] || PROFILES.slow;
const kb = n => (n / 1024).toFixed(1) + 'KB';

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const client = await page.createCDPSession();
  await client.send('Network.enable');
  await client.send('Network.emulateNetworkConditions', { offline: false, ...NET });
  await client.send('Emulation.setCPUThrottlingRate', { rate: NET.cpu });
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await page.setCacheEnabled(false);

  const byId = new Map();
  client.on('Network.requestWillBeSent', e => byId.set(e.requestId, { url: e.request.url, start: e.timestamp, type: e.type }));
  client.on('Network.responseReceived', e => { const r = byId.get(e.requestId); if (r) { r.status = e.response.status; r.mime = e.response.mimeType; r.type = e.type || r.type; } });
  client.on('Network.loadingFinished', e => { const r = byId.get(e.requestId); if (r) { r.bytes = e.encodedDataLength; r.end = e.timestamp; } });

  await Promise.all([page.coverage.startJSCoverage({ resetOnNavigation: false }), page.coverage.startCSSCoverage({ resetOnNavigation: false })]);
  await page.evaluateOnNewDocument(() => {
    window.__longTasks = [];
    try { new PerformanceObserver(l => l.getEntries().forEach(e => window.__longTasks.push([Math.round(e.startTime), Math.round(e.duration)]))).observe({ type: 'longtask', buffered: true }); } catch { }
  });

  await page.goto(BASE + PATHNAME, { waitUntil: 'load', timeout: 180000 });
  await new Promise(r => setTimeout(r, 4000));

  const vitals = await page.evaluate(() => new Promise(resolve => {
    let lcp = null, lcpEl = '', cls = 0;
    try {
      new PerformanceObserver(list => {
        const e = list.getEntries()[list.getEntries().length - 1];
        lcp = Math.round(e.startTime);
        lcpEl = e.element ? (e.element.tagName.toLowerCase() + (e.element.id ? '#' + e.element.id : '') + (e.element.className ? '.' + String(e.element.className).split(' ')[0] : '')) : e.url || '';
      }).observe({ type: 'largest-contentful-paint', buffered: true });
      new PerformanceObserver(list => list.getEntries().forEach(e => { if (!e.hadRecentInput) cls += e.value; })).observe({ type: 'layout-shift', buffered: true });
    } catch { }
    setTimeout(() => {
      const nav = performance.getEntriesByType('navigation')[0] || {};
      const fcp = performance.getEntriesByName('first-contentful-paint')[0];
      resolve({
        ttfb: Math.round(nav.responseStart || 0), htmlDone: Math.round(nav.responseEnd || 0),
        fcp: fcp ? Math.round(fcp.startTime) : null, lcp, lcpEl, cls: Number(cls.toFixed(3)),
        dcl: Math.round(nav.domContentLoadedEventEnd || 0), load: Math.round(nav.loadEventEnd || 0),
        longTasks: window.__longTasks || [],
      });
    }, 600);
  }));

  const [js, css] = await Promise.all([page.coverage.stopJSCoverage(), page.coverage.stopCSSCoverage()]);
  const coverage = [...js, ...css].map(entry => {
    const used = entry.ranges.reduce((sum, r) => sum + r.end - r.start, 0);
    return { url: entry.url, total: entry.text.length, used, unused: entry.text.length - used };
  }).filter(c => c.total > 2000).sort((a, b) => b.unused - a.unused);

  const requests = [...byId.values()].filter(r => r.bytes != null)
    .map(r => ({ url: r.url.replace(BASE, ''), type: r.type, status: r.status, bytes: r.bytes, ms: Math.round((r.end - r.start) * 1000) }))
    .sort((a, b) => b.bytes - a.bytes);
  const total = requests.reduce((s, r) => s + r.bytes, 0);
  const byType = {};
  for (const r of requests) byType[r.type] = (byType[r.type] || 0) + r.bytes;

  console.log(`\n══ ${BASE}${PATHNAME} — موبایل ${arg('net', 'slow')} (CPU ${NET.cpu}×) ══\n`);
  console.log('  TTFB %sms · HTML %sms · FCP %sms · LCP %sms (%s) · CLS %s · DOMReady %sms · Load %sms',
    vitals.ttfb, vitals.htmlDone, vitals.fcp, vitals.lcp, vitals.lcpEl, vitals.cls, vitals.dcl, vitals.load);
  const busy = (vitals.longTasks || []).reduce((s, t) => s + t[1], 0);
  console.log('  Long tasks: %d عدد · مجموع %dms · بلندترین %dms',
    vitals.longTasks.length, busy, vitals.longTasks.reduce((m, t) => Math.max(m, t[1]), 0));

  console.log(`\n  ── ${requests.length} درخواست · مجموع ${kb(total)} ──`);
  for (const [type, bytes] of Object.entries(byType).sort((a, b) => b[1] - a[1])) console.log('   %s %s', String(type).padEnd(12), kb(bytes));
  console.log('\n  ── سنگین‌ترین منابع ──');
  for (const r of requests.slice(0, 16)) console.log('   %s %s %s', kb(r.bytes).padStart(9), String(r.ms + 'ms').padStart(7), r.url.slice(0, 70));

  console.log('\n  ── کدِ دانلودشده ولی استفاده‌نشده (Coverage) ──');
  for (const c of coverage.slice(0, 14)) {
    console.log('   %s بلااستفاده از %s  (%s٪)  %s', kb(c.unused).padStart(9), kb(c.total).padStart(9),
      String(Math.round(c.unused / c.total * 100)).padStart(3), c.url.replace(BASE, '').slice(0, 62) || '(inline)');
  }
  const unusedTotal = coverage.reduce((s, c) => s + c.unused, 0);
  console.log('\n   مجموع بلااستفاده: %s\n', kb(unusedTotal));

  await browser.close();
})();
