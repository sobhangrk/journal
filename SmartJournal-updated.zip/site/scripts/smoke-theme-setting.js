/**
 * smoke-theme-setting.js — کارت «ظاهر برنامه» در تنظیمات
 *
 * باگ اصلی: کارت فقط رویداد pa-theme-set را dispatch می‌کرد و هیچ شنونده‌ای
 * در کل پروژه برایش نبود؛ pa-theme-change هم هرگز فرستاده نمی‌شد. نتیجه:
 * کلیک روی «روشن» هیچ کاری نمی‌کرد، انتخاب ذخیره نمی‌شد، تیک فعال جابه‌جا
 * نمی‌شد و حالت «خودکار» اصلاً وجود خارجی نداشت.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const w = ms => new Promise(r => setTimeout(r, ms));

function client() {
  const jar = [];
  return {
    jar,
    async post(p, b) {
      const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(b) });
      (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
      return { status: r.status, data: await r.json().catch(() => ({})) };
    },
  };
}

const isLight = () => document.documentElement.classList.contains('pa-light');

(async () => {
  const a = client();
  let s2 = { status: 0 };
  for (let attempt = 0; attempt < 5 && s2.status !== 201; attempt++) {
    if (attempt) await w(1500);
    const mobile = '09' + String(Math.floor(1e9 + Math.random() * 8.9e9)).slice(0, 9);
    const s = await a.post('/api/auth/signup', { name: 'کاربر پوسته', mobile, password: 'Thm@11111111', remember: true,
      acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
    if (!s.data.challengeToken) continue;
    s2 = await a.post('/api/auth/signup/verify', { challengeToken: s.data.challengeToken, code: s.data.devCode });
  }
  ok('حساب آزمایشی ساخته شد', s2.status === 201, 'status=' + s2.status);
  if (s2.status !== 201) { console.log('\n  سرور اجازهٔ ثبت‌نام نداد؛ آزمون متوقف شد.\n'); process.exit(1); }

  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  const page = await browser.newPage();
  await page.setCacheEnabled(false);
  await page.evaluateOnNewDocument(() => {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.getRegistrations?.().then(rs => rs.forEach(r => r.unregister()));
      if (window.caches) caches.keys().then(ks => ks.forEach(k => caches.delete(k)));
    }
  });
  await page.setViewport({ width: 1440, height: 1000 });
  await page.setCookie(...a.jar.map(c => { const [n, ...v] = c.split('='); return { name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }; }));
  await page.goto(B + '/journal', { waitUntil: 'networkidle2' });
  await page.waitForSelector('#root');
  await w(3000);

  // ---- ۱) موتور پوسته اصلاً وجود دارد؟
  ok('API پوستهٔ سراسری (window.PATheme) نصب شده', await page.evaluate(() => !!(window.PATheme && window.PATheme.set)));

  // ---- ۲) رفتن به تنظیمات و پیدا کردن کارت
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button,a')].find(e => /تنظیمات/.test(e.textContent || ''));
    if (b) b.click();
  });
  await w(2500);
  await page.evaluate(() => document.getElementById('pa-set-appearance')?.scrollIntoView());
  await w(600);
  const opts = await page.$$eval('.pa-theme-opt', els => els.map(e => e.className));
  ok('کارت «ظاهر برنامه» با هر سه گزینه رندر شده', opts.length === 3, opts.length + ' گزینه');

  // ---- ۳) کلیک روی «روشن» واقعاً پوسته را عوض می‌کند
  await page.evaluate(() => document.querySelector('.pa-theme-opt.light')?.click());
  await w(900);
  let st = await page.evaluate(() => ({
    light: document.documentElement.classList.contains('pa-light'),
    stored: localStorage.getItem('pa-theme'),
    active: document.querySelector('.pa-theme-opt.light')?.classList.contains('active'),
    bg: getComputedStyle(document.body).backgroundColor,
  }));
  ok('کلیک روی «روشن» پوسته را روشن می‌کند', st.light, 'bg=' + st.bg);
  ok('انتخاب «روشن» ذخیره می‌شود', st.stored === 'light', 'stored=' + st.stored);
  ok('تیک «فعال» روی گزینهٔ روشن می‌نشیند', !!st.active);

  // ---- ۴) پس از رفرش هم باقی می‌ماند (و قبل از رنگ‌آمیزی، بدون پرش)
  await page.reload({ waitUntil: 'networkidle2' });
  await w(2500);
  ok('بعد از رفرش، پوستهٔ روشن باقی می‌ماند', await page.evaluate(isLight));

  // ---- ۵) برگشت به تیره
  await page.evaluate(() => window.PATheme.set('dark'));
  await w(600);
  st = await page.evaluate(() => ({ light: document.documentElement.classList.contains('pa-light'),
    dark: document.documentElement.classList.contains('pa-dark'), stored: localStorage.getItem('pa-theme') }));
  ok('بازگشت به «تیره» کار می‌کند', !st.light && st.dark, 'stored=' + st.stored);

  // ---- ۶) حالت «خودکار» از پوستهٔ سیستم پیروی می‌کند
  await page.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: 'light' }]);
  await page.evaluate(() => window.PATheme.set('auto'));
  await w(700);
  ok('«خودکار» با سیستمِ روشن، روشن می‌شود', await page.evaluate(isLight));
  await page.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: 'dark' }]);
  await w(700);
  ok('«خودکار» با تغییر زندهٔ سیستم به تیره برمی‌گردد', !(await page.evaluate(isLight)));
  await page.emulateMediaFeatures([]);

  // ---- ۷) میان‌بر Ctrl+J که در متن همان کارت وعده داده شده
  await page.evaluate(() => window.PATheme.set('dark'));
  await w(400);
  await page.keyboard.down('Control'); await page.keyboard.press('KeyJ'); await page.keyboard.up('Control');
  await w(600);
  ok('میان‌بر Ctrl+J پوسته را عوض می‌کند', await page.evaluate(isLight));

  // ---- ۸) خوانایی واقعی در پوستهٔ روشن: متن روی زمینهٔ روشن گم نشود
  await page.evaluate(() => window.PATheme.set('light'));
  await w(900);
  const contrast = await page.evaluate(() => {
    const rgba = c => { const m = c.match(/[\d.]+/g); return m ? { r: +m[0], g: +m[1], b: +m[2], a: m[3] === undefined ? 1 : +m[3] } : null; };
    const lum = c => { const f = [c.r, c.g, c.b].map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4) });
      return .2126 * f[0] + .7152 * f[1] + .0722 * f[2]; };
    // ترکیب لایه‌های نیمه‌شفاف روی هم؛ بدون این کار، rgba(...,.09) روی سفید
    // اشتباهاً «تیره» خوانده می‌شد و آزمون هشدار الکی می‌داد.
    const over = (fg, bg) => ({ r: fg.r * fg.a + bg.r * (1 - fg.a), g: fg.g * fg.a + bg.g * (1 - fg.a), b: fg.b * fg.a + bg.b * (1 - fg.a), a: 1 });
    const bad = [];
    document.querySelectorAll('*').forEach(e => {
      const b = e.getBoundingClientRect();
      if (b.width < 30 || b.height < 10) return;
      const own = [...e.childNodes].filter(n => n.nodeType === 3 && n.textContent.trim()).length;
      if (!own) return;
      const cs = getComputedStyle(e);
      if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity < .3) return;
      const layers = [];
      let x = e, grad = false;
      while (x) {
        const c = getComputedStyle(x);
        if (c.backgroundImage && c.backgroundImage !== 'none') { grad = true; break; }
        const p = rgba(c.backgroundColor);
        if (p && p.a > 0) { layers.push(p); if (p.a === 1) break; }
        x = x.parentElement;
      }
      if (grad) return; // زمینهٔ گرادیانی را نمی‌شود مطمئن سنجید
      let bg = { r: 255, g: 255, b: 255, a: 1 };
      for (let i = layers.length - 1; i >= 0; i--) bg = over(layers[i], bg);
      const fg0 = rgba(cs.color); if (!fg0) return;
      const fg = over(fg0, bg);
      const l1 = lum(fg), l2 = lum(bg);
      const cr = (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05);
      if (cr < 2.5) bad.push((typeof e.className === 'string' && e.className ? e.className : e.tagName).slice(0, 40) + ' cr=' + cr.toFixed(2));
    });
    return [...new Set(bad)].slice(0, 8);
  });
  ok('در پوستهٔ روشن متنِ کم‌کنتراست/نامرئی نداریم', contrast.length === 0, contrast.join(' | ') || 'تمیز');

  // ---- ۹) هیچ بلوک تیرهٔ جامانده‌ای وسط پوستهٔ روشن نباشد
  const darkBoxes = await page.evaluate(() => {
    const dark = c => { const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/); if (!m) return false;
      if (m[4] !== undefined && +m[4] < .5) return false; return (+m[1] + +m[2] + +m[3]) / 3 < 90; };
    const out = [];
    document.querySelectorAll('.pa-set-card, .pa-set-card *').forEach(e => {
      const b = e.getBoundingClientRect();
      if (b.width < 60 || b.height < 24) return;
      const cs = getComputedStyle(e);
      if (dark(cs.backgroundColor)) out.push((typeof e.className === 'string' ? e.className : e.tagName).slice(0, 40));
    });
    return [...new Set(out)].slice(0, 8);
  });
  ok('در تنظیماتِ روشن، بلوک تیرهٔ جامانده نیست', darkBoxes.length === 0, darkBoxes.join(' | ') || 'تمیز');

  await browser.close();
  const pass = R.filter(r => r[0]).length;
  console.log('\n  ' + pass + ' قبول · ' + (R.length - pass) + ' رد\n');
  process.exit(pass === R.length ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
