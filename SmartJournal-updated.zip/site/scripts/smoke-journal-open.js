/**
 * smoke-journal-open.js — رگرسیون «صفحه ژورنال باز نمی‌شود»
 *
 * سه export اصلی سایت مستقل بودند و با location.href بین فایل‌های
 * SmartJournal-login.html / SmartJournal-journal.html جابه‌جا می‌شدند.
 * روی سرور واقعی این فایل‌ها وجود ندارند ⇒ کاربر بعد از کلیک روی
 * «ورود به ژورنال» یا بعد از ورود موفق، صفحه ۴۰۴ می‌دید.
 *
 * اجرا:  PUPPETEER_PATH=/tmp/node_modules/puppeteer node scripts/smoke-journal-open.js
 */
const puppeteer=require(process.env.PUPPETEER_PATH||'puppeteer');
const B=process.env.SMOKE_BASE_URL||process.env.BASE||'http://127.0.0.1:3000';
const S=[];const ok=(n,c,x='')=>{S.push([c,n,x]);console.log((c?'  ✓':'  ✗')+' '+n+(x?'  — '+x:''))};

async function state(p){return p.evaluate(()=>{
  const vis=el=>{if(!el)return false;const s=getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&el.getClientRects().length>0};
  return {url:location.pathname,cls:document.documentElement.className,
    landing:vis(document.getElementById('pa-landing')),
    auth:vis(document.getElementById('pa-auth')),
    app:vis(document.querySelector('#root .pa-app'))||vis(document.querySelector('#root>*')),
    text:(document.body.innerText||'').trim().slice(0,120).replace(/\n/g,' / ')};});}

async function clickText(p,sel,rx){
  const h=await p.evaluateHandle((sel,rxs)=>{const rx=new RegExp(rxs);
    return [...document.querySelectorAll(sel)].filter(e=>e.getClientRects().length).find(e=>rx.test((e.innerText||e.value||'').trim()))||null;},sel,rx.source);
  const el=h.asElement(); if(!el) return false;
  await el.evaluate(e=>e.scrollIntoView({block:'center'}));
  await new Promise(r=>setTimeout(r,500));
  const b=await el.boundingBox(); if(!b) return false;
  await p.mouse.click(b.x+b.width/2,b.y+b.height/2);
  return true;
}

(async()=>{
const br=await puppeteer.launch({headless:'new',args:['--no-sandbox','--disable-dev-shm-usage']});
const p=await br.newPage(); await p.setViewport({width:1440,height:900});
const errs=[],four=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,200)));
let signupBody=null;
p.on('response',async r=>{const u=r.url();if(r.status()>=400&&!/\/api\/journal\/storage\//.test(u))four.push(r.status()+' '+u.replace(B,''));
 if(/\/api\/auth\/signup$/.test(u)){try{signupBody=await r.json()}catch(e){}}});

console.log('\n── ۱) لندینگ → دکمه «ورود به ژورنال» ──');
await p.goto(B+'/',{waitUntil:'networkidle2',timeout:60000});
await new Promise(r=>setTimeout(r,3500));
let s=await state(p); ok('لندینگ نمایش داده می‌شود',s.landing);
await clickText(p,'#pa-landing button,#pa-landing a',/ورود به ژورنال/);
await new Promise(r=>setTimeout(r,2500));
s=await state(p);
ok('بدون رفتن به ۴۰۴',!/SmartJournal-.*\.html/.test(s.url),s.url);
ok('پنل ورود باز شد',s.auth,'url='+s.url+' landing='+s.landing);

console.log('\n── ۲) دکمه «شروع ژورنال» در هیرو ──');
await p.goto(B+'/',{waitUntil:'networkidle2',timeout:60000});
await new Promise(r=>setTimeout(r,3500));
await clickText(p,'#pa-landing button',/شروع ژورنال/);
await new Promise(r=>setTimeout(r,2500));
s=await state(p); ok('پنل ورود باز شد',s.auth,'url='+s.url);

console.log('\n── ۳) ثبت‌نام واقعی از داخل فرم و ورود به ژورنال ──');
const mobile='0989'+String(Date.now()).slice(-7);
await p.click('[data-auth-mode="signup"]').catch(()=>{});
await new Promise(r=>setTimeout(r,900));
await p.type('#pa-a-name','کاربر آزمایشی',{delay:8});
await p.type('#pa-a-mobile',mobile,{delay:8});
await p.type('#pa-a-password','Test@12345',{delay:8});
await p.type('#pa-a-confirm','Test@12345',{delay:8}).catch(()=>{});
// legal checkboxes
await p.evaluate(()=>{['pa-accept-terms','pa-accept-privacy','pa-accept-disclaimer'].forEach(id=>{const c=document.getElementById(id);if(c&&!c.checked)c.click()})});
await new Promise(r=>setTimeout(r,300));
await clickText(p,'#pa-auth button',/ادامه و تأیید|ورود و همگام/);
await new Promise(r=>setTimeout(r,3000));
const otpVisible=await p.evaluate(()=>!!document.getElementById('pa-otp-code'));
ok('مرحله کد پیامک نمایش داده شد',otpVisible,await p.evaluate(()=>{const e=document.getElementById('pa-a-error');return e?e.innerText.trim().slice(0,120):''}));
let devCode=signupBody&&(signupBody.devCode||signupBody.developmentCode||'');
console.log('     کد توسعه:',devCode);
if(devCode){
  await p.type('#pa-otp-code',devCode,{delay:20});
  await clickText(p,'#pa-auth button',/تأیید کد و ادامه/);
  await new Promise(r=>setTimeout(r,9000));
  s=await state(p);
  ok('بعد از ورود ۴۰۴ نشد',!/SmartJournal-.*\.html/.test(s.url),'url='+s.url);
  ok('اپ ژورنال باز شد',s.app,'url='+s.url+' | '+s.text);
  await p.screenshot({path:'/tmp/after-login.png'});
}

console.log('\n── ۴) رفرش روی /journal با نشست فعال ──');
await p.goto(B+'/journal',{waitUntil:'networkidle2',timeout:60000});
await new Promise(r=>setTimeout(r,6000));
s=await state(p); ok('ژورنال مستقیم باز می‌شود',s.app,s.text.slice(0,80));

console.log('\n── ۵) خطاهای JS و ۴۰۴ ──');
ok('بدون خطای JS',errs.length===0,errs.join(' | '));
ok('بدون درخواست ۴۰۴/خطا',four.filter(x=>!/401 \/api\/auth\/me/.test(x)).length===0,[...new Set(four)].join(' | '));

const bad=S.filter(x=>!x[0]).length;
console.log(`\n${S.length-bad}/${S.length} تست موفق`);
await br.close(); process.exit(bad?1:0);
})();
