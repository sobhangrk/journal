#!/usr/bin/env node
'use strict';
/* آزمون مرورگری جداسازی: صفحهٔ اصلی نباید باندل را بگیرد، ورود به ژورنال
   باید بدون بارگذاری دوبارهٔ صفحه کار کند و /journal باید برنامه را بالا بیاورد. */
const puppeteer = require('puppeteer');
const BASE = process.env.BASE || 'http://127.0.0.1:3000';

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const report = {};
  try {
    // ---------- صفحهٔ اصلی ----------
    let page = await browser.newPage();
    await page.setCacheEnabled(false);
    const requests = [], errors = [];
    page.on('request', r => requests.push(r.url()));
    page.on('pageerror', e => errors.push(String(e.message)));
    page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
    await page.goto(BASE + '/', { waitUntil: 'networkidle2' });
    const html = await page.content();
    report.landing = {
      transferJs: requests.filter(u => /journal-app\./.test(u)).length,
      landingVisible: await page.$eval('#pa-landing', el => !el.hidden && getComputedStyle(el).display !== 'none'),
      heroText: (await page.$eval('#pa-landing', el => el.innerText.trim().slice(0, 60))),
      errors: errors.slice(0, 5),
      domNodes: await page.evaluate(() => document.querySelectorAll('*').length),
      hasLoader: html.includes('pa-journal-loader'),
    };

    // ---------- ورود به ژورنال از روی لندینگ ----------
    await page.click('[data-pa-enter]');
    await new Promise(r => setTimeout(r, 5000));
    report.enter = {
      appChunkRequested: requests.filter(u => /journal-app\./.test(u)).length,
      url: page.url(),
      authVisible: await page.evaluate(() => {
        const el = document.querySelector('#pa-auth');
        return !!el && !el.hidden && getComputedStyle(el).display !== 'none';
      }),
      appLoaded: await page.evaluate(() => document.documentElement.classList.contains('pa-app-loaded')),
      errors: errors.slice(0, 5),
    };
    await page.close();

    // ---------- /journal مستقیم ----------
    page = await browser.newPage();
    const jsErrors = [];
    page.on('pageerror', e => jsErrors.push(String(e.message)));
    page.on('console', m => { if (m.type() === 'error') jsErrors.push('console: ' + m.text()); });
    await page.goto(BASE + '/journal', { waitUntil: 'networkidle2' });
    await new Promise(r => setTimeout(r, 3000));
    report.journal = {
      appLoaded: await page.evaluate(() => document.documentElement.classList.contains('pa-app-loaded')),
      rootChildren: await page.evaluate(() => document.getElementById('root')?.children.length ?? -1),
      authVisible: await page.evaluate(() => {
        const el = document.querySelector('#pa-auth');
        return !!el && !el.hidden && getComputedStyle(el).display !== 'none';
      }),
      globals: await page.evaluate(() => ({
        PAAuth: typeof window.PAAuth, PACloudStorage: typeof window.PACloudStorage, PAJournal: typeof window.PAJournal,
      })),
      errors: jsErrors.slice(0, 8),
    };
    await page.close();
  } finally {
    await browser.close();
  }
  console.log(JSON.stringify(report, null, 2));
})();
