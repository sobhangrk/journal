#!/usr/bin/env node
/* ==========================================================================
   enable-auto-cleanup.js — روشن کردن پاکسازی خودکار تصاویر یتیم
   --------------------------------------------------------------------------
   کاربر عکس معامله را آپلود می‌کند ولی فرم را رها می‌کند → فایل روی دیسک
   می‌ماند و هیچ معامله‌ای به آن وصل نیست. سرور از قبل موتور پاکسازی دارد
   (هر ۶ ساعت) ولی کلید آن خاموش است. این اسکریپت آن را روشن می‌کند:
   فایل‌های یتیمِ قدیمی‌تر از ۱۴ روز حذف می‌شوند و حجم حساب هم اصلاح می‌شود.
   ========================================================================== */
'use strict';
const path = require('path');
const APP_DIR = process.env.APP_DIR || '/opt/smartjournal';
const Database = require(path.join(APP_DIR, 'node_modules', 'better-sqlite3'));
const db = new Database(process.env.DATABASE_PATH || path.join(APP_DIR, 'data', 'admin.db'));

const row = db.prepare("SELECT * FROM file_settings WHERE id='default'").get();
if (!row) { console.log('✗ تنظیمات فایل پیدا نشد.'); process.exit(1); }

if (Number(row.auto_cleanup) === 1) {
  console.log('• پاکسازی خودکار از قبل روشن است ✓ (نگهداری فایل‌های یتیم تا ' + Number(row.orphan_retention_days || 14) + ' روز)');
  process.exit(0);
}

db.prepare("UPDATE file_settings SET auto_cleanup=1,orphan_retention_days=?,updated_at=? WHERE id='default'")
  .run(Number(process.env.ORPHAN_RETENTION_DAYS || 14), new Date().toISOString());
console.log('✅ پاکسازی خودکار روشن شد: هر ۶ ساعت، تصاویر یتیمِ قدیمی‌تر از ۱۴ روز حذف می‌شوند.');
console.log('   (تغییر فقط در سرور بعدی اجرا می‌شود؛ از پنل مدیریت هم قابل خاموش کردن است)');
