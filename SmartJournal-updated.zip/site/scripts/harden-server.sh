#!/bin/bash
# ============================================================================
#   harden-server.sh — سفت‌کاری امنیتی سرور (امن برای ورود با رمز)
#   اجرا روی سرور:  bash /opt/smartjournal/scripts/harden-server.sh
#
#   چه می‌کند:
#     ۱) fail2ban — بعد از ۵ تلاش ناموفق SSH، مهاجم ۱ ساعت بسته می‌شود
#     ۲) UFW — فقط پورت‌های ۲۲ (SSH)، ۸۰ و ۴۴۳ (وب) باز می‌مانند
#     ۳) سفت‌کاری امنِ sshd — بدون بستنِ ورود با رمز، پس قفل نمی‌شوید!
#
#   آگاهانه انجام نمی‌شود (تا شما را بیرون قفل نکند):
#     - غیرفعال کردن کامل ورود با رمز (اول باید کلید SSH بسازید؛ راهنمایش
#       پایینِ خروجی چاپ می‌شود)
#     - بستن ورود root
# ============================================================================
set -u
g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'
BACKUP_DIR="/root/server-hardening-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "${c}▶ ۱) بکاپ از تنظیمات فعلی${o}"
[ -f /etc/ssh/sshd_config ] && cp -a /etc/ssh/sshd_config "$BACKUP_DIR/sshd_config"
echo "  بکاپ در: $BACKUP_DIR"

echo
echo "${c}▶ ۲) نصب و فعال‌سازی fail2ban${o}"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq fail2ban ufw >/dev/null 2>&1
mkdir -p /etc/fail2ban
cat > /etc/fail2ban/jail.local <<'EOF'
# SmartJournal — پیکربندی fail2ban
[DEFAULT]
bantime = 1h
findtime = 10m
maxretry = 5
backend = systemd

[sshd]
enabled = true
EOF
systemctl enable fail2ban >/dev/null 2>&1
systemctl restart fail2ban >/dev/null 2>&1
if systemctl is-active --quiet fail2ban; then
  echo "  ${g}✓ fail2ban روشن است${o} (۵ تلاش اشتباه SSH = بستن ۱ ساعتهٔ مهاجم)"
else
  echo "  ${r}✗ fail2ban روشن نشد — خروجی systemctl status fail2ban را ببینید${o}"
fi

echo
echo "${c}▶ ۳) دیوار آتش UFW — فقط ۲۲، ۸۰ و ۴۴۳${o}"
ufw allow 22/tcp  >/dev/null 2>&1
ufw allow 80/tcp  >/dev/null 2>&1
ufw allow 443/tcp >/dev/null 2>&1
ufw default deny incoming  >/dev/null 2>&1
ufw default allow outgoing >/dev/null 2>&1
if ufw status 2>/dev/null | grep -q 'Status: active'; then
  ufw reload >/dev/null 2>&1
else
  ufw --force enable >/dev/null 2>&1
fi
echo "  ${g}✓ UFW روشن است${o}:"
ufw status | sed 's/^/    /'

echo
echo "${c}▶ ۴) سفت‌کاری امن sshd (ورود با رمز باز می‌ماند)${o}"
SSHD="/etc/ssh/sshd_config"
apply_sshd() { # کلید  مقدار
  local key="$1" value="$2"
  if grep -qE "^\s*${key}\s" "$SSHD"; then
    sed -i -E "s|^\s*${key}\s.*|${key} ${value}|" "$SSHD"
  else
    echo "${key} ${value}" >> "$SSHD"
  fi
}
apply_sshd "MaxAuthTries" "3"
apply_sshd "LoginGraceTime" "60"
apply_sshd "PermitEmptyPasswords" "no"
apply_sshd "X11Forwarding" "no"
apply_sshd "AllowAgentForwarding" "no"
apply_sshd "ClientAliveInterval" "300"
apply_sshd "ClientAliveCountMax" "3"
if sshd -t 2>/dev/null; then
  systemctl restart ssh sshd >/dev/null 2>&1 || service ssh restart >/dev/null 2>&1
  echo "  ${g}✓ تنظیمات SSH اعمال شد${o}: حداکثر ۳ تلاش رمز در هر اتصال، قطع اتصال‌های بیکار، بدون X11"
else
  cp -a "$BACKUP_DIR/sshd_config" "$SSHD"
  echo "  ${r}✗ پیکربندی جدید اشتباه بود — نسخهٔ قبلی برگشت و چیزی تغییر نکرد.${o}"
fi

echo
echo "====================================================="
echo "${g}✅ سفت‌کاری انجام شد.${o}"
echo
echo "${y}پیشنهاد بعدی (اختیاری ولی قوی‌تر): کلید SSH به‌جای رمز${o}"
echo "  روی ویندوز (cmd):"
echo "    ssh-keygen -t ed25519"
echo "    type %USERPROFILE%\.ssh\id_ed25519.pub | ssh root@185.204.197.128 \"mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys\""
echo "  بعد از اینکه مطمئن شدید با کلید وارد می‌شوید (پنجرهٔ جدید باز کنید)،"
echo "  به من بگویید تا ورود با رمز را هم برایتان ببندم."
echo
echo "${c}چک وضعیت حملات بسته‌شده:${o}  fail2ban-client status sshd"
echo "====================================================="
