'use strict';
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });

  const page = await browser.newPage();
  
  // Set high DPI viewport
  await page.setViewport({ width: 1200, height: 2000, deviceScaleFactor: 1 });

  // Load local HTML or HTML snippet with journal-share-card.js
  const scriptContent = fs.readFileSync(path.join(__dirname, 'public/journal-share-card.js'), 'utf8');

  const html = `
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <title>Share Card Generator</title>
      <style>
        @font-family { font-family: 'Vazirmatn'; src: local('Vazirmatn'), local('Tahoma'); }
        body { background: #060c15; color: #fff; margin: 0; padding: 20px; font-family: Vazirmatn, Tahoma, sans-serif; }
        canvas { background: #000; display: block; margin: 20px auto; max-width: 100%; height: auto; }
      </style>
    </head>
    <body>
      <canvas id="c-trade-story"></canvas>
      <canvas id="c-trade-square"></canvas>
      <canvas id="c-summary-story"></canvas>
      <script>
        ${scriptContent}
      </script>
    </body>
    </html>
  `;

  await page.setContent(html, { waitUntil: 'domcontentloaded' });

  // Mock trade sample data
  const sampleTrade = {
    symbol: 'XAUUSD',
    direction: 'BUY',
    lot: 0.50,
    entryPrice: 2042.50,
    exitPrice: 2065.80,
    pnl: 1165.00,
    pnlPercent: 5.82,
    pips: 233,
    rMultiple: 3.2,
    setupName: 'Breakout & Retest',
    timeframe: 'M15',
    date: '2026-09-02',
    entryTime: '14:30',
    exitTime: '16:45',
    notes: 'تاییدیه شکست سطح مقاومت ۲۰۴۲ با کندل قدرتمند و تثبیت بالای آن'
  };

  const sampleTrades = [
    { pnl: 450, win: true },
    { pnl: -120, win: false },
    { pnl: 680, win: true },
    { pnl: 310, win: true },
    { pnl: -180, win: false },
    { pnl: 890, win: true },
    { pnl: 520, win: true },
    { pnl: -90, win: false },
    { pnl: 1165, win: true },
    { pnl: 420, win: true }
  ];

  await page.evaluate((trade, trades) => {
    // 1. Single Trade Story (9:16)
    const canvas1 = document.getElementById('c-trade-story');
    window.paDrawTradeCanvas(canvas1, trade, {
      ratio: 'story',
      showAmount: true,
      showVolume: true,
      traderHandle: '@trader_pro'
    });

    // 2. Single Trade Square (1:1)
    const canvas2 = document.getElementById('c-trade-square');
    window.paDrawTradeCanvas(canvas2, trade, {
      ratio: 'square',
      showAmount: true,
      showVolume: true,
      traderHandle: '@trader_pro'
    });

    // 3. Summary Performance Story (9:16)
    const canvas3 = document.getElementById('c-summary-story');
    window.paDrawSummaryCanvas(canvas3, trades, {
      ratio: 'story',
      showAmount: true,
      traderHandle: '@trader_pro'
    });
  }, sampleTrade, sampleTrades);

  // Helper to extract canvas image data and save to file
  async function saveCanvas(selector, filePath) {
    const dataUrl = await page.evaluate((sel) => {
      const c = document.querySelector(sel);
      return c.toDataURL('image/png');
    }, selector);
    const base64Data = dataUrl.replace(/^data:image\/png;base64,/, '');
    fs.writeFileSync(filePath, base64Data, 'base64');
    console.log('Saved:', filePath);
  }

  await saveCanvas('#c-trade-story', '/home/user/card-trade-story.png');
  await saveCanvas('#c-trade-square', '/home/user/card-trade-square.png');
  await saveCanvas('#c-summary-story', '/home/user/card-summary-story.png');

  await browser.close();
})();
