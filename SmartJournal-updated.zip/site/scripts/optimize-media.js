#!/usr/bin/env node
'use strict';
/* ==========================================================================
   تصاویر ثابت سایت را به WebP تبدیل می‌کند و ارجاع‌ها را به‌روز می‌کند.
   آیکون‌های manifest عمداً PNG می‌مانند (بعضی پلتفرم‌ها برای نصب PWA
   هنوز PNG لازم دارند).
   ========================================================================== */

const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const ROOT = path.resolve(__dirname, '..');
const MEDIA = path.join(ROOT, 'public', 'media');
const QUALITY = Number(process.env.WEBP_QUALITY || 82);

(async () => {
  const pngs = fs.readdirSync(MEDIA).filter((f) => /\.png$/i.test(f)).sort();
  let before = 0, after = 0;
  const converted = [];

  for (const name of pngs) {
    const src = path.join(MEDIA, name);
    const dst = src.replace(/\.png$/i, '.webp');
    try {
      await sharp(src, { animated: true, failOn: 'none' })
        .webp({ quality: QUALITY, effort: 6 })
        .toFile(dst);
    } catch (error) {
      console.log(`  ! ${name}: ${error.message.slice(0, 70)}`);
      continue;
    }
    const a = fs.statSync(src).size, b = fs.statSync(dst).size;
    before += a; after += b;
    converted.push([name, path.basename(dst)]);
    console.log(`  ✓ ${name.padEnd(42)} ${(a / 1024).toFixed(1).padStart(8)} KB → `
      + `${(b / 1024).toFixed(1).padStart(7)} KB  (${Math.round(100 - (b * 100) / a)}% کمتر)`);
  }

  if (before) {
    console.log(`\n  مجموع: ${(before / 1024).toFixed(0)} KB → ${(after / 1024).toFixed(0)} KB `
      + `(${Math.round(100 - (after * 100) / before)}% کمتر)`);
  }

  // ------------------------------------------------------------ references
  const targets = [
    'public/index.html',
    'public/admin/index.html',
    'public/smartjournal-brand.js',
    'marketing-pages.js',
    'server.js',
  ].map((p) => path.join(ROOT, p)).filter(fs.existsSync);

  let rewritten = 0;
  for (const file of targets) {
    const original = fs.readFileSync(file, 'utf8');
    let text = original;
    for (const [png, webp] of converted) text = text.split(`/media/${png}`).join(`/media/${webp}`);
    if (text !== original) {
      fs.writeFileSync(file, text, 'utf8');
      rewritten += 1;
      console.log(`  → ارجاع‌ها به‌روز شد: ${path.relative(ROOT, file)}`);
    }
  }
  console.log(`\n  فایل‌های به‌روزشده: ${rewritten}`);
  console.log('  (آیکون‌های manifest.webmanifest عمداً PNG ماندند)');
})();
