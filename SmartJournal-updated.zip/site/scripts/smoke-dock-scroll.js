/**
 * smoke-dock-scroll.js — رگرسیون «دکمه‌های شناور با اسکرول کنار بروند»
 *
 * درخواست کاربر: در دسکتاپ هم مثل موبایل، ستون پایین‌چپ (نوار کاربر،
 * «پشتیبانی»، «؟») هنگام اسکرول به پایین نرم کنار برود و با اسکرول به بالا
 * برگردد. قبلاً onScroll روی عرض > ۷۶۰ خودش را خاموش می‌کرد.
 *
 * تست واقعی است: اسکرول می‌کنیم و opacity/transform محاسبه‌شدهٔ مرورگر را
 * می‌خوانیم — نه متن CSS را.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const SEL = ['.pa-auth-userbar', '.pa-support-launcher', '.pa-ux-help'];

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0994' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'کاربر اسکرول', mobile, password: 'Dock@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  const read = p => p.evaluate(sel => {
    const out = { away: document.documentElement.classList.contains('pa-dock-away'), items: {} };
    sel.forEach(s => {
      const el = document.querySelector(s);
      if (!el) return;
      const cs = getComputedStyle(el), r = el.getBoundingClientRect();
      out.items[s] = {
        opacity: Number(cs.opacity),
        pointer: cs.pointerEvents,
        transform: cs.transform,
        bottom: Math.round(r.top + r.height),
        vh: innerHeight
      };
    });
    return out;
  }, SEL);

  for (const [name, w, h] of [['دسکتاپ', 1366, 768], ['موبایل', 390, 844]]) {
    console.log(`\n── ${name} (${w}×${h}) ──`);
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: w < 500, hasTouch: w < 500 });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(4500);

    /* مطمئن شویم صفحه اصلاً قابل اسکرول است */
    const scrollable = await p.evaluate(() => {
      const d = document.documentElement;
      if (d.scrollHeight <= innerHeight + 200) {
        const pad = document.createElement('div');
        pad.style.height = '1600px'; pad.setAttribute('data-pa-test-pad', '1');
        document.body.appendChild(pad);
      }
      return document.documentElement.scrollHeight;
    });

    const before = await read(p);
    ok(`${name}: در ابتدای صفحه دکمه‌ها دیده می‌شوند`,
      SEL.every(s => !before.items[s] || before.items[s].opacity > 0.9), JSON.stringify(Object.keys(before.items)));

    await p.evaluate(() => { for (let y = 0; y <= 600; y += 60) window.scrollTo(0, y); });
    await wait(700);
    const away = await read(p);
    ok(`${name}: با اسکرول به پایین کلاس pa-dock-away فعال می‌شود`, away.away, 'scrollHeight=' + scrollable);
    SEL.forEach(s => {
      const it = away.items[s];
      if (!it) return;
      ok(`${name}: ${s} کنار رفته (شفافیت ۰ و جابه‌جا شده)`,
        it.opacity < 0.05 && it.pointer === 'none' && /matrix/.test(it.transform) && it.transform !== 'none',
        `opacity=${it.opacity} · ${it.transform}`);
    });

    await p.evaluate(() => window.scrollTo(0, 0));
    await wait(700);
    const back = await read(p);
    ok(`${name}: با بازگشت به بالا دوباره ظاهر می‌شوند`,
      !back.away && SEL.every(s => !back.items[s] || back.items[s].opacity > 0.9),
      'away=' + back.away);
    await p.evaluate(() => document.querySelectorAll('[data-pa-test-pad]').forEach(e => e.remove()));
    await p.close();
  }

  await br.close();
  const bad = R.filter(([c]) => !c).length;
  console.log(`\n${R.length - bad}/${R.length} آزمون اسکرول دکمه‌های شناور پاس شد.`);
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
