/**
 * probe-floats.js — کشف خودکار همه‌ی عناصر شناور و برخوردهایشان
 *
 *  ۱) هر عنصر fixed/sticky دیده‌شدنی
 *  ۲) به‌علاوه فرزندانی که از کادر والدِ شناور بیرون می‌زنند (مثل دکمه + که
 *     ۳۰ پیکسل از نوار پایین بیرون زده — همین از چشم تست قبلی پنهان ماند)
 *  ۳) برخورد شناور با شناور
 *  ۴) برخورد شناور با محتوای واقعی صفحه (دکمه/لینک/فیلد پوشانده‌شده)
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));

const COLLECT = () => {
  const vis = el => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) < .05) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    return r;
  };
  const label = el => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') +
    (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.') : '');

  const floaters = [];
  const roots = [];
  document.querySelectorAll('body *').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
    const r = vis(el); if (!r) return;
    let par = el.parentElement, nested = false;
    while (par && par !== document.body) { const pc = getComputedStyle(par); if (pc.position === 'fixed' || pc.position === 'sticky') { nested = true; break } par = par.parentElement }
    if (nested) return;
    roots.push(el);
    floaters.push({ name: label(el), owner: label(el), z: cs.zIndex, rect: [r.left, r.top, r.width, r.height].map(Math.round), kind: cs.position });
  });
  // فرزندانی که از کادر والد بیرون می‌زنند → مستطیل جدا
  const clipped = el => {
    let p = el.parentElement;
    while (p && p !== document.body) {
      const c = getComputedStyle(p);
      if (/auto|scroll|hidden/.test(c.overflowY) || /auto|scroll|hidden/.test(c.overflowX)) return true;
      p = p.parentElement;
    }
    return false;
  };
  roots.forEach(root => {
    const rr = root.getBoundingClientRect();
    root.querySelectorAll('*').forEach(ch => {
      if (clipped(ch)) return;
      const r = vis(ch); if (!r) return;
      const out = r.left < rr.left - 1 || r.top < rr.top - 1 || r.right > rr.right + 1 || r.bottom > rr.bottom + 1;
      if (!out) return;
      // فقط بیرون‌زدگی معنادار
      if ((rr.top - r.top) < 6 && (rr.left - r.left) < 6 && (r.right - rr.right) < 6 && (r.bottom - rr.bottom) < 6) return;
      floaters.push({ name: label(root) + ' ▸ ' + label(ch), owner: label(root), z: getComputedStyle(root).zIndex, rect: [r.left, r.top, r.width, r.height].map(Math.round), kind: 'overflow' });
    });
  });

  // محتوای تعاملی پوشانده‌شده
  const covered = [];
  document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) return;
    let f = el; while (f && f !== document.body) { const c = getComputedStyle(f); if (c.position === 'fixed' || c.position === 'sticky') return; f = f.parentElement }
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const hit = document.elementFromPoint(cx, cy);
    if (!hit) return;
    if (hit === el || el.contains(hit) || hit.contains(el)) return;
    let g = hit, fixedAncestor = null;
    while (g && g !== document.body) { const c = getComputedStyle(g); if (c.position === 'fixed' || c.position === 'sticky') { fixedAncestor = g; break } g = g.parentElement }
    covered.push({ el: label(el), txt: (el.innerText || el.value || '').replace(/\s+/g, ' ').trim().slice(0, 26), by: label(hit), byFloat: fixedAncestor ? label(fixedAncestor) : null });
  });

  // اندازه‌ی هدف لمسی
  const small = [];
  document.querySelectorAll('.pa-mobile-nav > button, .pa-auth-userbar button, .pa-support-launcher, .pa-ux-help, .pa-dock-btn').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.width < 40 || r.height < 40) small.push({ el: label(el), size: Math.round(r.width) + '×' + Math.round(r.height) });
  });

  const bar = document.querySelector('.pa-accounts-bar');
  return { floaters, covered, small, accountsBarH: bar ? Math.round(bar.getBoundingClientRect().height) : 0 };
};

const ov = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0993' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'sobhan goorakani', mobile, password: 'Lay@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  if (!s1.data.challengeToken) { console.log('signup failed', s1.status, JSON.stringify(s1.data).slice(0, 300)); process.exit(1); }
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const VIEWS = [['320', 320, 640], ['360', 360, 740], ['390', 390, 844], ['414', 414, 896], ['768', 768, 1024], ['1366', 1366, 768]];
  const TABS = process.env.PROBE_TAB ? [process.env.PROBE_TAB] : ['dash', 'new'];

  for (const [name, w, h] of VIEWS) {
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: w < 500, hasTouch: w < 500 });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(4500);

    for (const tab of TABS) {
      if (tab === 'new') {
        await p.evaluate(() => {
          const m = [...document.querySelectorAll('.pa-mobile-nav button')].find(x => /ثبت/.test(x.innerText || ''));
          if (m) return m.click();
          const t = [...document.querySelectorAll('.pa-header .pa-tab')].find(x => /معامله جدید|ثبت/.test((x.getAttribute('title') || '') + (x.textContent || '')));
          if (t) t.click();
        });
        await wait(1800);
      }
      await p.evaluate(() => window.scrollTo(0, 0));
      await wait(500);
      const dTop = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await wait(700);
      const dBot = await p.evaluate(COLLECT);
      await p.evaluate(() => window.scrollTo(0, 0));
      await wait(400);
      /* فقط عنصری «واقعاً دسترس‌ناپذیر» است که در هر دو حالت پوشیده باشد */
      const botKeys = new Set(dBot.covered.map(c => c.el + '|' + c.txt));
      const d = Object.assign({}, dTop, {
        covered: dTop.covered.filter(c => botKeys.has(c.el + '|' + c.txt))
      });
      console.log(`\n═══ ${name}×${h} · تب «${tab}» ═══   ارتفاع نوار حساب‌ها: ${d.accountsBarH}px`);
      d.floaters.forEach(f => console.log('  ', String(f.rect).padEnd(24), ('z=' + f.z).padEnd(13), f.name));
      const cl = [];
      for (let i = 0; i < d.floaters.length; i++) for (let j = i + 1; j < d.floaters.length; j++) {
        const a = d.floaters[i], b = d.floaters[j];
        if (a.owner === b.owner) continue;                 /* والد و فرزند خودش */
        if (ov(a.rect, b.rect)) cl.push(a.name + ' ✕ ' + b.name + '  ' + JSON.stringify(a.rect) + JSON.stringify(b.rect));
      }
      console.log(cl.length ? '  ✗ شناور روی شناور: ' + cl.join(' | ') : '  ✓ شناور روی شناور: پاک');
      console.log(d.covered.length ? '  ✗ محتوای پوشانده‌شده: ' + d.covered.map(c => `${c.el} «${c.txt}» زیرِ ${c.byFloat || c.by}`).join(' | ') : '  ✓ محتوای پوشانده‌شده: هیچ');
      console.log(d.small.length ? '  ✗ هدف لمسی کوچک: ' + d.small.map(s => s.el + ' ' + s.size).join(' | ') : '  ✓ هدف لمسی: همه ≥40px');
      if (w < 900) {
        const shotDir = process.env.SHOT_DIR || require('path').join(__dirname, '..', 'shots');
        require('fs').mkdirSync(shotDir, { recursive: true });
        await p.screenshot({ path: require('path').join(shotDir, `probe-${name}-${tab}.png`) });
      }
    }
    await p.close();
  }
  await br.close();
})();
