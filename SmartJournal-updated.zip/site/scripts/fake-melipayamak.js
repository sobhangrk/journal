/**
 * fake-melipayamak.js — شبیه‌ساز وب‌سرویس REST ملی‌پیامک برای تست
 *
 * ملی‌پیامک فقط از IP ایران جواب می‌دهد، پس برای تست واقعی مسیر کد،
 * همان قراردادِ مستندشده را اینجا پیاده می‌کنیم:
 *
 *   POST /api/SendSMS/BaseServiceNumber  {username,password,text,to,bodyId}
 *   POST /api/SendSMS/SendSMS            {username,password,to,from,text,isFlash}
 *   POST /api/SendSMS/GetCredit          {username,password}
 *   GET  /inbox                          پیام‌های دریافت‌شده (برای تست)
 *   POST /fail/:code                     وادار کردن سرویس به برگرداندن کد خطا
 *
 * اجرا:  node scripts/fake-melipayamak.js [port]
 */
const http = require('http');

const PORT = Number(process.argv[2] || process.env.PORT || 4556);
const USER = process.env.MP_USER || 'sjuser';
const PASS = process.env.MP_PASS || 'sjpass';
const BODY_ID = String(process.env.MP_BODYID || '12345');

let credit = 48250;
const inbox = [];
const seenPaths = [];      /* برای اینکه تست بتواند آدرس دقیق را بررسی کند */
let forcedError = null;

const send = (res, code, data) => {
  const payload = JSON.stringify(data);
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
  res.end(payload);
};
const recId = () => String(Date.now()) + String(Math.floor(Math.random() * 900 + 100));

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

  if (req.method === 'GET' && url.pathname === '/inbox') return send(res, 200, { rows: inbox, paths: seenPaths });
  if (req.method === 'POST' && url.pathname === '/reset') { inbox.length = 0; seenPaths.length = 0; forcedError = null; credit = 48250; return send(res, 200, { ok: true }); }
  if (req.method === 'POST' && url.pathname.startsWith('/fail/')) {
    forcedError = url.pathname.split('/').pop();
    return send(res, 200, { ok: true, forcedError });
  }

  let raw = '';
  req.on('data', chunk => { raw += chunk; if (raw.length > 1e6) req.destroy(); });
  req.on('end', () => {
    let body = {};
    try { body = JSON.parse(raw || '{}'); }
    catch { body = Object.fromEntries(new URLSearchParams(raw)); }

    const authOk = body.username === USER && String(body.password) === PASS;

    seenPaths.push(url.pathname);
    /* سرور واقعی فقط این سه مسیر دقیق را می‌شناسد؛ بقیه ۴۰۴ می‌گیرند.
       نسخه‌ی قبلی این فایل با endsWith کار می‌کرد و همین باعث شد باگِ
       «/api/GetCredit به‌جای /api/SendSMS/GetCredit» در تست دیده نشود. */
    const ROOT = '/api/SendSMS/';
    if (!url.pathname.startsWith(ROOT)) {
      return send(res, 404, { error: 'not found', path: url.pathname });
    }

    if (url.pathname === ROOT + 'GetCredit') {
      if (!authOk) return send(res, 200, { Value: '0', RetStatus: 0, StrRetStatus: 'نام کاربری یا رمز اشتباه است' });
      return send(res, 200, { Value: String(credit), RetStatus: 1, StrRetStatus: 'Ok' });
    }

    if (url.pathname === ROOT + 'GetDeliveries2') {
      if (!authOk) return send(res, 200, { Value: '0', RetStatus: 0, StrRetStatus: 'Error' });
      const rec = String(body.recId || '');
      const hit = inbox.find((m) => m.recId === rec);
      /* اولین پرسش «در صف»، بعدی «تحویل شد» — مثل رفتار واقعی */
      if (!hit) return send(res, 200, { Value: [100], RetStatus: 1, StrRetStatus: 'Ok' });
      hit.asked = (hit.asked || 0) + 1;
      return send(res, 200, { Value: [hit.asked >= 2 ? 1 : 0], RetStatus: 1, StrRetStatus: 'Ok' });
    }

    if (url.pathname === ROOT + 'BaseServiceNumber') {
      if (forcedError) { const code = forcedError; forcedError = null; return send(res, 200, { Value: code, RetStatus: 1, StrRetStatus: 'Error' }); }
      if (!authOk) return send(res, 200, { Value: '0', RetStatus: 1, StrRetStatus: 'Error' });
      if (String(body.bodyId) !== BODY_ID) return send(res, 200, { Value: '-4', RetStatus: 1, StrRetStatus: 'Error' });
      if (!/^09\d{9}$/.test(String(body.to || ''))) return send(res, 200, { Value: '18', RetStatus: 1, StrRetStatus: 'Error' });
      if (!String(body.text || '').length) return send(res, 200, { Value: '17', RetStatus: 1, StrRetStatus: 'Error' });
      { const rec = recId(); credit -= 150;
        inbox.push({ method: 'BaseServiceNumber', to: body.to, text: String(body.text), bodyId: String(body.bodyId), recId: rec, at: new Date().toISOString() });
        return send(res, 200, { Value: rec, RetStatus: 1, StrRetStatus: 'Ok' }); }
    }

    if (url.pathname === ROOT + 'SendSMS') {
      if (forcedError) { const code = forcedError; forcedError = null; return send(res, 200, { Value: code, RetStatus: 1, StrRetStatus: 'Error' }); }
      if (!authOk) return send(res, 200, { Value: '0', RetStatus: 1, StrRetStatus: 'Error' });
      if (!String(body.from || '').length) return send(res, 200, { Value: '5', RetStatus: 1, StrRetStatus: 'Error' });
      credit -= 150;
      inbox.push({ method: 'SendSMS', to: body.to, from: body.from, text: String(body.text), at: new Date().toISOString() });
      return send(res, 200, { Value: recId(), RetStatus: 1, StrRetStatus: 'Ok' });
    }

    send(res, 404, { error: 'not found' });
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`ملی‌پیامک ساختگی روی http://127.0.0.1:${PORT}  (user=${USER} bodyId=${BODY_ID})`);
});
