/**
 * smoke-social-links.js — راه‌های ارتباطی (تلگرام/اینستاگرام) از پنل تا سایت
 *
 * سناریو:
 *   ۱) قبل از تنظیم مدیر، هیچ لینکی روی سایت نیست و دکمه شناور هم ساخته نمی‌شود
 *   ۲) مدیر از پنل آدرس تلگرام و اینستاگرام را وارد و منتشر می‌کند
 *   ۳) آدرس‌های ناامن (javascript:) رد می‌شوند
 *   ۴) نوشتن فقط «@username» خودکار به آدرس کامل تبدیل می‌شود
 *   ۵) با مرورگر واقعی: دکمه شناور گوشه صفحه ساخته می‌شود، با اسکرول سر جایش
 *      می‌ماند، باز می‌شود و لینک‌ها درست‌اند
 *   ۶) لینک‌ها زیر کارت «تماس و پشتیبانی» صفحه اصلی هم می‌آیند
 *   ۷) حذف و خاموش‌کردن، بلافاصله روی سایت اثر می‌گذارد
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: jar.join('; ') };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const r = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(r);
  let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, data: d };
}

(async () => {
  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const path = require('path');
  const db = new Database(process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'admin.db'));
  const stamp = Date.now().toString(36);
  const username = 'socadmin' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_soc_' + stamp, 'مدیر تست شبکه‌ها', username, '093' + String(Date.now()).slice(-8),
         bcrypt.hashSync('SocAdmin@12345', 10), new Date().toISOString());
  db.prepare('DELETE FROM social_links').run();
  db.close();

  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'SocAdmin@12345' } });
  const csrf = login.data.csrfToken;
  ok('ورود مدیر', login.status === 200, 'status=' + login.status);

  console.log('\n── ۱) قبل از تنظیم مدیر ──');
  let pub = await req('/api/public/social-links');
  ok('سایت هیچ لینکی نشان نمی‌دهد', pub.status === 200 && pub.data.rows.length === 0,
     'تعداد=' + pub.data.rows.length);

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await br.newPage();
  await page.setViewport({ width: 1200, height: 820 });
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 200)));

  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(2500);
  ok('دکمه شناور بی‌خودی ساخته نمی‌شود',
     !(await page.$('#pa-support-widget')), 'وقتی مدیر چیزی منتشر نکرده');

  console.log('\n── ۲) مدیر آدرس‌ها را وارد می‌کند ──');
  const create = await req('/api/admin/social-links', { method: 'POST', csrf,
    body: { platform: 'telegram', label: 'تلگرام', url: '@smartjournal_support', handle: '@smartjournal_support', isPublished: true } });
  ok('لینک تلگرام ساخته شد', create.status === 201, JSON.stringify(create.data).slice(0, 120));
  ok('«@username» خودکار به آدرس کامل تبدیل شد',
     create.data.row?.url === 'https://t.me/smartjournal_support', create.data.row?.url);

  const insta = await req('/api/admin/social-links', { method: 'POST', csrf,
    body: { platform: 'instagram', label: 'اینستاگرام', url: 'https://instagram.com/smartjournal', isPublished: true } });
  ok('لینک اینستاگرام ساخته شد', insta.status === 201);

  console.log('\n── ۳) اعتبارسنجی آدرس ──');
  const evil = await req('/api/admin/social-links', { method: 'POST', csrf,
    body: { platform: 'custom', label: 'بد', url: 'javascript:alert(1)', isPublished: true } });
  ok('آدرس javascript: رد می‌شود', evil.status === 400, 'status=' + evil.status);
  const noLabel = await req('/api/admin/social-links', { method: 'POST', csrf,
    body: { platform: 'telegram', label: '   ', url: '@x' } });
  ok('عنوان خالی رد می‌شود', noLabel.status === 400);

  console.log('\n── ۴) خروجی عمومی ──');
  pub = await req('/api/public/social-links');
  ok('سایت هر دو لینک را می‌بیند', pub.data.rows.length === 2, 'تعداد=' + pub.data.rows.length);
  ok('پاسخ عمومی فقط فیلدهای لازم را دارد',
     Object.keys(pub.data.rows[0]).every(k => ['id', 'platform', 'label', 'handle', 'url', 'show_widget'].includes(k)),
     Object.keys(pub.data.rows[0]).join(','));

  console.log('\n── ۵) دکمه شناور در مرورگر واقعی ──');
  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(3000);
  const fab = await page.evaluate(() => {
    const w = document.getElementById('pa-support-widget');
    if (!w) return { exists: false };
    const b = w.querySelector('.pa-sup-fab').getBoundingClientRect();
    const cs = getComputedStyle(w);
    return { exists: true, position: cs.position, zIndex: cs.zIndex,
      bottom: Math.round(innerHeight - b.bottom), left: Math.round(b.left),
      onScreen: b.top >= 0 && b.bottom <= innerHeight && b.width > 20 };
  });
  ok('دکمه شناور ساخته شد', fab.exists);
  ok('position آن fixed است (با اسکرول سر جایش می‌ماند)', fab.position === 'fixed', fab.position);
  ok('در گوشه پایین-چپ صفحه است', fab.bottom >= 0 && fab.bottom < 60 && fab.left < 60,
     `فاصله از پایین ${fab.bottom}px · از چپ ${fab.left}px`);
  ok('روی صفحه دیده می‌شود', !!fab.onScreen);

  await page.evaluate(() => window.scrollTo(0, 1800));
  await wait(700);
  const after = await page.evaluate(() => {
    const b = document.querySelector('#pa-support-widget .pa-sup-fab').getBoundingClientRect();
    return { bottom: Math.round(innerHeight - b.bottom), scrollY: Math.round(scrollY) };
  });
  ok('بعد از اسکرول هم دقیقاً همان‌جاست', after.bottom === fab.bottom,
     `اسکرول ${after.scrollY}px · فاصله از پایین ${after.bottom}px`);

  await page.click('#pa-support-widget .pa-sup-fab');
  await wait(500);
  const opened = await page.evaluate(() => {
    const w = document.getElementById('pa-support-widget');
    const links = [...w.querySelectorAll('.pa-sup-link')];
    const panel = w.querySelector('.pa-sup-panel');
    const r = panel.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + 30);
    return { open: w.classList.contains('open'), count: links.length,
      hrefs: links.map(a => a.href), targets: links.map(a => a.target + '|' + a.rel),
      painted: !!hit && panel.contains(hit) };
  });
  ok('پنل با کلیک باز می‌شود', opened.open && opened.count === 2, 'تعداد لینک=' + opened.count);
  ok('پنل واقعاً روی صفحه رسم می‌شود', opened.painted);
  ok('لینک‌ها درست‌اند', opened.hrefs.includes('https://t.me/smartjournal_support')
    && opened.hrefs.some(h => h.includes('instagram.com/smartjournal')), opened.hrefs.join(' , '));
  ok('لینک‌ها امن باز می‌شوند (noopener)', opened.targets.every(t => t.includes('_blank') && t.includes('noopener')));

  console.log('\n── ۶) کارت «تماس و پشتیبانی» صفحه اصلی ──');
  const chips = await page.evaluate(() => {
    const row = document.getElementById('pa-social-row');
    if (!row) return { exists: false };
    const near = !!row.closest('.pa-l-more-links');
    return { exists: true, near, count: row.querySelectorAll('.pa-social-chip').length,
      text: row.innerText.replace(/\s+/g, ' ').trim() };
  });
  ok('چیپ‌های شبکه‌ها زیر بخش تماس اضافه شدند', chips.exists && chips.near, JSON.stringify(chips));
  ok('هر دو شبکه در آن هست', chips.count === 2, 'متن: ' + chips.text);

  console.log('\n── ۷) خاموش کردن و حذف ──');
  const rows = (await req('/api/admin/social-links')).data.rows;
  await req(`/api/admin/social-links/${rows[0].id}`, { method: 'PATCH', csrf, body: { isPublished: false } });
  pub = await req('/api/public/social-links');
  ok('لینک خاموش‌شده از سایت حذف می‌شود', pub.data.rows.length === 1, 'تعداد=' + pub.data.rows.length);

  const del = await req(`/api/admin/social-links/${rows[1].id}`, { method: 'DELETE', csrf });
  ok('حذف کار می‌کند', del.status === 200);
  pub = await req('/api/public/social-links');
  ok('بعد از حذف، سایت خالی می‌شود', pub.data.rows.length === 0);

  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(2500);
  ok('دکمه شناور هم برداشته می‌شود', !(await page.$('#pa-support-widget')));

  ok('هیچ خطای JS در صفحه رخ نداد', errs.length === 0, errs.join(' | '));
  await br.close();

  const fail = R.filter(r => !r[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون راه‌های ارتباطی پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nSOCIAL SMOKE FAILED:', e.stack || e); process.exit(1); });
