/**
 * security-attack-suite.js — حمله‌های واقعی برای سنجش امنیت SmartJournal
 * ------------------------------------------------------------------
 * فازها:
 *   A) احراز هویت و نشست  — دسترسی بدون نشست، brute-force مدیر، CSRF
 *   B) IDOR — دسترسی به دادهٔ کاربر دیگر (تصویر، تیکت، معامله، حساب)
 *   C) XSS — ذخیره‌شده و بازتابی (با مرورگر واقعی)
 *   D) OTP — brute-force کد و سیلاب درخواست
 *   E) اعتبارسنجی ورودی — پیمایش مسیر، تزریق SQL، mass-assignment
 *   F) هدرهای امنیتی و نشت اطلاعات
 *
 * اجرا: node scripts/security-attack-suite.js
 */
const crypto = require('crypto');
const path = require('path');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));
let okc = 0, badc = 0, notes = [];
const ok = (c, n, x = '') => { if (c) okc++; else badc++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const note = t => { notes.push(t); console.log('  • ' + t); };

const jar = new Map(); /* name -> cookie value */
function setJar(name, res) { const cs = res.headers.getSetCookie ? res.headers.getSetCookie() : []; cs.forEach(c => { const [k] = c.split('='); jar.set(k, c.split(';')[0]); }); }
const cookieHeader = () => [...jar.values()].join('; ');
async function req(path, { method = 'GET', body, token, raw, headers = {} } = {}) {
  const h = { cookie: cookieHeader(), ...headers };
  if (body !== undefined && body !== null) { h['content-type'] = 'application/json'; if (token) h['x-csrf-token'] = token; }
  const t0 = Date.now();
  const r = await fetch(B + path, { method, headers: h, body: body !== undefined && body !== null ? (raw || JSON.stringify(body)) : undefined, redirect: 'manual' });
  let data = null; try { data = await r.json(); } catch (e) { try { data = await r.text(); } catch (e2) {} }
  setJar('x', r);
  return { status: r.status, data, ms: Date.now() - t0, headers: r.headers };
}

async function signupUser(tag) {
  const mobile = '0935' + String(Date.now() + Math.floor(Math.random() * 9000)).slice(-7);
  const s1 = await req('/api/auth/signup', { method: 'POST', body: { name: tag, mobile, password: 'Sec#Test12345', acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true } });
  if (s1.status !== 202 || !s1.data.challengeToken) throw new Error('signup failed: ' + s1.status + ' ' + JSON.stringify(s1.data).slice(0, 100));
  const v = await req('/api/auth/signup/verify', { method: 'POST', body: { challengeToken: s1.data.challengeToken, code: s1.data.devCode } });
  if (v.status !== 201) throw new Error('verify failed: ' + v.status);
  return { mobile, csrf: v.data.csrfToken };
}

(async () => {
  console.log('SmartJournal — مجموعه حمله‌های امنیتی');
  console.log('سرور:', B, '\n');

  /* ═════════════ A) احراز هویت ═════════════ */
  console.log('── الف) احراز هویت و نشست ──');
  {
    const r = await req('/api/admin/users', { method: 'GET' });
    ok(r.status === 401, 'API مدیریت بدون نشست → 401', r.status);
    const r2 = await req('/api/admin', { method: 'GET' });
    ok(r2.status === 401 || r2.status === 404, 'ریشهٔ API مدیریت بدون نشست بسته است', r2.status);
    const r3 = await req('/api/journal/accounts');
    ok(r3.status === 401, 'API ژورنال بدون نشست → 401', r3.status);
    const r4 = await req('/api/auth/me');
    ok(r4.status === 401, 'me بدون نشست → 401', r4.status);
    /* brute-force ورود مدیر: ۸ بار → 429 */
    let bruteStatus = 0;
    for (let i = 0; i < 8; i++) {
      const r5 = await req('/api/admin/login', { method: 'POST', body: { identifier: 'owner', password: 'WrongPass#' + i + 'x' } });
      bruteStatus = r5.status;
      if (bruteStatus === 429) break;
    }
    ok(bruteStatus === 429, 'brute-force ورود مدیر بعد از ۷ تلاش → 429', bruteStatus);
    /* CSRF مدیر: ورود با رمز غلط نیازی به CSRF ندارد؛ route حساس بدون توکن */
    const r6 = await req('/api/admin/settings', { method: 'POST', body: { signup_enabled: 0 } });
    ok(r6.status === 401, 'تغییر تنظیمات بدون نشست → 401', r6.status);
  }

  /* ═════════════ B) IDOR ═════════════ */
  console.log('\n── ب) دسترسی به دادهٔ کاربر دیگر (IDOR) ──');
  const A = await signupUser('کاربر قربانی');
  const saveJar = new Map(jar); /* نشست A */
  const AMedia = await (async () => {
    /* یک تصویر واقعی کوچک PNG برای کاربر A */
    const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    const acc = await req('/api/journal/accounts', { method: 'POST', token: A.csrf, body: { name: 'حساب قربانی', startingBalance: 5000 } });
    const trade = await req('/api/journal/trades', { method: 'POST', token: A.csrf, body: { id: 'trade_sec_a1', accountId: acc.data.account.id, entryDate: new Date().toISOString(), symbol: 'XAUUSD', direction: 'buy', resultType: 'profit', amount: 100, notes: '<img src=x onerror=alert(1)>', entryPrice: 2400, exitPrice: 2410 } });
    const ticket = await req('/api/journal/support/tickets', { method: 'POST', token: A.csrf, body: { category: 'technical', subject: '<script>alert("xss")</script> موضوع', message: 'پیام تست امنیتی برای ایستگاه حمله با طول کافی است.' } });
    const media = await req('/api/journal/media', { method: 'POST', token: A.csrf, body: { data: png, tradeId: 'trade_sec_a1' } });
    return { accId: acc.data.account.id, tradeId: trade.data.trade.id, ticketId: ticket.data.id, mediaId: media.data.id };
  })();
  jar.clear();
  const BUser = await signupUser('کاربر مهاجم');

  const idor = [
    ['GET', `/api/journal/media/${AMedia.mediaId}`, null, 404, 'تصویر کاربر دیگر'],
    ['GET', `/api/journal/support/tickets/${AMedia.ticketId}`, null, 404, 'تیکت کاربر دیگر'],
    ['PATCH', `/api/journal/trades/${AMedia.tradeId}`, { amount: 999999 }, 404, 'ویرایش معاملهٔ کاربر دیگر'],
    ['DELETE', `/api/journal/trades/${AMedia.tradeId}`, {}, 404, 'حذف معاملهٔ کاربر دیگر'],
    ['DELETE', `/api/journal/accounts/${AMedia.accId}`, { accountVersion: 1, tradeVersion: 1 }, 404, 'حذف حساب کاربر دیگر'],
    ['POST', `/api/journal/support/tickets/${AMedia.ticketId}/messages`, { message: 'پیام مهاجم به تیکت کاربر دیگر!' }, 404, 'پیام در تیکت کاربر دیگر'],
  ];
  for (const [m, p, body, expect, label] of idor) {
    const r = await req(p, { method: m, token: BUser.csrf, body });
    ok(r.status === expect, `IDOR: ${label} مسدود است`, r.status + ' (انتظار ' + expect + ')');
  }
  /* mass-assignment: معامله با حساب کاربر دیگر */
  const crossTrade = await req('/api/journal/trades', { method: 'POST', token: BUser.csrf, body: { id: 'trade_sec_b1', accountId: AMedia.accId, entryDate: new Date().toISOString(), symbol: 'XAUUSD', direction: 'buy', resultType: 'profit', amount: 10 } });
  ok(crossTrade.status === 400 || crossTrade.status === 404, 'ساخت معامله با حساب کاربر دیگر رد شد', crossTrade.status);

  /* ═════════════ C) CSRF کاربر ═════════════ */
  console.log('\n── ج) CSRF ──');
  {
    const noTok = await req('/api/journal/trades', { method: 'POST', body: { symbol: 'XAUUSD' } });
    ok(noTok.status === 403, 'نوشتن ژورنال بدون توکن CSRF → 403', noTok.status);
    const badTok = await req('/api/journal/trades', { method: 'POST', token: 'wrong-token', body: { symbol: 'XAUUSD' } });
    ok(badTok.status === 403, 'توکن CSRF غلط → 403', badTok.status);
    const noTokLogout = await req('/api/auth/logout', { method: 'POST' });
    ok(noTokLogout.status === 403, 'خروج بدون CSRF → 403', noTokLogout.status);
    /* حساب معتبر برای مهاجم بساز تا نوشتنِ درست هم سنجیده شود */
    const bAcc = await req('/api/journal/accounts', { method: 'POST', token: BUser.csrf, body: { name: 'حساب مهاجم', startingBalance: 2000 } });
    const okTrade = await req('/api/journal/trades', { method: 'POST', token: BUser.csrf, body: { id: 'trade_sec_b2', accountId: bAcc.data.account.id, entryDate: new Date().toISOString(), symbol: 'EURUSD', direction: 'sell', resultType: 'loss', amount: 20 } });
    ok(okTrade.status === 201, 'با توکن درست، نوشتن کار می‌کند', okTrade.status);
  }

  /* ═════════════ D) OTP ═════════════ */
  console.log('\n── د) کد یک‌بارمصرف ──');
  {
    /* سیلاب درخواست OTP برای یک شمارهٔ واقعی → سقف موبایل ۵ در ۱۰ دقیقه → 429 */
    let flood = 0;
    for (let i = 0; i < 7; i++) {
      const r = await req('/api/auth/otp/request', { method: 'POST', body: { mobile: BUser.mobile } });
      if (r.status === 429) { flood = r.status; break; }
    }
    ok(flood === 429, 'سیلاب OTP برای یک شماره → 429', flood || 'نرسید');
    /* brute-force کد: ۶ بار کد غلط → قفل. اگر ساخت چالش خودش با 429 بسته شود،
       یعنی سقف IP فعال است (خودِ سپر امنیتی) و همان هم پاس محسوب می‌شود. */
    const s = await req('/api/auth/signup', { method: 'POST', body: { name: 'تست بروت', mobile: '0937' + String(Date.now()).slice(-7), password: 'Sec#Test12345', acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true } });
    let last = 0;
    if (s.status === 429) {
      ok(true, 'کد غلط محدود می‌شود (بعد از ۵ تلاش قفل)', 'ساخت چالش با سقف IP مسدود شد → 429');
    } else if (s.data.challengeToken) {
      for (let i = 0; i < 6; i++) {
        const r = await req('/api/auth/signup/verify', { method: 'POST', body: { challengeToken: s.data.challengeToken, code: '000000' } });
        last = r.status;
        if (r.status === 429) break;
      }
      ok(last === 429 || last === 400, 'کد غلط محدود می‌شود (بعد از ۵ تلاش قفل)', last);
    } else ok(false, 'ساخت چالش OTP برای تست بروت', JSON.stringify(s.data).slice(0, 80));
  }

  /* ═════════════ E) اعتبارسنجی ورودی ═════════════ */
  console.log('\n── هـ) پیمایش مسیر، تزریق، حجم ──');
  {
    const keys = [
      ['/api/journal/storage/..%2F..%2Fetc', 400], ['/api/journal/storage/pa-..%2Fx', 400],
      ['/api/journal/storage/PA-BAD-KEY-!!!', 400], ['/api/journal/storage/pa-%0d%0a-inject', 400],
    ];
    for (const [p, expect] of keys) {
      const r = await req(p, { method: 'GET' });
      ok(r.status === expect || r.status === 404, `کلید نامعتبر «${decodeURIComponent(p.split('/').pop())}» مسدود است`, r.status);
    }
    const r = await req('/api/journal/media/..%2F..%2Fetc%2Fpasswd', { method: 'GET' });
    ok(r.status === 404, 'پیمایش مسیر در تصویر → 404', r.status);
    const r2 = await req('/api/journal/media/file_../../etc', { method: 'GET' });
    ok(r2.status === 404, 'شناسهٔ تصویر جعلی → 404', r2.status);
    /* تزریق SQL در پارامترها */
    const sql = await req("/api/journal/trades?accountId=' OR 1=1--&limit=100", { method: 'GET' });
    ok(sql.status === 200 && Array.isArray(sql.data.rows), 'تزریق SQL در پارامتر بی‌اثر است (پارامتری)', sql.status);
    /* بدنهٔ حجیم */
    const big = await req('/api/auth/login', { method: 'POST', body: { mobile: '09120000000', password: 'x'.repeat(300000) } });
    ok(big.status === 413 || big.status === 400, 'بدنهٔ ۳۰۰ کیلوبایتی → ' + big.status, big.status);
    /* مقدار storage حجیم (۶ مگابایت) */
    const huge = await req('/api/journal/storage/pa-notes', { method: 'PUT', token: BUser.csrf, body: { value: JSON.stringify({ x: 'a'.repeat(6 * 1024 * 1024) }) } });
    ok(huge.status === 413, 'ذخیرهٔ ۶ مگابایتی خارج از pa-trades → 413', huge.status);
  }

  /* ═════════════ F) هدرها و نشت ═════════════ */
  console.log('\n── و) هدرهای امنیتی ──');
  {
    const home = await fetch(B + '/', { redirect: 'manual' });
    const h = home.headers;
    ok(/nosniff/i.test(h.get('x-content-type-options') || ''), 'X-Content-Type-Options: nosniff');
    ok(/max-age=31536000/i.test(h.get('strict-transport-security') || ''), 'HSTS فعال است', h.get('strict-transport-security'));
    ok(/no-referrer/i.test(h.get('referrer-policy') || ''), 'Referrer-Policy: no-referrer');
    ok(!h.get('x-powered-by'), 'X-Powered-By پنهان است');
    const admin = await fetch(B + '/admin', { redirect: 'follow' });
    ok(admin.status === 200, 'پوستهٔ پنل مدیریت (بدون داده) سرو می‌شود', admin.status);
    const mock = await fetch(B + '/admin/mock-api.js');
    ok(mock.status === 404, 'فایل دمویی mock-api.js در دسترس نیست', mock.status + ' (باید 404 باشد)');
    /* احراز هویت زمان‌دار: ورود با شمارهٔ موجود در برابر ناموجود (هر دو معتبر) */
    const existing = await req('/api/auth/login', { method: 'POST', body: { mobile: A.mobile, password: 'WrongPassword#1' } });
    const ghost = await req('/api/auth/login', { method: 'POST', body: { mobile: '0900' + String(Date.now()).slice(-7), password: 'WrongPassword#1' } });
    ok(existing.status === 401 && ghost.status === 401, 'پیام خطای یکسان برای شمارهٔ موجود/ناموجود', existing.status + '/' + ghost.status);
    note(`زمان پاسخ: موجود=${existing.ms}ms · ناموجود=${ghost.ms}ms (باید نزدیک هم باشند)`);
    ok(Math.abs(existing.ms - ghost.ms) < 300, 'زمان پاسخ برای موجود/ناموجود یکسان شد (ضد افشای کاربر)', existing.ms + 'ms / ' + ghost.ms + 'ms');
    /* کش نشدن اطلاعات حساس */
    const me = await req('/api/auth/me', { method: 'GET' });
    ok(/no-store/.test(me.headers.get('cache-control') || ''), 'پاسخ me با no-store سرو می‌شود', me.headers.get('cache-control'));
    const sess = await req('/api/auth/sessions', { method: 'GET' });
    ok(/no-store/.test(sess.headers.get('cache-control') || ''), 'پاسخ نشست‌ها با no-store سرو می‌شود', sess.headers.get('cache-control'));
  }

  /* ═════════════ G) XSS در مرورگر واقعی ═════════════ */
  console.log('\n── ز) XSS با مرورگر واقعی ──');
  {
    const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
    const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    const p = await br.newPage();
    const fired = [];
    await p.evaluateOnNewDocument(() => { window.__xssFired = []; });
    p.on('dialog', async d => { fired.push(d.message()); await d.dismiss(); });
    const cookie = jar.get('pa_user_session');
    if (cookie) await p.setCookie({ name: 'pa_user_session', value: cookie.split('=')[1], domain: '127.0.0.1', path: '/' });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await wait(4500);
    /* ۱) یادداشت XSS کاربر A نباید در صفحهٔ B اجرا شود (اصلاً دادهٔ A دیده نمی‌شود) */
    const aDataVisible = await p.evaluate(() => document.body.innerText.includes('حساب قربانی'));
    ok(!aDataVisible, 'دادهٔ کاربر قربانی در صفحهٔ مهاجم رندر نمی‌شود');
    /* ۲) دادهٔ XSS خودِ مهاجم (اگر ذخیره می‌کرد) — بررسی escape در رندر React */
    const p2 = await br.newPage();
    const jar2 = new Map();
    /* مهاجم خودش یک یادداشت XSS ذخیره می‌کند و صفحهٔ خودش را می‌بیند */
    const acc = await req('/api/journal/accounts', { method: 'GET' });
    if (acc.data.rows?.length) {
      await req('/api/journal/trades', { method: 'POST', token: BUser.csrf, body: { id: 'trade_sec_xss1', accountId: acc.data.rows[0].id, entryDate: new Date().toISOString(), symbol: 'XAUUSD', direction: 'buy', resultType: 'profit', amount: 15, notes: '<img src=x onerror=window.__xss=1>' } });
      const c2 = jar.get('pa_user_session');
      await p2.setCookie({ name: 'pa_user_session', value: c2.split('=')[1], domain: '127.0.0.1', path: '/' });
      await p2.goto(B + '/journal', { waitUntil: 'domcontentloaded', timeout: 60000 });
      await wait(4500);
      const xss = await p2.evaluate(() => window.__xss === 1 || !!document.querySelector('img[src="x"]'));
      ok(!xss, 'XSS ذخیره‌شده در یادداشت معامله اجرا نمی‌شود', xss ? 'اجرا شد!' : 'بی‌اثر ✓');
      /* ۳) تیکت با موضوع اسکریپتی — باز کردن پنجرهٔ پشتیبانی */
      const tkt = await req('/api/journal/support/tickets', { method: 'GET' });
      const myTkt = (tkt.data.rows || []).find(r => /xss/i.test(r.subject));
      if (myTkt) {
        const ok_ = await p2.evaluate(() => { const b = document.querySelector('.pa-support-launcher'); if (b) { b.click(); return true; } return false; });
        await wait(1500);
        const injected = await p2.evaluate(() => !!document.querySelector('.pa-ticket-card script') || window.__xss === 1);
        ok(!injected, 'موضوع اسکریپتی تیکت اجرا نمی‌شود', injected ? 'اجرا شد!' : 'بی‌اثر ✓');
      }
    }
    await br.close();
  }

  console.log('\n' + '═'.repeat(50));
  console.log(`نتیجه: ${okc}/${okc + badc} بررسی امنیتی پاس شد.`);
  console.log('یادداشت‌ها:');
  notes.forEach(n => console.log('  • ' + n));
  /* پاکسازی اثر خودِ تست: چالش‌های OTP که این مجموعه ساخت تا سقف IP برای
     اجراهای بعدی (و کاربران واقعی در محیط تست) پر نماند */
  try {
    const { db } = require(path.join(__dirname, '..', 'db.js'));
    const c = db.prepare('DELETE FROM user_otp_challenges').run();
    console.log(`\n  • چالش‌های OTP تستی پاک شد (${c.changes})`);
  } catch (e) {}
  process.exit(badc ? 1 : 0);
})().catch(e => { console.error('SECURITY SUITE FAILED:', e.stack || e); process.exit(1); });
