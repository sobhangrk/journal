'use strict';
/**
 * audit-browser.js — پیمایش مرورگری همهٔ صفحه‌های عمومی
 * برای هر صفحه در دو اندازهٔ دسکتاپ و موبایل بررسی می‌کند:
 *   • خطای JS و درخواست‌های ۴۰۰+
 *   • اسکرول افقی (سرریز چیدمان)
 *   • تصویر بدون alt، دکمهٔ بدون نام در دسترس‌پذیری
 *   • هدف لمسی کوچک‌تر از ۴۴px در موبایل
 *   • متن‌های خراب مثل undefined / NaN / [object Object]
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.BASE || 'http://127.0.0.1:3000';
const PAGES = ['/', '/pricing', '/faq', '/contact', '/about', '/quick-start', '/guides',
  '/guides/first-trade', '/guides/weekly-review', '/guides/risk-metrics', '/guides/trading-psychology',
  '/legal/terms', '/legal/privacy', '/legal/retention', '/legal/cookies', '/legal/dpa', '/legal/disclaimer'];
const VIEWS = [['دسکتاپ', 1440, 900], ['موبایل', 390, 844]];
const findings = [];

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  for (const [label, width, height] of VIEWS) {
    const page = await br.newPage();
    await page.setViewport({ width, height, isMobile: width < 700, deviceScaleFactor: 1 });
    for (const path of PAGES) {
      const errs = [], bad = [];
      const onErr = e => errs.push(String(e.message || e).slice(0, 160));
      const onRes = r => { if (r.status() >= 400) bad.push(r.status() + ' ' + r.url().replace(B, '')); };
      page.on('pageerror', onErr); page.on('response', onRes);
      page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 140)); });
      try {
        await page.goto(B + path, { waitUntil: 'networkidle2', timeout: 45000 });
      } catch (e) { findings.push([label, path, 'LOAD', e.message.slice(0, 100)]); continue; }
      await new Promise(r => setTimeout(r, 900));

      const report = await page.evaluate(() => {
        const out = {};
        out.overflow = Math.max(0, document.documentElement.scrollWidth - window.innerWidth);
        out.widest = null;
        if (out.overflow > 2) {
          let worst = null;
          document.querySelectorAll('*').forEach(el => {
            const r = el.getBoundingClientRect();
            if (r.width > 0 && r.right > window.innerWidth + 2 && (!worst || r.right > worst.right)) {
              worst = { right: Math.round(r.right), tag: el.tagName.toLowerCase(), cls: (el.className || '').toString().slice(0, 50) };
            }
          });
          out.widest = worst;
        }
        out.imgNoAlt = [...document.querySelectorAll('img:not([alt])')].map(i => i.src.split('/').pop()).slice(0, 5);
        const shown = el => { let n = el; while (n && n.nodeType === 1) { const c = getComputedStyle(n); if (c.visibility === 'hidden' || c.display === 'none' || c.opacity === '0') return false; n = n.parentElement; } return true; };
        out.namelessControls = [...document.querySelectorAll('button,a[href]')]
          .filter(el => el.getClientRects().length && shown(el) &&
            !(el.innerText || '').trim() && !el.getAttribute('aria-label') && !el.getAttribute('title'))
          .map(el => el.tagName.toLowerCase() + '.' + (el.className || '').toString().slice(0, 40)).slice(0, 5);
        /* لینک‌های داخل متن از قاعدهٔ ۴۴px مستثنا هستند (WCAG 2.5.8) */
        out.smallTargets = [...document.querySelectorAll('button,a[href],input,select')]
          .filter(el => shown(el) && !(el.tagName === 'A' && el.closest('p,li')))
          .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && (r.height < 32 || r.width < 24); })
          .map(el => el.tagName.toLowerCase() + '.' + (el.className || '').toString().slice(0, 30) + ' ' + Math.round(el.getBoundingClientRect().height) + 'px')
          .slice(0, 5);
        const text = document.body.innerText || '';
        out.badText = (text.match(/undefined|NaN|\[object Object\]|Infinity/g) || []).slice(0, 3);
        out.emptyHeadings = [...document.querySelectorAll('h1,h2,h3')].filter(h => !(h.innerText || '').trim()).length;
        out.h1 = document.querySelectorAll('h1').length;
        return out;
      });

      if (errs.length) findings.push([label, path, 'JS', [...new Set(errs)].join(' | ').slice(0, 200)]);
      if (bad.length) findings.push([label, path, 'REQ', [...new Set(bad)].join(' | ').slice(0, 200)]);
      if (report.overflow > 2) findings.push([label, path, 'OVERFLOW', report.overflow + 'px — ' + JSON.stringify(report.widest)]);
      if (report.imgNoAlt.length) findings.push([label, path, 'IMG-ALT', report.imgNoAlt.join(', ')]);
      if (report.namelessControls.length) findings.push([label, path, 'A11Y-NAME', report.namelessControls.join(', ')]);
      if (label === 'موبایل' && report.smallTargets.length) findings.push([label, path, 'TOUCH', report.smallTargets.join(', ')]);
      if (report.badText.length) findings.push([label, path, 'TEXT', report.badText.join(', ')]);
      if (report.emptyHeadings) findings.push([label, path, 'HEADING', report.emptyHeadings + ' تیتر خالی']);
      if (report.h1 !== 1) findings.push([label, path, 'H1', report.h1 + ' تگ h1']);

      page.off('pageerror', onErr); page.off('response', onRes);
    }
    await page.close();
  }
  await br.close();

  console.log('\n════════ یافته‌های مرورگری ════════');
  if (!findings.length) console.log('  هیچ مشکلی پیدا نشد.');
  findings.forEach(f => console.log(`  [${f[2]}] ${f[0]} ${f[1]}\n      ${f[3]}`));
  console.log('\nجمع: ' + findings.length + ' یافته در ' + PAGES.length + ' صفحه × ' + VIEWS.length + ' اندازه');
})();
