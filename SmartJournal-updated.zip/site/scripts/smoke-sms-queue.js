/**
 * smoke-sms-queue.js — رگرسیون «Job wait deliver timed out»
 *
 * باگ واقعی روی سرور کاربر: نصب‌کننده‌ی من QUEUE_ENABLED=true می‌گذاشت ولی
 * هیچ سرویسِ کارگری (worker) نصب نمی‌کرد. نتیجه:
 *   • «ارسال تست» در پنل کار می‌کرد (مستقیم صدا زده می‌شود)
 *   • ولی ثبت‌نام واقعی بعد از ۵۰ ثانیه با این خطا می‌افتاد:
 *       ارسال پیامک ناموفق بود: Job wait deliver timed out before finishing
 *
 * این تست دقیقاً همان وضعیت را می‌سازد: Redis روشن، صف روشن، کارگر خاموش —
 * و انتظار دارد ثبت‌نام با «ارسال مستقیم» موفق شود، نه اینکه بشکند.
 *
 * پیش‌نیاز: redis روی 6379 و شبیه‌ساز ملی‌پیامک روی 4556
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3100';
const FAKE = process.env.FAKE_MELI_URL || 'http://127.0.0.1:4556';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: jar.join('; ') };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const r = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(r); let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, data: d };
}
const inboxAll = async () => (await fetch(FAKE + '/inbox')).json();

(async () => {
  await fetch(FAKE + '/reset', { method: 'POST' });

  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const path = require('path');
  const dbPath = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'admin.db');
  const db = new Database(dbPath);
  const stamp = Date.now().toString(36);
  const username = 'qadmin' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_q_' + stamp, 'مدیر تست صف', username, '093' + String(Date.now()).slice(-8),
         bcrypt.hashSync('QAdmin@12345678', 10), new Date().toISOString());
  ['user_otp_challenges', 'sms_logs'].forEach(t => { try { db.prepare('DELETE FROM ' + t).run(); } catch {} });
  db.close();

  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'QAdmin@12345678' } });
  const csrf = login.data.csrfToken;
  ok('ورود مدیر', login.status === 200, 'status=' + login.status);

  const create = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'melipayamak', name: 'ملی‌پیامک صف ' + stamp, providerKey: 'qtest-' + stamp,
    priority: 1, unitCost: 150, isEnabled: true,
    config: { url: FAKE + '/api/SendSMS', template: '12345' },
    credentials: { username: 'sjuser', password: 'sjpass' } } });
  ok('درگاه ساخته شد', create.status === 201, JSON.stringify(create.data).slice(0, 100));
  await req(`/api/admin/sms/providers/${create.data.id}`, { method: 'PATCH', csrf, body: { makePrimary: true } });

  console.log('\n── ثبت‌نام واقعی وقتی صف روشن است ولی کارگری وجود ندارد ──');
  const mobile = '0991' + String(Date.now()).slice(-7);
  const started = Date.now();
  const signup = await fetch(BASE + '/api/auth/signup', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'کاربر صف', mobile, password: 'QUser@12345678', remember: true,
      acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false }),
  });
  const data = await signup.json().catch(() => ({}));
  const seconds = Math.round((Date.now() - started) / 1000);

  ok('ثبت‌نام با وجود نبودِ کارگر موفق شد (۲۰۲)', signup.status === 202,
     `status=${signup.status} · ${seconds}s · ${JSON.stringify(data).slice(0, 140)}`);
  ok('خطای «Job wait deliver timed out» دیده نمی‌شود',
     !/Job wait deliver timed out/i.test(JSON.stringify(data)));
  ok('سریع تسلیم شد و مستقیم فرستاد (نه انتظار ۵۰ ثانیه‌ای)', seconds < 10, seconds + ' ثانیه');

  const box = (await inboxAll()).rows;
  const last = box[box.length - 1] || {};
  ok('پیامک واقعاً به درگاه رسید', last.to === mobile, 'to=' + last.to);
  ok('از مسیر الگو رفت', last.method === 'BaseServiceNumber', 'method=' + last.method);

  const verify = await fetch(BASE + '/api/auth/signup/verify', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ challengeToken: data.challengeToken, code: String(last.text) }),
  });
  ok('کاربر با همان کد ثبت‌نامش کامل شد', verify.status === 201, 'status=' + verify.status);

  /* پاکسازی: اگر درگاه تست فعال بماند، تست‌های بعدی (auth/journal/trial) که
     به «کد توسعه» تکیه دارند می‌شکنند. یک‌بار این اتفاق افتاد. */
  await req(`/api/admin/sms/providers/${create.data.id}`, { method: 'DELETE', csrf, body: { force: true } });
  {
    const D = require('better-sqlite3');
    const d = new D(dbPath);
    d.prepare("DELETE FROM sms_providers WHERE provider_key LIKE 'qtest-%'").run();
    d.close();
  }
  ok('درگاه تست پاک شد و محیط تمیز ماند', true);

  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون صف پیامک پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nQUEUE SMOKE FAILED:', e.stack || e); process.exit(1); });
