'use strict';
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps, ImageChops
import math, random

# 1080x1920 High Resolution Marketing Share Card Canvas
W, H = 1080, 1920

# Create Deep Obsidian Dark Background
img = Image.new('RGBA', (W, H), (1, 4, 7, 255))

# --- STEP 1: Volumetric Studio Backdrop Spotlight ---
spotlight = Image.new('RGBA', (W, H), (0, 0, 0, 0))
sp_draw = ImageDraw.Draw(spotlight)

# Main Central Aura
for r in range(700, 0, -10):
    pct = 1.0 - (r / 700.0)
    alpha = int(120 * (pct ** 2.2))
    sp_draw.ellipse([W//2 - r, 720 - r, W//2 + r, 720 + r], fill=(15, 220, 120, alpha))

# Floor Lighting Stage Glow
for r in range(600, 0, -12):
    pct = 1.0 - (r / 600.0)
    alpha = int(90 * (pct ** 2.5))
    sp_draw.ellipse([W//2 - r, 1680 - r//2, W//2 + r, 1680 + r//2], fill=(10, 200, 110, alpha))

img = Image.alpha_composite(img, spotlight)
draw = ImageDraw.Draw(img)

# --- STEP 2: Glossy Studio Floor Stage & Perspective Grid ---
floor_y_start = 1400
floor_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
fl_draw = ImageDraw.Draw(floor_layer)

# Glossy Floor Dark Gradient Fill
for y in range(floor_y_start, H):
    dist = (y - floor_y_start) / float(H - floor_y_start)
    fl_draw.line([(0, y), (W, y)], fill=(int(2 + 8*(1-dist)), int(6 + 20*(1-dist)), int(10 + 15*(1-dist)), 255))

# 3D Perspective Grid
vanish_x, vanish_y = W//2, 1050
for i in range(-25, 26):
    x_bot = vanish_x + i * 95
    fl_draw.line([(vanish_x + i * 12, vanish_y), (x_bot, H)], fill=(29, 228, 123, 24), width=1)

for step in range(30):
    y = floor_y_start + int(12 * (1.16 ** step))
    if y >= H: break
    alpha = int(12 + 38 * (step / 30.0))
    fl_draw.line([(0, y), (W, y)], fill=(29, 228, 123, alpha), width=1)

img = Image.alpha_composite(img, floor_layer)
draw = ImageDraw.Draw(img)

# --- STEP 3: Background Candlesticks & Bokeh Sparks ---
chart_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
c_draw = ImageDraw.Draw(chart_layer)

# Left Background Candlesticks
left_candles = [
    (55, 600, 740, 620, 710),
    (90, 560, 700, 580, 670),
    (125, 520, 650, 540, 620),
    (160, 480, 600, 500, 570)
]
for x, top, bot, ctop, cbot in left_candles:
    c_draw.line([(x, top), (x, bot)], fill=(29, 228, 123, 85), width=2)
    c_draw.rectangle([x - 8, ctop, x + 8, cbot], fill=(29, 228, 123, 85))

# Right Background Candlesticks
right_candles = [
    (920, 880, 1020, 900, 990),
    (955, 800, 940, 820, 910),
    (990, 720, 860, 740, 830),
    (1025, 640, 780, 660, 750)
]
for x, top, bot, ctop, cbot in right_candles:
    c_draw.line([(x, top), (x, bot)], fill=(29, 228, 123, 95), width=2)
    c_draw.rectangle([x - 8, ctop, x + 8, cbot], fill=(29, 228, 123, 95))

chart_layer = chart_layer.filter(ImageFilter.GaussianBlur(1.8))
img = Image.alpha_composite(img, chart_layer)
draw = ImageDraw.Draw(img)

# Floating Light Sparks (Dust Particles)
sparks = Image.new('RGBA', (W, H), (0, 0, 0, 0))
s_draw = ImageDraw.Draw(sparks)
random.seed(101)
for _ in range(40):
    sx = random.randint(80, 1000)
    sy = random.randint(180, 1750)
    sr = random.randint(2, 5)
    sa = random.randint(50, 200)
    s_draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(29, 228, 123, sa))
sparks = sparks.filter(ImageFilter.GaussianBlur(1.2))
img = Image.alpha_composite(img, sparks)
draw = ImageDraw.Draw(img)

# --- FONTS SETUP ---
font_bold = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
font_reg = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

f_title = ImageFont.truetype(font_bold, 48)
f_sub = ImageFont.truetype(font_bold, 16)
f_symbol = ImageFont.truetype(font_bold, 54)
f_sym_sub = ImageFont.truetype(font_bold, 18)
f_label = ImageFont.truetype(font_bold, 20)
f_profit = ImageFont.truetype(font_bold, 98)
f_buy = ImageFont.truetype(font_bold, 44)
f_value = ImageFont.truetype(font_bold, 48)
f_unit = ImageFont.truetype(font_bold, 28)
f_handle = ImageFont.truetype(font_bold, 24)
f_footer = ImageFont.truetype(font_bold, 36)
f_domain = ImageFont.truetype(font_bold, 22)

# --- STEP 4: Render Main Glass Card Object ---
card_w, card_h = 720, 1120
card_img = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
cdraw = ImageDraw.Draw(card_img)

# Glass Slab Dark Tint Body
cdraw.rounded_rectangle([0, 0, card_w, card_h], radius=46, fill=(4, 15, 20, 242))

# Bevelled Refraction Edge Highlight
cdraw.rounded_rectangle([3, 3, card_w - 3, card_h - 3], radius=43, outline=(255, 255, 255, 22), width=2)

# Neon Glass Tube Border Stroke
cdraw.rounded_rectangle([0, 0, card_w, card_h], radius=46, outline=(29, 228, 123, 255), width=4)

# Glass Glossy Sheen Reflection Overlay
sheen = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
sh_draw = ImageDraw.Draw(sheen)
sh_draw.polygon([(0, 0), (360, 0), (0, 520)], fill=(255, 255, 255, 12))
cdraw.bitmap((0, 0), sheen, fill=None)

# --- INSIDE CARD CONTENT ---
cx_pad = 50
cy_pad = 50
inner_w = card_w - (cx_pad * 2)

# 1. Gold Symbol Badge
badge_cx, badge_cy = cx_pad + 50, cy_pad + 50
cdraw.ellipse([badge_cx - 48, badge_cy - 48, badge_cx + 48, badge_cy + 48], fill=(10, 28, 20, 255), outline=(212, 175, 55, 255), width=2)

# 3D Metallic Gold Bars
cdraw.polygon([(badge_cx - 24, badge_cy + 8), (badge_cx, badge_cy - 8), (badge_cx + 24, badge_cy + 8), (badge_cx, badge_cy + 24)], fill=(255, 215, 0))
cdraw.polygon([(badge_cx - 24, badge_cy + 8), (badge_cx, badge_cy + 24), (badge_cx, badge_cy + 34), (badge_cx - 24, badge_cy + 18)], fill=(212, 175, 55))
cdraw.polygon([(badge_cx, badge_cy + 24), (badge_cx + 24, badge_cy + 8), (badge_cx + 24, badge_cy + 18), (badge_cx, badge_cy + 34)], fill=(184, 134, 11))

cdraw.polygon([(badge_cx - 14, badge_cy - 8), (badge_cx + 8, badge_cy - 24), (badge_cx + 30, badge_cy - 8), (badge_cx + 8, badge_cy + 8)], fill=(255, 235, 100))
cdraw.polygon([(badge_cx - 14, badge_cy - 8), (badge_cx + 8, badge_cy + 8), (badge_cx + 8, badge_cy + 18), (badge_cx - 14, badge_cy + 2)], fill=(230, 184, 0))
cdraw.polygon([(badge_cx + 8, badge_cy + 8), (badge_cx + 30, badge_cy - 8), (badge_cx + 30, badge_cy + 2), (badge_cx + 8, badge_cy + 18)], fill=(199, 156, 0))

cdraw.text((cx_pad + 120, cy_pad + 18), "XAUUSD", font=f_symbol, fill=(255, 255, 255, 255))
cdraw.text((cx_pad + 120, cy_pad + 80), "GOLD / U.S. DOLLAR", font=f_sym_sub, fill=(100, 116, 139, 255))

cdraw.line([(cx_pad, cy_pad + 130), (cx_pad + inner_w, cy_pad + 130)], fill=(255, 255, 255, 22), width=1)

# 2. Profit Display
cur_y = cy_pad + 165
cdraw.text((cx_pad, cur_y), "PROFIT", font=f_label, fill=(100, 116, 139, 255))

cur_y += 38
# Text Glow Effect for Amount
profit_glow = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
pg_draw = ImageDraw.Draw(profit_glow)
pg_draw.text((cx_pad, cur_y), "+$68.17", font=f_profit, fill=(29, 228, 123, 255))
profit_glow = profit_glow.filter(ImageFilter.GaussianBlur(10))
card_img = Image.alpha_composite(card_img, profit_glow)
cdraw = ImageDraw.Draw(card_img)

cdraw.text((cx_pad, cur_y), "+$68.17", font=f_profit, fill=(29, 228, 123, 255))

# Sparkline Financial Chart
cur_y += 125
spark_pts = [
    (cx_pad, cur_y + 40),
    (cx_pad + 100, cur_y + 52),
    (cx_pad + 200, cur_y + 36),
    (cx_pad + 300, cur_y + 48),
    (cx_pad + 400, cur_y + 18),
    (cx_pad + 500, cur_y + 28),
    (cx_pad + inner_w, cur_y - 32)
]
for i in range(len(spark_pts) - 1):
    cdraw.line([spark_pts[i], spark_pts[i+1]], fill=(29, 228, 123, 255), width=4)

end_x, end_y = spark_pts[-1]
cdraw.ellipse([end_x - 12, end_y - 12, end_x + 12, end_y + 12], fill=(29, 228, 123, 130))
cdraw.ellipse([end_x - 6, end_y - 6, end_x + 6, end_y + 6], fill=(255, 255, 255, 255))

# 3. BUY Badge Button
cur_y += 75
buy_w, buy_h = inner_w, 96
cdraw.rounded_rectangle([cx_pad, cur_y, cx_pad + buy_w, cur_y + buy_h], radius=24, fill=(4, 38, 22, 240), outline=(29, 228, 123, 140), width=2)

chevron_x = cx_pad + buy_w//2 - 65
chevron_y = cur_y + buy_h//2
cdraw.line([(chevron_x - 18, chevron_y + 8), (chevron_x, chevron_y - 10), (chevron_x + 18, chevron_y + 8)], fill=(29, 228, 123, 255), width=5)
cdraw.line([(chevron_x - 18, chevron_y + 18), (chevron_x, chevron_y), (chevron_x + 18, chevron_y + 18)], fill=(29, 228, 123, 255), width=5)

cdraw.text((cx_pad + buy_w//2 + 30, cur_y + buy_h//2), "BUY", font=f_buy, fill=(29, 228, 123, 255), anchor="mm")

# 4. 2x2 Grid Container
cur_y += 130
grid_h = 360
cdraw.rounded_rectangle([cx_pad, cur_y, cx_pad + inner_w, cur_y + grid_h], radius=28, fill=(5, 17, 21, 210), outline=(255, 255, 255, 16), width=1)

mid_x = cx_pad + inner_w // 2
mid_y = cur_y + grid_h // 2
cdraw.line([(mid_x, cur_y + 20), (mid_x, cur_y + grid_h - 20)], fill=(255, 255, 255, 16), width=1)
cdraw.line([(cx_pad + 20, mid_y), (cx_pad + inner_w - 20, mid_y)], fill=(255, 255, 255, 16), width=1)

# Cell 1: VOLUME
cdraw.text((cx_pad + 40, cur_y + 35), "VOLUME", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((cx_pad + 40, cur_y + 90), "0.17", font=f_value, fill=(29, 228, 123, 255))
cdraw.text((cx_pad + 155, cur_y + 106), "LOT", font=f_unit, fill=(100, 116, 139, 255))

# Cell 2: RISK
cdraw.text((mid_x + 40, cur_y + 35), "RISK", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((mid_x + 40, cur_y + 90), "1%", font=f_value, fill=(29, 228, 123, 255))

# Cell 3: TIMEFRAME
cdraw.text((cx_pad + 40, mid_y + 35), "TIMEFRAME", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((cx_pad + 40, mid_y + 90), "15M", font=f_value, fill=(29, 228, 123, 255))

# Cell 4: Analog Clock Icon
clock_cx, clock_cy = mid_x + 160, mid_y + 90
cdraw.ellipse([clock_cx - 36, clock_cy - 36, clock_cx + 36, clock_cy + 36], outline=(29, 228, 123, 255), width=3)
cdraw.ellipse([clock_cx - 4, clock_cy - 4, clock_cx + 4, clock_cy + 4], fill=(255, 255, 255, 255))
cdraw.line([(clock_cx, clock_cy), (clock_cx - 12, clock_cy - 16)], fill=(29, 228, 123, 255), width=3)
cdraw.line([(clock_cx, clock_cy), (clock_cx + 18, clock_cy - 10)], fill=(29, 228, 123, 255), width=3)

# --- STEP 5: Render 3D Mirror Floor Reflection ---
card_pos_x = 180
card_pos_y = 250

reflection = card_img.transpose(Image.FLIP_TOP_BOTTOM)
mask = Image.new('L', (card_w, card_h), 0)
m_draw = ImageDraw.Draw(mask)
for y in range(card_h):
    alpha = int(125 * ((1.0 - y / float(card_h)) ** 1.8))
    m_draw.line([(0, y), (card_w, y)], fill=alpha)

reflection.putalpha(mask)
reflection = reflection.filter(ImageFilter.GaussianBlur(3.0))

img.alpha_composite(reflection, (card_pos_x, card_pos_y + card_h - 20))

# --- STEP 6: Card Outer Neon Tube Glow Aura ---
card_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
cg_draw = ImageDraw.Draw(card_glow)
cg_draw.rounded_rectangle([card_pos_x - 6, card_pos_y - 6, card_pos_x + card_w + 6, card_pos_y + card_h + 6], radius=50, outline=(29, 228, 123, 230), width=8)
card_glow = card_glow.filter(ImageFilter.GaussianBlur(18))
img = Image.alpha_composite(img, card_glow)
draw = ImageDraw.Draw(img)

# Composite Glass Card Body
img.alpha_composite(card_img, (card_pos_x, card_pos_y))

# --- STEP 7: Top Branding Header ---
s_cx, s_cy = W//2, 100
draw.polygon([(s_cx - 22, s_cy - 28), (s_cx + 16, s_cy - 28), (s_cx + 26, s_cy - 14), (s_cx - 4, s_cy - 2), (s_cx - 22, s_cy + 6)], fill=(29, 228, 123, 255))
draw.polygon([(s_cx + 22, s_cy + 28), (s_cx - 16, s_cy + 28), (s_cx - 26, s_cy + 14), (s_cx + 4, s_cy + 2), (s_cx + 22, s_cy - 6)], fill=(29, 228, 123, 255))

draw.text((W//2, 150), "SmartJournal", font=f_title, fill=(255, 255, 255, 255), anchor="mm")
draw.text((W//2, 192), "T R A D I N G   J O U R N A L", font=f_sub, fill=(100, 116, 139, 255), anchor="mm")

# --- STEP 8: Floating Trader Handle Badge ---
handle_y = card_pos_y + card_h + 80
handle_w, handle_h = 320, 64
handle_x = W//2 - handle_w//2

# Shadow
h_shadow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
hs_draw = ImageDraw.Draw(h_shadow)
hs_draw.rounded_rectangle([handle_x - 4, handle_y - 4, handle_x + handle_w + 4, handle_y + handle_h + 4], radius=34, fill=(0, 0, 0, 180))
h_shadow = h_shadow.filter(ImageFilter.GaussianBlur(8))
img = Image.alpha_composite(img, h_shadow)
draw = ImageDraw.Draw(img)

draw.rounded_rectangle([handle_x, handle_y, handle_x + handle_w, handle_y + handle_h], radius=32, fill=(6, 18, 23, 235), outline=(29, 228, 123, 90), width=1)

u_cx, u_cy = handle_x + 70, handle_y + handle_h//2
draw.ellipse([u_cx - 10, u_cy - 14, u_cx + 10, u_cy + 6], outline=(255, 255, 255, 255), width=2)
draw.arc([u_cx - 18, u_cy + 2, u_cx + 18, u_cy + 22], start=180, end=360, fill=(255, 255, 255, 255), width=2)

draw.text((handle_x + 180, handle_y + handle_h//2), "@trader_pro", font=f_handle, fill=(255, 255, 255, 255), anchor="mm")

# Hanging Light Bead
dot_y = handle_y + 100
dot_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
dg_draw = ImageDraw.Draw(dot_glow)
for r in range(18, 0, -2):
    alpha = int(200 * (1 - r / 18.0))
    dg_draw.ellipse([W//2 - r, dot_y - r, W//2 + r, dot_y + r], fill=(29, 228, 123, alpha))
dot_glow = dot_glow.filter(ImageFilter.GaussianBlur(3))
img = Image.alpha_composite(img, dot_glow)
draw = ImageDraw.Draw(img)

draw.ellipse([W//2 - 3, dot_y - 3, W//2 + 3, dot_y + 3], fill=(255, 255, 255, 255))

# --- STEP 9: High-Converting Marketing Footer ---
footer_y = H - 120
s_cx, s_cy = W//2 - 120, footer_y
draw.polygon([(s_cx - 12, s_cy - 15), (s_cx + 8, s_cy - 15), (s_cx + 15, s_cy - 7), (s_cx - 3, s_cy - 1), (s_cx - 12, s_cy + 3)], fill=(29, 228, 123, 255))
draw.polygon([(s_cx + 12, s_cy + 15), (s_cx - 8, s_cy + 15), (s_cx - 15, s_cy + 7), (s_cx + 3, s_cy + 1), (s_cx + 12, s_cy - 3)], fill=(29, 228, 123, 255))

draw.text((W//2 + 10, footer_y), "SmartJournal", font=f_footer, fill=(255, 255, 255, 255), anchor="mm")

# Globe Icon + smarttradejournal.ir
globe_y = footer_y + 45
g_cx = W//2 - 140
draw.ellipse([g_cx - 12, globe_y - 12, g_cx + 12, globe_y + 12], outline=(29, 228, 123, 255), width=2)
draw.line([(g_cx - 12, globe_y), (g_cx + 12, globe_y)], fill=(29, 228, 123, 255), width=1)
draw.ellipse([g_cx - 6, globe_y - 12, g_cx + 6, globe_y + 12], outline=(29, 228, 123, 255), width=1)

draw.text((W//2 + 10, globe_y), "smarttradejournal.ir", font=f_domain, fill=(29, 228, 123, 255), anchor="mm")

# Save Deliverable Image
img.save('/home/user/smartjournal-story-card.png', 'PNG')
print('Successfully saved marketing share card deliverable /home/user/smartjournal-story-card.png')
