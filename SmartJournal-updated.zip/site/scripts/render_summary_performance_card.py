'use strict';
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps, ImageChops
import math, random

# 1080x1920 Premium Summary Card Render Canvas
W, H = 1080, 1920

# Load Actual Site Logo
logo_path = '/home/user/site/public/media/smartjournal-logo-512.png'
site_logo = Image.open(logo_path).convert('RGBA')

# Base Obsidian Charcoal Image
img = Image.new('RGBA', (W, H), (1, 3, 6, 255))

# --- STEP 1: Dual-Tone Studio Lighting & Volumetric Atmosphere ---
spotlight = Image.new('RGBA', (W, H), (0, 0, 0, 0))
sp_draw = ImageDraw.Draw(spotlight)

# Main Cyan-Mint Central Aura
for r in range(820, 0, -8):
    pct = 1.0 - (r / 820.0)
    alpha = int(150 * (pct ** 2.2))
    r_val = int(0 * pct)
    g_val = int(255 * pct)
    b_val = int(180 + 50 * (1-pct))
    sp_draw.ellipse([W//2 - r, 740 - r, W//2 + r, 740 + r], fill=(r_val, g_val, b_val, alpha))

# Floor Stage Ambient Lighting
for r in range(680, 0, -10):
    pct = 1.0 - (r / 680.0)
    alpha = int(120 * (pct ** 2.5))
    sp_draw.ellipse([W//2 - r, 1680 - r//2, W//2 + r, 1680 + r//2], fill=(0, 240, 150, alpha))

img = Image.alpha_composite(img, spotlight)
draw = ImageDraw.Draw(img)

# --- STEP 2: Studio Floor Stage & 3D Perspective Grid ---
floor_horizon = 1380
floor_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
fl_draw = ImageDraw.Draw(floor_layer)

for y in range(floor_horizon, H):
    dist = (y - floor_horizon) / float(H - floor_horizon)
    fl_draw.line([(0, y), (W, y)], fill=(int(1 + 8*(1-dist)), int(5 + 24*(1-dist)), int(10 + 20*(1-dist)), 255))

vanish_x, vanish_y = W//2, 1050
for i in range(-25, 26):
    x_bot = vanish_x + i * 95
    fl_draw.line([(vanish_x + i * 12, vanish_y), (x_bot, H)], fill=(0, 255, 180, 30), width=1)

for step in range(30):
    y = floor_horizon + int(12 * (1.16 ** step))
    if y >= H: break
    alpha = int(12 + 50 * (step / 30.0))
    fl_draw.line([(0, y), (W, y)], fill=(0, 255, 180, alpha), width=1)

img = Image.alpha_composite(img, floor_layer)
draw = ImageDraw.Draw(img)

# --- STEP 3: Background Candlesticks & Floating Bokeh Sparks ---
chart_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
c_draw = ImageDraw.Draw(chart_layer)

left_candles = [
    (55, 600, 740, 620, 710),
    (90, 560, 700, 580, 670),
    (125, 520, 650, 540, 620),
    (160, 480, 600, 500, 570)
]
for x, top, bot, ctop, cbot in left_candles:
    c_draw.line([(x, top), (x, bot)], fill=(0, 255, 180, 100), width=2)
    c_draw.rectangle([x - 8, ctop, x + 8, cbot], fill=(0, 255, 180, 100))

right_candles = [
    (920, 880, 1020, 900, 990),
    (955, 800, 940, 820, 910),
    (990, 720, 860, 740, 830),
    (1025, 640, 780, 660, 750)
]
for x, top, bot, ctop, cbot in right_candles:
    c_draw.line([(x, top), (x, bot)], fill=(0, 255, 180, 110), width=2)
    c_draw.rectangle([x - 8, ctop, x + 8, cbot], fill=(0, 255, 180, 110))

chart_layer = chart_layer.filter(ImageFilter.GaussianBlur(1.8))
img = Image.alpha_composite(img, chart_layer)
draw = ImageDraw.Draw(img)

sparks = Image.new('RGBA', (W, H), (0, 0, 0, 0))
s_draw = ImageDraw.Draw(sparks)
random.seed(555)
for _ in range(60):
    sx = random.randint(50, 1030)
    sy = random.randint(120, 1820)
    sr = random.randint(2, 7)
    sa = random.randint(70, 250)
    s_draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(0, 255, 190, sa))
sparks = sparks.filter(ImageFilter.GaussianBlur(1.2))
img = Image.alpha_composite(img, sparks)
draw = ImageDraw.Draw(img)

# FONTS SETUP
font_bold = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
font_reg = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

f_title = ImageFont.truetype(font_bold, 48)
f_sub = ImageFont.truetype(font_bold, 16)
f_sym_sub = ImageFont.truetype(font_bold, 18)
f_label = ImageFont.truetype(font_bold, 20)
f_profit = ImageFont.truetype(font_bold, 92)
f_value = ImageFont.truetype(font_bold, 48)
f_unit = ImageFont.truetype(font_bold, 28)
f_handle = ImageFont.truetype(font_bold, 24)
f_footer = ImageFont.truetype(font_bold, 36)
f_domain = ImageFont.truetype(font_bold, 22)

# --- STEP 4: Render Summary Glass Card Object ---
card_w, card_h = 730, 1100
card_img = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
cdraw = ImageDraw.Draw(card_img)

cdraw.rounded_rectangle([0, 0, card_w, card_h], radius=48, fill=(4, 18, 24, 248))
cdraw.rounded_rectangle([3, 3, card_w - 3, card_h - 3], radius=45, outline=(255, 255, 255, 30), width=2)
cdraw.rounded_rectangle([0, 0, card_w, card_h], radius=48, outline=(0, 255, 180, 255), width=4)

sheen = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
sh_draw = ImageDraw.Draw(sheen)
sh_draw.polygon([(0, 0), (420, 0), (0, 580)], fill=(255, 255, 255, 20))
cdraw.bitmap((0, 0), sheen, fill=None)

cx_pad = 50
cy_pad = 50
inner_w = card_w - (cx_pad * 2)

# 1. Summary Badge Header
badge_cx, badge_cy = cx_pad + 50, cy_pad + 50
cdraw.ellipse([badge_cx - 48, badge_cy - 48, badge_cx + 48, badge_cy + 48], fill=(10, 28, 20, 255), outline=(0, 255, 180, 255), width=2)

# Trophy / Star Performance Icon inside Badge
cdraw.polygon([(badge_cx, badge_cy - 22), (badge_cx + 8, badge_cy - 6), (badge_cx + 24, badge_cy - 4), (badge_cx + 12, badge_cy + 8), (badge_cx + 16, badge_cy + 24), (badge_cx, badge_cy + 14), (badge_cx - 16, badge_cy + 24), (badge_cx - 12, badge_cy + 8), (badge_cx - 24, badge_cy - 4), (badge_cx - 8, badge_cy - 6)], fill=(255, 215, 0))

cdraw.text((cx_pad + 120, cy_pad + 18), "PERFORMANCE", font=f_title, fill=(255, 255, 255, 255))
cdraw.text((cx_pad + 120, cy_pad + 80), "TRADING SUMMARY & STATS", font=f_sym_sub, fill=(100, 116, 139, 255))

cdraw.line([(cx_pad, cy_pad + 130), (cx_pad + inner_w, cy_pad + 130)], fill=(255, 255, 255, 22), width=1)

# 2. Net Profit Display
cur_y = cy_pad + 165
cdraw.text((cx_pad, cur_y), "NET PROFIT / LOSS", font=f_label, fill=(100, 116, 139, 255))

cur_y += 38
profit_glow = Image.new('RGBA', (card_w, card_h), (0, 0, 0, 0))
pg_draw = ImageDraw.Draw(profit_glow)
pg_draw.text((cx_pad, cur_y), "+$4,825.50", font=f_profit, fill=(0, 255, 180, 255))
profit_glow = profit_glow.filter(ImageFilter.GaussianBlur(14))
card_img = Image.alpha_composite(card_img, profit_glow)
cdraw = ImageDraw.Draw(card_img)

cdraw.text((cx_pad, cur_y), "+$4,825.50", font=f_profit, fill=(0, 255, 180, 255))

# Equity Curve Chart Line
cur_y += 125
equity_pts = [
    (cx_pad, cur_y + 60),
    (cx_pad + 80, cur_y + 45),
    (cx_pad + 160, cur_y + 55),
    (cx_pad + 240, cur_y + 30),
    (cx_pad + 320, cur_y + 40),
    (cx_pad + 400, cur_y + 10),
    (cx_pad + 480, cur_y + 20),
    (cx_pad + inner_w, cur_y - 40)
]
for i in range(len(equity_pts) - 1):
    cdraw.line([equity_pts[i], equity_pts[i+1]], fill=(0, 255, 180, 255), width=4)

end_x, end_y = equity_pts[-1]
cdraw.ellipse([end_x - 12, end_y - 12, end_x + 12, end_y + 12], fill=(0, 255, 180, 150))
cdraw.ellipse([end_x - 6, end_y - 6, end_x + 6, end_y + 6], fill=(255, 255, 255, 255))

# Sparkle Lens Flare ✨
flare_size = 18
cdraw.line([(end_x - flare_size, end_y), (end_x + flare_size, end_y)], fill=(255, 255, 255, 255), width=2)
cdraw.line([(end_x, end_y - flare_size), (end_x, end_y + flare_size)], fill=(255, 255, 255, 255), width=2)

# 3. 2x2 Performance Grid
cur_y += 80
grid_h = 440
cdraw.rounded_rectangle([cx_pad, cur_y, cx_pad + inner_w, cur_y + grid_h], radius=28, fill=(5, 17, 21, 210), outline=(255, 255, 255, 18), width=1)

mid_x = cx_pad + inner_w // 2
mid_y = cur_y + grid_h // 2
cdraw.line([(mid_x, cur_y + 20), (mid_x, cur_y + grid_h - 20)], fill=(255, 255, 255, 18), width=1)
cdraw.line([(cx_pad + 20, mid_y), (cx_pad + inner_w - 20, mid_y)], fill=(255, 255, 255, 18), width=1)

# Cell 1: WIN RATE
cdraw.text((cx_pad + 40, cur_y + 40), "WIN RATE", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((cx_pad + 40, cur_y + 110), "68.5%", font=f_value, fill=(0, 255, 180, 255))

# Cell 2: TOTAL TRADES
cdraw.text((mid_x + 40, cur_y + 40), "TOTAL TRADES", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((mid_x + 40, cur_y + 110), "124", font=f_value, fill=(255, 255, 255, 255))

# Cell 3: PROFIT FACTOR
cdraw.text((cx_pad + 40, mid_y + 40), "PROFIT FACTOR", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((cx_pad + 40, mid_y + 110), "2.45", font=f_value, fill=(0, 255, 180, 255))

# Cell 4: WINNING TRADES
cdraw.text((mid_x + 40, mid_y + 40), "WINNING TRADES", font=f_label, fill=(100, 116, 139, 255))
cdraw.text((mid_x + 40, mid_y + 110), "85 / 124", font=f_value, fill=(0, 255, 180, 255))

# --- STEP 5: Render 3D Mirror Floor Reflection ---
card_pos_x = 175
card_pos_y = 280

reflection = card_img.transpose(Image.FLIP_TOP_BOTTOM)
mask = Image.new('L', (card_w, card_h), 0)
m_draw = ImageDraw.Draw(mask)
for y in range(card_h):
    alpha = int(145 * ((1.0 - y / float(card_h)) ** 1.8))
    m_draw.line([(0, y), (card_w, y)], fill=alpha)

reflection.putalpha(mask)
reflection = reflection.filter(ImageFilter.GaussianBlur(3.0))

img.alpha_composite(reflection, (card_pos_x, card_pos_y + card_h - 20))

# --- STEP 6: Outer Neon Tube Glow Aura ---
card_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
cg_draw = ImageDraw.Draw(card_glow)
cg_draw.rounded_rectangle([card_pos_x - 6, card_pos_y - 6, card_pos_x + card_w + 6, card_pos_y + card_h + 6], radius=52, outline=(0, 255, 180, 250), width=8)
card_glow = card_glow.filter(ImageFilter.GaussianBlur(18))
img = Image.alpha_composite(img, card_glow)
draw = ImageDraw.Draw(img)

# Composite Glass Card Body
img.alpha_composite(card_img, (card_pos_x, card_pos_y))

# --- STEP 7: Top Branding Header ---
top_logo_size = 64
logo_top = site_logo.resize((top_logo_size, top_logo_size), Image.Resampling.LANCZOS)
top_logo_x = W//2 - top_logo_size//2
top_logo_y = 75
img.alpha_composite(logo_top, (top_logo_x, top_logo_y))

draw.text((W//2, 160), "SmartJournal", font=f_title, fill=(255, 255, 255, 255), anchor="mm")
draw.text((W//2, 202), "P E R F O R M A N C E   C A R D", font=f_sub, fill=(100, 116, 139, 255), anchor="mm")

# --- STEP 8: Floating Trader Handle Badge ---
handle_y = card_pos_y + card_h + 75
handle_w, handle_h = 320, 64
handle_x = W//2 - handle_w//2

h_shadow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
hs_draw = ImageDraw.Draw(h_shadow)
hs_draw.rounded_rectangle([handle_x - 4, handle_y - 4, handle_x + handle_w + 4, handle_y + handle_h + 4], radius=34, fill=(0, 0, 0, 180))
h_shadow = h_shadow.filter(ImageFilter.GaussianBlur(8))
img = Image.alpha_composite(img, h_shadow)
draw = ImageDraw.Draw(img)

draw.rounded_rectangle([handle_x, handle_y, handle_x + handle_w, handle_y + handle_h], radius=32, fill=(6, 18, 23, 235), outline=(0, 255, 180, 100), width=1)

u_cx, u_cy = handle_x + 70, handle_y + handle_h//2
draw.ellipse([u_cx - 10, u_cy - 14, u_cx + 10, u_cy + 6], outline=(255, 255, 255, 255), width=2)
draw.arc([u_cx - 18, u_cy + 2, u_cx + 18, u_cy + 22], start=180, end=360, fill=(255, 255, 255, 255), width=2)

draw.text((handle_x + 180, handle_y + handle_h//2), "@trader_pro", font=f_handle, fill=(255, 255, 255, 255), anchor="mm")

# Hanging Light Bead
dot_y = handle_y + 95
dot_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
dg_draw = ImageDraw.Draw(dot_glow)
for r in range(18, 0, -2):
    alpha = int(210 * (1 - r / 18.0))
    dg_draw.ellipse([W//2 - r, dot_y - r, W//2 + r, dot_y + r], fill=(0, 255, 180, alpha))
dot_glow = dot_glow.filter(ImageFilter.GaussianBlur(3))
img = Image.alpha_composite(img, dot_glow)
draw = ImageDraw.Draw(img)

draw.ellipse([W//2 - 3, dot_y - 3, W//2 + 3, dot_y + 3], fill=(255, 255, 255, 255))

# --- STEP 9: Bottom Branding Footer ---
footer_y = H - 120
footer_logo_size = 48
logo_footer = site_logo.resize((footer_logo_size, footer_logo_size), Image.Resampling.LANCZOS)
img.alpha_composite(logo_footer, (W//2 - 165, footer_y - 24))

draw.text((W//2 + 10, footer_y), "SmartJournal", font=f_footer, fill=(255, 255, 255, 255), anchor="mm")

globe_y = footer_y + 45
g_cx = W//2 - 140
draw.ellipse([g_cx - 12, globe_y - 12, g_cx + 12, globe_y + 12], outline=(0, 255, 180, 255), width=2)
draw.line([(g_cx - 12, globe_y), (g_cx + 12, globe_y)], fill=(0, 255, 180, 255), width=1)
draw.ellipse([g_cx - 6, globe_y - 12, g_cx + 6, globe_y + 12], outline=(0, 255, 180, 255), width=1)

draw.text((W//2 + 10, globe_y), "smarttradejournal.ir", font=f_domain, fill=(0, 255, 180, 255), anchor="mm")

# Save Summary Deliverable PNG
img.save('/home/user/smartjournal-summary-card.png', 'PNG')
print('Successfully saved summary performance card /home/user/smartjournal-summary-card.png')
