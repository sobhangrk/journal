'use strict';
/**
 * smoke-share-card.js — تست ساخت کارت تصویری معامله و کارنامه (Social Share Card)
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const SHARE_SRC = fs.readFileSync(path.join(ROOT, 'public', 'journal-share-card.js'), 'utf8');

const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

console.log('\n── تست قابلیت کارت تصویری استوری (Social Share Card) ──');

// Fake Canvas Context
function createFakeCanvas() {
  const calls = [];
  const ctx = {
    fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', direction: '',
    shadowColor: '', shadowBlur: 0, shadowOffsetY: 0,
    fillRect: (...args) => calls.push(['fillRect', args]),
    strokeRect: (...args) => calls.push(['strokeRect', args]),
    fillText: (...args) => calls.push(['fillText', args]),
    beginPath: () => calls.push(['beginPath']),
    closePath: () => calls.push(['closePath']),
    moveTo: (...args) => calls.push(['moveTo', args]),
    lineTo: (...args) => calls.push(['lineTo', args]),
    quadraticCurveTo: (...args) => calls.push(['quadraticCurveTo', args]),
    bezierCurveTo: (...args) => calls.push(['bezierCurveTo', args]),
    arc: (...args) => calls.push(['arc', args]),
    save: () => calls.push(['save']),
    restore: () => calls.push(['restore']),
    translate: (...args) => calls.push(['translate', args]),
    scale: (...args) => calls.push(['scale', args]),
    stroke: () => calls.push(['stroke']),
    fill: () => calls.push(['fill']),
    createLinearGradient: () => ({ addColorStop: () => {} }),
    createRadialGradient: () => ({ addColorStop: () => {} }),
  };
  return {
    width: 0, height: 0,
    getContext: () => ctx,
    toDataURL: () => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    _calls: calls
  };
}

const window = {
  document: {
    getElementById: () => null,
    createElement: () => ({ setAttribute: () => {}, appendChild: () => {}, style: {} }),
    head: { appendChild: () => {} },
    body: { appendChild: () => {} }
  },
  navigator: {},
  requestAnimationFrame: (fn) => fn()
};

const ctx = {
  window,
  document: window.document,
  navigator: window.navigator,
  requestAnimationFrame: window.requestAnimationFrame,
  console, Date, Number, String, Math, Object, Array, JSON
};

vm.createContext(ctx);
vm.runInContext(SHARE_SRC, ctx);

ok('توابع کارت تصویری روی window ثبت شده‌اند',
  typeof ctx.window.paDrawTradeCanvas === 'function' &&
  typeof ctx.window.paDrawSummaryCanvas === 'function' &&
  typeof ctx.window.paOpenShareModal === 'function' &&
  typeof ctx.window.paOpenShareSummaryModal === 'function'
);

const canvas = createFakeCanvas();
const sampleTrade = {
  symbol: 'XAUUSD', direction: 'buy', amount: 68.17, resultType: 'profit',
  positionSize: '0.17', timeframe: '15M', setupName: 'شکست سطح',
  entryDate: '2026-08-28T08:24:29.000Z'
};

ctx.window.paDrawTradeCanvas(canvas, sampleTrade, { ratio: 'story', theme: 'neon', traderHandle: '@trader_test' });
ok('ابعاد کارت استوری تکی صحیح است (1080x1920)', canvas.width === 1080 && canvas.height === 1920);
ok('متن‌ها و فونت‌ها روی بوم رسم شدند', canvas._calls.some(c => c[0] === 'fillText'));

const squareCanvas = createFakeCanvas();
ctx.window.paDrawTradeCanvas(squareCanvas, sampleTrade, { ratio: 'square', theme: 'gold' });
ok('ابعاد کارت مربعی پست صحیح است (1080x1080)', squareCanvas.width === 1080 && squareCanvas.height === 1080);

const summaryCanvas = createFakeCanvas();
const sampleTrades = [sampleTrade, { symbol: 'DJIUSD', direction: 'sell', amount: 100, resultType: 'loss' }];
ctx.window.paDrawSummaryCanvas(summaryCanvas, sampleTrades, { ratio: 'story', theme: 'emerald' });
ok('کارت استوری کارنامه/عملکرد رسم می‌شود (1080x1920)', summaryCanvas.width === 1080 && summaryCanvas.height === 1920);

const bad = R.filter(([c]) => !c).length;
console.log(`\n${R.length - bad}/${R.length} تست کارت تصویری با موفقیت پاس شد.`);
process.exit(bad ? 1 : 0);
