#!/bin/bash
# ============================================================================
#   SmartJournal — نصب کامل با یک دستور
#
#   روی سرور (به‌عنوان root) اجرا کنید:
#       bash quick-install.sh
#
#   خودش همه‌چیز را انجام می‌دهد:
#     نصب Node/PostgreSQL/Redis/Nginx · ساخت دیتابیس · باز کردن فایل zip
#     نصب وابستگی‌ها · پیدا کردن IP سرور · ساخت .env · اجرای سرویس
#
#   شما هیچ فایلی را دستی ویرایش نمی‌کنید.
# ============================================================================
set -u
LOG=/var/log/smartjournal-install.log
exec > >(tee -a "$LOG") 2>&1

APP_USER="smartjournal"
APP_DIR="/opt/smartjournal"
DB_NAME="smartjournal"
DB_USER="sjuser"

c_ok="\033[1;32m"; c_no="\033[1;31m"; c_hi="\033[1;36m"; c_off="\033[0m"
say()  { echo -e "\n${c_hi}▶ $*${c_off}"; }
ok()   { echo -e "  ${c_ok}✓${c_off} $*"; }
warn() { echo -e "  ${c_no}!${c_off} $*"; }
die()  { echo -e "\n${c_no}✗ خطا: $*${c_off}\n  گزارش کامل: $LOG"; exit 1; }

echo "==============================================="
echo "   نصب SmartJournal — $(date)"
echo "==============================================="

[ "$(id -u)" -eq 0 ] || die "باید با کاربر root اجرا شود.  دستور:  sudo bash $0"

# ------------------------------------------------- ۰) پیدا کردن فایل zip ---
say "پیدا کردن فایل نصب"
ZIP="${1:-}"
if [ -z "$ZIP" ]; then
  ZIP=$(ls -1t /root/SmartJournal-Platform.zip /tmp/SmartJournal-Platform.zip \
        ./SmartJournal-Platform.zip 2>/dev/null | head -1)
fi
[ -n "$ZIP" ] && [ -f "$ZIP" ] || die "فایل SmartJournal-Platform.zip پیدا نشد.
  اول از کامپیوتر خودتان آپلودش کنید:
      scp SmartJournal-Platform.zip root@$(hostname -I | awk '{print $1}'):/root/
  بعد دوباره همین اسکریپت را اجرا کنید."
ok "فایل پیدا شد: $ZIP"

# ------------------------------------------------------------ ۱) پیش‌نیاز ---
say "نصب پیش‌نیازها (چند دقیقه طول می‌کشد)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null || die "apt-get update ناموفق بود"
apt-get install -y curl ca-certificates gnupg unzip ufw build-essential python3 >/dev/null \
  || die "نصب ابزارهای پایه ناموفق بود"
ok "ابزارهای پایه"

if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1 || die "افزودن مخزن Node ناموفق بود"
  apt-get install -y nodejs >/dev/null || die "نصب Node ناموفق بود"
fi
ok "Node $(node -v)"

apt-get install -y postgresql postgresql-contrib >/dev/null || die "نصب PostgreSQL ناموفق بود"
systemctl enable --now postgresql >/dev/null 2>&1
ok "PostgreSQL"

apt-get install -y redis-server >/dev/null || die "نصب Redis ناموفق بود"
systemctl enable --now redis-server >/dev/null 2>&1
ok "Redis"

apt-get install -y nginx certbot python3-certbot-nginx >/dev/null || die "نصب Nginx ناموفق بود"
systemctl enable --now nginx >/dev/null 2>&1
ok "Nginx + Certbot"

# ------------------------------------------------------------ ۲) دیتابیس ---
say "ساخت دیتابیس"
DB_PASS="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 24)"
if sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1; then
  sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" >/dev/null
else
  sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" >/dev/null
fi
sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 \
  || sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" >/dev/null
sudo -u postgres psql -c "ALTER DATABASE ${DB_NAME} OWNER TO ${DB_USER};" >/dev/null
ok "دیتابیس ${DB_NAME} آماده است"

# --------------------------------------------------------- ۳) باز کردن کد ---
say "نصب کد برنامه"
id -u "$APP_USER" >/dev/null 2>&1 || useradd --system --create-home --shell /bin/bash "$APP_USER"
rm -rf /tmp/sj-unpack && mkdir -p /tmp/sj-unpack
unzip -q -o "$ZIP" -d /tmp/sj-unpack || die "باز کردن zip ناموفق بود"
SRC=$(find /tmp/sj-unpack -maxdepth 3 -name server.js -printf '%h\n' 2>/dev/null | head -1)
[ -n "$SRC" ] || die "داخل zip فایل server.js پیدا نشد"
mkdir -p "$APP_DIR"
cp -r "$SRC"/. "$APP_DIR"/
mkdir -p "$APP_DIR/data/uploads" /var/backups/smartjournal
chown -R "$APP_USER:$APP_USER" "$APP_DIR" /var/backups/smartjournal
ok "کد در $APP_DIR قرار گرفت"

say "نصب وابستگی‌های Node (طولانی‌ترین مرحله)"
cd "$APP_DIR" || die "ورود به $APP_DIR ناموفق"
if ! sudo -u "$APP_USER" npm ci --omit=dev --no-audit --no-fund; then
  warn "npm ci ناموفق بود؛ با رجیستری داخلی دوباره تلاش می‌کنم"
  sudo -u "$APP_USER" npm config set registry https://registry.npmmirror.com
  sudo -u "$APP_USER" npm ci --omit=dev --no-audit --no-fund || die "نصب وابستگی‌ها ناموفق بود"
fi
ok "وابستگی‌ها نصب شد"

# ------------------------------------------------------------- ۴) IP سرور ---
say "پیدا کردن آدرس سرور"
PUBIP=$(curl -s --max-time 8 https://api.ipify.org 2>/dev/null)
[ -z "$PUBIP" ] && PUBIP=$(curl -s --max-time 8 http://ifconfig.me 2>/dev/null)
[ -z "$PUBIP" ] && PUBIP=$(hostname -I | awk '{print $1}')
[ -n "$PUBIP" ] || die "IP سرور پیدا نشد"
ok "آدرس سرور: $PUBIP"

# --------------------------------------------------------------- ۵) .env ---
say "ساخت فایل تنظیمات"
ADMIN_PASS="$(openssl rand -base64 18 | tr -dc 'A-Za-z0-9' | head -c 14)Aa1@"
cat > "$APP_DIR/.env" <<ENVFILE
NODE_ENV=production
PORT=3000
HOST=127.0.0.1

DB_ENGINE=postgres
DATABASE_URL=postgres://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}
REDIS_URL=redis://127.0.0.1:6379
# صف پیامک/رسانه فقط برای بار سنگین لازم است و به یک سرویس جدا (worker) نیاز دارد.
# روی نصب تک‌سروری خاموش می‌ماند؛ ارسال پیامک همان لحظه و مستقیم انجام می‌شود.
# برای روشن کردنش:  bash scripts/install-worker.sh
QUEUE_ENABLED=false

APP_ENCRYPTION_KEY=$(openssl rand -base64 48 | tr -d '\n')
BACKUP_ENCRYPTION_KEY=$(openssl rand -base64 48 | tr -d '\n')
METRICS_TOKEN=$(openssl rand -hex 24)

UPLOAD_DIR=${APP_DIR}/data/uploads
SEED_DEMO_DATA=false
FREE_TRIAL_DAYS=7

# --- آدرس سایت: فعلاً با IP، بعد از خرید دامنه عوضش کنید ---
PUBLIC_BASE_URL=http://${PUBIP}
WEBAUTHN_RP_ID=${PUBIP}
WEBAUTHN_ORIGIN=http://${PUBIP}

# --- چون هنوز HTTPS نداریم؛ بعد از نصب دامنه این خط را پاک کنید ---
COOKIE_SECURE=false

# --- حساب مدیر ---
ADMIN_USERNAME=owner
ADMIN_MOBILE=09120000000
ADMIN_PASSWORD=${ADMIN_PASS}
SUPPORT_EMAIL=support@${PUBIP}
ENVFILE
chmod 600 "$APP_DIR/.env"
chown "$APP_USER:$APP_USER" "$APP_DIR/.env"
ok "تنظیمات با IP سرور نوشته شد"

# ------------------------------------------------- ۵.۵) هویت حقوقی ---
# بدون این سه مقدار، اسناد حقوقی در حالت production منتشر نمی‌شوند و
# ثبت‌نام کاربران با خطای «اسناد حقوقی منتشر نشده‌اند» قفل می‌ماند.
say "هویت حقوقی (برای باز شدن ثبت‌نام لازم است)"
if [ -n "${LEGAL_NAME:-}" ] && [ -n "${LEGAL_REG:-}" ] && [ -n "${LEGAL_ADDR:-}" ]; then
  cat >> "$APP_DIR/.env" <<LEGALENV
LEGAL_OPERATOR_NAME=${LEGAL_NAME}
LEGAL_OPERATOR_REGISTRATION=${LEGAL_REG}
LEGAL_OPERATOR_ADDRESS=${LEGAL_ADDR}
LEGALENV
  ok "هویت حقوقی از متغیرهای محیطی ثبت شد"
else
  warn "هویت حقوقی وارد نشده — ثبت‌نام کاربران فعلاً قفل می‌ماند."
  echo "     بعد از نصب این را اجرا کنید:"
  echo "       cd $APP_DIR && node scripts/publish-legal.js \\"
  echo "         --name \"نام شما\" --registration \"کد ملی\" --address \"نشانی\""
  echo "       systemctl restart smartjournal"
fi

# ------------------------------------------------------------- ۶) سرویس ---
say "ساخت و اجرای سرویس"
cat > /etc/systemd/system/smartjournal.service <<'UNIT'
[Unit]
Description=SmartJournal
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=smartjournal
WorkingDirectory=/opt/smartjournal
EnvironmentFile=/opt/smartjournal/.env
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable smartjournal >/dev/null 2>&1
systemctl restart smartjournal
sleep 6
systemctl is-active --quiet smartjournal \
  && ok "سرویس در حال اجراست" \
  || { warn "سرویس بالا نیامد — آخرین خطاها:"; journalctl -u smartjournal -n 25 --no-pager; die "اجرای سرویس ناموفق بود"; }

# --------------------------------------------------------------- ۷) Nginx ---
say "اتصال Nginx"
cat > /etc/nginx/sites-available/smartjournal <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    client_max_body_size 12M;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 120s;
    }
}
NGINX
ln -sf /etc/nginx/sites-available/smartjournal /etc/nginx/sites-enabled/smartjournal
rm -f /etc/nginx/sites-enabled/default
nginx -t >/dev/null 2>&1 && systemctl reload nginx || die "کانفیگ Nginx مشکل دارد"
ok "Nginx به برنامه وصل شد"

# ------------------------------------------------------------ ۸) فایروال ---
say "فایروال"
ufw allow OpenSSH >/dev/null 2>&1
ufw allow 80/tcp  >/dev/null 2>&1
ufw allow 443/tcp >/dev/null 2>&1
ufw --force enable >/dev/null 2>&1
ok "پورت‌های ۲۲، ۸۰ و ۴۴۳ باز است"

# ------------------------------------------------------------- ۹) تست‌ها ---
say "تست نهایی"
sleep 2
HOME_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1/ )
ADMIN_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1/admin )
[ "$HOME_CODE" = "200" ]  && ok "صفحه اصلی: $HOME_CODE"   || warn "صفحه اصلی: $HOME_CODE"
[ "$ADMIN_CODE" = "200" ] && ok "پنل مدیریت: $ADMIN_CODE" || warn "پنل مدیریت: $ADMIN_CODE"

SMS_CODE=$(timeout 20 curl -s -o /dev/null -w '%{http_code}' https://api.kavenegar.com/ 2>/dev/null)
if [ -n "$SMS_CODE" ] && [ "$SMS_CODE" != "000" ]; then
  SMS_MSG="✅ باز است (HTTP $SMS_CODE) — پیامک کار خواهد کرد"
else
  SMS_MSG="❌ بسته/تایم‌اوت — ثبت‌نام کاربران کار نمی‌کند!"
fi
echo -e "  درگاه پیامک: $SMS_MSG"

# -------------------------------------------------------------- ۱۰) خلاصه ---
cat > /root/smartjournal-info.txt <<INFO
=========================================================
  SmartJournal نصب شد — $(date)
=========================================================

  آدرس سایت    http://${PUBIP}
  ژورنال       http://${PUBIP}/journal
  پنل مدیریت   http://${PUBIP}/admin

  ورود مدیر
    نام کاربری : owner
    موبایل     : 09120000000
    رمز عبور   : ${ADMIN_PASS}

  دیتابیس
    نام / کاربر : ${DB_NAME} / ${DB_USER}
    رمز         : ${DB_PASS}

  درگاه پیامک : ${SMS_MSG}

---------------------------------------------------------
  دستورهای مفید
---------------------------------------------------------
  وضعیت   : systemctl status smartjournal
  لاگ زنده: journalctl -u smartjournal -f
  ری‌استارت: systemctl restart smartjournal
  تنظیمات : nano /opt/smartjournal/.env

---------------------------------------------------------
  بعد از خرید دامنه
---------------------------------------------------------
  1) رکورد A دامنه را به ${PUBIP} وصل کنید
  2) certbot --nginx -d yourdomain.ir -d www.yourdomain.ir
  3) nano /opt/smartjournal/.env
       PUBLIC_BASE_URL=https://yourdomain.ir
       WEBAUTHN_RP_ID=yourdomain.ir
       WEBAUTHN_ORIGIN=https://yourdomain.ir
       خط COOKIE_SECURE=false را پاک کنید
  4) systemctl restart smartjournal
=========================================================
INFO
chmod 600 /root/smartjournal-info.txt

echo ""
echo "==============================================="
echo -e "  ${c_ok}✅ نصب تمام شد${c_off}"
echo "==============================================="
echo ""
echo -e "   سایت شما:  ${c_hi}http://${PUBIP}${c_off}"
echo -e "   پنل مدیر:  ${c_hi}http://${PUBIP}/admin${c_off}"
echo ""
echo "   نام کاربری : owner"
echo "   رمز عبور   : ${ADMIN_PASS}"
echo ""
echo "   این اطلاعات ذخیره شد در:  /root/smartjournal-info.txt"
echo "==============================================="
