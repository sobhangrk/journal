#!/usr/bin/env python3
"""
Rebuild public/admin/index.html and public/index.html from the single-file
HTML exports, by de-inlining the shared assets.

The exports inline admin.css + admin.js + mock-api.js into one file. The mock
is what makes the panel fake, so the reconstructed admin shell links the real
assets and drops the mock entirely.
"""
import re
from pathlib import Path

UP = Path("/home/user/uploads")
OUT = Path("/home/user/platform/public")


def load(p):
    return Path(p).read_text(encoding="utf-8")


def find_tag_span(html, start_hint, tag):
    """Return (open_start, close_end) of the <tag> block containing start_hint."""
    open_start = html.rfind(f"<{tag}", 0, start_hint)
    close = html.find(f"</{tag}>", start_hint)
    if open_start < 0 or close < 0:
        raise SystemExit(f"could not locate <{tag}> around {start_hint}")
    return open_start, close + len(f"</{tag}>")


def replace_inlined(html, asset_text, replacement, tag, label):
    """Find the <tag> block that contains asset_text and swap it for replacement."""
    probe = asset_text.strip()[:120]
    idx = html.find(probe)
    if idx < 0:
        print(f"    · {label}: not inlined, skipped")
        return html, False
    a, b = find_tag_span(html, idx, tag)
    print(f"    · {label}: removed {(b - a) / 1024:.0f} KB of inlined code")
    return html[:a] + replacement + html[b:], True


# ---------------------------------------------------------------- admin shell
print("[admin] rebuilding public/admin/index.html")
html = load(UP / "SmartJournal-Admin.html")
admin_js = load(UP / "admin.js")
admin_css = load(UP / "admin.css")
mock_js = load(UP / "mock-api.js")
brand_js = load(UP / "smartjournal-brand.js")

html, _ = replace_inlined(html, admin_css, '<link rel="stylesheet" href="/admin/admin.css">', "style", "admin.css")
# the mock is dropped, not replaced — this is what makes the panel real
html, dropped = replace_inlined(html, mock_js, "", "script", "mock-api.js (DROPPED — panel becomes real)")
html, _ = replace_inlined(html, brand_js, '<script src="/smartjournal-brand.js" defer></script>', "script", "smartjournal-brand.js")
html, _ = replace_inlined(html, admin_js, '<script src="/admin/admin.js" defer></script>', "script", "admin.js")

if not dropped:
    raise SystemExit("!! mock-api.js was not found — refusing to ship a possibly-fake panel")

# the standalone export bolted a localStorage banking module onto the end;
# the real panel gets banking from the server instead.
for block_id in ("pa-banking-runtime", "pa-banking-styles"):
    s = html.find(f'<{"script" if "runtime" in block_id else "style"} id="{block_id}">')
    if s >= 0:
        tag = "script" if "runtime" in block_id else "style"
        e = html.find(f"</{tag}>", s) + len(f"</{tag}>")
        html = html[:s] + html[e:]
        print(f"    · removed standalone block #{block_id}")

# --- fix: آیکون‌ها به صورت base64 داخل HTML بودند (۲۲۷ کیلوبایت روی هر بار
#     باز کردن پنل) و لینک manifest هم نبود.
ADMIN_ICONS = ('<link rel="icon" type="image/png" sizes="192x192" href="/media/smartjournal-logo-192.png">\n'
               '<link rel="apple-touch-icon" href="/media/smartjournal-logo-192.png">\n')
_n_icon = 0
for _pat in (r'<link[^>]*rel="icon"[^>]*data:image/[^>]*>',
             r'<link[^>]*rel="apple-touch-icon"[^>]*data:image/[^>]*>',
             r'<link[^>]*rel="apple-touch-startup-image"[^>]*>'):
    html, _k = re.subn(_pat, '', html)
    _n_icon += _k
if _n_icon:
    html = html.replace("</title>", "</title>\n" + ADMIN_ICONS, 1)
    print(f"    · {_n_icon} آیکون base64 با فایل واقعی جایگزین شد")
_b64 = re.compile(r'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADAC[A-Za-z0-9+/=]+')
html, _k = _b64.subn('/media/smartjournal-logo-192.webp', html)
if _k:
    print(f"    · {_k} لوگوی base64 → /media/smartjournal-logo-192.webp")

# --- منوی «محتوای سایت و نظرات» (site-content CMS) که سرور اضافه‌اش کرده و در
#     export قدیمی وجود ندارد؛ اینجا تزریق می‌شود تا با هر rebuild از بین نرود.
SITECONTENT_NAV = ('<button class="nav-item" data-view="sitecontent">'
                   '<i data-icon="file"></i><span>محتوای سایت و نظرات</span></button>')
if 'data-view="sitecontent"' not in html:
    anchor = '<button class="nav-item" data-view="legal">'
    if anchor not in html:
        raise SystemExit("!! nav anchor for sitecontent not found")
    html = html.replace(anchor, SITECONTENT_NAV + "\n        " + anchor, 1)
    print("    · منوی «محتوای سایت و نظرات» اضافه شد")

# make sure nothing still references the mock
assert "PA_STANDALONE_MOCK" not in html, "mock reference survived"
for _needed in ('data-view="sitecontent"', 'data-view="banking"', '/admin/admin.js', '/admin/admin.css'):
    assert _needed in html, f"missing {_needed}"
(OUT / "admin" / "index.html").write_text(html, encoding="utf-8")
print(f"    → {(OUT / 'admin' / 'index.html').stat().st_size / 1024:.0f} KB shell\n")


# ----------------------------------------------------------------- public app
# public/index.html دیگر اینجا ساخته نمی‌شود.
#
# این بخش قبلاً فقط از SmartJournal-journal.html می‌ساخت، یعنی صفحه لندینگ و
# پنل ورود اصلاً داخلش نبود. حالا scripts/build-index.py هر سه export را با هم
# ادغام می‌کند و همه اصلاحات (مسیر /journal، فونت محلی، آیکون‌ها، منوی CMS و …)
# را اعمال می‌کند. اجرای دوباره کد قدیمی، آن فایل درست را خراب می‌کرد.
print("[site] public/index.html → `npm run build:index` (scripts/build-index.py)")
