'use strict';
/* ==========================================================================
   کارت‌به‌کارت + تبدیل WebP روی PostgreSQL واقعی (از طریق pg-mem)
   چون Production با Postgres بالا می‌آید، این مسیرها باید آنجا هم کار کنند.
   ========================================================================== */

const assert = require('node:assert/strict');
const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');
const { spawn } = require('node:child_process');
const sharp = require('sharp');

const root = path.resolve(__dirname, '..');
const uploadDir = path.join(root, '.tmp', `pg-cards-uploads-${process.pid}`);
let passed = 0;
const ok = (n) => { passed += 1; console.log('✓ ' + n); };

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); });
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function cookies(res) {
  const v = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie() : [res.headers.get('set-cookie')].filter(Boolean);
  return v.flatMap((x) => String(x).split(/,(?=\s*[^;,]+=)/)).map((x) => x.trim().split(';')[0]).join('; ');
}

(async () => {
  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  fs.mkdirSync(uploadDir, { recursive: true });

  const child = spawn(process.execPath, ['server.js'], {
    cwd: root,
    env: {
      ...process.env,
      NODE_ENV: 'development',
      DB_ENGINE: 'postgres',
      POSTGRES_EMBEDDED_TEST: 'true',
      PA_PG_SCHEMA: 'pa_journal',
      HOST: '127.0.0.1', PORT: String(port),
      SEED_DEMO_DATA: 'false',
      UPLOAD_DIR: uploadDir,
      APP_ENCRYPTION_KEY: 'postgres-cards-smoke-encryption-32-bytes',
      ADMIN_NAME: 'مالک', ADMIN_USERNAME: 'owner',
      ADMIN_MOBILE: '09120000000', ADMIN_PASSWORD: 'Owner-Test@12345',
      PUBLIC_BASE_URL: 'https://journal.test', SUPPORT_EMAIL: 'support@journal.test',
      REDIS_ENABLED: 'false', QUEUE_ENABLED: 'false', STORAGE_BACKEND: 'local',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let logs = '';
  child.stdout.on('data', (c) => { logs += c; });
  child.stderr.on('data', (c) => { logs += c; });

  async function request(url, { method = 'GET', body, session, status = 200 } = {}) {
    const headers = {};
    if (body !== undefined) {
      headers['content-type'] = 'application/json';
      if (session) headers['x-csrf-token'] = session.csrf;
    }
    if (session) headers.cookie = session.cookie;
    const res = await fetch(base + url, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch { data = text; }
    assert.equal(res.status, status, `${method} ${url}: ${res.status} ${JSON.stringify(data).slice(0, 220)}`);
    return { res, data };
  }

  try {
    for (let i = 0; i < 150; i++) {
      if (child.exitCode !== null) throw new Error(`server exited (${child.exitCode}): ${logs.slice(-2500)}`);
      try { if ((await fetch(base + '/api/health/live')).ok) break; } catch {}
      if (i === 149) throw new Error(`server never became ready: ${logs.slice(-2500)}`);
      await sleep(100);
    }
    const health = await request('/api/health/ready');
    assert.equal(health.data.dependencies.database.engine, 'postgres');
    ok('سرور روی PostgreSQL بالا آمد');

    // ---- the card/receipt tables must be created on Postgres too ----
    const adminLogin = await request('/api/admin/login', {
      method: 'POST', body: { identifier: 'owner', password: 'Owner-Test@12345' },
    });
    let admin = { cookie: cookies(adminLogin.res), csrf: adminLogin.data.csrfToken };
    // owner must clear MFA first
    const setup = await request('/api/admin/mfa/totp/setup', { method: 'POST', body: {}, session: admin });
    const crypto = require('node:crypto');
    const b32 = (v) => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
      let bits = '';
      for (const ch of String(v).replace(/=+$/, '').toUpperCase()) bits += chars.indexOf(ch).toString(2).padStart(5, '0');
      const out = [];
      for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
      return Buffer.from(out);
    };
    const totp = (secret) => {
      const counter = Buffer.alloc(8);
      counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 30000)));
      const d = crypto.createHmac('sha1', b32(secret)).update(counter).digest();
      const o = d[d.length - 1] & 15;
      return String((d.readUInt32BE(o) & 0x7fffffff) % 1e6).padStart(6, '0');
    };
    await request('/api/admin/mfa/totp/verify', {
      method: 'POST', body: { code: totp(setup.data.secret) }, session: admin,
    });
    ok('ورود مدیر و عبور از MFA روی PostgreSQL');

    const card = await request('/api/admin/bank-cards', {
      method: 'POST', session: admin, status: 201,
      body: { bankName: 'بانک ملت', holder: 'اسمارت ژورنال', cardNumber: '6104337812345674' },
    });
    ok('جدول bank_cards روی PostgreSQL ساخته شد و کارت ثبت شد');

    // ---- the summary query (the one that used SUM(boolean)) ----
    const summary = await request('/api/admin/receipts-summary', { session: admin });
    assert.equal(typeof summary.data.pending, 'number');
    assert.equal(typeof summary.data.revenue, 'number');
    ok('کوئری خلاصه‌ی فیش‌ها روی PostgreSQL اجرا شد (SUM(boolean) رفع شد)');

    // ---- a real user submits a receipt ----
    const mobile = '097' + String(Date.now()).slice(-8);
    const signup = await request('/api/auth/signup', {
      method: 'POST', status: 202,
      body: {
        name: 'کاربر PG', mobile, password: 'Postgres@12345', remember: true,
        acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false,
      },
    });
    const verified = await request('/api/auth/signup/verify', {
      method: 'POST', status: 201,
      body: { challengeToken: signup.data.challengeToken, code: signup.data.devCode },
    });
    const user = { cookie: cookies(verified.res), csrf: verified.data.csrfToken };

    const cards = await request('/api/billing/bank-cards', { session: user });
    assert.equal(cards.data.rows.length, 1);
    ok('کاربر شماره کارت را از PostgreSQL می‌بیند');

    const png = await sharp({ create: { width: 500, height: 320, channels: 3, background: { r: 10, g: 30, b: 50 } } })
      .png().toBuffer();
    const plans = await request('/api/public/plans');
    const paid = plans.data.rows.find((p) => Number(p.price_monthly) > 0);

    const receipt = await request('/api/billing/receipts', {
      method: 'POST', session: user, status: 201,
      body: { planId: paid.id, bankCardId: card.data.row.id, trackingCode: '۹۹۸۸۷۷۶۶',
              receipt: `data:image/png;base64,${png.toString('base64')}` },
    });
    ok('ثبت فیش روی PostgreSQL (با کد پیگیری فارسی)');

    const list = await request('/api/admin/receipts?status=pending&q=PG', { session: admin });
    ok('جستجوی فیش‌ها روی PostgreSQL کار کرد (LOWER/LIKE)');

    const mine = await request('/api/billing/receipts', { session: user });
    assert.equal(mine.data.rows[0].status, 'pending');
    ok('کاربر وضعیت فیش خود را می‌بیند');

    // ---- approve: transaction + payment row + subscription, all on Postgres ----
    const approved = await request(`/api/admin/receipts/${receipt.data.id}/approve`, {
      method: 'POST', session: admin, body: { days: 30, note: 'تایید PG' },
    });
    assert.match(approved.data.invoice, /^INV-CTC-/);
    ok(`تایید فیش داخل تراکنش PostgreSQL — فاکتور ${approved.data.invoice}`);

    const ent = await request('/api/journal/entitlements', { session: user });
    const planName = ent.data.plan?.name || ent.data.planName;
    assert.equal(String(planName), String(paid.name));
    ok('اشتراک کاربر روی PostgreSQL فعال شد');

    const after = await request('/api/admin/receipts-summary', { session: admin });
    assert.equal(after.data.approved, 1);
    assert.equal(after.data.revenue, Number(paid.price_monthly));
    ok('آمار درآمد روی PostgreSQL درست محاسبه شد');

    // ---- WebP conversion must also work on Postgres ----
    const media = await request('/api/journal/media', {
      method: 'POST', session: user, status: 201,
      body: { data: `data:image/png;base64,${png.toString('base64')}` },
    });
    const mid = media.data.id || media.data.fileId || (media.data.files && media.data.files[0]);
    const img = await fetch(`${base}/api/journal/media/${mid}`, { headers: { cookie: user.cookie } });
    assert.equal(img.headers.get('content-type'), 'image/webp');
    ok('تبدیل خودکار WebP روی PostgreSQL هم کار می‌کند');

    console.log(`\n${passed} آزمون PostgreSQL برای کارت‌به‌کارت و WebP پاس شد.`);
  } finally {
    child.kill('SIGTERM');
    await sleep(400);
    fs.rmSync(uploadDir, { recursive: true, force: true });
  }
})().catch((e) => { console.error('\n✗ ' + e.message); process.exit(1); });
