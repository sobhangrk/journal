#!/bin/bash
# ============================================================================
#   install-watchdog.sh — نصب زمان‌بند دیده‌بان خودکار (هر ۱۵ دقیقه)
#   اجرا روی سرور:  bash /opt/smartjournal/scripts/install-watchdog.sh
# ============================================================================
set -u
APP_DIR="${APP_DIR:-/opt/smartjournal}"
CRON_FILE="/etc/cron.d/smartjournal-watchdog"
NODE_BIN="$(command -v node || true)"

g=$'\033[1;32m'; r=$'\033[1;31m'; c=$'\033[1;36m'; o=$'\033[0m'

[ -n "$NODE_BIN" ] || NODE_BIN="$(ls /usr/bin/node /usr/local/bin/node 2>/dev/null | head -1 || true)"
if [ -z "$NODE_BIN" ]; then
  echo "${r}✗ node پیدا نشد — اول Node.js را نصب کنید.${o}"
  exit 1
fi
if [ ! -f "$APP_DIR/scripts/watchdog.js" ]; then
  echo "${r}✗ $APP_DIR/scripts/watchdog.js پیدا نشد — اول بستهٔ جدید را نصب کنید.${o}"
  exit 1
fi

mkdir -p /etc/cron.d
cat > "$CRON_FILE" <<EOF
# SmartJournal — دیده‌بان خودکار (سایت، پیامک، دیسک، SSL)
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
*/15 * * * * root cd $APP_DIR && $NODE_BIN scripts/watchdog.js >> /var/log/smartjournal-watchdog.log 2>&1
EOF
chmod 644 "$CRON_FILE"

if command -v systemctl >/dev/null 2>&1 && systemctl restart cron >/dev/null 2>&1; then
  echo "${g}✓ cron ری‌استارت شد${o}"
fi

echo "${g}✓ دیده‌بان نصب شد${o}: هر ۱۵ دقیقه اجرا می‌شود"
echo "  لاگ:  /var/log/smartjournal-watchdog.log"
echo
echo "${c}تست فوری (پیامک آزمایشی به شمارهٔ مدیر):${o}"
echo "  cd $APP_DIR && $NODE_BIN scripts/watchdog.js --test"
echo
echo "${c}وضعیت بدون ارسال پیامک:${o}"
echo "  cd $APP_DIR && $NODE_BIN scripts/watchdog.js --status"
