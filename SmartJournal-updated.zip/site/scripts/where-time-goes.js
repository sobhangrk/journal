#!/usr/bin/env node
'use strict';
/* کجای پاسخ صفحه اصلی وقت می‌برد؟ */
const fs = require('node:fs');
const zlib = require('node:zlib');
const path = require('node:path');

const file = path.resolve(__dirname, '..', 'public', 'index.html');
const raw = fs.readFileSync(file);
console.log(`  حجم خام index.html        ${(raw.length / 1048576).toFixed(2)} MB`);

// how long does the disk read take?
let t = process.hrtime.bigint();
for (let i = 0; i < 20; i++) fs.readFileSync(file, 'utf8');
console.log(`  خواندن از دیسک            ${(Number(process.hrtime.bigint() - t) / 1e6 / 20).toFixed(1)} ms`);

// how long does gzip take (what compression middleware does per request)?
for (const level of [1, 6, 9]) {
  t = process.hrtime.bigint();
  let out;
  for (let i = 0; i < 10; i++) out = zlib.gzipSync(raw, { level });
  const ms = Number(process.hrtime.bigint() - t) / 1e6 / 10;
  console.log(`  gzip level ${level}              ${ms.toFixed(1).padStart(6)} ms  →  ${(out.length / 1024).toFixed(0)} KB`);
}

t = process.hrtime.bigint();
const br = zlib.brotliCompressSync(raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5 } });
console.log(`  brotli q5                 ${(Number(process.hrtime.bigint() - t) / 1e6).toFixed(1).padStart(6)} ms  →  ${(br.length / 1024).toFixed(0)} KB`);

// the SEO string replace
const text = raw.toString('utf8');
t = process.hrtime.bigint();
for (let i = 0; i < 50; i++) text.replace('<!-- PA_SERVER_SEO -->', '<meta name="x">');
console.log(`  جایگزینی رشته SEO         ${(Number(process.hrtime.bigint() - t) / 1e6 / 50).toFixed(2)} ms`);

console.log('\n  → یعنی بیشتر وقت صرف فشرده‌سازی ۲ مگابایت HTML در هر درخواست می‌شود.');
console.log('    اگر خروجی فشرده cache شود، این هزینه فقط یک بار پرداخت می‌شود.');
