/**
 * dev-print-preview.js — یک حساب نمونه با معاملهٔ واقعی می‌سازد و خروجی
 * «چاپ گزارش» را به PDF و تصویر می‌گیرد تا بشود واقعاً نگاهش کرد.
 * فقط ابزار توسعه است، نه بخشی از محصول.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const OUT = process.env.OUT || 'shots/print-preview';
const w = ms => new Promise(r => setTimeout(r, ms));

function client() {
  const jar = [];
  return {
    jar,
    async post(p, b) {
      const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(b) });
      (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
      return { status: r.status, data: await r.json().catch(() => ({})) };
    },
  };
}

const SYMBOLS = ['XAUUSD', 'EURUSD', 'GBPJPY', 'US30', 'BTCUSD'];
const SETUPS = ['شکست رنج لندن', 'برگشت از اوردربلاک', 'ادامهٔ روند H4', 'پولبک به میانگین ۵۰'];
const EMO = ['آرام', 'مطمئن', 'بی‌حوصله', 'مضطرب'];
const MIST = ['ورود زودهنگام', 'جابه‌جایی حد ضرر', 'حجم بیش از حد', 'معامله انتقامی'];

function buildTrades(accountId) {
  const out = [];
  let seed = 7;
  const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
  for (let i = 0; i < 48; i++) {
    const dt = new Date();
    dt.setDate(dt.getDate() - Math.floor(i * 1.6));
    dt.setHours(9 + Math.floor(rnd() * 8), Math.floor(rnd() * 59), 0, 0);
    const win = rnd() > 0.42;
    const amount = Number(((win ? 1 : -1) * (40 + rnd() * 260)).toFixed(2));
    out.push({
      id: 'tr' + i.toString(36) + Math.floor(rnd() * 1e6).toString(36),
      accountId,
      symbol: SYMBOLS[Math.floor(rnd() * SYMBOLS.length)],
      direction: rnd() > 0.5 ? 'buy' : 'sell',
      entryDate: dt.toISOString().slice(0, 16),
      timeframe: ['5M', '15M', '1H', '4H'][Math.floor(rnd() * 4)],
      positionSize: (0.2 + rnd() * 1.4).toFixed(2),
      riskPercent: (0.5 + rnd() * 1.5).toFixed(2),
      plannedRR: (1.2 + rnd() * 2.4).toFixed(1),
      resultType: win ? 'profit' : 'loss',
      amount,
      commission: Number((rnd() * 4).toFixed(2)),
      swap: 0,
      riskFree: false,
      setupName: SETUPS[Math.floor(rnd() * SETUPS.length)],
      durationValue: String(10 + Math.floor(rnd() * 200)),
      durationUnit: 'minute',
      chartImageData: null, afterImageData: null, imageTags: [],
      pre: {
        followedSetup: rnd() > 0.25, rrAcceptable: rnd() > 0.2, sizeMatchesRisk: rnd() > 0.2,
        newsUpcoming: rnd() > 0.8, matchesPlan: rnd() > 0.25, checkedOtherTimeframes: rnd() > 0.35,
        emotionBefore: EMO[Math.floor(rnd() * EMO.length)], energyLevel: 1 + Math.floor(rnd() * 5),
        setupConfidence: 1 + Math.floor(rnd() * 5), motivations: [], psychStates: [],
      },
      post: {
        emotionAfter: EMO[Math.floor(rnd() * EMO.length)],
        executionQuality: 1 + Math.floor(rnd() * 5),
        mistakes: win ? [] : (rnd() > 0.5 ? [MIST[Math.floor(rnd() * MIST.length)]] : []),
        notes: win ? 'طبق پلن پیش رفت.' : 'زودتر از تأیید وارد شدم.',
      },
      createdAt: dt.toISOString(),
    });
  }
  return out.reverse();
}

(async () => {
  const mobile = '0913' + String(Date.now()).slice(-7);
  const a = client();
  const s = await a.post('/api/auth/signup', { name: 'رضا محمدی', mobile, password: 'Print@1111111', remember: true,
    acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  await a.post('/api/auth/signup/verify', { challengeToken: s.data.challengeToken, code: s.data.devCode });
  console.log('user:', mobile);

  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  const page = await browser.newPage();
  await page.setCacheEnabled(false);
  // Service Worker نسخهٔ قدیمی اسکریپت‌ها را سرو می‌کند و پیش‌نمایش را
  // گمراه‌کننده می‌کند؛ برای آزمون پاکش می‌کنیم.
  await page.evaluateOnNewDocument(() => {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.getRegistrations?.().then(rs => rs.forEach(r => r.unregister()));
      if (window.caches) caches.keys().then(ks => ks.forEach(k => caches.delete(k)));
    }
  });
  await page.setViewport({ width: 1440, height: 1100 });
  await page.setCookie(...a.jar.map(c => { const [n, ...v] = c.split('='); return { name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }; }));
  await page.goto(B + '/journal', { waitUntil: 'networkidle2' });
  await page.waitForSelector('#root');
  await w(3000);

  const accountId = 'acc' + Date.now().toString(36);
  const account = { id: accountId, name: 'حساب اصلی — FTMO 100K', broker: 'FTMO', initialBalance: 100000,
    currency: '$', createdAt: new Date().toISOString(), withdrawals: [] };
  const trades = buildTrades(accountId);

  await page.evaluate(async (acc, trs) => {
    await window.storage.set('pa-accounts', JSON.stringify([acc]));
    await window.storage.set('pa-trades', JSON.stringify(trs));
    await window.storage.set('pa-active-account', acc.id);
  }, account, trades);

  await page.goto(B + '/journal', { waitUntil: 'networkidle2' });
  await page.waitForSelector('#root');
  await w(4500);

  // چاپ باید در عرض واقعی کاغذ چیده شود، نه عرض دسکتاپ:
  // A4 منهای حاشیه‌های @page ≈ 749px در 96dpi.
  // تا وقتی داشبورد واقعاً رندر نشده چاپ نگیر، وگرنه صفحهٔ ورود در PDF می‌افتد.
  await page.waitForSelector('.pa-dash', { timeout: 30000 });
  await page.emulateMediaType('print');
  await page.setViewport({ width: 749, height: 1123 });
  await w(1800);
  // preferCSSPageSize تا @page خودِ استایل‌شیت (A4 + حاشیه‌ها) ملاک باشد،
  // وگرنه چیدمان با عرض viewport رندر می‌شود و پیش‌نمایش گمراه‌کننده است.
  await page.pdf({ path: OUT + '.pdf', printBackground: true, preferCSSPageSize: true });
  await page.screenshot({ path: OUT + '.png', fullPage: true, captureBeyondViewport: true });
  const probe = await page.evaluate(() => {
    const W = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('.pa-app *').forEach(e => {
      const b = e.getBoundingClientRect();
      if (b.width > 4 && (b.right > W + 2 || b.left < -2))
        bad.push((typeof e.className === 'string' ? e.className : e.tagName).slice(0, 50));
    });
    const chrome = ['.ctcu-fab', '.pa-support-launcher', '.pa-skip-link', '.pa-auth-userbar', '.pa-dash-hero', '.pa-period-print-row']
      .filter(s => { const e = document.querySelector(s); return e && getComputedStyle(e).display !== 'none'; });
    const f = document.querySelector('.ctcu-fab'), hm = document.querySelector('.pa-heatmap');
    const dark = c => { const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/); if (!m) return false; if (m[4] !== undefined && +m[4] < .5) return false; return (+m[1] + +m[2] + +m[3]) / 3 < 110 };
    const dbg = {
      media: matchMedia('print').matches,
      bodyH: document.body.scrollHeight,
      // هر بلوکی که روی کاغذ سفید، پس‌زمینهٔ تیره نگه داشته باشد
      darkBoxes: (() => {
        const out = [];
        document.querySelectorAll('.pa-dash *').forEach(e => {
          const b = e.getBoundingClientRect();
          if (b.width < 40 || b.height < 18) return;
          const cs = getComputedStyle(e);
          if (dark(cs.backgroundColor)) out.push((typeof e.className === 'string' ? e.className : e.tagName).slice(0, 46) + ' bg=' + cs.backgroundColor);
        });
        return [...new Set(out)].slice(0, 14);
      })(),
      chain: (() => { let n = document.querySelector('.pa-print-head'), o = []; while (n && n !== document.documentElement) { const c = getComputedStyle(n); o.push((n.id ? '#' + n.id : (typeof n.className === 'string' ? '.' + n.className.trim().split(/\s+/)[0] : n.tagName)) + ' d=' + c.display + ' v=' + c.visibility + ' o=' + c.opacity + ' cl=' + c.clipPath); n = n.parentElement } return o })() };
    return { dbg, overflow: [...new Set(bad)].slice(0, 8), visibleChrome: chrome,
      headFound: !!document.querySelector('.pa-print-head'),
      headVisible: !!document.querySelector('.pa-print-head') && getComputedStyle(document.querySelector('.pa-print-head')).display !== 'none' };
  });
  console.log('probe:', JSON.stringify(probe));
  await page.emulateMediaType('screen');
  console.log('written:', OUT + '.pdf', OUT + '.png');
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
