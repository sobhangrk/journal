#!/bin/bash
# ============================================================================
#   SmartJournal — کارگر صف (worker)
#
#   کِی لازم است؟  فقط وقتی QUEUE_ENABLED=true باشد.
#   روی نصب تک‌سروری اصلاً لازم نیست و پیشنهاد ما خاموش‌گذاشتن صف است.
#
#   اجرا:
#       bash scripts/install-worker.sh            # نصب سرویس کارگر
#       bash scripts/install-worker.sh --disable  # خاموش‌کردن صف (ساده‌ترین راه)
# ============================================================================
set -u
APP_DIR="${APP_DIR:-/opt/smartjournal}"
APP_USER="${APP_USER:-smartjournal}"
g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'
say(){ echo; echo "${c}▶ $*${o}"; }
ok(){ echo "  ${g}✓${o} $*"; }
warn(){ echo "  ${y}!${o} $*"; }
die(){ echo; echo "${r}✗ $*${o}"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "با root اجرا کنید:  sudo bash $0"
[ -f "$APP_DIR/.env" ] || die "$APP_DIR/.env پیدا نشد."

setenv(){ local k="$1" v="$2"
  if grep -q "^${k}=" "$APP_DIR/.env"; then sed -i "s#^${k}=.*#${k}=${v}#" "$APP_DIR/.env"
  else printf '%s=%s\n' "$k" "$v" >> "$APP_DIR/.env"; fi; }

# --------------------------------------------------------- خاموش‌کردن ----
if [ "${1:-}" = "--disable" ]; then
  say "خاموش‌کردن صف پیامک"
  cp "$APP_DIR/.env" "/root/env-backup-$(date +%s)"
  setenv QUEUE_ENABLED false
  systemctl disable --now smartjournal-worker >/dev/null 2>&1 && ok "سرویس کارگر متوقف شد" || true
  systemctl restart smartjournal
  sleep 5
  systemctl is-active --quiet smartjournal && ok "سرویس اصلی فعال است" || die "سرویس بالا نیامد"
  echo
  ok "صف خاموش شد؛ پیامک‌ها همان لحظه و مستقیم ارسال می‌شوند."
  exit 0
fi

# ------------------------------------------------------------- نصب -------
say "بررسی پیش‌نیازها"
grep -q '^REDIS_URL=' "$APP_DIR/.env" || die "REDIS_URL در .env نیست."
redis-cli ping >/dev/null 2>&1 && ok "Redis پاسخ می‌دهد" || die "Redis در دسترس نیست: systemctl status redis-server"

TOKEN=$(grep -oP '^INTERNAL_WORKER_TOKEN=\K.*' "$APP_DIR/.env" 2>/dev/null)
if [ -z "$TOKEN" ] || [ ${#TOKEN} -lt 24 ]; then
  TOKEN=$(openssl rand -hex 24)
  setenv INTERNAL_WORKER_TOKEN "$TOKEN"
  ok "توکن ارتباط داخلی ساخته شد"
else
  ok "توکن ارتباط داخلی از قبل موجود بود"
fi
PORT=$(grep -oP '^PORT=\K.*' "$APP_DIR/.env" 2>/dev/null); PORT="${PORT:-3000}"
setenv INTERNAL_APP_URL "http://127.0.0.1:${PORT}"
setenv QUEUE_ENABLED true
ok "تنظیمات .env به‌روزرسانی شد"

say "ساخت سرویس systemd"
cat > /etc/systemd/system/smartjournal-worker.service <<UNIT
[Unit]
Description=SmartJournal queue worker (SMS, media, maintenance)
After=network.target redis-server.service smartjournal.service
Requires=smartjournal.service

[Service]
Type=simple
User=${APP_USER}
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStart=/usr/bin/node ${APP_DIR}/worker.js
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
ok "سرویس smartjournal-worker ساخته شد"

say "راه‌اندازی"
systemctl restart smartjournal
sleep 4
systemctl enable --now smartjournal-worker >/dev/null 2>&1
sleep 4
if systemctl is-active --quiet smartjournal-worker; then
  ok "کارگر در حال اجراست"
else
  journalctl -u smartjournal-worker -n 20 --no-pager
  warn "کارگر بالا نیامد — با --disable صف را خاموش کنید تا سایت سالم بماند:"
  echo "      bash $0 --disable"
  exit 1
fi

say "تست"
systemctl is-active --quiet smartjournal && ok "سرویس اصلی فعال است" || warn "سرویس اصلی فعال نیست"
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1/)
[ "$code" = "200" ] && ok "سایت: $code" || warn "سایت: $code"

echo
echo "==============================================="
echo "  ${g}✅ کارگر صف نصب و فعال شد${o}"
echo "==============================================="
echo "   وضعیت : systemctl status smartjournal-worker"
echo "   لاگ‌ها : journalctl -u smartjournal-worker -f"
echo "   خاموش : bash $0 --disable"
echo
