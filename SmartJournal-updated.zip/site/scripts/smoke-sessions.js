'use strict';
/**
 * smoke-sessions.js — رگرسیون «سشن‌های معاملاتی درست نیستند»
 *
 * باگ: سشن با getHours() (ساعت محلی مرورگر) و مرزهای ثابتِ گرینویچی حساب
 * می‌شد؛ هم برای کاربر ایرانی جابه‌جا بود و هم DST را نمی‌دید.
 *
 * حالا هر سشن با ساعت کاری همان شهر و منطقهٔ زمانی واقعی‌اش سنجیده می‌شود.
 * این تست هم منطق را (بدون مرورگر) و هم رابط کاربری را (با مرورگر) می‌سنجد.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('node:assert/strict');

const SRC = path.join(__dirname, '..', 'src-html', 'index.combined.html');
const src = fs.readFileSync(SRC, 'utf8');
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

function grab(name) {
  const start = src.indexOf('\nfunction ' + name + '(');
  if (start < 0) throw new Error('تابع پیدا نشد: ' + name);
  return src.slice(start + 1, src.indexOf('\n}\n', start) + 3);
}
function grabConst(name, endToken) {
  const start = src.indexOf('\nconst ' + name + ' = ');
  if (start < 0) throw new Error('ثابت پیدا نشد: ' + name);
  return src.slice(start + 1, src.indexOf(endToken, start) + endToken.length);
}

const code = [
  grabConst('PA_SESSION_DEFS', '}];'),
  grabConst('PA_IMPORT_TZ_OPTIONS', '}];'),
  'const paZoneCache = {};',
  ...['paZoneParts', 'paZoneOffsetMinutes', 'paSessionsAt', 'Tg', 'paSessionRangeLocal', 'paNaiveToInstant',
    'paDigits', 'paKey', 'paNumber', 'paDate', 'paDirection', 'paResultSign', 'paBuildImportedTrade'].map(grab),
  'const xl = { pre: {}, post: {} };function Lu(){ return "id" + Math.random().toString(36).slice(2) }',
  'globalThis.PA_SESSION_DEFS = PA_SESSION_DEFS; globalThis.PA_IMPORT_TZ_OPTIONS = PA_IMPORT_TZ_OPTIONS;',
].join('\n');
const ctx = { console, Intl, Date, Number, String, Math, Object, Array, isNaN };
vm.createContext(ctx);
vm.runInContext(code, ctx, { filename: 'sessions.js' });

/* ── ۱) ساعت‌های واقعی بازار، تابستان و زمستان ───────────────────────── */
const cases = [
  ['2026-06-15T09:00:00Z', 'لندن', 'دوشنبه تابستان، ۱۰:۰۰ لندن'],
  ['2026-06-15T13:30:00Z', 'لندن-نیویورک', 'هم‌پوشانی لندن و نیویورک'],
  ['2026-06-15T06:30:00Z', 'توکیو', '۱۵:۳۰ توکیو، لندن هنوز بسته'],
  ['2026-06-15T18:00:00Z', 'نیویورک', 'لندن بسته شده'],
  ['2026-06-15T23:00:00Z', 'سیدنی', '۰۹:۰۰ سیدنی'],
  ['2026-06-15T03:00:00Z', 'سیدنی-توکیو', 'هم‌پوشانی سیدنی و توکیو'],
  ['2026-01-15T09:00:00Z', 'لندن', 'زمستان: ۰۹:۰۰ لندن'],
  ['2026-01-15T21:00:00Z', 'سیدنی-نیویورک', 'زمستان: سیدنی باز، نیویورک هنوز باز'],
  ['2026-06-13T12:00:00Z', 'بازار تعطیل', 'شنبه'],
  ['2026-06-14T20:00:00Z', 'بازار تعطیل', 'یکشنبه پیش از بازگشایی سیدنی'],
];
cases.forEach(([iso, expect, why]) => ok(`${iso} ⇐ ${expect}`, ctx.Tg(iso) === expect, why + ' · گرفته شد: ' + ctx.Tg(iso)));

/* باگ اصلی گزارش‌شده: ۱۰ صبح ایران نباید «لندن» باشد */
const tehranTen = new Date('2026-06-15T06:30:00Z'); // ۱۰:۰۰ تهران
ok('۱۰:۰۰ صبح به وقت ایران دیگر «لندن» برچسب نمی‌خورد', ctx.Tg(tehranTen) !== 'لندن', ctx.Tg(tehranTen));
const tehranFive = new Date('2026-06-15T13:30:00Z'); // ۱۷:۰۰ تهران
ok('۱۷:۰۰ به وقت ایران = هم‌پوشانی لندن-نیویورک (قبلاً «نیویورک» بود)', ctx.Tg(tehranFive) === 'لندن-نیویورک', ctx.Tg(tehranFive));

/* ── ۲) DST دقیقاً در مرز ───────────────────────────────────────────── */
ok('۳۰ مارس ۲۰۲۶، ۰۷:۳۰ UTC داخل سشن لندن است (BST)', ctx.Tg('2026-03-30T07:30:00Z').includes('لندن'), ctx.Tg('2026-03-30T07:30:00Z'));
ok('۰۷:۳۰ UTC در زمستان هنوز لندن باز نشده', ctx.Tg('2026-01-19T07:30:00Z') !== 'لندن', ctx.Tg('2026-01-19T07:30:00Z'));

/* ── ۳) تبدیل ساعت سرور بروکر ───────────────────────────────────────── */
const naive = new Date(2026, 5, 15, 12, 0, 0);              // ۱۲:۰۰ «به وقت سرور»
assert.equal(ctx.paNaiveToInstant(naive, 'local').getTime(), naive.getTime());
ok('حالت «همان ساعت دستگاه» چیزی را تغییر نمی‌دهد', true);
assert.equal(ctx.paNaiveToInstant(naive, 'utc+2').toISOString(), '2026-06-15T10:00:00.000Z');
assert.equal(ctx.paNaiveToInstant(naive, 'utc+3.5').toISOString(), '2026-06-15T08:30:00.000Z');
assert.equal(ctx.paNaiveToInstant(naive, 'utc-5').toISOString(), '2026-06-15T17:00:00.000Z');
ok('آفست ثابت GMT درست تبدیل می‌شود', '12:00 GMT+2 → 10:00Z');
assert.equal(ctx.paNaiveToInstant(naive, 'Europe/Athens').toISOString(), '2026-06-15T09:00:00.000Z');
assert.equal(ctx.paNaiveToInstant(new Date(2026, 0, 15, 12, 0, 0), 'Europe/Athens').toISOString(), '2026-01-15T10:00:00.000Z');
ok('سرور اروپایی: تابستان GMT+3 و زمستان GMT+2 خودکار', '12:00 → 09:00Z / 10:00Z');

/* ── ۴) ورود متاتریدر با منطقهٔ زمانی انتخاب‌شده ─────────────────────── */
const row = { c0: '2026.06.15 12:00:00', c1: 'EURUSD', c2: 'buy', c3: '120.00', __row: 2 };
const map = { date: 'c0', symbol: 'c1', direction: 'c2', pnl: 'c3' };
const built = zone => ctx.paBuildImportedTrade(row, map, { accountId: 'a', timezone: zone }).trade;
const withServer = built('Europe/Athens');
const withLocal = built('local');
assert.equal(withServer.entryDate, '2026-06-15T09:00:00.000Z');
ok('معاملهٔ واردشده با ساعت سرور به لحظهٔ واقعی تبدیل می‌شود', withServer.entryDate);
ok('سشن معاملهٔ واردشده درست محاسبه می‌شود', ctx.Tg(withServer.entryDate) === 'لندن', ctx.Tg(withServer.entryDate));
ok('بدون تنظیم منطقه، رفتار قبلی (ساعت محلی) حفظ می‌شود', withLocal.entryDate === new Date(2026, 5, 15, 12, 0, 0).toISOString());

/* ── ۵) فهرست گزینه‌ها و بازهٔ محلی ─────────────────────────────────── */
ok('گزینه‌های منطقهٔ زمانی کامل‌اند', ctx.PA_IMPORT_TZ_OPTIONS.length >= 8 && ctx.PA_IMPORT_TZ_OPTIONS[0].id === 'local', ctx.PA_IMPORT_TZ_OPTIONS.length + ' گزینه');
const range = ctx.paSessionRangeLocal(ctx.PA_SESSION_DEFS[2], new Date('2026-06-15T09:00:00Z'));
ok('بازهٔ سشن به وقت محلی محاسبه می‌شود', /^\d{2}:\d{2}–\d{2}:\d{2}$/.test(range), 'لندن: ' + range);

/* ── ۶) رابط کاربری: فیلد تنظیمات و یادداشت صفحهٔ ورود ───────────────── */
(async () => {
  const bundle = fs.readdirSync(path.join(__dirname, '..', 'public', 'app')).filter(f => /^journal-app\..*\.js$/.test(f))[0];
  const built = fs.readFileSync(path.join(__dirname, '..', 'public', 'app', bundle), 'utf8');
  ok('باندل ساخته‌شده منطق تازهٔ سشن را دارد', built.includes('PA_SESSION_DEFS') && built.includes('Australia/Sydney'), bundle);
  ok('باندل فیلد منطقهٔ زمانی بروکر را دارد', built.includes('PA_IMPORT_TZ_OPTIONS') && built.includes('منطقهٔ زمانی سرور بروکر'));
  ok('باندل دیگر از getHours() برای سشن استفاده نمی‌کند', !/new Date\(e\)\.getHours\(\)/.test(built));

  const bad = R.filter(([c]) => !c).length;
  console.log(`\n${R.length - bad}/${R.length} آزمون سشن‌های معاملاتی پاس شد.`);
  process.exit(bad ? 1 : 0);
})();
