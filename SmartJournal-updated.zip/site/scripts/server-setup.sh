#!/bin/bash
# ============================================================================
#  SmartJournal — Startup Script برای سرور ابری پارس‌پک (Ubuntu 22.04 / 24.04)
#
#  این اسکریپت را در مرحله «افزودن استارت‌آپ اسکریپت» کپی کنید.
#  به‌محض اولین بوت سرور، همه‌چیز را نصب و آماده می‌کند:
#     Node.js 20 · PostgreSQL · Redis · Nginx · Certbot · فایروال · کاربر اپ
#
#  گزارش کامل اجرا در:  /var/log/smartjournal-setup.log
#  خلاصه و رمزها در:    /root/smartjournal-info.txt
# ============================================================================
set -u
exec > >(tee -a /var/log/smartjournal-setup.log) 2>&1
echo "=============================================="
echo " SmartJournal setup — شروع: $(date)"
echo "=============================================="

export DEBIAN_FRONTEND=noninteractive
APP_USER="smartjournal"
APP_DIR="/opt/smartjournal"
DB_NAME="smartjournal"
DB_USER="sjuser"

step() { echo ""; echo "▶ $*"; }
ok()   { echo "  ✓ $*"; }
die()  { echo "  ✗ خطا: $*"; echo "SETUP_FAILED" > /root/smartjournal-status; exit 1; }

# ---------------------------------------------------------------- ۱) پایه ---
step "به‌روزرسانی سیستم و ابزارهای پایه"
apt-get update -y || die "apt-get update ناموفق بود"
apt-get install -y curl ca-certificates gnupg git ufw unzip build-essential \
  python3 htop nano || die "نصب ابزارهای پایه ناموفق بود"
ok "ابزارهای پایه نصب شد"

# ------------------------------------------------------------ ۲) Node.js ---
step "نصب Node.js 20 LTS"
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - || die "افزودن مخزن NodeSource ناموفق بود"
  apt-get install -y nodejs || die "نصب Node ناموفق بود"
fi
ok "Node $(node -v) · npm $(npm -v)"

# --------------------------------------------------------- ۳) PostgreSQL ---
step "نصب PostgreSQL"
apt-get install -y postgresql postgresql-contrib || die "نصب PostgreSQL ناموفق بود"
systemctl enable --now postgresql
DB_PASS="$(openssl rand -base64 24 | tr -d '/+=' | head -c 24)"
sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 \
  || sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 \
  || sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"
sudo -u postgres psql -c "ALTER DATABASE ${DB_NAME} OWNER TO ${DB_USER};" >/dev/null
ok "PostgreSQL $(sudo -u postgres psql -tAc 'SHOW server_version;' | xargs) آماده است"

# --------------------------------------------------------------- ۴) Redis ---
step "نصب Redis"
apt-get install -y redis-server || die "نصب Redis ناموفق بود"
sed -i 's/^supervised .*/supervised systemd/' /etc/redis/redis.conf 2>/dev/null || true
systemctl enable --now redis-server
ok "Redis فعال است"

# --------------------------------------------------------------- ۵) Nginx ---
step "نصب Nginx و Certbot"
apt-get install -y nginx certbot python3-certbot-nginx || die "نصب Nginx ناموفق بود"
systemctl enable --now nginx
ok "Nginx فعال است"

# ------------------------------------------------------------ ۶) کاربر اپ ---
step "ساخت کاربر و پوشه برنامه"
id -u "${APP_USER}" >/dev/null 2>&1 || useradd --system --create-home --shell /bin/bash "${APP_USER}"
mkdir -p "${APP_DIR}" "${APP_DIR}/data/uploads" "/var/backups/smartjournal"
chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}" "/var/backups/smartjournal"
ok "کاربر ${APP_USER} و پوشه ${APP_DIR} ساخته شد"

# ------------------------------------------------------------- ۷) کلیدها ---
step "تولید کلیدهای رمزنگاری"
APP_KEY="$(openssl rand -base64 48 | tr -d '\n')"
BACKUP_KEY="$(openssl rand -base64 48 | tr -d '\n')"
METRICS_TOKEN="$(openssl rand -hex 24)"
ADMIN_PASS="$(openssl rand -base64 18 | tr -d '/+=' | head -c 18)Aa1!"

cat > "${APP_DIR}/.env" <<ENVFILE
NODE_ENV=production
PORT=3000
HOST=127.0.0.1

DB_ENGINE=postgres
DATABASE_URL=postgres://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}

REDIS_URL=redis://127.0.0.1:6379
QUEUE_ENABLED=true

APP_ENCRYPTION_KEY=${APP_KEY}
BACKUP_ENCRYPTION_KEY=${BACKUP_KEY}
METRICS_TOKEN=${METRICS_TOKEN}

UPLOAD_DIR=${APP_DIR}/data/uploads
SEED_DEMO_DATA=false
FREE_TRIAL_DAYS=7

# ↓↓↓ این‌ها را خودتان پر کنید ↓↓↓
PUBLIC_BASE_URL=https://example.ir
WEBAUTHN_RP_ID=example.ir
WEBAUTHN_ORIGIN=https://example.ir
SUPPORT_EMAIL=support@example.ir
ADMIN_USERNAME=owner
ADMIN_MOBILE=09120000000
ADMIN_PASSWORD=${ADMIN_PASS}
LEGAL_OPERATOR_NAME=
LEGAL_OPERATOR_REGISTRATION=
LEGAL_OPERATOR_ADDRESS=
ENVFILE
chmod 600 "${APP_DIR}/.env"
chown "${APP_USER}:${APP_USER}" "${APP_DIR}/.env"
ok "فایل .env با کلیدهای تصادفی ساخته شد"

# --------------------------------------------------------- ۸) سرویس systemd ---
step "ساخت سرویس systemd"
cat > /etc/systemd/system/smartjournal.service <<'UNIT'
[Unit]
Description=SmartJournal trading journal
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=smartjournal
WorkingDirectory=/opt/smartjournal
EnvironmentFile=/opt/smartjournal/.env
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
ok "سرویس ساخته شد (هنوز start نشده — کد هنوز آپلود نشده)"

# ------------------------------------------------------------- ۹) Nginx ---
step "پیکربندی Nginx به‌عنوان reverse proxy"
cat > /etc/nginx/sites-available/smartjournal <<'NGINX'
server {
    listen 80;
    listen [::]:80;
    server_name _;

    client_max_body_size 12M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 120s;
    }
}
NGINX
ln -sf /etc/nginx/sites-available/smartjournal /etc/nginx/sites-enabled/smartjournal
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
ok "Nginx روی پورت ۸۰ به اپ وصل شد"

# ------------------------------------------------------------ ۱۰) فایروال ---
step "تنظیم فایروال"
ufw allow OpenSSH >/dev/null
ufw allow 80/tcp  >/dev/null
ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null
ok "فایروال فعال شد (فقط SSH، ۸۰ و ۴۴۳ باز است)"

# ------------------------------------------- ۱۱) تست دسترسی به درگاه پیامک ---
step "تست دسترسی به API کاوه‌نگار (مهم‌ترین تست)"
SMS_OK="نامشخص"
if timeout 15 curl -s -o /dev/null -w '%{http_code}' https://api.kavenegar.com/ 2>/dev/null | grep -qE '^[2-4]'; then
  SMS_OK="✅ باز است — پیامک کار خواهد کرد"
else
  SMS_OK="❌ بسته/تایم‌اوت — پیامک کار نمی‌کند! با پشتیبانی تماس بگیرید"
fi
echo "  ${SMS_OK}"

# ------------------------------------------------------------- ۱۲) خلاصه ---
cat > /root/smartjournal-info.txt <<INFO
==========================================================
  SmartJournal — سرور آماده شد
  تاریخ: $(date)
==========================================================

نصب‌شده:
  Node.js        $(node -v)
  PostgreSQL     $(sudo -u postgres psql -tAc 'SHOW server_version;' 2>/dev/null | xargs)
  Redis          $(redis-server --version 2>/dev/null | awk '{print $3}')
  Nginx          $(nginx -v 2>&1 | cut -d/ -f2)

دیتابیس:
  نام            ${DB_NAME}
  کاربر          ${DB_USER}
  رمز            ${DB_PASS}

رمز مدیر پنل (ADMIN_PASSWORD):
  ${ADMIN_PASS}

دسترسی به API پیامک:  ${SMS_OK}

----------------------------------------------------------
 کارهای بعدی (دستی):
----------------------------------------------------------
 ۱) فایل zip پروژه را آپلود کنید:
      scp SmartJournal-Platform.zip root@<IP>:/tmp/
      unzip /tmp/SmartJournal-Platform.zip -d /tmp/sj
      cp -r /tmp/sj/platform/* ${APP_DIR}/
      chown -R ${APP_USER}:${APP_USER} ${APP_DIR}

 ۲) نصب وابستگی‌ها:
      cd ${APP_DIR} && sudo -u ${APP_USER} npm ci --omit=dev

 ۳) دامنه را در ${APP_DIR}/.env درست کنید
      (PUBLIC_BASE_URL, WEBAUTHN_RP_ID, WEBAUTHN_ORIGIN, SUPPORT_EMAIL)

 ۴) گواهی HTTPS:
      certbot --nginx -d yourdomain.ir -d www.yourdomain.ir

 ۵) اجرا:
      systemctl enable --now smartjournal
      systemctl status smartjournal
      journalctl -u smartjournal -f

 ۶) چک‌لیست production:
      cd ${APP_DIR} && npm run preflight:production

 ۷) در پنل مدیریت، درگاه پیامک را تنظیم کنید (SMS.md)
==========================================================
INFO
chmod 600 /root/smartjournal-info.txt
echo "SETUP_OK" > /root/smartjournal-status

echo ""
echo "=============================================="
echo " ✅ تمام شد — پایان: $(date)"
echo " خلاصه و رمزها:  cat /root/smartjournal-info.txt"
echo "=============================================="
