#!/bin/bash
# ============================================================================
#  SmartJournal — گزارش وضعیت سرور
#  روی سرور تازه اجرا کنید و خروجی را کامل کپی کنید.
#      bash server-check.sh
# ============================================================================
export LC_ALL=C.UTF-8 2>/dev/null || true
line() { printf '%s\n' "────────────────────────────────────────────────"; }
have() { command -v "$1" >/dev/null 2>&1; }
yn()   { if [ "$1" -eq 0 ]; then echo "✅"; else echo "❌"; fi; }

echo "════════════════════════════════════════════════"
echo "  گزارش وضعیت سرور SmartJournal"
echo "  $(date)"
echo "════════════════════════════════════════════════"

line; echo "۱) مشخصات ماشین"
echo "  سیستم‌عامل : $(. /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || echo نامشخص)"
echo "  معماری     : $(uname -m)"
echo "  هسته CPU   : $(nproc 2>/dev/null || echo ?)"
echo "  حافظه      : $(free -m 2>/dev/null | awk '/Mem:/{printf "%s MB کل / %s MB آزاد", $2, $7}')"
echo "  دیسک /     : $(df -h / 2>/dev/null | awk 'NR==2{printf "%s کل / %s آزاد", $2, $4}')"
echo "  کاربر فعلی : $(whoami)"
if [ "$(id -u)" -eq 0 ]; then echo "  دسترسی root: ✅ هستید"; else echo "  دسترسی root: ⚠️ root نیستید — با sudo اجرا کنید"; fi

line; echo "۲) نرم‌افزارهای لازم"
printf "  Node.js     "; have node       && echo "✅ $(node -v)"                                   || echo "❌ نصب نیست"
printf "  npm         "; have npm        && echo "✅ $(npm -v)"                                    || echo "❌ نصب نیست"
printf "  PostgreSQL  "; have psql       && echo "✅ $(psql --version | awk '{print $3}')"          || echo "❌ نصب نیست"
printf "  Redis       "; have redis-cli  && echo "✅ $(redis-cli --version | awk '{print $2}')"     || echo "❌ نصب نیست"
printf "  Nginx       "; have nginx      && echo "✅ $(nginx -v 2>&1 | cut -d/ -f2)"                || echo "❌ نصب نیست"
printf "  Certbot     "; have certbot    && echo "✅ نصب است"                                       || echo "❌ نصب نیست"
printf "  unzip       "; have unzip      && echo "✅ نصب است"                                       || echo "❌ نصب نیست"

line; echo "۳) سرویس‌های در حال اجرا"
for s in postgresql redis-server nginx smartjournal; do
  printf "  %-14s " "$s"
  if systemctl is-active --quiet "$s" 2>/dev/null; then echo "✅ فعال"
  elif systemctl list-unit-files 2>/dev/null | grep -q "^${s}"; then echo "⏸ نصب هست ولی خاموش"
  else echo "— وجود ندارد"; fi
done

line; echo "۴) پورت‌های باز"
(ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null) | awk 'NR>1{print $4}' \
  | grep -oE '[0-9]+$' | sort -un | tr '\n' ' ' | sed 's/^/  /'
echo ""

line; echo "۵) 🔴 مهم‌ترین تست — دسترسی به درگاه پیامک"
for host in api.kavenegar.com rest.payamak-panel.com; do
  printf "  %-26s " "$host"
  code=$(timeout 20 curl -s -o /dev/null -w '%{http_code}' "https://$host/" 2>/dev/null)
  if [ -n "$code" ] && [ "$code" != "000" ]; then
    echo "✅ باز است (HTTP $code)"
  else
    echo "❌ بسته یا تایم‌اوت"
  fi
done
echo "  ↳ اگر کاوه‌نگار ❌ بود، همین هفته سرور را پس بدهید."

line; echo "۶) دسترسی اینترنت عمومی"
for host in registry.npmjs.org deb.nodesource.com; do
  printf "  %-26s " "$host"
  code=$(timeout 15 curl -s -o /dev/null -w '%{http_code}' "https://$host/" 2>/dev/null)
  [ -n "$code" ] && [ "$code" != "000" ] && echo "✅ (HTTP $code)" || echo "❌ در دسترس نیست"
done

line; echo "۷) وضعیت نصب SmartJournal"
if [ -f /root/smartjournal-status ]; then
  echo "  استارت‌آپ اسکریپت : $(cat /root/smartjournal-status)"
else
  echo "  استارت‌آپ اسکریپت : اجرا نشده (سرور خام است)"
fi
[ -d /opt/smartjournal ] && echo "  پوشه /opt/smartjournal : ✅ ساخته شده" || echo "  پوشه /opt/smartjournal : ❌ نیست"
[ -f /opt/smartjournal/server.js ] && echo "  کد برنامه              : ✅ آپلود شده" || echo "  کد برنامه              : ❌ هنوز آپلود نشده"
[ -f /opt/smartjournal/.env ] && echo "  فایل .env              : ✅ هست" || echo "  فایل .env              : ❌ نیست"

line; echo "۸) فایروال"
if have ufw; then ufw status 2>/dev/null | head -6 | sed 's/^/  /'; else echo "  ufw نصب نیست"; fi

echo ""
echo "════════════════════════════════════════════════"
echo "  پایان گزارش — این خروجی را کامل کپی کنید"
echo "════════════════════════════════════════════════"
