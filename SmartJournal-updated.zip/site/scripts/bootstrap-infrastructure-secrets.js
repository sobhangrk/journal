'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const target=path.resolve(process.env.INFRA_SECRETS_DIR||path.join(__dirname,'..','deploy','secrets'));
const names=['app_encryption_key','backup_encryption_key','metrics_token','internal_worker_token','redis_password','postgres_password','minio_password','grafana_password','smtp_password'];
fs.mkdirSync(target,{recursive:true,mode:0o700});
const existing=names.filter(name=>fs.existsSync(path.join(target,name)));if(existing.length&&!process.argv.includes('--fill-missing'))throw new Error(`Refusing to overwrite existing secrets: ${existing.join(', ')}. Use --fill-missing to create only absent files.`);
for(const name of names){const file=path.join(target,name);if(fs.existsSync(file))continue;const value=crypto.randomBytes(name==='app_encryption_key'?48:32).toString('base64url');fs.writeFileSync(file,value+'\n',{mode:0o600,flag:'wx'});console.log(`created ${file}`)}
console.log('Infrastructure secrets are ready. Keep deploy/secrets out of source control and include them in the credential recovery process.');
