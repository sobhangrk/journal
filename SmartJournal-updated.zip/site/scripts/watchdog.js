#!/usr/bin/env node
/* ==========================================================================
   SMARTJOURNAL-WATCHDOG — دیده‌بان خودکار سایت
   --------------------------------------------------------------------------
   هر ۱۵ دقیقه (با cron) این‌ها را چک می‌کند و اگر مشکلی باشد به شمارهٔ مدیر
   پیامک می‌دهد:

     ۱) بالا بودن سایت  (https://smarttradejournal.ir و خود اپلیکیشن)
     ۲) اعتبار ملی‌پیامک (اگر کم شود، ثبت‌نام و ورود از کار می‌افتد!)
     ۳) خطاهای اخیر ارسال پیامک (خرابی درگاه)
     ۴) پر شدن دیسک
     ۵) انقضای گواهی SSL (زیر ۱۰ روز)
     ۶) روشن بودن سرویس systemd

   هر مشکل فقط یک‌بار پیامک می‌دهد (بعد از ۶ ساعت تکرار می‌شود) و وقتی برطرف
   شد هم یک پیامک «برطرف شد» می‌فرستد.

   اجرا:
     node scripts/watchdog.js           ← چک و هشدار (برای cron)
     node scripts/watchdog.js --test    ← چک + پیامک آزمایشی به مدیر
     node scripts/watchdog.js --status  ← نمایش وضعیت بدون ارسال
   تنظیم با متغیر محیطی (اختیاری):
     WATCHDOG_PHONE       شمارهٔ مدیر (پیش‌فرض: موبایل owner در پنل)
     WATCHDOG_URL         آدرس سایت (پیش‌فرض: PUBLIC_BASE_URL)
     WATCHDOG_DISK_PCT    آستانهٔ پر شدن دیسک (پیش‌فرض ۸۵)
     WATCHDOG_SMS_MIN     حداقل اعتبار پیامک (پیش‌فرض ۱۰۰)
     WATCHDOG_SMS_FAILS   حداکثر خطای پیامک در ۶۰ دقیقه (پیش‌فرض ۵)
     WATCHDOG_REPEAT_H    فاصلهٔ تکرار هشدار به ساعت (پیش‌فرض ۶)
   ========================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const APP_DIR = process.env.APP_DIR || '/opt/smartjournal';
const MODE = process.argv.includes('--test') ? 'test' : (process.argv.includes('--status') ? 'status' : 'run');

/* ─────────── بارگذاری .env سرور (برای اجرای مستقل) ─────────── */
function loadEnv() {
  try {
    for (const line of fs.readFileSync(path.join(APP_DIR, '.env'), 'utf8').split('\n')) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch {}
}
loadEnv();

const PORT = process.env.PORT || '3000';
const DATA_DIR = process.env.DATA_DIR || path.join(APP_DIR, 'data');
const STATE_FILE = path.join(DATA_DIR, 'watchdog-state.json');
const LOG_FILE = '/var/log/smartjournal-watchdog.log';
const REPEAT_MS = Number(process.env.WATCHDOG_REPEAT_H || 6) * 3600000;

/* ─────────── خروجی: هم کنسول هم فایل (با سقف ۲ مگابایت) ─────────── */
function logLine(text) {
  const line = `[${new Date().toISOString()}] ${text}`;
  console.log(line);
  try {
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) fs.truncateSync(LOG_FILE, 0);
    fs.appendFileSync(LOG_FILE, line + '\n');
  } catch {}
}

/* ─────────── دیتابیس (فقط‌خواندنی برای چک‌ها) ─────────── */
let Database = null, db = null, dbWrite = null;
try {
  Database = require(path.join(APP_DIR, 'node_modules', 'better-sqlite3'));
  db = new Database(process.env.DATABASE_PATH || path.join(DATA_DIR, 'admin.db'), { readonly: true });
} catch (e) { logLine('خطا در باز کردن دیتابیس: ' + e.message); }
function getWriteDb() {
  if (dbWrite) return dbWrite;
  try { dbWrite = new Database(process.env.DATABASE_PATH || path.join(DATA_DIR, 'admin.db')); } catch {}
  return dbWrite;
}

/* ─────────── ابزار ─────────── */
const wait = ms => new Promise(r => setTimeout(r, ms));
async function fetchOk(url, timeoutMs = 12000) {
  const t0 = Date.now();
  try {
    const r = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(timeoutMs) });
    return { ok: r.status >= 200 && r.status < 400, status: r.status, ms: Date.now() - t0 };
  } catch (e) {
    return { ok: false, status: 0, ms: Date.now() - t0, error: String(e.message || e).slice(0, 120) };
  }
}
function readState() { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { return { alerts: {}, lastRun: null }; } }
function writeState(state) { try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2)); } catch {} }
function ownerPhone() {
  try { return db.prepare("SELECT mobile FROM admins WHERE role='owner' ORDER BY created_at LIMIT 1").get()?.mobile || null; } catch { return null; }
}

/* ─────────── چک‌ها — هر کدام {key,label,ok,detail,skip} ─────────── */
async function runChecks() {
  const checks = [];

  /* ۱) خود اپلیکیشن (روی پورت محلی) */
  try {
    const r = await fetchOk(`http://127.0.0.1:${PORT}/api/health/live`);
    checks.push({ key: 'app', label: 'اپلیکیشن', ok: r.ok, detail: r.ok ? `پاسخ ${r.status} در ${r.ms}ms` : `پاسخ ${r.status || r.error}` });
  } catch (e) { checks.push({ key: 'app', label: 'اپلیکیشن', ok: false, detail: String(e.message).slice(0, 100) }); }

  /* ۲) سایت عمومی */
  const siteUrl = process.env.WATCHDOG_URL || process.env.PUBLIC_BASE_URL || '';
  if (siteUrl) {
    const r = await fetchOk(siteUrl);
    checks.push({ key: 'site', label: 'سایت', ok: r.ok, detail: r.ok ? `پاسخ ${r.status} در ${r.ms}ms` : `پاسخ ${r.status || r.error}` });
  } else {
    checks.push({ key: 'site', label: 'سایت', ok: true, skip: true, detail: 'WATCHDOG_URL تنظیم نشده — رد شد' });
  }

  /* ۳) سرویس systemd (اگر موجود باشد) */
  if (process.env.WATCHDOG_NO_SYSTEMD === '1') {
    checks.push({ key: 'systemd', label: 'سرویس', ok: true, skip: true, detail: 'با WATCHDOG_NO_SYSTEMD رد شد' });
  } else try {
    const has = spawnSync('systemctl', ['--version'], { timeout: 3000 });
    if (has.error || has.status !== 0) {
      checks.push({ key: 'systemd', label: 'سرویس', ok: true, skip: true, detail: 'systemd در دسترس نیست — رد شد' });
    } else {
      const r = spawnSync('systemctl', ['is-active', 'smartjournal'], { timeout: 5000, encoding: 'utf8' });
      const active = String(r.stdout || '').trim();
      checks.push({ key: 'systemd', label: 'سرویس', ok: active === 'active', detail: `وضعیت: ${active || r.stderr || 'نامشخص'}` });
    }
  } catch (e) { checks.push({ key: 'systemd', label: 'سرویس', ok: true, skip: true, detail: 'بررسی ممکن نشد' }); }

  /* ۴) اعتبار ملی‌پیامک */
  try {
    /* درگاه‌ها را مثل sms-alert مرتب می‌خوانیم: اصلی، سپس اولویت. قبلاً با
       find() اولین ردیف ملی‌پیامک برداشته می‌شد و اگر آن ردیف نمونهٔ خالیِ
       نصب اولیه بود (بدون کلید)، دیده‌بان برای همیشه هشدار دروغین
       «اطلاعات اتصال موجود نیست» می‌داد و اعتبار واقعی هرگز چک نمی‌شد. */
    const providers = db.prepare("SELECT * FROM sms_providers WHERE is_enabled=1 ORDER BY is_primary DESC, priority").all();
    const { decryptSecret } = require('./sms-alert');
    const melis = providers.filter(p => p.provider_type === 'melipayamak');
    const meli = melis.find(p => p.credentials_encrypted && decryptSecret(p.credentials_encrypted)) || melis[0] || null;
    const anyReal = providers.some(p => p.provider_type !== 'development');
    if (!anyReal) {
      checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: true, skip: true, detail: 'هیچ درگاه واقعی فعال نیست (حالت توسعه)' });
    } else if (!meli) {
      checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: true, skip: true, detail: 'ملی‌پیامک فعال نیست' });
    } else {
      const creds = decryptSecret(meli.credentials_encrypted);
      if (!creds) {
        checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: false, detail: 'اطلاعات اتصال ملی‌پیامک موجود نیست' });
      } else {
        let config = {}; try { config = JSON.parse(meli.config_json || '{}') || {}; } catch {}
        let base = String(config.url || '').trim().replace(/\/+$/, '');
        if (!base) base = 'https://rest.payamak-panel.com/api/SendSMS';
        base = base.replace(/\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i, '').replace(/\/SendSMS\/SendSMS$/i, '/SendSMS');
        const r = await fetch(`${base}/GetCredit`, {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ username: creds.username, password: creds.password || creds.apiKey }),
          signal: AbortSignal.timeout(10000),
        });
        const data = await r.json().catch(() => ({}));
        if (Number(data?.RetStatus) === 1) {
          const credit = Number(data?.Value || 0);
          const min = Number(process.env.WATCHDOG_SMS_MIN || 100);
          checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: credit >= min, detail: `اعتبار: ${credit.toLocaleString('fa-IR')} (حداقل هشدار: ${min})` });
        } else {
          checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: false, detail: `پاسخ درگاه: ${data?.StrRetStatus || data?.RetStatus || r.status}` });
        }
      }
    }
  } catch (e) { checks.push({ key: 'sms-credit', label: 'اعتبار پیامک', ok: false, detail: String(e.message).slice(0, 100) }); }

  /* ۵) خطاهای اخیر پیامک */
  try {
    const fails = Number(db.prepare("SELECT COUNT(*) c FROM sms_logs WHERE status='failed' AND created_at>?").get(new Date(Date.now() - 3600000).toISOString()).c || 0);
    const max = Number(process.env.WATCHDOG_SMS_FAILS || 5);
    checks.push({ key: 'sms-fails', label: 'خطاهای پیامک', ok: fails < max, detail: `${fails} خطا در ۶۰ دقیقهٔ اخیر (آستانه: ${max})` });
  } catch (e) { checks.push({ key: 'sms-fails', label: 'خطاهای پیامک', ok: true, skip: true, detail: 'بررسی ممکن نشد' }); }

  /* ۶) دیسک */
  try {
    const dir = fs.existsSync(DATA_DIR) ? DATA_DIR : APP_DIR;
    const s = fs.statfsSync(dir);
    const total = s.blocks * s.bsize, free = s.bavail * s.bsize;
    const pct = total > 0 ? Math.round((1 - free / total) * 100) : 0;
    const max = Number(process.env.WATCHDOG_DISK_PCT || 85);
    const freeGb = (free / 1073741824).toFixed(1);
    checks.push({ key: 'disk', label: 'دیسک', ok: pct < max && free > 1073741824, detail: `${pct}% پر · ${freeGb} گیگابایت آزاد (آستانه: ${max}%)` });
  } catch (e) { checks.push({ key: 'disk', label: 'دیسک', ok: true, skip: true, detail: 'بررسی ممکن نشد: ' + String(e.message).slice(0, 60) }); }

  /* ۷) گواهی SSL */
  try {
    const certDir = process.env.WATCHDOG_CERT_DIR || '/etc/letsencrypt/live';
    let found = 0, soonest = null;
    if (fs.existsSync(certDir)) {
      for (const domain of fs.readdirSync(certDir)) {
        const pem = path.join(certDir, domain, 'cert.pem');
        if (!fs.existsSync(pem)) continue;
        const cert = new crypto.X509Certificate(fs.readFileSync(pem, 'utf8'));
        const days = (new Date(cert.validTo) - Date.now()) / 86400000;
        found++;
        if (!soonest || days < soonest) soonest = days;
      }
    }
    if (!found) checks.push({ key: 'cert', label: 'گواهی SSL', ok: true, skip: true, detail: 'گواهی Let\'s Encrypt پیدا نشد — رد شد' });
    else checks.push({ key: 'cert', label: 'گواهی SSL', ok: soonest > 10, detail: `${Math.round(soonest)} روز تا انقضا (هشدار زیر ۱۰ روز)` });
  } catch (e) { checks.push({ key: 'cert', label: 'گواهی SSL', ok: true, skip: true, detail: 'بررسی ممکن نشد: ' + String(e.message).slice(0, 60) }); }

  return checks;
}

/* ─────────── ارسال هشدار با حذف تکرار ─────────── */
async function maybeAlert(phone, check, state) {
  const now = Date.now();
  const last = state.alerts[check.key];
  if (check.ok) {
    if (last) {
      delete state.alerts[check.key];
      if (process.env.WATCHDOG_NO_RECOVERY !== '1') {
        await require('./sms-alert').sendAlert(getWriteDb(), phone, `SmartJournal ✅ برطرف شد: ${check.label}. ${check.detail}`);
      }
      logLine(`✅ برطرف شد: ${check.label}`);
    }
    return;
  }
  if (last && now - last < REPEAT_MS) return; /* تازه هشدار داده‌ایم */
  state.alerts[check.key] = now;
  const r = await require('./sms-alert').sendAlert(getWriteDb(), phone, `⚠️ هشدار SmartJournal: ${check.label} — ${check.detail}`);
  logLine(`⚠️ هشدار ارسال شد: ${check.label} → ${r.ok ? 'پیامک رفت (' + r.provider + ')' : 'ارسال پیامک ناموفق: ' + r.error}`);
}

async function main() {
  const checks = await runChecks();

  if (MODE === 'status') {
    const state = readState();
    console.log('── وضعیت دیده‌بان ──');
    for (const c of checks) console.log(`  ${c.ok ? '✓' : '✗'} ${c.label}${c.skip ? ' (رد شد)' : ''} — ${c.detail}`);
    console.log(`آخرین اجرا: ${state.lastRun || '—'}`);
    console.log(`هشدارهای باز: ${Object.keys(state.alerts).length ? Object.keys(state.alerts).join('، ') : 'هیچ'}`);
    return;
  }

  if (MODE === 'test') {
    console.log('── دیده‌بان SmartJournal — اجرای آزمایشی ──');
    for (const c of checks) console.log(`  ${c.ok ? '✓' : '✗'} ${c.label}${c.skip ? ' (رد شد)' : ''} — ${c.detail}`);
    const phone = process.env.WATCHDOG_PHONE || ownerPhone();
    if (!phone || !/^09\d{9}$/.test(phone)) { console.log('✗ شمارهٔ مدیر برای پیامک آزمایشی پیدا نشد (WATCHDOG_PHONE را بگذارید)'); process.exit(1); }
    console.log(`\nارسال پیامک آزمایشی به ${phone.slice(0, 4)}***${phone.slice(-4)} …`);
    const r = await require('./sms-alert').sendAlert(getWriteDb(), phone, 'پیام آزمایشی دیده‌بان SmartJournal — همه‌چیز برقرار است. ✅');
    console.log(r.ok ? `✅ پیامک از درگاه «${r.provider}» ارسال شد — گوشی‌تان را چک کنید.` : `✗ ارسال ناموفق: ${r.error}`);
    process.exit(r.ok ? 0 : 1);
  }

  /* ── اجرای عادی (cron) ── */
  const phone = process.env.WATCHDOG_PHONE || ownerPhone();
  const state = readState();
  state.lastRun = new Date().toISOString();
  writeState(state);
  if (!phone || !/^09\d{9}$/.test(phone)) {
    logLine('✗ شمارهٔ مدیر پیدا نشد — هشداری ارسال نمی‌شود (WATCHDOG_PHONE را تنظیم کنید)');
    process.exit(1);
  }
  for (const c of checks) {
    if (c.skip) { if (process.env.WATCHDOG_VERBOSE === '1') logLine(`• رد شد: ${c.label} — ${c.detail}`); continue; }
    if (process.env.WATCHDOG_VERBOSE === '1') logLine(`${c.ok ? '✓' : '✗'} ${c.label} — ${c.detail}`);
    if (!c.ok) logLine(`✗ مشکل: ${c.label} — ${c.detail}`);
    await maybeAlert(phone, c, state);
  }
  writeState(state);
}

main().then(() => { try { if (db) db.close(); } catch {} try { if (dbWrite) dbWrite.close(); } catch {} process.exit(0); })
  .catch(e => { logLine('خطای دیده‌بان: ' + (e.stack || e)); try { if (db) db.close(); } catch {} process.exit(1); });
