#!/usr/bin/env node
'use strict';
/* ============================================================================
   اندازه‌گیری سرعت صفحهٔ اصلی — قبل و بعد از جداسازی باندل

   شبکه روی «موبایل کند» شبیه‌سازی می‌شود (۱.۶ مگابیت دانلود، ۱۵۰ms تأخیر —
   همان پروفایلی که Lighthouse برای موبایل استفاده می‌کند) و CPU چهار برابر
   کند می‌شود. هر آدرس چند بار اندازه‌گیری و میانه گزارش می‌شود.

   اجرا:  node scripts/measure-landing.js  [--runs 3]
   آدرس‌ها با متغیر محیطی: NEW=http://127.0.0.1:3000  OLD=http://127.0.0.1:3100
========================================================================== */
const puppeteer = require('puppeteer');

const RUNS = Number((process.argv.find(a => a.startsWith('--runs=')) || '').split('=')[1] || 3);
const TARGETS = [
  ['قبل (باندل داخل صفحه)', process.env.OLD || 'http://127.0.0.1:3100'],
  ['بعد (باندل جدا)', process.env.NEW || 'http://127.0.0.1:3000'],
];
const PATHS = ['/', '/journal'];

const NETWORK = { offline: false, downloadThroughput: (1.6 * 1024 * 1024) / 8, uploadThroughput: (750 * 1024) / 8, latency: 150 };
const median = (values) => values.slice().sort((a, b) => a - b)[Math.floor(values.length / 2)];

async function measure(browser, url) {
  const page = await browser.newPage();
  const client = await page.createCDPSession();
  await client.send('Network.enable');
  await client.send('Network.emulateNetworkConditions', NETWORK);
  await client.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  await page.setCacheEnabled(false);

  let transferred = 0, htmlBytes = 0, jsBytes = 0;
  client.on('Network.loadingFinished', e => { transferred += e.encodedDataLength || 0; });
  page.on('response', async res => {
    const type = String(res.headers()['content-type'] || '');
    const len = Number(res.headers()['content-length'] || 0);
    if (/html/.test(type)) htmlBytes += len;
    if (/javascript/.test(type)) jsBytes += len;
  });

  const started = Date.now();
  await page.goto(url, { waitUntil: 'load', timeout: 180000 });
  const paint = await page.evaluate(() => new Promise(resolve => {
    const read = () => {
      const fcp = performance.getEntriesByName('first-contentful-paint')[0];
      const nav = performance.getEntriesByType('navigation')[0] || {};
      resolve({ fcp: fcp ? fcp.startTime : null, dcl: nav.domContentLoadedEventEnd || null, resp: nav.responseEnd || null });
    };
    if (performance.getEntriesByName('first-contentful-paint')[0]) return read();
    new PerformanceObserver(read).observe({ type: 'paint', buffered: true });
    setTimeout(read, 15000);
  }));
  const interactive = Date.now() - started;
  await new Promise(r => setTimeout(r, 2500));      // فرصت برای prefetchهای بعد از load
  const lcp = await page.evaluate(() => new Promise(resolve => {
    let value = null;
    try {
      new PerformanceObserver(list => { const e = list.getEntries(); value = e[e.length - 1].startTime; })
        .observe({ type: 'largest-contentful-paint', buffered: true });
    } catch { }
    setTimeout(() => resolve(value), 400);
  }));
  await page.close();
  return { fcp: paint.fcp, lcp, dcl: paint.dcl, htmlEnd: paint.resp, interactive, transferred, htmlBytes, jsBytes };
}

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const rows = [];
  try {
    for (const [label, base] of TARGETS) {
      for (const p of PATHS) {
        const runs = [];
        for (let i = 0; i < RUNS; i++) runs.push(await measure(browser, base + p));
        rows.push({
          label, path: p,
          html: Math.round(median(runs.map(r => r.htmlBytes)) / 1024),
          transfer: Math.round(median(runs.map(r => r.transferred)) / 1024),
          htmlEnd: Math.round(median(runs.map(r => r.htmlEnd || 0))),
          fcp: Math.round(median(runs.map(r => r.fcp || 0))),
          lcp: Math.round(median(runs.map(r => r.lcp || 0))),
          dcl: Math.round(median(runs.map(r => r.dcl || 0))),
        });
      }
    }
  } finally { await browser.close(); }

  const pad = (s, n) => String(s).padEnd(n);
  console.log('\n  موبایل کند (۱.۶Mbps · ۱۵۰ms · CPU ۴×) — میانهٔ ' + RUNS + ' اجرا\n');
  console.log('  ' + pad('حالت', 26) + pad('مسیر', 10) + pad('HTML', 9) + pad('کل انتقال', 11) + pad('FCP', 9) + pad('LCP', 9) + 'DOMReady');
  console.log('  ' + '-'.repeat(84));
  for (const r of rows) {
    console.log('  ' + pad(r.label, 26) + pad(r.path, 10) + pad(r.html + 'KB', 9) + pad(r.transfer + 'KB', 11) +
      pad(r.fcp + 'ms', 9) + pad(r.lcp + 'ms', 9) + r.dcl + 'ms');
  }
  console.log('');
  console.log(JSON.stringify(rows));
})();
