/**
 * smoke-account-flows.js — سه چیزی که کاربر خواست
 *
 *   ۱) «ورود با کد یک‌بارمصرف»   (بدون رمز، فقط پیامک)
 *   ۲) «رمز را فراموش کرده‌ام»    (بازیابی + تعیین رمز جدید)
 *   ۳) «تغییر رمز عبور» از داخل ژورنال، توسط خود کاربر
 *
 * هر سه هم از سمت API و هم با مرورگر واقعی بررسی می‌شوند.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

function client() {
  const jar = [];
  return {
    jar,
    async post(path, body) {
      const r = await fetch(B + path, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
      (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
      let d = {}; try { d = await r.json(); } catch {}
      return { status: r.status, data: d };
    },
    async get(path) {
      const r = await fetch(B + path, { headers: { cookie: jar.join('; ') } });
      let d = {}; try { d = await r.json(); } catch {}
      return { status: r.status, data: d };
    },
  };
}

(async () => {
  const mobile = '0994' + String(Date.now()).slice(-7);
  const pass1 = 'FlowUser@111111';
  const pass2 = 'FlowUser@222222';
  const pass3 = 'FlowUser@333333';

  console.log('\n── آماده‌سازی: ساخت حساب ──');
  const a = client();
  const s1 = await a.post('/api/auth/signup', { name: 'کاربر جریان', mobile, password: pass1, remember: true,
    acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  ok('ثبت‌نام پذیرفته شد', s1.status === 202, 'status=' + s1.status);
  const s2 = await a.post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });
  ok('حساب ساخته شد', s2.status === 201, 'status=' + s2.status);

  console.log('\n── ۱) ورود با کد یک‌بارمصرف ──');
  const b = client();
  const otpReq = await b.post('/api/auth/otp/request', { mobile, remember: true });
  ok('درخواست کد یک‌بارمصرف پذیرفته شد', otpReq.status === 202,
     'status=' + otpReq.status + ' ' + String(otpReq.data.error || '').slice(0, 60));
  ok('پیام «CAPTCHA لازم است» نمی‌دهد', !/CAPTCHA/i.test(JSON.stringify(otpReq.data)));
  const otpVerify = await b.post('/api/auth/otp/verify', { challengeToken: otpReq.data.challengeToken, code: otpReq.data.devCode });
  ok('با کد پیامکی وارد شد', otpVerify.status === 200, 'status=' + otpVerify.status);
  const me1 = await b.get('/api/auth/me');
  ok('نشست معتبر است', me1.status === 200 && me1.data.user?.mobile === mobile, 'status=' + me1.status);

  console.log('\n── ۲) رمز را فراموش کرده‌ام ──');
  const c = client();
  const recReq = await c.post('/api/auth/recovery/request', { mobile });
  ok('درخواست بازیابی پذیرفته شد', recReq.status === 202,
     'status=' + recReq.status + ' ' + String(recReq.data.error || '').slice(0, 60));
  const recVerify = await c.post('/api/auth/recovery/verify', { challengeToken: recReq.data.challengeToken, code: recReq.data.devCode });
  ok('کد بازیابی تأیید شد و توکن تغییر رمز داد', recVerify.status === 200 && !!recVerify.data.resetToken,
     'status=' + recVerify.status);
  const recReset = await c.post('/api/auth/recovery/reset', { resetToken: recVerify.data.resetToken, newPassword: pass2 });
  ok('رمز جدید ثبت شد', recReset.status === 200, 'status=' + recReset.status);
  const oldLogin = await client().post('/api/auth/login', { mobile, password: pass1 });
  ok('رمز قدیمی دیگر کار نمی‌کند', oldLogin.status === 401, 'status=' + oldLogin.status);
  const d = client();
  const newLogin = await d.post('/api/auth/login', { mobile, password: pass2 });
  ok('با رمز جدید وارد می‌شود', newLogin.status === 200 || newLogin.status === 202, 'status=' + newLogin.status);

  console.log('\n── ۳) تغییر رمز از داخل ژورنال (API) ──');
  const session = newLogin.status === 200 ? d : await (async () => {
    const e = client();
    const v = await e.post('/api/auth/login/verify', { challengeToken: newLogin.data.challengeToken, code: newLogin.data.devCode });
    return v.status === 200 ? e : d;
  })();
  let csrf = newLogin.data.csrfToken;
  if (!csrf) { const me = await session.get('/api/auth/me'); csrf = me.data.csrfToken; }
  const wrongCurrent = await fetch(B + '/api/auth/profile', { method: 'PATCH',
    headers: { 'content-type': 'application/json', cookie: session.jar.join('; '), 'x-csrf-token': csrf || '' },
    body: JSON.stringify({ currentPassword: 'TotallyWrong@1', newPassword: pass3 }) });
  ok('با رمز فعلیِ اشتباه، تغییر رمز رد می‌شود', wrongCurrent.status === 400, 'status=' + wrongCurrent.status);

  const change = await fetch(B + '/api/auth/profile', { method: 'PATCH',
    headers: { 'content-type': 'application/json', cookie: session.jar.join('; '), 'x-csrf-token': csrf || '' },
    body: JSON.stringify({ currentPassword: pass2, newPassword: pass3 }) });
  ok('تغییر رمز با رمز فعلیِ درست انجام شد', change.status === 200,
     'status=' + change.status + ' ' + (await change.text()).slice(0, 80));
  const afterChange = await client().post('/api/auth/login', { mobile, password: pass3 });
  ok('با رمز تازه وارد می‌شود', afterChange.status === 200 || afterChange.status === 202, 'status=' + afterChange.status);

  console.log('\n── ۳٫۵) ورود با شماره و رمزِ درست نباید پیامک بخواهد ──');
  const plain = client();
  const direct = await plain.post('/api/auth/login', { mobile, password: pass3, remember: true });
  ok('ورود با رمز درست، بدون مرحله پیامک انجام شد', direct.status === 200,
     'status=' + direct.status + (direct.data.mfaRequired ? ' · mfaRequired=true' : ''));
  ok('پاسخ اصلاً mfaRequired نمی‌دهد', !direct.data.mfaRequired, JSON.stringify(direct.data).slice(0, 90));
  const meDirect = await plain.get('/api/auth/me');
  ok('نشست بلافاصله فعال است', meDirect.status === 200 && meDirect.data.user?.mobile === mobile);
  /* حتی از یک «دستگاه جدید» (کوکی دستگاه تازه) هم نباید پیامک بخواهد */
  const freshDevice = client();
  const again = await freshDevice.post('/api/auth/login', { mobile, password: pass3, remember: true });
  ok('از دستگاه تازه هم پیامک نمی‌خواهد', again.status === 200 && !again.data.mfaRequired,
     'status=' + again.status);

  console.log('\n── ۴) دیده‌شدن در مرورگر واقعی ──');
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await br.newPage();
  await page.setViewport({ width: 1280, height: 900 });
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 160)));

  await page.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
  for (const cookie of session.jar) {
    const [name, ...rest] = cookie.split('=');
    await page.setCookie({ name, value: rest.join('='), domain: '127.0.0.1', path: '/' });
  }
  await page.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(4000);

  const btn = await page.evaluate(() => {
    const el = document.getElementById('pa-auth-manage');
    if (!el) return { exists: false };
    const r = el.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return { exists: true, text: (el.innerText || '').trim(), width: Math.round(r.width),
      clickable: !!hit && (hit === el || el.contains(hit)) };
  });
  ok('دکمه ورود به بخش رمز عبور متن دارد', btn.exists && /رمز عبور/.test(btn.text || ''), 'متن: «' + btn.text + '»');
  ok('دکمه قابل کلیک است', !!btn.clickable, 'عرض ' + btn.width + 'px');

  await page.click('#pa-auth-manage');
  await wait(2200);
  const dialog = await page.evaluate(() => {
    const overlay = document.getElementById('pa-security-center');
    if (!overlay) return { open: false };
    const active = overlay.querySelector('[data-security-tab].is-active');
    return {
      open: true,
      activeTab: active ? (active.innerText || '').trim() : null,
      hasCurrent: !!document.getElementById('pa-profile-current-password'),
      hasNew: !!document.getElementById('pa-profile-new-password'),
      hasConfirm: !!document.getElementById('pa-profile-confirm-password'),
      heading: (overlay.querySelector('.pa-profile-security h3') || {}).innerText || null,
    };
  });
  ok('پنجره امنیت باز شد', dialog.open);
  ok('مستقیم روی تب رمز عبور باز می‌شود', /رمز عبور/.test(dialog.activeTab || ''), 'تب: ' + dialog.activeTab);
  ok('عنوان «تغییر رمز عبور» دیده می‌شود', /تغییر رمز عبور/.test(dialog.heading || ''), dialog.heading);
  ok('هر سه کادر رمز موجود است', dialog.hasCurrent && dialog.hasNew && dialog.hasConfirm, JSON.stringify(dialog));

  // تایپوی رمز نباید کاربر را قفل کند
  await page.evaluate(() => {
    document.getElementById('pa-profile-current-password').value = 'x';
    document.getElementById('pa-profile-new-password').value = 'NewPass@1234';
    document.getElementById('pa-profile-confirm-password').value = 'NewPass@9999';
  });
  await page.evaluate(() => document.querySelector('[data-save-profile]').click());
  await wait(1200);
  const notice = await page.evaluate(() => (document.querySelector('.pa-security-notice, #pa-security-notice, .pa-security-dialog .notice') || document.body).innerText.match(/تکرار رمز[^\n]*/)?.[0] || '');
  ok('تکرار نادرست رمز، قبل از ارسال گرفته می‌شود', /تکرار رمز/.test(notice), notice || '(پیامی پیدا نشد)');

  await page.screenshot({ path: '/tmp/journal-password.png' });
  ok('هیچ خطای JS رخ نداد', errs.length === 0, errs.join(' | '));
  await br.close();

  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون حساب کاربری پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nACCOUNT FLOWS SMOKE FAILED:', e.stack || e); process.exit(1); });
