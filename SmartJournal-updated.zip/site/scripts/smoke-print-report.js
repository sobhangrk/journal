/**
 * smoke-print-report.js — کیفیت خروجی «چاپ گزارش»
 *
 * قبلاً این دکمه فقط window.print() بود و PDF حاصل: پس‌زمینهٔ مشکی، حباب
 * «۷ روز مانده» و دکمهٔ پشتیبانی روی هر صفحه، بدون عنوان/تاریخ/نام حساب،
 * و هیت‌مپ بیرون‌زده از لبهٔ کاغذ. این آزمون همان موارد را می‌سنجد.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const w = ms => new Promise(r => setTimeout(r, ms));

function client() {
  const jar = [];
  return {
    jar,
    async post(p, b) {
      const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(b) });
      (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
      return { status: r.status, data: await r.json().catch(() => ({})) };
    },
  };
}

function trades(accountId) {
  const out = [];
  let seed = 11;
  const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
  for (let i = 0; i < 26; i++) {
    const dt = new Date(); dt.setDate(dt.getDate() - i * 2);
    const win = rnd() > 0.4;
    out.push({ id: 'p' + i.toString(36), accountId, symbol: 'XAUUSD', direction: 'buy',
      entryDate: dt.toISOString().slice(0, 16), timeframe: '15M', positionSize: '0.5', riskPercent: '1',
      plannedRR: '2', resultType: win ? 'profit' : 'loss', amount: Number(((win ? 1 : -1) * (50 + rnd() * 200)).toFixed(2)),
      commission: 1, swap: 0, riskFree: false, setupName: 'شکست رنج', durationValue: '45', durationUnit: 'minute',
      chartImageData: null, afterImageData: null, imageTags: [],
      pre: { followedSetup: true, rrAcceptable: true, sizeMatchesRisk: true, newsUpcoming: false, matchesPlan: true,
        checkedOtherTimeframes: true, emotionBefore: 'آرام', energyLevel: 4, setupConfidence: 4, motivations: [], psychStates: [] },
      post: { emotionAfter: 'آرام', executionQuality: 4, mistakes: [], notes: '' },
      createdAt: dt.toISOString() });
  }
  return out;
}

(async () => {
  // شمارهٔ کاملاً تصادفی + چند تلاش، چون سرور روی ثبت‌نام‌های پشت‌سرهم
  // محدودیت نرخ دارد و آزمون نباید به‌خاطر آن قرمز شود.
  const a = client();
  let s2 = { status: 0 }, mobile = '';
  for (let attempt = 0; attempt < 5 && s2.status !== 201; attempt++) {
    if (attempt) await w(1500);
    mobile = '09' + String(Math.floor(1e9 + Math.random() * 8.9e9)).slice(0, 9);
    const s = await a.post('/api/auth/signup', { name: 'کاربر گزارش', mobile, password: 'Rep@11111111', remember: true,
      acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
    if (!s.data.challengeToken) continue;
    s2 = await a.post('/api/auth/signup/verify', { challengeToken: s.data.challengeToken, code: s.data.devCode });
  }
  ok('حساب آزمایشی ساخته شد', s2.status === 201, 'status=' + s2.status);
  if (s2.status !== 201) { console.log('\n  سرور اجازهٔ ثبت‌نام نداد؛ آزمون متوقف شد.\n'); process.exit(1) }

  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  const page = await browser.newPage();
  await page.setCacheEnabled(false);
  await page.evaluateOnNewDocument(() => {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.getRegistrations?.().then(rs => rs.forEach(r => r.unregister()));
      if (window.caches) caches.keys().then(ks => ks.forEach(k => caches.delete(k)));
    }
  });
  await page.setViewport({ width: 1440, height: 1000 });
  await page.setCookie(...a.jar.map(c => { const [n, ...v] = c.split('='); return { name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }; }));
  await page.goto(B + '/journal', { waitUntil: 'networkidle2' });
  await page.waitForSelector('#root');
  await w(3000);

  const accountId = 'acc' + Date.now().toString(36);
  await page.evaluate(async (acc, trs) => {
    await window.storage.set('pa-accounts', JSON.stringify([acc]));
    await window.storage.set('pa-trades', JSON.stringify(trs));
    await window.storage.set('pa-active-account', acc.id);
  }, { id: accountId, name: 'حساب اصلی', broker: 'FTMO', initialBalance: 100000, currency: '$',
    createdAt: new Date().toISOString(), withdrawals: [] }, trades(accountId));

  await page.goto(B + '/journal', { waitUntil: 'networkidle2' });
  await page.waitForSelector('.pa-dash', { timeout: 30000 });
  await w(3500);

  // دکمه باید وجود داشته باشد و روی صفحه (نه در چاپ) دیده شود
  const btn = await page.$eval('.pa-print-btn', el => el.textContent.trim()).catch(() => null);
  ok('دکمهٔ چاپ گزارش روی داشبورد هست', !!btn && /چاپ گزارش/.test(btn), String(btn));

  // ---- حالت چاپ ----
  await page.emulateMediaType('print');
  await page.setViewport({ width: 749, height: 1123 });
  await w(1800);

  const head = await page.evaluate(() => {
    const h = document.querySelector('.pa-print-head');
    if (!h) return null;
    const t = document.querySelector('.pa-print-title');
    return {
      visible: getComputedStyle(h).display !== 'none',
      title: t ? t.textContent.trim() : '',
      meta: [...document.querySelectorAll('.pa-print-meta dd')].map(e => e.textContent.trim()),
      kpis: [...document.querySelectorAll('.pa-print-kpi')].length,
      issued: (document.querySelector('.pa-print-issued strong') || {}).textContent || '',
    };
  });
  ok('سربرگ گزارش در چاپ دیده می‌شود', !!head && head.visible);
  ok('عنوان سند درست است', !!head && head.title === 'گزارش عملکرد معاملاتی', head && head.title);
  ok('نام معامله‌گر و حساب در فراداده آمده', !!head && /کاربر گزارش/.test(head.meta[0] || '') && /حساب اصلی/.test(head.meta[1] || ''),
     head && head.meta.slice(0, 2).join(' | '));
  ok('تاریخ صدور درج شده', !!head && head.issued.length > 6, head && head.issued);
  ok('شش شاخص کلیدی در سربرگ هست', !!head && head.kpis === 6, head && String(head.kpis));

  const chrome = await page.evaluate(() => ['.ctcu-fab', '.pa-support-launcher', '.pa-skip-link', '.pa-auth-userbar',
    '.pa-header', '.pa-tabs', '.pa-dash-hero', '.pa-period-print-row', '.pa-print-hide', '#pa-auth']
    .filter(s => { const e = document.querySelector(s); return e && getComputedStyle(e).display !== 'none'; }));
  ok('هیچ عنصر رابط کاربری در چاپ باقی نمانده', chrome.length === 0, chrome.join(', '));

  const overflow = await page.evaluate(() => {
    const W = document.documentElement.clientWidth, bad = new Set();
    document.querySelectorAll('.pa-app *').forEach(e => {
      const b = e.getBoundingClientRect();
      if (b.width > 4 && (b.right > W + 2 || b.left < -2)) bad.add((typeof e.className === 'string' ? e.className : e.tagName).slice(0, 40));
    });
    return [...bad];
  });
  ok('هیچ چیزی از عرض کاغذ بیرون نمی‌زند', overflow.length === 0, overflow.slice(0, 4).join(', '));

  const dark = await page.evaluate(() => {
    const isDark = c => { const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/); if (!m) return false;
      if (m[4] !== undefined && +m[4] < .5) return false; return (+m[1] + +m[2] + +m[3]) / 3 < 110 };
    const out = new Set();
    document.querySelectorAll('.pa-dash *').forEach(e => {
      const b = e.getBoundingClientRect(); if (b.width < 40 || b.height < 18) return;
      if (isDark(getComputedStyle(e).backgroundColor)) out.add((typeof e.className === 'string' ? e.className : e.tagName).slice(0, 40));
    });
    return [...out];
  });
  ok('هیچ بلوک تیره‌ای روی کاغذ نمی‌ماند', dark.length === 0, dark.slice(0, 4).join(', '));

  const readable = await page.evaluate(() => {
    const lum = c => { const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)/); return m ? (+m[1] + +m[2] + +m[3]) / 3 : 255 };
    let pale = 0, total = 0;
    document.querySelectorAll('.pa-dash .pa-card-title, .pa-dash .pa-stat-value, .pa-print-title, .pa-print-kpi strong').forEach(e => {
      if (!e.textContent.trim()) return; total++; if (lum(getComputedStyle(e).color) > 170) pale++;
    });
    return { pale, total };
  });
  ok('متن‌ها روی کاغذ سفید خوانا هستند (سفیدِ روی سفید نیست)', readable.total > 0 && readable.pale === 0,
     readable.pale + '/' + readable.total + ' کم‌رنگ');

  // خروجی واقعی PDF
  const pdf = Buffer.from(await page.pdf({ printBackground: true, preferCSSPageSize: true }));
  const isPdf = pdf.slice(0, 5).toString() === '%PDF-';
  const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
  ok('خروجی یک PDF معتبر است', isPdf && pdf.length > 20000, pdf.length + ' بایت');
  ok('صفحه‌بندی معقول است', pages >= 3 && pages <= 12, pages + ' صفحه');

  await browser.close();
  const pass = R.filter(r => r[0]).length, fail = R.length - pass;
  console.log(`\n  ${pass} قبول · ${fail} رد\n`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
