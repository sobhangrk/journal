/**
 * scripts/login-sms-off.js — خاموش کردن پیامک هنگام ورود با رمز درست
 *
 * اجرا روی سرور:
 *     cd /opt/smartjournal && node scripts/login-sms-off.js
 *     cd /opt/smartjournal && node scripts/login-sms-off.js --status   (فقط گزارش)
 *
 * قانون سرور برای درخواست کد پیامکی هنگام ورود دقیقاً این است:
 *
 *   requiresOtp = موبایل تأیید نشده
 *              || کاربر خودش «تأیید دومرحله‌ای» را روشن کرده
 *              || سطح امنیت کاربر = sensitive
 *              || (تنظیم «کد برای دستگاه جدید» روشن باشد و دستگاه جدید باشد)
 *
 * این اسکریپت مورد چهارم را خاموش می‌کند و سه مورد دیگر را گزارش می‌دهد،
 * چون آن‌ها مربوط به تک‌تک کاربران‌اند نه تنظیم کلی.
 */
'use strict';
const m = require('../db.js');
const db = m.db || m;
const ONLY_STATUS = process.argv.includes('--status');

const g = '\x1b[1;32m', r = '\x1b[1;31m', y = '\x1b[1;33m', c = '\x1b[1;36m', o = '\x1b[0m';

function main() {
  const before = db.prepare('SELECT new_device_otp FROM auth_security_settings WHERE id=?').get('default');
  if (!before) {
    console.log(`${r}✗ ردیف تنظیمات امنیتی پیدا نشد.${o}`);
    console.log('  سرویس را یک بار ری‌استارت کنید تا ساخته شود:  systemctl restart smartjournal');
    process.exit(1);
  }

  console.log(`\n${c}▶ وضعیت فعلی${o}`);
  console.log(`  کد پیامکی برای دستگاه جدید: ${before.new_device_otp ? y + 'روشن' + o : g + 'خاموش' + o}`);

  if (!ONLY_STATUS) {
    if (before.new_device_otp) {
      db.prepare('UPDATE auth_security_settings SET new_device_otp=0, updated_at=? WHERE id=?')
        .run(new Date().toISOString(), 'default');
      const after = db.prepare('SELECT new_device_otp FROM auth_security_settings WHERE id=?').get('default');
      if (after.new_device_otp === 0) console.log(`  ${g}✓ خاموش شد${o}  (۱ → ۰)`);
      else { console.log(`${r}✗ تغییر ثبت نشد${o}`); process.exit(1); }
    } else {
      console.log(`  ${g}✓ از قبل خاموش بود — کاری لازم نبود${o}`);
    }
  }

  // ---- سه دلیل دیگری که هنوز می‌توانند پیامک بخواهند ----
  console.log(`\n${c}▶ کاربرانی که با وجود این تنظیم، باز هم کد پیامکی می‌خواهند${o}`);
  let rows = [];
  try {
    rows = db.prepare(`
      SELECT name, mobile,
             CASE WHEN mobile_verified_at IS NULL THEN 1 ELSE 0 END AS unverified,
             require_2fa,
             security_level
      FROM users
      WHERE deleted_at IS NULL
        AND (mobile_verified_at IS NULL OR require_2fa=1 OR security_level='sensitive')
      ORDER BY created_at DESC
      LIMIT 30
    `).all();
  } catch (e) {
    console.log(`  ${y}!${o} خواندن جدول کاربران ممکن نشد: ${e.message}`);
  }

  if (!rows.length) {
    console.log(`  ${g}✓ هیچ‌کس — ورود با رمز درست دیگر پیامک نمی‌خواهد${o}`);
  } else {
    rows.forEach(u => {
      const why = [];
      if (u.unverified) why.push('موبایل تأیید نشده');
      if (u.require_2fa) why.push('تأیید دومرحله‌ای شخصی روشن است');
      if (u.security_level === 'sensitive') why.push('سطح امنیت: sensitive');
      console.log(`  ${y}•${o} ${u.name || '—'} (${u.mobile}) → ${why.join(' · ')}`);
    });
    console.log(`\n  ${c}برای خاموش کردن این‌ها هم${o} (اختیاری — امنیت را کمی پایین می‌آورد):`);
    console.log(`    node scripts/login-sms-off.js --users`);
  }

  if (process.argv.includes('--users')) {
    const now = new Date().toISOString();
    const res1 = db.prepare("UPDATE users SET require_2fa=0, updated_at=? WHERE require_2fa=1 AND deleted_at IS NULL").run(now);
    const res2 = db.prepare("UPDATE users SET security_level='standard', updated_at=? WHERE security_level='sensitive' AND deleted_at IS NULL").run(now);
    console.log(`\n  ${g}✓ تأیید دومرحله‌ای شخصی خاموش شد:${o} ${res1.changes} کاربر`);
    console.log(`  ${g}✓ سطح امنیت به standard برگشت:${o} ${res2.changes} کاربر`);
    console.log(`  ${y}توجه:${o} «موبایل تأیید نشده» عمداً دست‌نخورده می‌ماند — تأیید شماره`);
    console.log(`  بخشی از ثبت‌نام است و نباید دور زده شود.`);
  }

  console.log(`\n${c}▶ قدم آخر${o}`);
  console.log('  systemctl restart smartjournal');
  console.log('');
}

main();
