/**
 * smoke-header-rail.js — دو درخواست اخیر کاربر:
 *   ۱) هدر جذاب موبایل در صفحهٔ اصلی (لندینگ): نوار شناور شیشه‌ای، دکمهٔ
 *      ورودِ قرصی، دکمهٔ منوی دایره‌ای — بدون تداخل و درون کادر دید
 *   ۲) دسکتاپ ژورنال: دکمهٔ باز/بسته شدن کشوی کناری + ماندگاری وضعیت
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const ov = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  /* ───────────────────────── ۱) هدر موبایل لندینگ ───────────────────────── */
  console.log('\n── هدر موبایل صفحهٔ اصلی ──');
  for (const [name, w, h] of [['موبایل معمولی', 390, 844], ['موبایل باریک', 320, 660]]) {
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: true, hasTouch: true });
    await p.goto(B + '/', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(2200); // cinematic intro

    const s = await p.evaluate(() => {
      const pick = sel => {
        const el = document.querySelector(sel);
        if (!el) return null;
        const cs = getComputedStyle(el), r = el.getBoundingClientRect();
        if (cs.display === 'none' || cs.visibility === 'hidden' || !r.width) return null;
        return { sel, rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)], radius: cs.borderRadius, pos: cs.position };
      };
      const nav = document.querySelector('.pa-l-nav');
      const navBg = nav ? getComputedStyle(nav).backgroundImage : '';
      return {
        nav: pick('.pa-l-nav'), brand: pick('.pa-l-brand'), logo: pick('.pa-l-logo'),
        copy: pick('.pa-l-brand-copy'), cta: pick('.pa-l-nav-actions .pa-l-nav-btn'),
        burger: pick('.pa-l-burger'), inner: pick('.pa-l-nav-inner'),
        navBg, styleInjected: !!document.getElementById('pa-landing-header-polish'),
      };
    });

    ok(`${name}: استایل هدر موبایل تزریق شده`, s.styleInjected);
    ok(`${name}: هدر دیده می‌شود`, !!s.nav, JSON.stringify(s.nav && s.nav.rect));
    if (s.nav) {
      ok(`${name}: هدر شناور و گرد است`, s.nav.pos === 'sticky' && /18px/.test(s.nav.radius), 'radius=' + s.nav.radius);
      ok(`${name}: هدر داخل کادر دید است`, s.nav.rect[0] >= 0 && s.nav.rect[0] + s.nav.rect[2] <= w + 1);
      ok(`${name}: هدر شیشه‌ای (گرادیان + بلور) است`, /gradient/.test(s.navBg));
    }
    ok(`${name}: لوگو + نام برند دیده می‌شود`, !!s.logo && !!s.copy && !!s.brand);
    ok(`${name}: دکمهٔ «ورود» در خودِ هدر دیده می‌شود`, !!s.cta, s.cta ? 'w=' + s.cta.rect[2] : 'پنهان!');
    ok(`${name}: دکمهٔ منو دیده می‌شود`, !!s.burger);
    const parts = [s.cta, s.burger, s.brand].filter(Boolean);
    let clash = false;
    for (let i = 0; i < parts.length; i++) for (let j = i + 1; j < parts.length; j++) if (ov(parts[i].rect, parts[j].rect)) clash = true;
    ok(`${name}: برند، دکمهٔ ورود و منو روی هم نیستند`, !clash, clash ? 'تداخل!' : 'مرتب');
    if (s.cta) ok(`${name}: دکمهٔ ورود قرصی است`, /999px/.test(await p.evaluate(() => getComputedStyle(document.querySelector('.pa-l-nav-actions .pa-l-nav-btn')).borderRadius)));

    // باز شدن منو → همبرگر × می‌شود
    await p.click('.pa-l-burger');
    await wait(450);
    const expanded = await p.evaluate(() => document.querySelector('.pa-l-burger').getAttribute('aria-expanded'));
    const menuOpen = await p.evaluate(() => document.querySelector('.pa-l-mobile').classList.contains('open'));
    ok(`${name}: منو با کلیک باز می‌شود`, expanded === 'true' && menuOpen, 'aria=' + expanded);

    await p.screenshot({ path: `/home/user/uploads/هدر-موبایل-${w}.png` });
    await p.close();
  }

  /* ───────────────────── ۲) کشوی کناری دسکتاپ ژورنال ───────────────────── */
  console.log('\n── کشوی کناری دسکتاپ ژورنال ──');
  const mobile = '0993' + String(Date.now()).slice(-7);
  let s1;
  for (let i = 0; i < 3; i++) {
    s1 = await post('/api/auth/signup', { name: 'کاربر کشو', mobile, password: 'Lay@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
    if (s1.data.challengeToken) break;
    await wait(1500);
  }
  if (!s1.data.challengeToken) { console.log('✗ signup failed'); process.exit(1); }
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const p = await br.newPage();
  const DW = 1366, DH = 768;
  await p.setViewport({ width: DW, height: DH });
  await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
  for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
  await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(4500);

  const railState = () => p.evaluate(() => {
    const head = document.querySelector('.pa-header'), app = document.querySelector('.pa-app');
    const r = head.getBoundingClientRect();
    return {
      closed: document.documentElement.classList.contains('pa-rail-closed'),
      headRight: Math.round(r.right), headLeft: Math.round(r.left),
      padStart: getComputedStyle(app).paddingInlineStart,
      toggle: (() => { const t = document.querySelector('.pa-rail-toggle'); if (!t) return false; const tr = t.getBoundingClientRect(), cs = getComputedStyle(t); return cs.display !== 'none' && tr.width > 0; })(),
      handle: (() => { const h = document.querySelector('.pa-rail-open-handle'); if (!h) return false; const hr = h.getBoundingClientRect(), cs = getComputedStyle(h); return cs.display !== 'none' && hr.width > 0; })(),
    };
  });

  let st = await railState();
  ok('دکمهٔ «بستن منو» داخل کشو دیده می‌شود', st.toggle);
  // RTL: کشو سمت راست صفحه است؛ باز ⇔ لبهٔ راستش به لبهٔ صفحه چسبیده
  ok('کشو در حالت باز است', !st.closed && st.headRight >= DW - 4 && st.headLeft > DW - 400, 'left=' + st.headLeft + ' · right=' + st.headRight);
  ok('محتوای اصلی کنار کشو است (پدینگ ۲۶۲px)', st.padStart.includes('262'), 'padding=' + st.padStart);

  await p.click('.pa-rail-toggle');
  await wait(600);
  st = await railState();
  ok('با کلیک روی «بستن منو» کشو بسته می‌شود', st.closed && st.headLeft >= DW - 4, 'left=' + st.headLeft);
  ok('محتوای اصلی تمام عرض را می‌گیرد', st.padStart === '0px' || parseFloat(st.padStart) === 0, 'padding=' + st.padStart);
  ok('دستگیرهٔ باز کردن لبهٔ صفحه دیده می‌شود', st.handle);
  await p.screenshot({ path: '/home/user/uploads/کشو-بسته-دسکتاپ.png' });

  // ماندگاری: بارگذاری دوباره
  await p.reload({ waitUntil: 'networkidle2', timeout: 60000 });
  await wait(4000);
  st = await railState();
  ok('وضعیت بسته‌بودن بعد از رفرش می‌ماند', st.closed, st.closed ? 'بسته ✓' : 'باز شد!');

  await p.click('.pa-rail-open-handle');
  await wait(600);
  st = await railState();
  ok('با کلیک روی دستگیره، کشو دوباره باز می‌شود', !st.closed && st.headRight >= DW - 4 && st.headLeft > DW - 400, 'left=' + st.headLeft);
  ok('حباب اشتراک هم‌چنان بالا-چپ است', await p.evaluate(() => { const f = document.querySelector('.ctcu-fab'); if (!f) return false; const r = f.getBoundingClientRect(); return r.top < 100 && r.left < 100; }));
  await p.screenshot({ path: '/home/user/uploads/کشو-باز-دسکتاپ.png' });

  // موبایل: دکمهٔ کشو نباید دیده شود
  const pm = await br.newPage();
  await pm.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  await pm.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
  for (const c of jar) { const [n, ...v] = c.split('='); await pm.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
  await pm.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(4200);
  const mobileNoToggle = await pm.evaluate(() => {
    const t = document.querySelector('.pa-rail-toggle'), h = document.querySelector('.pa-rail-open-handle');
    const vis = el => { if (!el) return false; const r = el.getBoundingClientRect(); return getComputedStyle(el).display !== 'none' && r.width > 0; };
    return !vis(t) && !vis(h) && !document.documentElement.classList.contains('pa-rail-closed');
  });
  ok('موبایل: دکمهٔ کشو ظاهر نمی‌شود', mobileNoToggle);
  await pm.close();

  await br.close();
  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} بررسی هدر و کشو پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nSMOKE FAILED:', e.stack || e); process.exit(1); });
