/**
 * smoke-float-layout.js — رگرسیون «همه‌ی دکمه‌های شناور توی هم رفته‌اند»
 *
 * کاربر عکس فرستاد: نوار کاربر، «پشتیبانی»، «؟»، نوار پایین موبایل و حباب
 * اشتراک همه در یک گوشه روی هم افتاده بودند.
 *
 * این تست به CSS اعتماد نمی‌کند؛ مستطیل واقعی هر عنصر را از مرورگر می‌گیرد و
 * هم‌پوشانی هندسی را حساب می‌کند. ضمناً بررسی می‌کند نوار حساب‌ها فقط در
 * داشبورد دیده شود.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

const overlap = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0993' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'کاربر چیدمان', mobile, password: 'Lay@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  for (const [name, w, h] of [['دسکتاپ', 1366, 768], ['موبایل', 390, 844]]) {
    console.log(`\n── ${name} (${w}×${h}) ──`);
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: w < 500, hasTouch: w < 500 });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(4500);

    const boxes = await p.evaluate(() => {
      const sel = ['.pa-auth-userbar', '.pa-support-launcher', '.pa-ux-help', '.pa-mobile-nav', '.ctcu-fab'];
      const out = {};
      sel.forEach(s => {
        const el = document.querySelector(s);
        if (!el) return;
        const cs = getComputedStyle(el), r = el.getBoundingClientRect();
        if (cs.display === 'none' || cs.visibility === 'hidden' || !r.width) return;
        out[s] = [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)];
      });
      return out;
    });
    const names = Object.keys(boxes);
    names.forEach(n2 => console.log('   ', n2.padEnd(22), JSON.stringify(boxes[n2])));

    let clashes = [];
    for (let i = 0; i < names.length; i++)
      for (let j = i + 1; j < names.length; j++)
        if (overlap(boxes[names[i]], boxes[names[j]])) clashes.push(names[i] + ' × ' + names[j]);
    ok(`${name}: هیچ دو عنصر شناوری روی هم نیست`, clashes.length === 0, clashes.join(' · ') || 'پاک');

    const inView = Object.values(boxes).every(b => b[1] >= 0 && b[1] + b[3] <= h + 1 && b[0] >= 0 && b[0] + b[2] <= w + 1);
    ok(`${name}: همه داخل کادر دید هستند`, inView);

    // حباب اشتراک باید بالای صفحه (سمت هدر) باشد، نه پایین
    const fab = boxes['.ctcu-fab'];
    ok(`${name}: حباب اشتراک دیده می‌شود`, !!fab, fab ? 'top=' + fab[1] : 'پیدا نشد');
    if (fab) {
      ok(`${name}: حباب اشتراک در نیمهٔ بالای صفحه است`, fab[1] < 100 && fab[1] + fab[3] < h / 2,
        'top=' + fab[1] + ' · bottom=' + (fab[1] + fab[3]));
      ok(`${name}: حباب اشتراک سمت چپ/هدر است (نه روی محتوا وسط)`, fab[0] < 100,
        'left=' + fab[0] + ' · right=' + (fab[0] + fab[2]));
    }

    // نوار حساب‌ها فقط در داشبورد
    const onDash = await p.evaluate(() => {
      const bar = document.querySelector('.pa-accounts-bar');
      return { exists: !!bar, visible: !!bar && bar.getClientRects().length > 0, view: document.documentElement.getAttribute('data-pa-view') };
    });
    ok(`${name}: در داشبورد نوار حساب‌ها دیده می‌شود`, onDash.visible, 'view=' + onDash.view);

    const moved = await p.evaluate(() => {
      const tabs = [...document.querySelectorAll('.pa-header .pa-tab')];
      const t = tabs.find(x => /تاریخچه/.test(x.getAttribute('title') || ''));
      if (t) { t.click(); return 'sidebar'; }
      const m = [...document.querySelectorAll('.pa-mobile-nav button')].find(x => /تاریخچه/.test(x.innerText || ''));
      if (m) { m.click(); return 'mobile-nav'; }
      return null;
    });
    await wait(1800);
    const offDash = await p.evaluate(() => {
      const bar = document.querySelector('.pa-accounts-bar');
      return { visible: !!bar && bar.getClientRects().length > 0, view: document.documentElement.getAttribute('data-pa-view') };
    });
    ok(`${name}: بیرون داشبورد نوار حساب‌ها مخفی می‌شود`, moved && !offDash.visible,
       'از راه ' + moved + ' · view=' + offDash.view);

    // حباب اشتراک: در عرض‌های باریک فقط در داشبورد می‌ماند (تا متن سربرگ تب‌ها را نپوشاند)
    if (w < 500) {
      const fabOff = await p.evaluate(() => {
        const el = document.querySelector('.ctcu-fab');
        if (!el) return false;
        const cs = getComputedStyle(el);
        return cs.display !== 'none' && el.getClientRects().length > 0;
      });
      ok('موبایل: حباب اشتراک بیرون داشبورد مخفی می‌شود', !fabOff, fabOff ? 'هنوز دیده می‌شود' : 'پنهان ✓');
    }

    await p.screenshot({ path: `/tmp/float-${w}.png` });
    await p.close();
  }

  await br.close();
  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون چیدمان پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nLAYOUT SMOKE FAILED:', e.stack || e); process.exit(1); });
