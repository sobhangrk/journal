'use strict';
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const source = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'admin.db');
const dir = process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups');
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const target = path.join(dir, `pa-journal-${stamp}.db`);
const db = new Database(source, { readonly: true });
db.backup(target)
  .then(() => {
    db.close();
    console.log(`Backup created: ${target}`);
  })
  .catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
