/**
 * ممیزی قابلیت‌های درخواستی — هرکدام با API/DB واقعی بررسی می‌شود.
 *   ۱) CMS متن‌های سایت      ۲) اعتمادسازی صفحه اصلی
 *   ۳) پلن رایگان ۷ روزه      ۴) کارت‌به‌کارت
 *   ۵) WebP                   ۶) درگاه پیامک
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const out = [];
const check = (feature, item, ok, detail = '') => { out.push([feature, item, ok, detail]); };

const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: jar.join('; ') };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const r = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(r); let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, data: d };
}

(async () => {
  const db = new Database(process.env.DB_FILE || require('path').join(__dirname, '..', 'data', 'admin.db'));
  const stamp = Date.now().toString(36), username = 'audit' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_audit_' + stamp, 'ممیز', username, '090' + String(Date.now()).slice(-8),
         bcrypt.hashSync('Audit@12345', 10), new Date().toISOString());
  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'Audit@12345' } });
  const csrf = login.data.csrfToken;

  /* ═════ ۱) CMS متن‌های سایت ═════ */
  const texts = await req('/api/public/site-texts');
  check('۱ CMS متن سایت', 'API عمومی متن‌ها کار می‌کند', texts.status === 200,
    `${(texts.data.rows || []).length} متن سفارشی‌شده (فقط تغییرها ارسال می‌شود)`);
  const adminTexts = await req('/api/admin/site-texts');
  const rows = adminTexts.data.rows || adminTexts.data.texts || [];
  check('۱ CMS متن سایت', 'مدیر همه متن‌ها را می‌بیند', adminTexts.status === 200 && rows.length >= 100,
    `${rows.length} ردیف`);
  const groups = [...new Set(rows.map(r => r.group_label || r.group_key))];
  check('۱ CMS متن سایت', 'گروه‌بندی دارد', groups.length >= 5, groups.slice(0, 9).join('، '));
  // ویرایش واقعی
  const target = rows.find(r => r.id && r.default_value);
  if (target) {
    const marker = 'ممیزی-' + stamp;
    const patch = await req(`/api/admin/site-texts/${encodeURIComponent(target.id)}`,
      { method: 'PATCH', csrf, body: { value: marker } });
    check('۱ CMS متن سایت', 'ذخیره تغییر متن', patch.status === 200, target.text_key + ' — ' + JSON.stringify(patch.data).slice(0,60));
    const after = await req('/api/public/site-texts');
    const found = (after.data.rows || []).find(r => r.text_key === target.text_key);
    check('۱ CMS متن سایت', 'تغییر بلافاصله در API عمومی دیده می‌شود', !!found && found.value === marker,
      found ? found.value.slice(0, 30) : 'پیدا نشد');
    const reset = await req(`/api/admin/site-texts/${encodeURIComponent(target.id)}/reset`, { method: 'POST', csrf, body: {} });
    check('۱ CMS متن سایت', 'بازگرداندن به حالت اولیه', reset.status === 200);
  }

  /* ═════ ۲) اعتمادسازی ═════ */
  const tst = await req('/api/public/testimonials');
  const items = tst.data.rows || tst.data.testimonials || [];
  check('۲ اعتمادسازی', 'API نظرات کاربران', tst.status === 200, `${items.length} نظر`);
  check('۲ اعتمادسازی', 'حداقل ۳ نظر منتشرشده', items.length >= 3);
  check('۲ اعتمادسازی', 'نظرات امتیاز دارند', items.every(t => Number(t.rating) >= 1 && Number(t.rating) <= 5));
  const badges = tst.data.badges || tst.data.trustBadges || [];
  check('۲ اعتمادسازی', 'نشان‌های اعتماد', badges.length >= 3, `${badges.length} نشان`);
  const adminT = await req('/api/admin/testimonials');
  check('۲ اعتمادسازی', 'مدیریت نظرات در پنل', adminT.status === 200, `${(adminT.data.rows || []).length} ردیف`);

  /* ═════ ۳) پلن رایگان ۷ روزه ═════ */
  const plans = await req('/api/public/plans');
  const list = plans.data.plans || plans.data.rows || [];
  const free = list.find(p => p.name === 'free');
  check('۳ پلن رایگان', 'پلن رایگان در لیست هست', !!free, free ? free.name_fa : '—');
  check('۳ پلن رایگان', 'مدت ۷ روز است', free && Number(free.duration_days) === 7, free ? free.duration_days + ' روز' : '');
  const sections = db.prepare(`SELECT COUNT(*) c FROM plan_journal_sections s
    JOIN plans p ON p.id=s.plan_id WHERE p.name='free' AND s.is_enabled=1`).get().c;
  const allSections = db.prepare('SELECT COUNT(DISTINCT section_key) c FROM plan_journal_sections').get().c;
  check('۳ پلن رایگان', 'به همه بخش‌ها دسترسی دارد', sections === allSections, `${sections} از ${allSections}`);
  const expired = db.prepare("SELECT * FROM plans WHERE name='expired'").get();
  check('۳ پلن رایگان', 'پلن «پایان دوره» برای بعد از ۷ روز', !!expired, expired ? expired.name_fa : '—');
  check('۳ پلن رایگان', 'پلن پایان‌دوره مخفی است', expired && !expired.is_active);
  const expiredSections = expired ? db.prepare('SELECT COUNT(*) c FROM plan_journal_sections WHERE plan_id=? AND is_enabled=1').get(expired.id).c : 0;
  check('۳ پلن رایگان', 'بعد از ۷ روز فقط خواندنی', expiredSections > 0 && expiredSections < allSections, `${expiredSections} بخش`);
  const freeQuota = free ? Number(free.max_storage_bytes || 0) : 0;
  const pro = list.find(p => p.name === 'pro');
  check('۳ پلن رایگان', 'سهمیه فضا برابر پلن حرفه‌ای', pro && freeQuota === Number(pro.max_storage_bytes),
    `${Math.round(freeQuota / 1048576)}MB`);

  /* ═════ ۴) کارت‌به‌کارت ═════ */
  const cards = await req('/api/admin/bank-cards');
  check('۴ کارت‌به‌کارت', 'مدیریت کارت‌های بانکی', cards.status === 200, `${(cards.data.rows || []).length} کارت`);
  const receipts = await req('/api/admin/receipts-summary');
  check('۴ کارت‌به‌کارت', 'خلاصه فیش‌ها', receipts.status === 200, JSON.stringify(receipts.data).slice(0, 70));

  /* ═════ ۵) WebP ═════ */
  const fs = require('fs');
  const media = fs.readdirSync(require('path').join(__dirname, '..', 'public', 'media'));
  check('۵ WebP', 'تصاویر WebP موجودند', media.filter(f => f.endsWith('.webp')).length >= 4,
    media.filter(f => f.endsWith('.webp')).length + ' فایل');
  const settings = await req('/api/admin/files/overview');
  const mimes = JSON.stringify(settings.data?.settings?.allowed_mime_types || '');
  check('۵ WebP', 'image/webp در فرمت‌های مجاز', /webp/.test(mimes));

  /* ═════ ۶) درگاه پیامک ═════ */
  const sms = await req('/api/admin/sms/status');
  check('۶ درگاه پیامک', 'وضعیت درگاه گزارش می‌شود', sms.status === 200,
    sms.data.ready ? 'آماده: ' + sms.data.activeProvider : 'آماده نیست (طبیعی، کلید وارد نشده)');
  check('۶ درگاه پیامک', 'مشکلات را دقیق توضیح می‌دهد', (sms.data.problems || []).length > 0 || sms.data.ready);
  const provs = (await req('/api/admin/usage')).data.providers || [];
  check('۶ درگاه پیامک', 'درگاه‌ها در پنل قابل مدیریت‌اند', provs.length >= 2, `${provs.length} درگاه`);

  /* ═════ گزارش ═════ */
  db.close();
  let current = '';
  let fail = 0;
  for (const [feature, item, ok, detail] of out) {
    if (feature !== current) { console.log(`\n${feature}`); current = feature; }
    if (!ok) fail++;
    console.log(`  ${ok ? '✓' : '✗'} ${item}${detail ? '  — ' + detail : ''}`);
  }
  console.log(`\n${out.length - fail}/${out.length} مورد تایید شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('AUDIT FAILED:', e.stack || e); process.exit(1); });
