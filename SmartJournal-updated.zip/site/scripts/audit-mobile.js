/**
 * ممیزی موبایل — هیچ‌وقت بررسی نشده بود.
 * سرریز افقی، دکمه‌های ریزتر از حد لمس، متن خیلی کوچک، و بخش اعتمادسازی.
 */
const puppeteer = require(process.env.PUPPETEER_PATH||'puppeteer');
const B = 'http://127.0.0.1:3000';
const DEVICES = [
  { name: 'iPhone SE', width: 375, height: 667 },
  { name: 'iPhone 14', width: 390, height: 844 },
  { name: 'Galaxy A', width: 412, height: 915 },
  { name: 'iPad', width: 768, height: 1024 },
];
const PAGES = ['/', '/pricing', '/faq', '/legal/terms'];
const bugs = [];

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  for (const device of DEVICES) {
    console.log(`\n──── ${device.name} (${device.width}px) ────`);
    for (const path of PAGES) {
      const p = await br.newPage();
      await p.setViewport({ width: device.width, height: device.height, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
      const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 120)));
      await p.goto(B + path, { waitUntil: 'networkidle2', timeout: 45000 });
      await new Promise(r => setTimeout(r, 3500));

      const r = await p.evaluate(vw => {
        const scroller = document.getElementById('pa-landing') || document.scrollingElement;
        const overflowX = Math.max(0, (scroller.scrollWidth || 0) - vw);
        const inScroller = el => {
          for (let n = el.parentElement; n; n = n.parentElement) {
            const ox = getComputedStyle(n).overflowX;
            if (ox === 'auto' || ox === 'scroll' || ox === 'hidden' || ox === 'clip') return true;
          }
          return false;
        };
        const wide = [...document.querySelectorAll('body *')]
          .filter(e => { const st = getComputedStyle(e); const b = e.getBoundingClientRect();
            return b.width > 0 && (b.right > vw + 2 || b.left < -2)
              && st.position !== 'fixed' && st.pointerEvents !== 'none' && !inScroller(e); })
          .slice(0, 4)
          .map(e => e.tagName.toLowerCase() + (e.className && typeof e.className === 'string' ? '.' + e.className.split(' ')[0] : ''));
        const smallTap = [...document.querySelectorAll('a,button,[role=button]')]
          .filter(e => { const b = e.getBoundingClientRect();
            return b.width > 0 && b.height > 0 && (b.height < 32 || b.width < 32); })
          .map(e => (e.innerText || e.getAttribute('aria-label') || '?').trim().slice(0, 18)).filter(Boolean);
        const tinyText = [...document.querySelectorAll('p,li,span,small')]
          .filter(e => e.innerText && e.innerText.trim().length > 20 && parseFloat(getComputedStyle(e).fontSize) < 11).length;
        const burger = document.querySelector('.pa-l-burger,.burger,[aria-label*="منو"]');
        return { overflowX, wide: [...new Set(wide)], smallTap: [...new Set(smallTap)].slice(0, 6),
          tinyText, burgerVisible: !!(burger && burger.getClientRects().length),
          trust: !!document.getElementById('pa-l-trust') };
      }, device.width);

      const flags = [];
      if (r.overflowX > 4) flags.push(`سرریز افقی ${r.overflowX}px`);
      if (r.wide.length) flags.push('عناصر بیرون‌زده: ' + r.wide.join(', '));
      if (r.smallTap.length > 2) flags.push('دکمه کوچک‌تر از ۳۲px: ' + r.smallTap.join(', '));
      if (r.tinyText > 3) flags.push(`${r.tinyText} متن زیر ۱۱px`);
      if (errs.length) flags.push('خطای JS: ' + errs[0]);
      console.log(`  ${flags.length ? '⚠' : '✓'} ${path.padEnd(16)} ${flags.join(' · ') || 'سالم'}`);
      flags.forEach(f => bugs.push([`${device.name} ${path}`, f]));

      if (path === '/' && device.width === 390) {
        await p.screenshot({ path: '/tmp/mobile-home.png', fullPage: false });
        console.log(`     بخش اعتمادسازی: ${r.trust ? '✓ هست' : '✗ نیست'} · دکمه منو: ${r.burgerVisible ? '✓' : '✗'}`);
      }
      await p.close();
    }
  }
  console.log('\n════════ خلاصه ════════');
  if (!bugs.length) console.log('  هیچ مشکل موبایلی پیدا نشد.');
  else bugs.forEach(([where, msg]) => console.log(`  ⚠ ${where}\n      ${msg}`));
  await br.close();
})();
