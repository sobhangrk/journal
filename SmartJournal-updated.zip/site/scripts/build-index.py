#!/usr/bin/env python3
"""
public/index.html را از سه snapshot جداگانه می‌سازد.

هیچ‌کدام از exportها به‌تنهایی اپ کامل نیستند:
  SmartJournal-index.html   → فقط لندینگ  (#pa-landing، بدون #root)
  SmartJournal-login.html   → فقط پنل ورود (#pa-auth)
  SmartJournal-journal.html → فقط اپ ژورنال (#root + باندل React)

سرور برای هر دو مسیر / و /journal همین یک فایل را سرو می‌کند و اپ با کلاس
روی <html> بین صفحه‌ها جابه‌جا می‌شود؛ پس هر سه باید در یک فایل باشند.

⚠️ بعد از اجرای این اسکریپت، خروجی «همه‌چیز در یک فایل» است (~۱.۷MB).
   حتماً بلافاصله اجرا کنید:

       cp public/index.html src-html/index.combined.html
       npm run build:split      # باندل ژورنال را از لندینگ جدا می‌کند
       npm run smoke:split

   وگرنه صفحهٔ اصلی دوباره سنگین می‌شود. توضیح کامل: PERFORMANCE-SPLIT.md
"""
import re
import subprocess
from pathlib import Path

UP = Path("/home/user/uploads")
OUT = Path("/home/user/platform/public/index.html")

index_html = (UP / "SmartJournal-index.html").read_text(encoding="utf-8")
login_html = (UP / "SmartJournal-login.html").read_text(encoding="utf-8")
journal_html = (UP / "SmartJournal-journal.html").read_text(encoding="utf-8")


def block(html, tag, ident, what="id"):
    """Return the full <tag id="ident">…</tag> including the tags."""
    m = re.search(rf'<{tag}\b[^>]*\b{what}="{re.escape(ident)}"[^>]*>', html)
    if not m:
        raise SystemExit(f"!! <{tag} {what}={ident}> not found")
    depth, pos = 1, m.end()
    pattern = re.compile(rf"</?{tag}\b", re.I)
    while depth:
        nxt = pattern.search(html, pos)
        if not nxt:
            raise SystemExit(f"!! unbalanced <{tag} {ident}>")
        depth += 1 if nxt.group(0)[1] != "/" else -1
        pos = nxt.end()
    return html[m.start(): html.index(">", pos) + 1]


def script_block(html, ident):
    return block(html, "script", ident)


# ------------------------------------------------------------------ head ---
# index export has the most complete stylesheet set (29.7 KB landing styles)
head = index_html[index_html.index("<head"): index_html.index("</head>")]
if "<!-- PA_SERVER_SEO -->" not in head:
    head = head.replace("</title>", "</title>\n<!-- PA_SERVER_SEO -->", 1)

# ------------------------------------------------------------------ body ---

# --- routing: the server serves this one file for both / and /journal, so the
#     initial screen has to be chosen from the URL. Done in <head> to avoid a
#     flash of the landing page on /journal.
ROUTE_HEAD = """<script id="pa-route-boot">
(function(){var c=document.documentElement.classList;
if(/^\\/journal(\\/|$)/.test(location.pathname)){c.remove('pa-landing-active');c.add('pa-auth-active')}
/* ورود به ژورنال بدون بارگذاری دوباره صفحه. در نسخه‌های standalone اینجا
   به یک فایل html جدا پرش می‌شد که روی سرور وجود ندارد و ۴۰۴ می‌داد. */
window.PAEnterJournal=function(){
  try{
    if(window.PAAuth&&typeof window.PAAuth.open==='function'){
      window.PAAuth.open();
      try{if(!/^\\/journal(\\/|$)/.test(location.pathname)){history.pushState({paJournal:1},'','/journal');window.__paPushedJournal=true}}catch(e){}
      return true;
    }
  }catch(e){}
  location.href='/journal';
  return false;
};
/* اگر کاربر از پنل ورود «بازگشت» بزند، آدرس هم باید به لندینگ برگردد */
window.PALeaveJournalUrl=function(){
  if(/^\\/journal(\\/|$)/.test(location.pathname)){
    try{history.replaceState({},'','/')}catch(e){}
    window.__paPushedJournal=false;
  }
};
document.addEventListener('click',function(e){
  var t=e.target&&e.target.closest?e.target.closest('#pa-a-back'):null;
  if(t)setTimeout(window.PALeaveJournalUrl,0);
},true);
document.addEventListener('keydown',function(e){
  if(e.key==='Escape')setTimeout(window.PALeaveJournalUrl,0);
},true);
window.addEventListener('popstate',function(){location.reload()});
/* اگر مرورگر نسخه کهنه‌ای را از cache سرویس‌ورکر نشان می‌دهد:
   کافی است آدرس را با ?fresh=1 باز کنید. */
if(/[?&]fresh=1/.test(location.search)&&'serviceWorker' in navigator){
  Promise.all([
    navigator.serviceWorker.getRegistrations().then(function(rs){return Promise.all(rs.map(function(r){return r.unregister()}))}),
    (window.caches?caches.keys().then(function(ks){return Promise.all(ks.map(function(k){return caches.delete(k)}))}):Promise.resolve())
  ]).then(function(){location.replace(location.pathname)});
}
/* وقتی سرویس‌ورکر جدید کنترل را می‌گیرد، صفحه یک‌بار تازه می‌شود تا کاربر
   هیچ‌وقت روی نسخه قدیمی گیر نکند. */
if('serviceWorker' in navigator){
  navigator.serviceWorker.addEventListener('controllerchange',function(){
    if(window.__paSWReloaded)return;window.__paSWReloaded=true;location.reload();
  });
}
})();
</script>
"""

# --- and once the auth module is ready, either drop straight into the journal
#     (already signed in) or show the sign-in panel.
ROUTE_TAIL = """<script id="pa-route-enter">
(function(){if(!/^\\/journal(\\/|$)/.test(location.pathname))return;var n=0;
(function go(){if(window.PAAuth&&window.PACloudStorage){try{window.PAAuth.open()}catch(e){}return}
if(n++<120)setTimeout(go,50)})();})();
</script>
"""

# --- فونت محلی: قبلاً از fonts.googleapis.com می‌آمد که در ایران کند یا بلاک
#     است و صفحه با تاهوما رندر می‌شد. هر دو فونت «متغیر» هستند پس یک فایل
#     همه وزن‌ها را پوشش می‌دهد. با scripts/build-fonts.py ساخته می‌شوند.
LOCAL_FONTS = """<link rel="preload" href="/fonts/vazirmatn-var.woff2" as="font" type="font/woff2" crossorigin>
<style id="pa-local-fonts">
@font-face{
  font-family:'Vazirmatn';
  src:url('/fonts/vazirmatn-var.woff2') format('woff2-variations'),
      url('/fonts/vazirmatn-var.woff2') format('woff2');
  font-weight:400 900; font-style:normal; font-display:swap;
}
@font-face{
  font-family:'JetBrains Mono';
  src:url('/fonts/jetbrains-mono-var.woff2') format('woff2-variations'),
      url('/fonts/jetbrains-mono-var.woff2') format('woff2');
  font-weight:400 800; font-style:normal; font-display:swap;
}
</style>
"""

# لینک‌های گوگل‌فونت و preconnectهایشان حذف می‌شوند
_removed = 0
for _pat in (
    r'<link[^>]*rel="preconnect"[^>]*fonts\.(?:googleapis|gstatic)\.com[^>]*>',
    r'<link[^>]*fonts\.googleapis\.com/css2[^>]*>',
):
    head, _n = re.subn(_pat, '', head)
    _removed += _n
if _removed:
    print(f"  · {_removed} ارجاع گوگل‌فونت حذف شد")
if 'pa-local-fonts' not in head:
    head = head.replace('</title>', '</title>\n' + LOCAL_FONTS, 1)
    print("  · فونت محلی جایگزین شد")

# --- fix: آیکون‌ها به‌صورت base64 داخل خود HTML بودند (۶ نسخه از یک لوگو،
#     ۳۴۲ کیلوبایت) و هیچ <link rel="manifest"> وجود نداشت؛ ضمناً دو لینک
#     apple-touch-startup-image به فایل‌هایی اشاره می‌کردند که وجود ندارند (۴۰۴).
ICON_LINKS = """<link rel="icon" type="image/png" sizes="192x192" href="/media/smartjournal-logo-192.png">
<link rel="icon" type="image/webp" sizes="512x512" href="/media/smartjournal-logo-512.webp">
<link rel="apple-touch-icon" href="/media/smartjournal-logo-192.png">
<link rel="manifest" href="/manifest.webmanifest">
"""
_icons = 0
for _pat in (
    r'<link[^>]*rel="icon"[^>]*data:image/[^>]*>',
    r'<link[^>]*rel="apple-touch-icon"[^>]*data:image/[^>]*>',
    r'<link[^>]*rel="apple-touch-startup-image"[^>]*>',
):
    head, _n = re.subn(_pat, '', head)
    _icons += _n
if _icons:
    head = head.replace('</title>', '</title>\n' + ICON_LINKS, 1)
    print(f"  · {_icons} لینک آیکون base64/۴۰۴ با فایل واقعی + manifest جایگزین شد")

head = head + ROUTE_HEAD
# --- fix: #pa-landing is position:fixed with z-index 100000 and is only hidden
#     by an explicit [hidden] attribute. In the separate exports "enter the
#     journal" meant navigating to another file, so it never had to hide.
#     In this single-page build it kept covering the journal, so bind its
#     visibility to the landing state instead.
LANDING_VISIBILITY_FIX = """<style id="pa-landing-visibility-fix">
body{font-family:'Vazirmatn',Tahoma,Arial,sans-serif}
html:not(.pa-landing-active) #pa-landing{display:none !important}
#pa-landing.is-exiting{pointer-events:none}
</style>
"""
head = head + LANDING_VISIBILITY_FIX

# --- fix: نوار اسکرول اصلی صفحه سفیدِ ویندوزی بود.
#     دو علت: (۱) همه قوانین ::-webkit-scrollbar داخل `.pa-app` محدود بودند،
#     پس اسکرول خودِ صفحه استایل نداشت. (۲) meta color-scheme روی
#     "dark light" بود و ویندوزِ روشنِ کاربر باعث می‌شد مرورگر
#     اسکرول‌بار و کنترل‌های بومی را روشن بکشد.
_scrollbar_css = subprocess.run(
    ["node", "-e", "process.stdout.write(require('./shared-scrollbar').SCROLLBAR_CSS)"],
    cwd="/home/user/platform", capture_output=True, text=True, check=True).stdout
SCROLLBAR_FIX = '<style id="pa-shared-scrollbar">' + _scrollbar_css + '</style>\n'
head = head + SCROLLBAR_FIX
# --- fix: سه عنصر شناور گوشه پایین-چپ (نوار کاربر، دکمه پشتیبانی، دکمه راهنما)
#     روی محتوای صفحه می‌افتادند؛ در صفحه «ورود CSV / MetaTrader» آیکون‌های
#     پایین جدول کاملاً زیرشان گم می‌شد.
FLOATING_CLEARANCE = """<style id="pa-floating-clearance">
.pa-import-layout,.pa-feature-page>section:last-child{padding-bottom:132px}
@media (max-width:760px){.pa-import-layout,.pa-feature-page>section:last-child{padding-bottom:150px}}
</style>
"""
head = head + FLOATING_CLEARANCE
# --- ویجت پشتیبانی شناور + لینک‌های شبکه‌های اجتماعی (از پنل مدیریت تنظیم می‌شوند)
head = head + '<script src="/support-widget.js" defer></script>\n'
head = head.replace('<meta name="color-scheme" content="dark light" />',
                    '<meta name="color-scheme" content="dark" />')
head = head.replace('<meta name="color-scheme" content="dark light">',
                    '<meta name="color-scheme" content="dark">')

# --- fix: ممیزی موبایل نشان داد کارت‌های شناور تزئینی از لبه صفحه بیرون
#     می‌زنند (روی ۳۹۰px کارت «DISCIPLINE SCORE» نصفه دیده می‌شد)، حلقه‌های
#     تزئینی روی تبلت ۱۱۶px سرریز می‌کردند، و ۶۰ متن زیر ۱۱px بود که روی
#     موبایل فارسی خوانا نیست.
MOBILE_FIXES = """<style id="pa-mobile-fixes">
@media (max-width: 820px){
  /* تزئینات شناور نباید از لبه بیرون بزنند */
  #pa-landing .pa-l-float,
  #pa-landing .pa-l-orbit,
  #pa-landing .pa-l-holo-ring{display:none !important}
  #pa-landing .pa-l-ticker-track{max-width:100vw}
  #pa-landing,#pa-landing .pa-l-hero,#pa-landing section{overflow-x:clip}

  /* حداقل اندازه خوانا برای متن فارسی روی موبایل */
  #pa-landing p,#pa-landing li,#pa-landing small,#pa-landing em,
  #pa-landing .pa-l-plan-tagline,#pa-landing .pa-l-journal-feature,
  #pa-landing .pa-faq-question,#pa-landing .pa-faq-link-copy,
  #pa-landing .pa-l-ops-note{font-size:max(12px,1em) !important;line-height:2}
  #pa-landing .pa-l-kicker{font-size:11px !important;letter-spacing:.12em}
  /* فوتر: متن‌های ریز داخل span/b هم خوانا شوند */
  #pa-landing .pa-l-foot span,#pa-landing .pa-l-foot b,
  #pa-landing footer span,#pa-landing footer b{font-size:max(11.5px,1em) !important}
}
</style>
"""
head = head + MOBILE_FIXES



skip_link = re.search(r'<a class="pa-skip-link".*?</a>', index_html, re.S).group(0)
auth_section = block(login_html, "section", "pa-auth")
auth_userbar = block(login_html, "div", "pa-auth-userbar")

# --- fix: site-accessibility.js treats any visible [role=dialog] as an OPEN modal
#     and marks every sibling `inert`. In the login-only export #pa-auth was the
#     whole page so it never carried `hidden`; here it sits next to the landing,
#     so at boot it made #pa-landing and #root inert — the page rendered but no
#     link or button could be clicked. The auth script sets hidden=false itself
#     when it opens the panel, so the correct initial state is hidden.
for _tag, _id in (("section", "pa-auth"), ("div", "pa-auth-userbar")):
    _open = re.search(rf'<{_tag} id="{_id}"[^>]*>', auth_section if _id == "pa-auth" else auth_userbar)
    if _open and " hidden" not in _open.group(0):
        _patched = _open.group(0)[:-1].rstrip() + " hidden>"
        if _id == "pa-auth":
            auth_section = auth_section.replace(_open.group(0), _patched, 1)
        else:
            auth_userbar = auth_userbar.replace(_open.group(0), _patched, 1)
        print(f"  · #{_id} starts hidden (stops it from making the page inert)")

landing = block(index_html, "div", "pa-landing")
root_div = '<div id="root"></div>'

# the React application bundle (largest script in the journal export)
app_script = max(
    (m for m in re.finditer(r"<script\b([^>]*)>", journal_html)
     if "src=" not in m.group(1)),
    key=lambda m: journal_html.find("</script>", m.end()) - m.end(),
)
app_end = journal_html.find("</script>", app_script.end())
app_tag = journal_html[app_script.start(): app_end + len("</script>")]
assert "createRoot" in app_tag, "app bundle not identified"

# --- fix: the bundle ships a hard-coded default greeting name, so every brand
#     new user was welcomed as someone else. Use the signed-in user's name
#     (injected by the server) and fall back to a neutral word.
OLD_NAME = 'userName: "\u0633\u0628\u062d\u0627\u0646"'
NEW_NAME = 'userName: (typeof window!=="undefined"&&window.__PA_USER_NAME__)||"\u0645\u0639\u0627\u0645\u0644\u0647\u200c\u06af\u0631"'
# --- fix: ورود گزارش MetaTrader 5 اعداد پرت و معاملات جعلی می‌ساخت.
#     فایل واقعی کاربر (ReportHistory-3070478.html) دو ایراد ساختاری داشت که
#     پارسر را از پا درمی‌آورد:
#
#     ۱) گزارش MT5 چهار جدول را در یک <table> پشت سر هم می‌گذارد:
#        Positions(۱۳ ستون) · Orders(۱۱) · Deals(۱۵) · Results.
#        پارسر همه ۲۱۸۲ ردیف را یک ماتریس واحد می‌دید و فقط یک سرستون
#        انتخاب می‌کرد ⇒ ردیف‌های Orders و Deals با سرستونِ Positions خوانده
#        می‌شدند و ستون Price به‌جای Profit می‌نشست ⇒ اعدادی مثل ‎-$53,181.75.
#
#     ۲) در بخش Positions سرستون ۱۳ ستون دارد ولی ردیف‌های داده ۱۴ ستون:
#        متاتریدر یک ستون بی‌نام Comment بعد از Type اضافه می‌کند. پس همه
#        ستون‌ها یکی جابه‌جا می‌شدند و «Profit» مقدار «Swap» را می‌خواند ⇒
#        همه‌ی ردیف‌ها ‎$0.00 (دقیقاً همان چیزی که در پیش‌نمایش دیده می‌شد).
_IMPORT_OLD = """function paParseImportText(e, t) {
  if (/\\.html?$/i.test(t) || /<table[\\s>]/i.test(e)) {
    const n = new DOMParser().parseFromString(e, "text/html"),
      r = [...n.querySelectorAll("tr")].map(a => [...a.querySelectorAll("th,td")].map(i => (i.textContent || "").replace(/\\s+/g, " ").trim())).filter(a => a.length > 2);
    return paTableFromMatrix(r, "MetaTrader HTML")
  }"""
_IMPORT_NEW = """function paSplitReportSections(matrix) {
  const sections = [];
  let current = null, pendingName = "";
  matrix.forEach(row => {
    const filled = row.filter(c => String(c).trim().length);
    if (filled.length <= 1) { if (filled.length === 1) pendingName = String(filled[0]).trim(); return }
    if (row.length < 3) return;
    const score = paHeaderScore(row);
    if (score >= 4 && (!current || current.rows.length > 1)) {
      current = { name: pendingName, header: row, rows: [row] };
      sections.push(current); pendingName = ""; return
    }
    if (current) current.rows.push(row)
  });
  return sections
}
function paPickReportSection(sections) {
  const hasProfit = s => s.header.some(h => /profit|p\\s*\\/?\\s*l|سود/i.test(String(h)));
  const rank = s => (hasProfit(s) ? 1e6 : 0) + (/position/i.test(s.name) ? 5e5 : 0)
    + (/deal/i.test(s.name) ? 2e5 : 0) - (/order/i.test(s.name) ? 1e5 : 0) + s.rows.length;
  return sections.slice().sort((a, b) => rank(b) - rank(a))[0] || null
}
function paParseImportText(e, t) {
  if (/\\.html?$/i.test(t) || /<table[\\s>]/i.test(e)) {
    const n = new DOMParser().parseFromString(e, "text/html"),
      r = [...n.querySelectorAll("tr")].map(a => [...a.querySelectorAll("th,td")].map(i => (i.textContent || "").replace(/\\s+/g, " ").trim())).filter(a => a.length > 2);
    const sections = paSplitReportSections(r), picked = sections.length > 1 ? paPickReportSection(sections) : null;
    if (picked && picked.rows.length > 1)
      return paTableFromMatrix(picked.rows, "MetaTrader HTML" + (picked.name ? " — " + picked.name : ""));
    return paTableFromMatrix(r, "MetaTrader HTML")
  }"""
if _IMPORT_OLD not in app_tag:
    raise SystemExit("!! الگوی paParseImportText پیدا نشد — از شیپ‌کردن نسخه ناقص خودداری شد")
app_tag = app_tag.replace(_IMPORT_OLD, _IMPORT_NEW, 1)

_ALIGN_OLD = """  const a = e[n].map((l, s) => String(l || `ستون ${s+1}`).trim()),"""
_ALIGN_NEW = """  let headerRow = e[n].slice();
  {
    const body = e.slice(n + 1).filter(l => l.some(s => String(s).trim())), tally = {};
    body.slice(0, 60).forEach(l => tally[l.length] = (tally[l.length] || 0) + 1);
    const modal = Number(Object.keys(tally).sort((x, y) => tally[y] - tally[x])[0] || headerRow.length);
    if (modal === headerRow.length + 1) {
      const at = headerRow.findIndex(h => /^\\s*type\\s*$/i.test(String(h)));
      headerRow.splice(at >= 0 ? at + 1 : headerRow.length, 0, "Comment")
    }
  }
  const a = headerRow.map((l, s) => String(l || `ستون ${s+1}`).trim()),"""
if _ALIGN_OLD not in app_tag:
    raise SystemExit("!! الگوی paTableFromMatrix پیدا نشد — از شیپ‌کردن نسخه ناقص خودداری شد")
app_tag = app_tag.replace(_ALIGN_OLD, _ALIGN_NEW, 1)
print("  · ورود MetaTrader: تفکیک بخش‌ها + هم‌ترازی ستون Comment")

if OLD_NAME in app_tag:
    app_tag = app_tag.replace(OLD_NAME, NEW_NAME, 1)
    print("  · replaced hard-coded demo greeting name")
else:
    print("  ! demo greeting name not found (already fixed?)")


# landing / marketing / auth behaviour scripts, kept inline exactly as exported
landing_motion = script_block(index_html, "pa-landing-motion")
marketing = script_block(index_html, "pa-marketing-experience")
hidden_admin = script_block(index_html, "pa-hidden-admin-access")
cms_runtime = script_block(index_html, "pa-cms-runtime")
header_nav = script_block(index_html, "pa-header-nav")

# --- fix: the CMS header menu was injected into the CTA area *next to* the
#     static links, so items like «قیمت‌گذاری» appeared twice. Render the CMS
#     menu into the real nav instead, replacing the static list, and dedupe.
OLD_MENU = ("var host=document.querySelector('.pa-l-nav-actions');if(!host)return;"
            "data.rows.forEach(function(item){if(host.querySelector('[data-cms-menu=\"'+item.id+'\"]'))return;"
            "var link=document.createElement('a');link.dataset.cmsMenu=item.id;link.href=item.url;"
            "link.textContent=item.label;link.style.cssText='color:#93a3b8;text-decoration:none;"
            "font-size:12px;margin:0 5px';host.insertBefore(link,host.firstChild)})")
NEW_MENU = ("if(!Array.isArray(data.rows)||!data.rows.length)return;"
            "var seen={},items=data.rows.filter(function(item){"
            "var key=String(item.url||'').replace(/\\/+$/,'')||String(item.label||'');"
            "if(seen[key])return false;seen[key]=1;return true});"
            "['.pa-l-mainnav','.pa-l-mobile'].forEach(function(sel){"
            "var host=document.querySelector(sel);if(!host)return;"
            "var sample=host.querySelector('a'),cls=sample?sample.className:'';"
            "host.innerHTML='';"
            "items.forEach(function(item){var link=document.createElement('a');"
            "link.dataset.cmsMenu=item.id;link.href=item.url;link.textContent=item.label;"
            "if(cls)link.className=cls;host.appendChild(link)})})")
if OLD_MENU in cms_runtime:
    cms_runtime = cms_runtime.replace(OLD_MENU, NEW_MENU, 1)
    print("  · fixed duplicated CMS header menu")
else:
    raise SystemExit("!! CMS menu snippet not found — refusing to ship the duplicate-nav bug")


# NOTE: this block already contains journal-cloud-auth.js *plus* 13.5 KB of
# motion code that does not exist in the standalone file, so it stays inline
# and journal-cloud-auth.js is deliberately NOT loaded again as an external.
auth_motion = script_block(login_html, "pa-premium-auth-motion")

# --- fix: «تغییر رمز عبور» عملاً پیدا نمی‌شد.
#     ورودی مرکز امنیت فقط یک آیکون سپرِ ۱۴px بدون متن بود، تب مربوطه اسمش
#     «پروفایل و موبایل» بود و فرم رمز جدید «تکرار رمز» نداشت (یک تایپو =
#     قفل شدن حساب). این بلوک inline است و از public/journal-cloud-auth.js
#     خوانده نمی‌شود، پس همان اصلاحات باید اینجا هم اعمال شود.
_AUTH_FIXES = [
    # ۱) دکمه ورودی: آیکون خالی → آیکون + متن
    ('manageButton.innerHTML=\'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>\';',
     'manageButton.innerHTML=\'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg><span>رمز عبور و امنیت</span>\';'),
    # ۲) تب رمز عبور اول و فعال
    ('<nav><button class="is-active" data-security-tab="devices">دستگاه\u200cها</button><button data-security-tab="sessions">نشست\u200cها</button><button data-security-tab="events">رخدادهای امنیتی</button><button data-security-tab="profile">پروفایل و موبایل</button>',
     '<nav><button class="is-active" data-security-tab="profile">رمز عبور و پروفایل</button><button data-security-tab="devices">دستگاه\u200cها</button><button data-security-tab="sessions">نشست\u200cها</button><button data-security-tab="events">رخدادهای امنیتی</button>'),
    ("renderSecurityTab('devices')", "renderSecurityTab('profile')"),
    # ۳) فرم رمز عبور با «تکرار رمز جدید»
    ('<div class="pa-profile-security"><section><h3>اطلاعات حساب و رمز عبور</h3><label>نام<input id="pa-profile-name" value="\'+h(currentAuth.user.name)+\'"></label><label>شماره فعلی<input value="\'+h(currentAuth.user.mobile)+\'" disabled dir="ltr"></label><label>رمز فعلی<input id="pa-profile-current-password" type="password" autocomplete="current-password"></label><label>رمز جدید (اختیاری)<input id="pa-profile-new-password" type="password" autocomplete="new-password" placeholder="حداقل ۸ کاراکتر"></label><button class="primary" data-save-profile>ذخیره و خروج نشست\u200cهای دیگر</button></section>',
     '<div class="pa-profile-security"><section><h3>تغییر رمز عبور</h3><p class="pa-pass-note">اول رمز فعلی را وارد کن. بعد از تغییر، همه دستگاه\u200cهای دیگر از حساب خارج می\u200cشوند.</p><label>رمز فعلی<input id="pa-profile-current-password" type="password" autocomplete="current-password" placeholder="رمز فعلی حساب"></label><label>رمز جدید<input id="pa-profile-new-password" type="password" autocomplete="new-password" placeholder="حداقل ۸ کاراکتر"></label><label>تکرار رمز جدید<input id="pa-profile-confirm-password" type="password" autocomplete="new-password" placeholder="دوباره همان رمز"></label><hr class="pa-pass-sep"><h3>نام نمایشی</h3><label>نام<input id="pa-profile-name" value="\'+h(currentAuth.user.name)+\'"></label><label>شماره فعلی<input value="\'+h(currentAuth.user.mobile)+\'" disabled dir="ltr"></label><button class="primary" data-save-profile>ذخیره تغییرات</button></section>'),
    # ۴) اعتبارسنجی قبل از ارسال
    ("async function saveProfile(){var button=document.querySelector('[data-save-profile]');button.disabled=true;try{",
     "async function saveProfile(){var button=document.querySelector('[data-save-profile]');"
     "var newPass=document.getElementById('pa-profile-new-password').value,"
     "confirmEl=document.getElementById('pa-profile-confirm-password'),"
     "confirmPass=confirmEl?confirmEl.value:newPass,"
     "currentPass=document.getElementById('pa-profile-current-password').value;"
     "if(!currentPass)return showSecurityNotice('رمز فعلی را وارد کن.',true);"
     "if(newPass){if(newPass.length<8)return showSecurityNotice('رمز جدید باید حداقل ۸ کاراکتر باشد.',true);"
     "if(newPass!==confirmPass)return showSecurityNotice('تکرار رمز جدید با رمز جدید یکی نیست.',true);"
     "if(newPass===currentPass)return showSecurityNotice('رمز جدید با رمز فعلی فرقی ندارد.',true);}"
     "button.disabled=true;try{"),
    ("showSecurityNotice('پروفایل ذخیره و نشست\u200cهای دیگر بسته شدند.')",
     "showSecurityNotice(newPass?'رمز عبور عوض شد و نشست\u200cهای دیگر بسته شدند.':'اطلاعات حساب ذخیره شد.')"),
    # ۵) دکمه دیگر یک دایره خالی نیست
    ('.pa-auth-manage{display:grid;place-items:center;width:26px;height:26px;border:0;border-radius:50%;color:#58cada;background:transparent;cursor:pointer}',
     '.pa-auth-manage{display:inline-flex;align-items:center;gap:5px;height:26px;padding:0 9px;border:1px solid rgba(88,202,218,.32);border-radius:999px;color:#7ee0ee;background:rgba(34,211,238,.08);cursor:pointer;font:inherit;font-size:9.5px;font-weight:700;white-space:nowrap;transition:.16s}'
     '.pa-auth-manage:hover{color:#bff3fb;border-color:rgba(103,232,249,.6);background:rgba(34,211,238,.16)}'
     '.pa-auth-manage svg{flex:none}'
     '.pa-pass-note{margin:0 0 10px;color:#8c9db1;font-size:9.5px;line-height:1.9}'
     '.pa-pass-sep{margin:16px 0 12px;border:0;border-top:1px solid #22304a}'
     '@media(max-width:560px){.pa-auth-manage span{display:none}.pa-auth-manage{width:26px;padding:0;justify-content:center}}'),
]
for _old, _new in _AUTH_FIXES:
    if _old not in auth_motion:
        raise SystemExit("!! الگوی بخش رمز عبور پیدا نشد — از شیپ‌کردن نسخه ناقص خودداری شد:\n   " + _old[:90])
    auth_motion = auth_motion.replace(_old, _new, 1)
print("  · «تغییر رمز عبور» قابل‌دیدن شد (دکمه برچسب‌دار + تب اول + تکرار رمز)")

body = "\n".join([
    skip_link,
    auth_section,
    auth_userbar,
    landing,
    root_div,
    # same synchronous position/semantics as the inline pa-cloud-storage-adapter
    '<script src="/journal-cloud.js"></script>',
    app_tag,
    landing_motion,
    marketing,
    hidden_admin,
    cms_runtime,
    auth_motion,
    header_nav,
    '<script src="/smartjournal-brand.js" defer></script>',
    '<script src="/journal-plan-support.js" defer></script>',
    '<script src="/journal-ux-runtime.js" defer></script>',
    '<script src="/site-accessibility.js" defer></script>',
    '<script src="/journal-card-payment.js" defer></script>',
    '<script src="/site-content.js" defer></script>',
    ROUTE_TAIL,
])

# --- fix: هر سه export مستقل بودند و بین فایل‌های .html جابه‌جا می‌شدند
#     (SmartJournal-login.html / SmartJournal-journal.html). روی سرور واقعی
#     این آدرس‌ها وجود ندارند و کاربر صفحه ۴۰۴ می‌دید ⇒ «صفحه ژورنال باز نمی‌شود».
LEGACY_NAV = [
    # دکمه‌های «ورود به ژورنال» در لندینگ → باز کردن پنل ورود در همان صفحه
    ("location.href='SmartJournal-login.html';", "window.PAEnterJournal();"),
    ("location.href=\"SmartJournal-login.html\";", "window.PAEnterJournal();"),
    # بعد از ورود موفق / نشست معتبر → مسیر واقعی ژورنال
    ("location.href='SmartJournal-journal.html'", "location.href='/journal'"),
    ("location.href=\"SmartJournal-journal.html\"", "location.href='/journal'"),
    # لینک‌های بازگشت به لندینگ
    ("location.href='SmartJournal-index.html'", "location.href='/'"),
    ("location.href=\"SmartJournal-index.html\"", "location.href='/'"),
    ("href=\"SmartJournal-index.html\"", "href=\"/\""),
    ("href=\"SmartJournal-login.html\"", "href=\"/journal\""),
    ("href=\"SmartJournal-journal.html\"", "href=\"/journal\""),
]
_nav_fixed = 0
for _old, _new in LEGACY_NAV:
    _n = body.count(_old)
    if _n:
        body = body.replace(_old, _new)
        _nav_fixed += _n
print(f"  · rewrote {_nav_fixed} legacy .html navigations to real routes")
if re.search(r"SmartJournal-(index|login|journal|Admin)\.html", body):
    left = set(re.findall(r"SmartJournal-\w+\.html", body))
    raise SystemExit(f"!! legacy file navigation still present: {left}")

doc = ('<!DOCTYPE html>\n'
       '<html lang="fa" dir="rtl" class="pa-landing-active">\n'
       f'{head}</head>\n<body>\n{body}\n</body>\n</html>\n')

# --- fix: همان لوگو ۶ بار به‌صورت base64 تکرار شده بود (۳۴۲ کیلوبایت روی هر
#     بارگذاری صفحه). حالا یک فایل جدا که مرورگر cache می‌کند.
_LOGO_B64 = re.compile(r'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADAC[A-Za-z0-9+/=]+')
_before = len(doc)
doc, _nlogo = _LOGO_B64.subn('/media/smartjournal-logo-192.webp', doc)
if _nlogo:
    print(f"  · {_nlogo} لوگوی base64 → /media/smartjournal-logo-192.webp  "
          f"({(_before-len(doc))/1024:.0f} KB کمتر)")

# --- مهر نسخه: تا همیشه بشود فهمید مرورگر دقیقاً کدام build را نشان می‌دهد
#     (کافی است در کنسول بزنید:  document.querySelector('meta[name=pa-build]').content )
import hashlib, datetime
_stamp = (datetime.datetime.now().strftime("%Y%m%d-%H%M")
          + "-" + hashlib.sha1(doc.encode("utf-8")).hexdigest()[:8])
doc = doc.replace("</title>", f'</title>\n<meta name="pa-build" content="{_stamp}">', 1)
print(f"  · build stamp: {_stamp}")

OUT.write_text(doc, encoding="utf-8")

print(f"  landing      {len(landing)/1024:9.1f} KB")
print(f"  auth panel   {len(auth_section)/1024:9.1f} KB")
print(f"  react app    {len(app_tag)/1024:9.1f} KB")
print(f"  auth motion  {len(auth_motion)/1024:9.1f} KB  (includes journal-cloud-auth)")
print(f"  → {OUT}  {OUT.stat().st_size/1024:.0f} KB")
for needed in ('id="pa-landing"', 'id="root"', 'id="pa-auth"', "createRoot", "PA_SERVER_SEO"):
    assert needed in doc, f"missing {needed}"
print("  ✓ landing + auth + app all present")
