#!/usr/bin/env node
'use strict';
/* ============================================================================
   SmartJournal — جداسازی باندل ژورنال از صفحهٔ اصلی
   ----------------------------------------------------------------------------
   مسئله: public/index.html حدود ۱.۷ مگابایت بود، چون کل برنامهٔ React ژورنال
   (۱.۴۵ مگابایت) و اسکریپت پنل ورود (۶۵ کیلوبایت) به‌صورت inline داخل همان
   فایل قرار داشتند. یعنی هر بازدیدکنندهٔ صفحهٔ اصلی — حتی کسی که فقط قیمت‌ها را
   می‌بیند — کل برنامه را دانلود می‌کرد. روی اینترنت موبایل ایران چند ثانیه
   تأخیر می‌شد و گوگل هم LCP/FCP را در رتبه‌بندی حساب می‌کند. ضمناً چون کد داخل
   HTML بود، هیچ‌وقت کش نمی‌شد: هر بار برگشت کاربر = دانلود دوباره.

   راه‌حل این اسکریپت:
     • باندل برنامه  → public/app/journal-app.<hash>.js   (تنبل / lazy)
     • اسکریپت ورود  → public/app/journal-auth.<hash>.js  (defer، کش‌شونده)
     • index.html فقط لندینگ می‌ماند + یک لودر ۱ کیلوبایتی.

   رفتار لودر:
     ۱. روی /journal باندل بلافاصله بارگذاری می‌شود (هیچ تأخیری اضافه نمی‌شود).
     ۲. روی صفحهٔ اصلی باندل اصلاً درخواست نمی‌شود؛ فقط بعد از load شدن کامل
        صفحه و در زمان بیکاری مرورگر prefetch می‌شود (روی 2G و Data Saver هم
        همین prefetch انجام نمی‌شود).
     ۳. با اولین نشانهٔ قصد کاربر (pointerdown/hover روی دکمه‌های ورود) بارگذاری
        زودتر شروع می‌شود، پس کلیک عملاً بدون انتظار باز می‌شود.

   نام فایل‌ها hash محتوا دارد ⇒ می‌شود «immutable» کش کرد و در عین حال هر نسخهٔ
   جدید بلافاصله به کاربر می‌رسد (مشکل کش کهنه که در BUGFIXES ثبت شده بود).

   منبع ساخت: src-html/index.combined.html (نسخهٔ کاملِ به‌هم‌چسبیده).
   اجرای دوباره بی‌خطر است (idempotent).
   اجرا:  npm run build:split
========================================================================== */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const PUBLIC = path.join(ROOT, 'public');
const APP_DIR = path.join(PUBLIC, 'app');
const SRC_DIR = path.join(ROOT, 'src-html');
const SOURCE = path.join(SRC_DIR, 'index.combined.html');
const TARGET = path.join(PUBLIC, 'index.html');
const MANIFEST = path.join(APP_DIR, 'chunks.json');

const log = (...a) => console.log('  ·', ...a);

/* ============================ اصلاح‌های سرعت روی HTML ======================
   این‌ها در زمان build روی خروجی اعمال می‌شوند، نه دستی روی فایل، تا اگر
   روزی build-index.py دوباره اجرا شد از بین نروند. پشتوانهٔ هرکدام اندازه‌گیری
   واقعی موبایل است (SPEED-NEXT.md).
   ========================================================================= */
const HTML_PATCHES = [
  {
    /* ۱) LCP: عنصر LCP صفحهٔ اصلی همان تیتر hero است و انیمیشن ورودی داشت
       (`paLReveal .8s ... .27s`)، یعنی از opacity صفر شروع و بیش از یک ثانیه
       بعد کامل می‌شد. اندازه‌گیری: FCP ۸۰۴ms ولی LCP ۲۱۶۰ms.
       فقط تیتر و پاراگراف زیرش از انیمیشن ورودی معاف می‌شوند؛ نمودار، شمع‌ها،
       دکمه‌ها و کارت‌های شناور دست‌نخورده می‌مانند. */
    name: 'LCP: تیتر hero بدون انیمیشن ورودی',
    apply(html) {
      if (html.includes('pa-lcp-hero-fix')) return html;
      const css = `<style id="pa-lcp-hero-fix">
#pa-landing .pa-l-title,#pa-landing .pa-l-lead{animation:none!important;opacity:1!important;transform:none!important;filter:none!important}
</style>
`;
      return html.replace('</head>', css + '</head>');
    },
  },
  {
    /* ۲) فونت مونو تزئینی است (برچسب و عدد) ولی preload شده بود و ۴۵ کیلوبایت
       را وسط مسیر بحرانی می‌گذاشت. @font-face سر جایش می‌ماند، فقط preload
       حذف می‌شود تا بعد از متن اصلی بارگذاری شود. */
    name: 'حذف preload فونت مونو',
    apply(html) {
      return html.replace(/<link[^>]*rel="preload"[^>]*jetbrains-mono-var\.woff2[^>]*>\s*/g, '');
    },
  },
  {
    /* ۳) محور وزن فونت‌ها به بازهٔ واقعیِ استفاده‌شده محدود شد
       (scripts/build-fonts.py). بازهٔ اعلام‌شده در @font-face باید با فایل
       بخواند وگرنه مرورگر وزن‌ها را اشتباه درون‌یابی می‌کند. */
    name: 'هم‌ترازی بازهٔ وزن @font-face با فونت جدید',
    apply(html) {
      return html.replace(/font-weight:\s*100 900/g, 'font-weight:400 900')
        .replace(/font-weight:\s*100 800/g, 'font-weight:400 800');
    },
  },
  {
    /* ۴) آیکون: نسخهٔ PNG اول در فهرست بود و مرورگر همان را می‌گرفت (۴۸ کیلوبایت،
       آن هم دو بار). حالا PNGها فشرده شده‌اند (npm run media:icons) و WebP
       سه‌کیلوبایتی اول فهرست است؛ PNG فقط fallback و apple-touch-icon می‌ماند. */
    name: 'ترتیب آیکون‌ها: اول WebP سبک',
    apply(html) {
      const old = '<link rel="icon" type="image/png" sizes="192x192" href="/media/smartjournal-logo-192.png">';
      if (!html.includes(old)) return html;
      return html.replace(old,
        '<link rel="icon" type="image/webp" sizes="192x192" href="/media/smartjournal-logo-192.webp">\n' + old);
    },
  },
];

/* ---------------------------------------------------------------- source -- */
function readSource() {
  if (fs.existsSync(SOURCE)) return fs.readFileSync(SOURCE, 'utf8');
  const current = fs.readFileSync(TARGET, 'utf8');
  if (!/<script\b[^>]*type="module"/.test(current)) {
    throw new Error('نه src-html/index.combined.html هست و نه public/index.html باندل inline دارد.');
  }
  fs.mkdirSync(SRC_DIR, { recursive: true });
  fs.writeFileSync(SOURCE, current);
  log('نسخهٔ کامل به‌عنوان منبع ساخت ذخیره شد: src-html/index.combined.html');
  return current;
}

/* یک <script …>…</script> کامل را برمی‌گرداند. محتوای باندل خودش رشتهٔ
   "<script" دارد، پس فقط اولین </script> بعد از شروع، پایان واقعی است. */
function scriptAt(html, startIndex) {
  const open = html.indexOf('>', startIndex) + 1;
  const close = html.indexOf('</script>', open);
  if (close < 0) throw new Error('تگ script بسته نشده است.');
  return { openTag: html.slice(startIndex, open), body: html.slice(open, close), end: close + '</script>'.length };
}

function findScript(html, test) {
  const re = /<script\b([^>]*)>/g;
  let m;
  while ((m = re.exec(html))) {
    if (!test(m[1])) continue;
    const found = scriptAt(html, m.index);
    if (found.end <= m.index) continue;
    re.lastIndex = found.end;                      // از داخل بدنه دوباره جست‌وجو نکن
    return { start: m.index, ...found, attrs: m[1] };
  }
  return null;
}

const sha8 = (text) => crypto.createHash('sha256').update(text).digest('hex').slice(0, 8);
const kb = (n) => (n / 1024).toFixed(1) + ' KB';

/* ----------------------------------------------------------------- build -- */
function build() {
  let html = readSource();
  const before = Buffer.byteLength(html);
  fs.mkdirSync(APP_DIR, { recursive: true });

  /* ۱) باندل React ژورنال (بزرگ‌ترین اسکریپت inline، type=module) */
  const app = findScript(html, (attrs) => /type="module"/.test(attrs) && !/src=/.test(attrs));
  if (!app) throw new Error('باندل type="module" پیدا نشد.');
  if (!/createRoot/.test(app.body)) throw new Error('اسکریپت پیداشده باندل React نیست (createRoot ندارد).');

  /* ۲) اسکریپت پنل ورود (شامل journal-cloud-auth + انیمیشن‌ها) */
  const auth = findScript(html, (attrs) => /id="pa-premium-auth-motion"/.test(attrs));
  if (!auth) throw new Error('بلوک pa-premium-auth-motion پیدا نشد.');

  const appName = `journal-app.${sha8(app.body)}.js`;
  const authName = `journal-auth.${sha8(auth.body)}.js`;
  const appUrl = `/app/${appName}`;
  const authUrl = `/app/${authName}`;

  const banner = '/* SmartJournal — ساخته‌شده با scripts/split-landing-bundle.js. دستی ویرایش نکنید. */\n';
  /* نسخهٔ فشرده هم همین‌جا ساخته می‌شود: فشرده‌سازی ۱.۵ مگابایت در هر درخواست
     روی Node تک‌نخی event loop را قفل می‌کند (همان مشکلی که برای HTML هم ثبت
     شده بود). سرور فایل .br / .gz آماده را مستقیم می‌فرستد. */
  /* گارد: بلوکی که inline بوده ممکن است `return` سطح‌بالا داشته باشد (دقیقاً
     همان باگی که یک‌بار journal-cloud-auth.js را از کار انداخت). داخل HTML
     مشکلی نمی‌سازد ولی به‌عنوان فایل مستقل، مرورگر کل فایل را دور می‌اندازد.
     node --check این را نمی‌گیرد (CommonJS است)، پس با vm.Script بررسی می‌کنیم. */
  function assertClassicScript(label, body) {
    try { new vm.Script(body, { filename: label }); }
    catch (error) {
      if (/import|export/.test(String(error.message))) return;   // ماژول ES
      throw new Error(`${label} به‌عنوان فایل مستقل معتبر نیست: ${error.message}`);
    }
  }

  function emit(name, body) {
    assertClassicScript(name, body);
    const file = path.join(APP_DIR, name);
    const buffer = Buffer.from(banner + body, 'utf8');
    fs.writeFileSync(file, buffer);
    fs.writeFileSync(file + '.gz', zlib.gzipSync(buffer, { level: 9 }));
    fs.writeFileSync(file + '.br', zlib.brotliCompressSync(buffer, {
      params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 10, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: buffer.length },
    }));
    return { bytes: buffer.length, brotli: fs.statSync(file + '.br').size };
  }
  const appOut = emit(appName, app.body);
  const authOut = emit(authName, auth.body);
  log(`باندل برنامه → ${appUrl} (${kb(appOut.bytes)} خام · ${kb(appOut.brotli)} با brotli)`);
  log(`اسکریپت ورود → ${authUrl} (${kb(authOut.bytes)} خام · ${kb(authOut.brotli)} با brotli)`);

  /* لودر جای خود باندل می‌نشیند تا PAEnterJournal قبل از هر کلیکی آماده باشد */
  const loader = `<script id="pa-journal-loader">
(function(){
  var CHUNKS={app:${JSON.stringify(appUrl)},auth:${JSON.stringify(authUrl)}};
  var root=document.documentElement,pending=null,prefetched=false;
  function inject(src,type){return new Promise(function(resolve,reject){
    var s=document.createElement('script');if(type)s.type=type;s.src=src;s.async=false;
    s.onload=function(){resolve(src)};s.onerror=function(){reject(new Error('chunk failed: '+src))};
    document.head.appendChild(s);
  })}
  function load(){
    if(pending)return pending;
    root.classList.add('pa-app-loading');
    pending=inject(CHUNKS.app,'module').then(function(){
      root.classList.remove('pa-app-loading');root.classList.add('pa-app-loaded');
      try{window.dispatchEvent(new Event('pa-journal-app-loaded'))}catch(e){}
    }).catch(function(error){
      pending=null;root.classList.remove('pa-app-loading');
      try{console.error('[SmartJournal] بارگذاری برنامه ناموفق بود',error)}catch(e){}
      throw error;
    });
    return pending;
  }
  function prefetch(){
    if(prefetched||pending)return;prefetched=true;
    var link=document.createElement('link');
    link.rel='prefetch';link.as='script';link.href=CHUNKS.app;
    document.head.appendChild(link);
  }
  window.PAJournal={chunks:CHUNKS,load:load,prefetch:prefetch,
    isLoading:function(){return !!pending&&!root.classList.contains('pa-app-loaded')},
    isLoaded:function(){return root.classList.contains('pa-app-loaded')}};

  /* روی /journal برنامه بلافاصله لازم است */
  if(/^\\/journal(\\/|$)/.test(location.pathname)){load();return}

  /* روی لندینگ: با اولین نشانهٔ قصد کاربر شروع کن (کلیک ورود ۴۰۰ms انیمیشن
     خروج دارد، پس معمولاً تا رسیدن به پنل ورود دانلود تمام شده است) */
  var warm=function(){load()};
  ['pointerdown','touchstart','pointerenter','focusin'].forEach(function(type){
    document.addEventListener(type,function(event){
      var target=event.target&&event.target.closest?event.target.closest('[data-pa-enter],a[href="/journal"]'):null;
      if(target)warm();
    },{capture:true,passive:true});
  });
  /* و در بدترین حالت، فقط وقتی مرورگر بیکار است prefetch کن — نه روی 2G و
     نه وقتی کاربر Data Saver را روشن کرده است. */
  var net=navigator.connection||{};
  if(!window.__PA_NO_PREFETCH&&!net.saveData&&!/(^|-)([23]g|slow-2g)$/.test(String(net.effectiveType||''))){
    window.addEventListener('load',function(){
      if('requestIdleCallback' in window)requestIdleCallback(prefetch,{timeout:8000});
      else setTimeout(prefetch,4000);
    });
  }
  /* ورود به ژورنال: اگر باندل هنوز نیامده، اول بیاورش بعد پنل را باز کن.
     (نسخهٔ قبلی pa-route-boot در این حالت به /journal ریدایرکت می‌کرد و کاربر
     یک بارگذاری کامل صفحه را دوباره تجربه می‌کرد.) */
  var enter=window.PAEnterJournal;
  window.PAEnterJournal=function(){
    load();
    if(window.PAAuth&&typeof window.PAAuth.open==='function')return enter?enter():window.PAAuth.open();
    var tries=0;
    (function wait(){
      if(window.PAAuth&&typeof window.PAAuth.open==='function')return enter?enter():window.PAAuth.open();
      if(tries++<200)return setTimeout(wait,25);
      location.href='/journal';
    })();
    return true;
  };
})();
</script>
`;

  /* اسکریپت ورود: inline بود ⇒ حالا خارجی و defer. ترتیب اجرا حفظ می‌شود چون
     journal-cloud.js هم قبل از آن و به‌صورت معمولی بارگذاری می‌شود. */
  const authTag = `<script src="${authUrl}" defer></script>\n`;

  /* برش‌ها را از انتها به ابتدا انجام می‌دهیم تا اندیس‌ها جابه‌جا نشوند */
  const cuts = [
    { start: auth.start, end: auth.end, replacement: authTag },
    { start: app.start, end: app.end, replacement: loader },
  ].sort((a, b) => b.start - a.start);
  for (const cut of cuts) html = html.slice(0, cut.start) + cut.replacement + html.slice(cut.end);

  /* رفتار «در حال آماده‌سازی» برای دکمهٔ ورود، تا کلیک بی‌بازخورد نماند */
  const LOADING_CSS = `<style id="pa-app-loading-style">
html.pa-app-loading [data-pa-enter]{cursor:progress}
html.pa-app-loading [data-pa-enter]:after{content:"";display:inline-block;width:12px;height:12px;margin-inline-start:8px;border:2px solid currentColor;border-top-color:transparent;border-radius:50%;vertical-align:-2px;animation:paAppSpin .7s linear infinite}
@keyframes paAppSpin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){html.pa-app-loading [data-pa-enter]:after{animation:none}}
</style>
`;
  if (!html.includes('pa-app-loading-style')) html = html.replace('</head>', LOADING_CSS + '</head>');

  /* اصلاح‌های سرعت (فونت، آیکون، LCP) — بالای همین فایل توضیح داده شده‌اند */
  for (const patch of HTML_PATCHES) {
    const before = html;
    html = patch.apply(html);
    log(`${patch.name}${html === before ? ' (بدون تغییر)' : ''}`);
  }

  fs.writeFileSync(TARGET, html);
  const after = Buffer.byteLength(html);

  const manifest = {
    builtAt: new Date().toISOString(),
    app: appUrl,
    auth: authUrl,
    landingBytes: after,
    combinedBytes: before,
    appBytes: appOut.bytes,
    appBrotliBytes: appOut.brotli,
    authBytes: authOut.bytes,
  };
  fs.writeFileSync(MANIFEST, JSON.stringify(manifest, null, 2) + '\n');

  /* نسخه‌های hash قدیمی پاک شوند تا دیسک پر نشود */
  let removed = 0;
  for (const file of fs.readdirSync(APP_DIR)) {
    if (file === 'chunks.json') continue;
    if (file === appName || file === authName) continue;
    if (file.startsWith(appName) || file.startsWith(authName)) continue;   // .gz / .br همین نسخه
    if (/^journal-(app|auth)\.[0-9a-f]{8}\.js(?:\.gz|\.br)?$/.test(file)) { fs.unlinkSync(path.join(APP_DIR, file)); removed++; }
  }
  if (removed) log(`${removed} نسخهٔ قدیمی chunk پاک شد`);

  console.log('');
  console.log(`  صفحهٔ اصلی: ${kb(before)}  →  ${kb(after)}`);
  console.log('');
  return manifest;
}

if (require.main === module) {
  try {
    build();
    console.log('✅ جداسازی انجام شد.');
  } catch (error) {
    console.error('❌ ' + error.message);
    process.exit(1);
  }
}

module.exports = { build };
