'use strict';
/* آزمون پلن رایگان ۷ روزه با دسترسی کامل و رفتار بعد از انقضا */

const assert = require('node:assert/strict');
const path = require('node:path');
const Database = require('better-sqlite3');

const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '../data/admin.db');
const db = new Database(DB_PATH);
const stamp = String(Date.now());
const fixture = { userId: null, mobile: '0990' + stamp.slice(-7) };
let passed = 0;
const ok = (n) => { passed += 1; console.log('✓ ' + n); };

function cookies(res) {
  const v = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie() : [res.headers.get('set-cookie')].filter(Boolean);
  return v.flatMap((x) => String(x).split(/,(?=\s*[^;,]+=)/)).map((x) => x.trim().split(';')[0]).join('; ');
}
async function req(url, { method = 'GET', body, session, status = 200 } = {}) {
  const headers = { 'user-agent': 'PA Trial Smoke' };
  if (session) headers.cookie = session.cookie;
  if (body !== undefined) {
    headers['content-type'] = 'application/json';
    if (session) headers['x-csrf-token'] = session.csrf;
  }
  const res = await fetch(BASE + url, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  assert.equal(res.status, status, `${method} ${url}: ${res.status} ${JSON.stringify(data).slice(0, 200)}`);
  return { res, data };
}
function cleanup() {
  try {
    db.pragma('foreign_keys = OFF');
    if (fixture.userId) {
      for (const t of ['payment_receipts', 'payments', 'subscriptions', 'user_sessions',
        'user_trusted_devices', 'user_security_events', 'user_otp_challenges', 'user_activity_logs',
        'user_contacts', 'user_legal_acceptances', 'journal_preferences', 'journal_sync_versions',
        'journal_trades', 'journal_accounts', 'media_files', 'sms_logs']) {
        try { db.prepare(`DELETE FROM ${t} WHERE user_id=?`).run(fixture.userId); } catch {}
      }
      db.prepare('DELETE FROM users WHERE id=?').run(fixture.userId);
    }
  } finally { db.close(); }
}

(async () => {
  /* ---- پیکربندی پلن ---- */
  const free = db.prepare("SELECT * FROM plans WHERE name='free'").get();
  assert.equal(Number(free.duration_days), 7, `free duration is ${free.duration_days}`);
  ok('پلن رایگان روی ۷ روز تنظیم است');

  const freeSections = db.prepare(
    'SELECT section_key,is_enabled FROM plan_journal_sections WHERE plan_id=?').all(free.id);
  const off = freeSections.filter((s) => !s.is_enabled).map((s) => s.section_key);
  assert.equal(off.length, 0, `still locked: ${off.join(',')}`);
  assert.equal(freeSections.length, 11);
  ok(`هر ۱۱ بخش ژورنال در پلن رایگان باز است (${freeSections.length}/11)`);

  const expired = db.prepare("SELECT * FROM plans WHERE name='expired'").get();
  assert.ok(expired, 'expired fallback plan missing');
  assert.equal(Number(expired.is_active), 0);
  ok('پلن مخفی «پایان دوره آزمایشی» ساخته شد و در سایت نمایش داده نمی‌شود');

  const publicPlans = await req('/api/public/plans');
  assert.ok(!publicPlans.data.rows.some((p) => p.name === 'expired'), 'expired leaked to public');
  ok('پلن مخفی در API عمومی قیمت‌ها دیده نمی‌شود');

  /* ---- کاربر جدید ---- */
  const signup = await req('/api/auth/signup', {
    method: 'POST', status: 202,
    body: { name: 'کاربر آزمایشی', mobile: fixture.mobile, password: 'Trial@12345', remember: true,
            acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false },
  });
  const verified = await req('/api/auth/signup/verify', {
    method: 'POST', status: 201,
    body: { challengeToken: signup.data.challengeToken, code: signup.data.devCode },
  });
  fixture.userId = verified.data.user.id;
  const user = { cookie: cookies(verified.res), csrf: verified.data.csrfToken };

  const sub = db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(fixture.userId);
  assert.ok(sub.expires_at, 'free signup got no expiry');
  const days = Math.round((new Date(sub.expires_at) - new Date(sub.started_at)) / 86400000);
  assert.equal(days, 7, `expiry is ${days} days`);
  ok(`کاربر جدید اشتراک ۷ روزه گرفت (تا ${String(sub.expires_at).slice(0, 10)})`);

  /* ---- دسترسی در دوره آزمایشی ---- */
  const ent = await req('/api/journal/entitlements', { session: user });
  const allowed = ent.data.allowedSections || (ent.data.sections || []).filter((s) => s.enabled).map((s) => s.key);
  assert.equal(allowed.length, 11, `only ${allowed.length} sections: ${allowed.join(',')}`);
  ok(`در دوره آزمایشی به هر ۱۱ بخش دسترسی دارد: ${allowed.slice(0, 5).join('، ')}…`);

  const acc = await req('/api/journal/accounts', {
    method: 'POST', session: user, status: 201,
    body: { name: 'حساب آزمایشی', startingBalance: 10000 },
  });
  ok('در دوره آزمایشی می‌تواند حساب و معامله ثبت کند');

  /* ---- شبیه‌سازی پایان دوره ---- */
  db.prepare('UPDATE subscriptions SET expires_at=? WHERE user_id=?')
    .run(new Date(Date.now() - 86400000).toISOString(), fixture.userId);

  const after = await req('/api/journal/entitlements', { session: user });
  const afterAllowed = after.data.allowedSections
    || (after.data.sections || []).filter((s) => s.enabled).map((s) => s.key);
  assert.ok(afterAllowed.length < 11, `still ${afterAllowed.length} sections after expiry`);
  assert.ok(afterAllowed.includes('dashboard'), 'dashboard should stay readable');
  assert.ok(afterAllowed.includes('history'), 'history should stay readable');
  assert.ok(!afterAllowed.includes('new'), 'new-trade must be locked after the trial');
  ok(`بعد از انقضا فقط ${afterAllowed.length} بخش باز است: ${afterAllowed.join('، ')}`);
  ok('ثبت معامله جدید بعد از پایان دوره قفل شد، ولی داده‌های قبلی قابل دیدن‌اند');

  const planAfter = after.data.plan?.name || after.data.planName;
  assert.equal(String(planAfter), 'expired');
  ok('پلن مؤثر بعد از انقضا «expired» است، نه رایگانِ کامل');

  /* ---- خرید اشتراک دوباره همه‌چیز را باز می‌کند ---- */
  const pro = db.prepare("SELECT id FROM plans WHERE name='pro'").get();
  db.prepare("UPDATE subscriptions SET plan_id=?,status='active',expires_at=? WHERE user_id=?")
    .run(pro.id, new Date(Date.now() + 30 * 86400000).toISOString(), fixture.userId);
  const paid = await req('/api/journal/entitlements', { session: user });
  const paidAllowed = paid.data.allowedSections
    || (paid.data.sections || []).filter((s) => s.enabled).map((s) => s.key);
  assert.ok(paidAllowed.length >= 10, `pro only has ${paidAllowed.length}`);
  ok(`با خرید پلن حرفه‌ای دوباره ${paidAllowed.length} بخش باز شد`);

  console.log(`\n${passed} آزمون پلن رایگان ۷ روزه پاس شد.`);
})()
  .then(() => cleanup())
  .catch((e) => { cleanup(); console.error('\n✗ ' + e.message); process.exit(1); });
