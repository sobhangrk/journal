/**
 * smoke-watchdog.js — تست دیده‌بان خودکار و ابزارهای نگهداری
 *   ۱) tune-sms-limits — فقط پیش‌فرض‌ها را بالا می‌برد و idempotent است
 *   ۲) enable-auto-cleanup — پاکسازی خودکار را روشن می‌کند
 *   ۳) watchdog — چک‌ها، هشدار، حذف تکرار، پیام «برطرف شد»، بررسی گواهی
 *   ۴) sms-alert — ارسال واقعی به یک درگاه ساختگی محلی + ثبت sms_logs
 * بعد از تست همه‌چیز به حالت قبل برمی‌گردد.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const APP_DIR = process.env.APP_DIR || ROOT;
const DATABASE_PATH = process.env.DATABASE_PATH || path.join(ROOT, 'data', 'admin.db');
const SECRET = process.env.APP_ENCRYPTION_SECRET || 'pa-journal-development-encryption-key-change-me';
/* روی حجم خانه (نه /tmp) — /tmp در محیط‌های تستی ممکن است پر باشد و خودِ
   دیده‌بان درست هشدار «دیسک پر» بدهد؛ آنجا هشدار دیسک را با آستانهٔ ۱٪
   عمدی خراب می‌کنیم نه با دیسک واقعاً پر. */
const TMP = path.join(ROOT, '.tmp-wd-test');
fs.mkdirSync(TMP, { recursive: true });

const Database = require(path.join(APP_DIR, 'node_modules', 'better-sqlite3'));
const db = new Database(DATABASE_PATH);

let okc = 0, badc = 0;
const ok = (c, n, x = '') => { if (c) okc++; else badc++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

function encryptSecret(value) {
  const key = crypto.createHash('sha256').update(SECRET).digest();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), enc]).toString('base64url');
}

/* درگاه ساختگی محلی — پاسخ ملی‌پیامک را شبیه‌سازی می‌کند */
const fakeHits = { credit: 0, send: 0 };
const fakeServer = http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    res.setHeader('content-type', 'application/json');
    if (req.url.includes('/GetCredit')) { fakeHits.credit++; res.end(JSON.stringify({ RetStatus: 1, Value: 500 })); return; }
    if (req.url.includes('/SendSMS')) { fakeHits.send++; res.end(JSON.stringify({ RetStatus: 1, Value: '1234567890123456789' })); return; }
    res.statusCode = 404; res.end('{}');
  });
});

function runWatchdog(args, env) {
  /* spawnSync حلقهٔ رویدادِ همین فرایند را قفل می‌کند و سرور ساختگیِ تست
     نمی‌تواند به دیده‌بان جواب بدهد؛ پس async spawn لازم است. */
  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    const child = spawn(process.execPath, [path.join(ROOT, 'scripts', 'watchdog.js'), ...args], {
      env: { ...process.env, ...env },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let out = '';
    child.stdout.on('data', d => out += d);
    child.stderr.on('data', d => out += d);
    const kill = setTimeout(() => { try { child.kill('SIGKILL'); } catch {} }, 90000);
    child.on('exit', code => { clearTimeout(kill); resolve({ code, out }); });
    child.on('error', reject);
  });
}
function runScript(script, args = []) {
  const r = spawnSync(process.execPath, [path.join(ROOT, 'scripts', script), ...args], {
    env: { ...process.env, APP_DIR, DATABASE_PATH },
    encoding: 'utf8', timeout: 60000,
  });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || '') };
}

(async () => {
  /* ═══════ ۱) tune-sms-limits ═══════ */
  console.log('── ۱) بالا بردن سقف پیامک (NAT ایران) ──');
  const before = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  const r1 = runScript('tune-sms-limits.js');
  let after = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
  ok(Number(after.mobile_limit_count) === 10 && Number(after.ip_limit_count) === 60, 'سقف‌ها از ۵/۱۲ به ۱۰/۶۰ رسید', `${after.mobile_limit_count}/${after.ip_limit_count}`);
  const r2 = runScript('tune-sms-limits.js');
  ok(/قبلاً تغییر/.test(r2.out), 'اجرای دوباره چیزی را عوض نمی‌کند (idempotent)', '');

  /* ═══════ ۲) enable-auto-cleanup ═══════ */
  console.log('\n── ۲) پاکسازی خودکار تصاویر یتیم ──');
  const c1 = runScript('enable-auto-cleanup.js');
  const ac = db.prepare("SELECT auto_cleanup FROM file_settings WHERE id='default'").get();
  ok(Number(ac.auto_cleanup) === 1, 'پاکسازی خودکار روشن شد', 'auto_cleanup=' + ac.auto_cleanup);
  const c2 = runScript('enable-auto-cleanup.js');
  ok(/از قبل روشن/.test(c2.out), 'اجرای دوباره بی‌اثر و سالم است', '');

  /* ═══════ ۳) درگاه ساختگی + هشدار واقعی ═══════ */
  console.log('\n── ۳) دیده‌بان: هشدار، حذف تکرار، برطرف‌شدن ──');
  await new Promise(res => fakeServer.listen(0, '127.0.0.1', res));
  const port = fakeServer.address().port;
  const fakeUrl = `http://127.0.0.1:${port}/api/SendSMS`;
  db.prepare(`INSERT INTO sms_providers (id,provider_key,provider_type,name,config_json,credentials_encrypted,balance,unit_cost,status,is_enabled,is_primary,priority,updated_at)
    VALUES ('prov_wd_test','wd_test_meli','melipayamak','ملی‌پیامک تست دیده‌بان',?,?,0,0,'healthy',1,1,1,?)`)
    .run(JSON.stringify({ url: fakeUrl }), encryptSecret({ username: '09938917033', password: 'testpass' }), new Date().toISOString());

  const baseEnv = {
    APP_DIR, DATABASE_PATH,
    APP_ENCRYPTION_SECRET: SECRET,
    DATA_DIR: TMP,
    WATCHDOG_PHONE: '09121112233',
    WATCHDOG_NO_RECOVERY: '1', /* فاز اول فقط هشدار */
    WATCHDOG_NO_SYSTEMD: '1',  /* در محیط تست systemd نیست */
    WATCHDOG_REPEAT_H: '1',
  };
  /* فاز الف: همه‌چیز خراب — سایت، دیسک، خطاهای پیامک */
  const failEnv = { ...baseEnv, WATCHDOG_URL: 'http://127.0.0.1:9', WATCHDOG_DISK_PCT: '1', WATCHDOG_SMS_FAILS: '0', WATCHDOG_CERT_DIR: TMP + '/nocert' };
  let out = await runWatchdog([], failEnv);
  const state1 = JSON.parse(fs.readFileSync(path.join(TMP, 'watchdog-state.json'), 'utf8'));
  ok(!!state1.alerts.site, 'هشدار «سایت پایین است» ثبت شد', '');
  ok(!!state1.alerts.disk, 'هشدار «دیسک پر است» ثبت شد', '');
  ok(!!state1.alerts['sms-fails'], 'هشدار «خطاهای پیامک» ثبت شد', '');
  ok(fakeHits.send >= 3, 'پیامک هشدار واقعاً به درگاه رفت', `${fakeHits.send} پیامک`);
  const wdLogs1 = db.prepare("SELECT COUNT(*) c FROM sms_logs WHERE type='watchdog' AND status='sent'").get().c;
  ok(wdLogs1 >= 3, 'پیامک‌ها در sms_logs ثبت شدند', wdLogs1 + ' ردیف');

  /* اجرای دوبارهٔ فوری → بدون تکرار */
  await runWatchdog([], failEnv);
  const wdLogs2 = db.prepare("SELECT COUNT(*) c FROM sms_logs WHERE type='watchdog' AND status='sent'").get().c;
  ok(wdLogs2 === wdLogs1, 'اجرای فوریِ دوباره پیامک تکراری نمی‌فرستد (ضد اسپم)', wdLogs1 + ' → ' + wdLogs2);

  /* فاز ب: همه‌چیز درست شد → پیام «برطرف شد» + پاک شدن هشدارها */
  const okEnv = { ...baseEnv, WATCHDOG_URL: 'http://127.0.0.1:3000', WATCHDOG_DISK_PCT: '99', WATCHDOG_SMS_FAILS: '999', WATCHDOG_NO_RECOVERY: undefined };
  out = await runWatchdog([], okEnv);
  const state2 = JSON.parse(fs.readFileSync(path.join(TMP, 'watchdog-state.json'), 'utf8'));
  ok(Object.keys(state2.alerts).length === 0, 'بعد از رفع مشکل، هشدارهای باز صفر شد', JSON.stringify(state2.alerts));
  ok(/✅ برطرف شد/.test(out.out), 'پیام «برطرف شد» ارسال شد', '');
  ok(fakeHits.credit >= 2, 'اعتبار ملی‌پیامک واقعاً چک شد (GetCredit)', `${fakeHits.credit} بار`);

  /* فاز ج: بررسی گواهی SSL — یکی منقضی‌شونده، یکی سالم */
  const certDir = path.join(TMP, 'certs');
  fs.mkdirSync(certDir, { recursive: true });
  fs.mkdirSync(path.join(certDir, 'expiring'), { recursive: true });
  fs.mkdirSync(path.join(certDir, 'healthy'), { recursive: true });
  const mk = days => spawnSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-keyout', '/tmp/wdkey.pem', '-out', '/tmp/wdcert.pem', '-days', String(days), '-nodes', '-subj', '/CN=test'], { encoding: 'utf8' });
  mk(5); fs.copyFileSync('/tmp/wdcert.pem', path.join(certDir, 'expiring', 'cert.pem'));
  mk(60); fs.copyFileSync('/tmp/wdcert.pem', path.join(certDir, 'healthy', 'cert.pem'));
  const certEnv = { ...okEnv, WATCHDOG_CERT_DIR: certDir };
  out = await runWatchdog([], certEnv);
  ok(/گواهی SSL/.test(out.out) && /✗/.test(out.out), 'گواهی ۵ روزه هشدار داد', '');
  const state3 = JSON.parse(fs.readFileSync(path.join(TMP, 'watchdog-state.json'), 'utf8'));
  ok(!!state3.alerts.cert, 'هشدار گواهی در وضعیت ثبت شد', '');

  /* فاز د: --test و --status */
  const sendBefore = fakeHits.send;
  out = await runWatchdog(['--test'], okEnv);
  ok(/ارسال پیامک آزمایشی/.test(out.out) && fakeHits.send > sendBefore, 'حالت --test پیامک آزمایشی می‌فرستد', fakeHits.send + ' پیامک');
  out = await runWatchdog(['--status'], okEnv);
  ok(/وضعیت دیده‌بان/.test(out.out), 'حالت --status گزارش می‌دهد', '');

  /* ═══════ پاک‌سازی ═══════ */
  db.prepare("DELETE FROM sms_providers WHERE id IN ('prov_wd_test','prov_wd_debug')").run();
  db.prepare("DELETE FROM sms_logs WHERE type='watchdog'").run();
  db.prepare("UPDATE sms_settings SET mobile_limit_count=?,ip_limit_count=?,rate_window_minutes=? WHERE id='default'")
    .run(before.mobile_limit_count, before.ip_limit_count, before.rate_window_minutes);
  db.prepare("UPDATE file_settings SET auto_cleanup=0 WHERE id='default'").run();
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
  fakeServer.close();

  console.log(`\n${okc}/${okc + badc} بررسی نگهداری و دیده‌بان پاس شد.`);
  process.exit(badc ? 1 : 0);
})().catch(e => { console.error('WATCHDOG SMOKE FAILED:', e.stack || e); try { db.prepare("DELETE FROM sms_providers WHERE id='prov_wd_test'").run(); } catch {} process.exit(1); });
