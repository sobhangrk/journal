/**
 * probe-sub-top.js — قرارداد جدید حباب اشتراک:
 *   • >۹۰۰px (ریل دسکتاپ): همیشه بالا-چپ، بدون تداخل با متن و چیپ‌ها
 *   • ≤۹۰۰px (موبایل/تبلت): فقط در داشبورد دیده می‌شود؛ در داشبورد هم
 *     پایین/روی نوار حساب‌ها بدون تداخل با چیپ‌ها و متن‌ها
 *   • ≤۳۸۰px: نقطهٔ وضعیت پنهان؛ ≤۳۶۰px: برچسب روز پنهان (جمع‌وجور)
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));
const overlap = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);
const MIN_HIT = 6; // تداخلِ واقعیِ «جوهر متن» حداقل ۶px در هر دو بُعد
const hitLine = (fab, glyphs) => {
  for (const lines of glyphs) {
    for (const l of (Array.isArray(lines[0]) ? lines : [lines])) {
      const ox = Math.min(fab[0] + fab[2], l[0] + l[2]) - Math.max(fab[0], l[0]);
      const oy = Math.min(fab[1] + fab[3], l[1] + l[3]) - Math.max(fab[1], l[1]);
      if (ox >= MIN_HIT && oy >= MIN_HIT) return l;
    }
  }
  return null;
};

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0993' + String(Date.now()).slice(-7);
  let s1;
  for (let i = 0; i < 3; i++) {
    s1 = await post('/api/auth/signup', { name: 'کاربر حباب', mobile, password: 'Top@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
    if (s1.data.challengeToken) break;
    await wait(1500);
  }
  if (!s1.data.challengeToken) { console.error('signup failed'); process.exit(1); }
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  let okc = 0, badc = 0;
  const ok = (c, n, x = '') => { if (c) okc++; else badc++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

  const getState = p => p.evaluate(() => {
    const pick = s => {
      const el = document.querySelector(s);
      if (!el) return null;
      const cs = getComputedStyle(el), r = el.getBoundingClientRect();
      if (cs.display === 'none' || cs.visibility === 'hidden' || !r.width) return null;
      return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)];
    };
    const glyph = s => {
      const el = document.querySelector(s);
      if (!el) return null;
      try {
        const range = document.createRange();
        range.selectNodeContents(el);
        // هر خط جداگانه — جعبهٔ اتحادیِ چند خط گوشه‌های خالی دارد و خطا می‌دهد
        const lines = [...range.getClientRects()].map(r => [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]);
        if (!lines.length) return null;
        return lines;
      } catch (e) { return null; }
    };
    const chips = () => {
      const bar = document.querySelector('.pa-accounts-bar');
      if (!bar) return [];
      return [...bar.querySelectorAll('button, input, .pa-account-chip')].map(e => {
        const r = e.getBoundingClientRect();
        return r.width ? [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)] : null;
      }).filter(Boolean);
    };
    return {
      fab: pick('.ctcu-fab'),
      view: document.documentElement.getAttribute('data-pa-view') || null,
      chips: chips(),
      glyphs: [glyph('.pa-greeting'), glyph('.pa-section-title'),
        glyph('.pa-form-hero-title'), glyph('.pa-form-hero-eyebrow'),
        glyph('.pa-feature-hero-copy'), glyph('.pa-check-hero-l'), glyph('.pa-set-hero-main')].filter(Boolean),
    };
  });

  const sizes = [[1366, 768, 'desktop'], [1100, 800, 'desktop'], [1000, 800, 'desktop'], [901, 800, 'desktop'], [900, 1180, 'narrow'], [820, 1180, 'narrow'], [760, 900, 'narrow'], [390, 844, 'narrow'], [360, 800, 'narrow'], [320, 660, 'narrow']];
  const tabs = ['new', 'history', 'calendar', 'risk', 'checklist', 'settings'];

  for (const [w, h, kind] of sizes) {
    const p = await br.newPage();
    await p.setViewport({ width: w, height: h, isMobile: w < 700, hasTouch: w < 700 });
    await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
    for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
    await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(4200);

    console.log(`\n── ${w}×${h} (${kind}) ──`);
    let st = await getState(p);
    ok(!!st.fab, `داشبورد: حباب دیده می‌شود`, JSON.stringify(st.fab));
    if (st.fab) {
      ok(st.fab[1] < 130, `داشبورد: حباب بالای صفحه است`, 'top=' + st.fab[1]);
      ok(st.fab[0] < 100, `داشبورد: حباب سمت چپ است`, 'left=' + st.fab[0]);
      let hit = false;
      for (const c of st.chips) if (overlap(st.fab, c)) hit = true;
      ok(!hit, `داشبورد: با چیپ‌های نوار حساب‌ها تداخل ندارد`, hit ? 'تداخل!' : st.chips.length + ' چیپ آزاد');
      const ghit = hitLine(st.fab, st.glyphs);
      ok(!ghit, `داشبورد: با متن‌ها تداخل ندارد`, ghit ? JSON.stringify(ghit) : 'پاک');
      if (w <= 380) ok(st.fab[2] < 150, `≤۳۸۰px: حباب جمع‌وجور است`, 'width=' + st.fab[2]);
    }

    for (const t of tabs) {
      const clicked = await p.evaluate(t => {
        const el = document.querySelector(`.pa-tab[data-tab="${t}"]`) || [...document.querySelectorAll('.pa-mobile-nav button')].find(b => (b.innerText || '').includes({ new: 'ثبت', history: 'تاریخچه', calendar: 'تقویم', risk: 'ریسک', checklist: 'چک', settings: 'تنظیمات' }[t]));
        if (el) { el.click(); return true; }
        return false;
      }, t);
      if (!clicked) continue;
      await wait(1300);
      st = await getState(p);
      if (kind === 'narrow') {
        ok(!st.fab, `[${t}] ≤۹۰۰px: حباب مخفی است تا متن سربرگ را نپوشاند`, st.fab ? 'دیده می‌شود ' + JSON.stringify(st.fab) : 'پنهان ✓');
      } else {
        ok(!!st.fab, `[${t}] دسکتاپ: حباب دیده می‌شود`, JSON.stringify(st.fab));
        if (st.fab) {
          const ghit = hitLine(st.fab, st.glyphs);
          ok(!ghit, `[${t}] دسکتاپ: با متن تداخل ندارد`, ghit ? JSON.stringify(ghit) : 'پاک');
        }
      }
    }
    await p.close();
  }

  await br.close();
  console.log(`\n${okc}/${okc + badc} بررسی پاس شد.`);
  process.exit(badc ? 1 : 0);
})().catch(e => { console.error('PROBE FAILED:', e.stack || e); process.exit(1); });
