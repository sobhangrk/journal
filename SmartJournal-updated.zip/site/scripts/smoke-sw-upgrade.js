/**
 * smoke-sw-upgrade.js — آیا نسخهٔ جدید واقعاً به مرورگری می‌رسد که نسخهٔ
 * قدیمی را کش کرده است؟
 *
 * چرا این تست؟ کاربر گفت «هنوز سایت تغییری نکرده». باید بدون حدس ثابت کنیم
 * مسیر ارتقا کار می‌کند: مرورگری که Service Worker قدیمی (کش ثابت + «اول کش»)
 * را نصب کرده، بعد از آپلود نسخهٔ جدید، در چند بار باز کردن صفحه کد تازه را
 * اجرا می‌کند؟
 *
 * روش: یک سرور کوچک واقعی که می‌تواند بین «قدیمی» و «جدید» سوییچ کند، و یک
 * مرورگر واقعی که همان مسیر کاربر را طی می‌کند.
 */
const http = require('http');
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const wait = ms => new Promise(r => setTimeout(r, ms));
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

let MODE = 'old';          // old | new
let APPV = 'v1';           // نسخهٔ کدِ برنامه
let stamp = 'stamp-1';

/* ---- Service Worker قدیمی: نام کش ثابت + «اول کش» برای فایل‌های کد ---- */
const SW_OLD = `
const CACHE='smartjournal-shell-v19';
const SHELL=['/app.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.mode==='navigate')return;
  if(!SHELL.includes(u.pathname))return;
  e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request)));
});
`;

/* ---- Service Worker جدید: نام کش نسخه‌دار + «اول شبکه» برای کد ---- */
const SW_NEW = () => `
const BUILD='${stamp}';
const CACHE='smartjournal-'+BUILD;
const CODE=['/app.js'];
self.addEventListener('install',e=>{e.waitUntil(self.skipWaiting())});
self.addEventListener('activate',e=>{e.waitUntil(
  caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())
)});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.mode==='navigate')return;
  if(!CODE.includes(u.pathname))return;
  e.respondWith(fetch(e.request).then(r=>{
    if(r.ok){const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c))}
    return r;
  }).catch(()=>caches.match(e.request)));
});
`;

const PAGE = `<!doctype html><html><head><meta charset="utf-8"><title>sw</title></head><body>
<script src="/app.js"></script>
<script>
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('/sw.js',{scope:'/'});
  navigator.serviceWorker.addEventListener('controllerchange',function(){
    var k='pa_sw_reloaded_v1';
    try{ if(sessionStorage.getItem(k))return; sessionStorage.setItem(k,'1'); }catch(_){ return }
    location.reload();
  });
  addEventListener('load',function(){setTimeout(function(){
    navigator.serviceWorker.getRegistration().then(function(r){ if(r){ r.update(); if(r.waiting) r.waiting.postMessage('skip'); } });
  },400)});
}
</script></body></html>`;

const server = http.createServer((req, res) => {
  const u = req.url.split('?')[0];
  if (u === '/sw.js') {
    res.writeHead(200, { 'Content-Type': 'application/javascript', 'Cache-Control': 'no-store' });
    return res.end(MODE === 'old' ? SW_OLD : SW_NEW());
  }
  if (u === '/app.js') {
    res.writeHead(200, { 'Content-Type': 'application/javascript', 'Cache-Control': 'no-cache' });
    return res.end(`window.__APP_VERSION__=${JSON.stringify(APPV)};`);
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
  res.end(PAGE);
});

(async () => {
  await new Promise(r => server.listen(4777, '127.0.0.1', r));
  const B = 'http://127.0.0.1:4777/';
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const p = await br.newPage();

  console.log('\n── ۱) وضعیت کاربر: نسخهٔ قدیمی نصب و کش شده ──');
  await p.goto(B, { waitUntil: 'networkidle2' });
  await wait(1200);
  await p.reload({ waitUntil: 'networkidle2' });   // تا SW کنترل را بگیرد
  await wait(1200);
  const controlled = await p.evaluate(() => !!navigator.serviceWorker.controller);
  ok('Service Worker قدیمی صفحه را کنترل می‌کند', controlled);
  ok('کد نسخهٔ ۱ اجرا می‌شود', (await p.evaluate(() => window.__APP_VERSION__)) === 'v1');

  /* ثابت کنیم باگ واقعی است: فقط فایل کد را عوض کن، SW قدیمی بماند */
  APPV = 'v2';
  await p.reload({ waitUntil: 'networkidle2' }); await wait(1000);
  const stuck = await p.evaluate(() => window.__APP_VERSION__);
  ok('بازتولید باگ: با SW قدیمی، کد جدید اجرا نمی‌شود', stuck === 'v1', 'اجرا شد: ' + stuck);

  console.log('\n── ۲) آپلود نسخهٔ جدید روی سرور ──');
  MODE = 'new'; stamp = 'stamp-2';
  let reloads = 0, got = null;
  for (let i = 0; i < 3; i++) {
    reloads++;
    await p.reload({ waitUntil: 'networkidle2' });
    await wait(1800);                       // فرصت برای نصب/فعال‌سازی و ریلود خودکار
    got = await p.evaluate(() => window.__APP_VERSION__);
    if (got === 'v2') break;
  }
  ok('بعد از آپلود، کد جدید واقعاً اجرا می‌شود', got === 'v2', `با ${reloads} بار باز کردن صفحه`);
  ok('چند بار باز کردن لازم است؟ حداکثر ۲ بار', got === 'v2' && reloads <= 2, reloads + ' بار');

  const caches = await p.evaluate(() => caches.keys());
  ok('کش قدیمی پاک شده است', !caches.includes('smartjournal-shell-v19'), JSON.stringify(caches));

  console.log('\n── ۳) نسخهٔ بعدی هم بدون دردسر می‌رسد ──');
  APPV = 'v3'; stamp = 'stamp-3';
  let r2 = 0, got2 = null;
  for (let i = 0; i < 2; i++) {
    r2++;
    await p.reload({ waitUntil: 'networkidle2' });
    await wait(1500);
    got2 = await p.evaluate(() => window.__APP_VERSION__);
    if (got2 === 'v3') break;
  }
  ok('نسخهٔ سوم با یک بار باز کردن می‌رسد', got2 === 'v3' && r2 === 1, got2 + ' با ' + r2 + ' بار');

  await br.close();
  server.close();
  const pass = R.filter(x => x[0]).length;
  console.log(`\n${pass}/${R.length} تست موفق`);
  process.exit(pass === R.length ? 0 : 1);
})();
