/**
 * smoke-captcha-lockout.js — رگرسیون «قفل شدن پشت CAPTCHAی ناموجود»
 *
 * باگ واقعی روی سرور کاربر: بعد از چند رمز اشتباه، صفحه‌ی ورود می‌گفت
 *   «پس از چند تلاش ناموفق، تأیید CAPTCHA لازم است»
 * و در همان کادر می‌نوشت «CAPTCHA در محیط فعلی تنظیم نشده».
 *
 * علت: verifyTurnstile وقتی کلیدی تنظیم نبود، در production همیشه false
 * برمی‌گرداند ⇒ کاربر برای همیشه پشت دری می‌ماند که کلیدش وجود ندارد.
 *
 * این تست دقیقاً همان وضعیت را می‌سازد: production، بدون کلید Turnstile،
 * چند رمز اشتباه، بعد رمز درست.
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3200';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

async function post(path, body, jar = []) {
  const r = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json', cookie: jar.join('; ') },
    body: JSON.stringify(body),
  });
  (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
  let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, data: d };
}

(async () => {
  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const path = require('path');
  const db = new Database(process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'admin.db'));

  const stamp = Date.now().toString(36);
  const mobile = '0992' + String(Date.now()).slice(-7);
  const password = 'CaptchaUser@12345';
  const userId = 'usr_cap_' + stamp;
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO users (id,name,mobile,password_hash,status,created_at,updated_at,mobile_verified_at,failed_login_count)
              VALUES (?,?,?,?, 'active', ?, ?, ?, 0)`)
    .run(userId, 'کاربر تست کپچا', mobile, bcrypt.hashSync(password, 10), now, now, now);
  db.close();

  console.log('\n── ۱) وضعیت پیکربندی CAPTCHA ──');
  const cfg = await fetch(BASE + '/api/auth/security-config').then(r => r.json()).catch(() => ({}));
  ok('سرور می‌گوید CAPTCHA تنظیم نشده', cfg.captchaConfigured === false || !cfg.turnstileSiteKey,
     JSON.stringify(cfg).slice(0, 120));

  console.log('\n── ۲) چهار بار رمز اشتباه ──');
  for (let i = 1; i <= 4; i++) {
    const r = await post('/api/auth/login', { mobile, password: 'WrongPass@' + i });
    console.log(`   تلاش ${i}: ${r.status} · captchaRequired=${r.data.captchaRequired}`);
  }
  const counted = (() => {
    const d = new Database(process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'admin.db'));
    const row = d.prepare('SELECT failed_login_count c FROM users WHERE id=?').get(userId);
    d.close(); return Number(row?.c || 0);
  })();
  ok('شمارنده‌ی تلاش ناموفق بالا رفت', counted >= 3, 'تعداد=' + counted);

  console.log('\n── ۳) حالا با رمز درست ──');
  const good = await post('/api/auth/login', { mobile, password });
  ok('ورود با رمز درست قفل نشد (۴۲۸ نمی‌دهد)', good.status !== 428,
     `status=${good.status} · ${String(good.data.error || '').slice(0, 70)}`);
  /* اگر درگاه پیامکی در این محیط تنظیم نباشد، ۵۰۳ «ارسال پیامک ناموفق»
     می‌گیریم — این یعنی از دروازه‌ی CAPTCHA رد شده‌ایم و به مرحله‌ی OTP
     رسیده‌ایم، که همان چیزی است که این تست می‌سنجد. */
  const passedGate = good.status === 200 || good.status === 202
    || (good.status === 503 && /پیامک/.test(String(good.data.error || '')));
  ok('از دروازه‌ی CAPTCHA رد شد و به مرحله بعد رسید', passedGate,
     'status=' + good.status + ' · ' + String(good.data.error || 'بدون خطا').slice(0, 60));
  ok('پیام «تأیید CAPTCHA لازم است» دیده نمی‌شود',
     !/CAPTCHA/i.test(JSON.stringify(good.data)), JSON.stringify(good.data).slice(0, 90));

  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون CAPTCHA پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nCAPTCHA SMOKE FAILED:', e.stack || e); process.exit(1); });
