/**
 * تست عیب‌یابی درگاه پیامک — هر خرابی باید در مرحله «درست» گیر بیفتد.
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000', FAKE = 'http://127.0.0.1:4555';
const R = []; const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '\n        ' + x : '')); };
const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: jar.join('; ') };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const r = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(r); let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, data: d };
}
const show = steps => steps.map(s => `${s.ok ? '✓' : '✗'} ${s.label} — ${String(s.detail).slice(0, 90)}`).join('\n        ');

(async () => {
  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const stamp = Date.now().toString(36), username = 'diag' + stamp;
  const db = new Database(require('path').join(__dirname, '..', 'data', 'admin.db'));
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_diag_' + stamp, 'مدیر عیب‌یابی', username, '096' + String(Date.now()).slice(-8),
         bcrypt.hashSync('Diag@12345', 10), new Date().toISOString());
  db.prepare("DELETE FROM sms_providers WHERE provider_key LIKE 'diag-%'").run();
  // حالت پایه: درگاه‌های seed بدون کلید باشند تا تست تکرارپذیر بماند
  db.prepare("UPDATE sms_providers SET credentials_encrypted=NULL WHERE provider_key IN ('kavenegar','melipayamak','farazsms')").run();
  db.close();

  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'Diag@12345' } });
  const csrf = login.data.csrfToken;
  const mk = async (name, cfg, creds, type = 'generic_webhook') => (await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: type, name: name + ' ' + stamp, providerKey: 'diag-' + name + '-' + stamp,
    priority: 50, isEnabled: false, config: cfg, credentials: creds } })).data.id;
  const diag = async pid => (await req(`/api/admin/sms/providers/${pid}/diagnose`, { method: 'POST', csrf, body: {} })).data;

  console.log('\n── ۱) درگاه سالم ──');
  const good = await mk('healthy', { url: FAKE + '/send' }, { bearerToken: 'TEST-SECRET-KEY' });
  let d = await diag(good);
  ok('همه مراحل سبز', d.ok === true, show(d.steps));

  console.log('\n── ۲) توکن اشتباه (باید در مرحله «اعتبارسنجی کلید» گیر کند) ──');
  const badToken = await mk('badtoken', { url: FAKE + '/send' }, { bearerToken: 'WRONG' });
  d = await diag(badToken);
  const authStep = d.steps.find(s => s.key === 'auth');
  ok('مرحله شبکه سالم گزارش شد', d.steps.filter(s => ['dns', 'tcp', 'tls'].includes(s.key)).every(s => s.ok));
  ok('دقیقاً مرحله اعتبارسنجی کلید قرمز شد', authStep && !authStep.ok, show(d.steps));
  ok('پیام خطا توکن اشتباه را می‌گوید', /401|توکن/.test(authStep && authStep.detail || ''));

  console.log('\n── ۳) آدرس اشتباه / سرور خاموش (باید در TCP گیر کند) ──');
  const deadHost = await mk('dead', { url: 'http://127.0.0.1:4999/send' }, { bearerToken: 'x' });
  d = await diag(deadHost);
  const tcpStep = d.steps.find(s => s.key === 'tcp');
  ok('مرحله TCP قرمز شد', tcpStep && !tcpStep.ok, show(d.steps));

  console.log('\n── ۴) دامنه ناموجود ──');
  const rejected = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'generic_webhook', name: 'baddns ' + stamp, providerKey: 'diag-baddns-' + stamp,
    priority: 50, isEnabled: false, config: { url: 'https://this-host-does-not-exist-' + stamp + '.invalid/send' },
    credentials: { bearerToken: 'x' } } });
  ok('همان موقع ساخت جلویش گرفته می‌شود', rejected.status >= 400,
     'status=' + rejected.status + ' · ' + String(rejected.data.error || '').slice(0, 90));
  const badDns = null;

  console.log('\n── ۵) بدون API Key (باید همان اول گیر کند) ──');
  const noCreds = (await req('/api/admin/sms/providers')).data;
  const kavenegar = (await req('/api/admin/usage')).data.providers.find(p => p.provider_type === 'kavenegar');
  d = await diag(kavenegar.id);
  ok('مرحله «اطلاعات اتصال» قرمز شد', d.steps[0] && !d.steps[0].ok, show(d.steps));
  ok('بقیه مراحل بیهوده اجرا نشدند', d.steps.length === 1);

  console.log('\n── ۶) کاوه‌نگار واقعی با کلید الکی (از این سندباکس) ──');
  await req(`/api/admin/sms/providers/${kavenegar.id}`, { method: 'PATCH', csrf, body: {
    providerType: 'kavenegar', name: kavenegar.name, providerKey: kavenegar.provider_key,
    config: { template: 'verify' }, credentials: { apiKey: 'FAKE-KEY-FOR-DIAGNOSTIC' } } });
  d = await diag(kavenegar.id);
  ok('عیب‌یابی نتیجه داد (بدون کرش)', Array.isArray(d.steps) && d.steps.length >= 3, show(d.steps));
  const netStep = d.steps.find(s => ['tls', 'tcp'].includes(s.key) && !s.ok);
  ok('مسدودی شبکه به‌جای «کلید اشتباه» گزارش شد', !!netStep,
     netStep ? netStep.label + ' → ' + netStep.detail.slice(0, 110) : 'شبکه باز بود');

  // پاکسازی
  for (const pid of [good, badToken, deadHost].filter(Boolean)) await req(`/api/admin/sms/providers/${pid}`, { method: 'DELETE', csrf, body: { force: true } });
  await req(`/api/admin/sms/providers/${kavenegar.id}`, { method: 'PATCH', csrf, body: {
    providerType: 'kavenegar', name: kavenegar.name, providerKey: kavenegar.provider_key, config: {}, credentials: null } });

  const bad = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - bad}/${R.length} آزمون عیب‌یابی پاس شد.`);
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error('FAILED:', e.stack || e); process.exit(1); });
