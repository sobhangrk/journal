/**
 * smoke-mt5-import.js — رگرسیون «ورود متاتریدر اعداد پرت می‌سازد»
 *
 * با فایل واقعی کاربر (ReportHistory-3070478.html) کار می‌کند.
 *
 * دو باگ ساختاری که این فایل رو کرد:
 *   ۱) گزارش MT5 چهار جدول را پشت سر هم در یک <table> می‌گذارد
 *      (Positions ۱۳ ستون · Orders ۱۱ · Deals ۱۵ · Results) و پارسر همه را
 *      یک ماتریس با یک سرستون می‌دید ⇒ ستون Price به‌جای Profit خوانده می‌شد.
 *   ۲) در Positions سرستون ۱۳ ستون دارد ولی داده‌ها ۱۴ (ستون بی‌نام Comment
 *      بعد از Type) ⇒ «Profit» مقدار «Swap» را می‌خواند ⇒ همه ‎$0.00.
 *
 * ملاک درستی، خودِ فایل است: بخش Results می‌گوید Total Net Profit = -1 512.43
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const fs = require('fs');
const path = require('path');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const FILE = process.env.MT5_FILE || '/home/user/uploads/ReportHistory-3070478.html';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

/* حقیقت مرجع را مستقیم از خود فایل درمی‌آوریم */
function truthFromFile() {
  const text = fs.readFileSync(FILE).toString('utf16le');
  const rows = [...text.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
    .map(m => [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => c[1].replace(/<[^>]+>/g, '').replace(/&nbsp;|\u00a0/g, ' ').trim()));
  const start = rows.findIndex(r => r.length === 1 && /^Positions$/i.test(r[0]));
  const header = rows[start + 1];
  const body = [];
  for (let i = start + 2; i < rows.length; i++) {
    if (rows[i].length !== header.length + 1) break;
    body.push(rows[i]);
  }
  const num = v => Number(String(v).replace(/[\s\u00a0]/g, '').replace(/[−–—]/g, '-')) || 0;
  const net = body.reduce((s, r) => s + num(r[r.length - 1]), 0);
  const net2 = [...text.matchAll(/Total Net Profit:[\s\S]{0,200}?>(-?[\d\s,.\u00a0]+)</gi)]
    .map(m => num(m[1]))[0];
  return { positions: body.length, net, reported: net2, sample: body.slice(0, 3).map(r => num(r[r.length - 1])) };
}

(async () => {
  if (!fs.existsSync(FILE)) { console.log('  فایل نمونه MT5 موجود نیست — تست رد شد:', FILE); process.exit(0); }
  const truth = truthFromFile();
  console.log('\n── حقیقت مرجع، از خودِ فایل ──');
  console.log(`  ردیف‌های Positions      : ${truth.positions}`);
  console.log(`  جمع ستون Profit         : ${truth.net.toFixed(2)}`);
  console.log(`  «Total Net Profit» فایل : ${truth.reported}`);

  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0996' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'کاربر متاتریدر', mobile, password: 'Mt5@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await br.newPage();
  await page.setViewport({ width: 1366, height: 900 });
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 160)));
  await page.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
  for (const c of jar) { const [n, ...v] = c.split('='); await page.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
  await page.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(4500);

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button,a')].find(x => /MetaTrader|CSV/.test(x.innerText || ''));
    if (b) b.click();
  });
  await wait(2500);

  const input = await page.$('input[type=file]');
  ok('کادر انتخاب فایل پیدا شد', !!input);
  await input.uploadFile(FILE);
  await wait(6000);

  const parsed = await page.evaluate(() => {
    const txt = document.body.innerText;
    const detected = (txt.match(/MetaTrader HTML[^\n]*/) || [])[0] || null;
    const willSave = (txt.match(/([\d۰-۹,]+)\s*معامله در حساب/) || [])[1] || null;
    const more = (txt.match(/و\s*([\d۰-۹,]+)\s*ردیف دیگر/) || [])[1] || null;
    const cells = [...document.querySelectorAll('.pa-import-table tbody tr')].map(tr =>
      [...tr.querySelectorAll('td')].map(td => td.innerText.trim()));
    return { detected, willSave, more, rows: cells.slice(0, 8) };
  });
  const fa2en = v => String(v || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/,/g, '');
  const saveCount = Number(fa2en(parsed.willSave));

  console.log('\n── آنچه برنامه فهمید ──');
  console.log('  تشخیص  :', parsed.detected);
  console.log('  ذخیره  :', saveCount, 'معامله');
  parsed.rows.slice(0, 5).forEach(r => console.log('   ', r.join(' | ').slice(0, 96)));

  ok('فرمت MetaTrader تشخیص داده شد', /MetaTrader/i.test(parsed.detected || ''), parsed.detected);
  ok('تعداد معاملات با فایل می‌خواند', Math.abs(saveCount - truth.positions) <= 2,
     `برنامه ${saveCount} · فایل ${truth.positions}`);

  const plValues = parsed.rows.map(r => Number(String(r[5] || '').replace(/[^\d.-]/g, ''))).filter(v => !Number.isNaN(v));
  ok('P/L همه‌ی ردیف‌ها صفر نیست', plValues.some(v => v !== 0), 'نمونه: ' + plValues.join(', '));
  ok('هیچ عدد پرتی (بزرگ‌تر از ۲۰٬۰۰۰ دلار) نیست', plValues.every(v => Math.abs(v) < 20000),
     'بیشینه: ' + Math.max(...plValues.map(Math.abs)));

  console.log('\n── ورود واقعی و بررسی جمع کل ──');
  const clicked = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find(x => /^ورود\s+[\d۰-۹,]+\s+معامله$/.test((x.innerText || '').trim()));
    if (!b || b.disabled) return null;
    b.click(); return (b.innerText || '').trim();
  });
  ok('دکمه «ورود معاملات» فعال بود', !!clicked, clicked || 'پیدا نشد/غیرفعال');
  await wait(9000);

  const balance = await page.evaluate(() => {
    const chip = [...document.querySelectorAll('button,div,span')]
      .map(e => (e.innerText || '').trim())
      .find(t => /^حساب اصلی\s*\$?-?[\d,.]+$/.test(t) || /^\$?-?[\d,.]+\s*حساب اصلی$/.test(t));
    return chip || null;
  });
  const shown = Number(String(balance || '').replace(/[^\d.-]/g, '')) || null;
  const expected = 10000 + truth.net;         // موجودی اولیه ۱۰٬۰۰۰ دلار
  console.log(`  موجودی نمایش‌داده‌شده: ${balance}`);
  console.log(`  انتظار (۱۰٬۰۰۰ + سود/زیان فایل): ${expected.toFixed(2)}`);
  ok('موجودی حساب بعد از ورود، با جمع فایل می‌خواند',
     shown !== null && Math.abs(shown - expected) < 60, `برنامه ${shown} · انتظار ${expected.toFixed(2)}`);

  await page.screenshot({ path: '/tmp/mt5-import.png' });
  ok('هیچ خطای JS رخ نداد', errs.length === 0, errs.join(' | '));
  await br.close();

  const fail = R.filter(x => !x[0]).length;
  console.log(`\n${R.length - fail}/${R.length} آزمون ورود MetaTrader پاس شد.`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('\nMT5 IMPORT SMOKE FAILED:', e.stack || e); process.exit(1); });
