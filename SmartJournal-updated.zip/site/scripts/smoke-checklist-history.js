/**
 * smoke-checklist-history.js
 * بررسی می‌کند که:
 *   ۱) در تب چک‌لیست می‌شود به روزها/هفته‌های دیگر رفت و برگشت.
 *   ۲) تیک روزِ گذشته ذخیره و بعد از رفرش برمی‌گردد.
 *   ۳) مرور هفتگی/ماهانه در بازه‌های مختلف ذخیره می‌شود و همه در آرشیو دیده می‌شوند.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

function client() {
  const jar = [];
  return {
    jar,
    async post(path, body) {
      const r = await fetch(B + path, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
      (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
      let d = {}; try { d = await r.json(); } catch {}
      return { status: r.status, data: d };
    },
  };
}

(async () => {
  const mobile = '0995' + String(Date.now()).slice(-7);
  const pass = 'ChkUser@111111';
  const a = client();
  const s1 = await a.post('/api/auth/signup', { name: 'کاربر چک‌لیست', mobile, password: pass, remember: true,
    acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  const s2 = await a.post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });
  ok('حساب آزمایشی ساخته شد', s2.status === 201, 'status=' + s2.status);

  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 1000 });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e.message || e)));
  // ۴۰۴ روی کلیدهای ذخیره‌سازیِ هنوز خالی رفتار عادی سرور است، نه خطای ما.
  page.on('response', r => {
    if (r.status() >= 400 && !/\/api\/journal\/storage\//.test(r.url())) errors.push(r.status() + ' ' + r.url());
  });

  const cookies = a.jar.map(c => { const [name, ...v] = c.split('='); return { name, value: v.join('='), domain: '127.0.0.1', path: '/' }; });
  await page.setCookie(...cookies);

  await page.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForSelector('#root', { timeout: 30000 });
  await wait(2500);

  // به تب چک‌لیست برو
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('[data-tab]')].find(x => x.getAttribute('data-tab') === 'checklist');
    b && b.click();
  });
  await wait(1200);

  const hasCards = await page.$$eval('.pa-checklist-card', n => n.length);
  ok('کارت‌های چک‌لیست رندر شدند', hasCards >= 4, 'count=' + hasCards);

  const navs = await page.$$eval('.pa-period-nav', n => n.length);
  ok('پیمایشگر بازه روی هر چهار کارت هست', navs === 4, 'count=' + navs);

  // یک کار روزانه اضافه کن
  await page.evaluate(() => {
    const card = document.querySelector('.pa-checklist-card[data-period="daily"]');
    const input = card.querySelector('.pa-checklist-add input');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(input, 'تست انضباط');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    card.querySelector('.pa-checklist-add button').click();
  });
  await wait(600);

  // برو به روز قبل
  const beforeLabel = await page.$eval('.pa-checklist-card[data-period="daily"] .pa-period-label', el => el.textContent.trim());
  await page.evaluate(() => {
    document.querySelector('.pa-checklist-card[data-period="daily"] .pa-period-arrow').click();
  });
  await wait(500);
  const afterLabel = await page.$eval('.pa-checklist-card[data-period="daily"] .pa-period-label', el => el.textContent.trim());
  ok('با فلش قبلی به روز دیگری می‌رود', beforeLabel !== afterLabel, beforeLabel + ' → ' + afterLabel);

  const archiveNote = await page.$$eval('.pa-period-archive', n => n.length);
  ok('هشدار «آرشیو» برای روز گذشته نمایش داده می‌شود', archiveNote >= 1);

  // تیک بزن روی روز گذشته
  await page.evaluate(() => {
    document.querySelector('.pa-checklist-card[data-period="daily"] .pa-checklist-check').click();
  });
  await wait(900);
  const checkedPast = await page.$$eval('.pa-checklist-card[data-period="daily"] .pa-checklist-check.checked', n => n.length);
  ok('تیک روی روز گذشته ثبت شد', checkedPast === 1);

  // مرور هفتگی: هفتهٔ جاری
  await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][0];
    const ta = card.querySelector('textarea');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, 'مرور هفتهٔ جاری');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    card.querySelector('.pa-note-save').click();
  });
  await wait(900);

  // برو هفتهٔ قبل و آنجا هم بنویس
  await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][0];
    card.querySelector('.pa-period-arrow').click();
  });
  await wait(600);
  const emptyOnPrevWeek = await page.evaluate(() => [...document.querySelectorAll('.pa-review-note-card')][0].querySelector('textarea').value);
  ok('هفتهٔ قبل جدا و خالی است (متن هفتهٔ جاری نشت نکرده)', emptyOnPrevWeek === '', 'value=' + JSON.stringify(emptyOnPrevWeek));

  await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][0];
    const ta = card.querySelector('textarea');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, 'مرور هفتهٔ گذشته');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    card.querySelector('.pa-note-save').click();
  });
  await wait(900);

  // مرور ماهانه: ماه جاری + ماه قبل
  await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][1];
    const ta = card.querySelector('textarea');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, 'مرور ماه جاری');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    card.querySelector('.pa-note-save').click();
  });
  await wait(900);
  await page.evaluate(() => {
    [...document.querySelectorAll('.pa-review-note-card')][1].querySelector('.pa-period-arrow').click();
  });
  await wait(600);
  await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][1];
    const ta = card.querySelector('textarea');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, 'مرور ماه گذشته');
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    card.querySelector('.pa-note-save').click();
  });
  await wait(1200);

  // ---- رفرش و بررسی ماندگاری ----
  await page.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForSelector('#root', { timeout: 30000 });

  await wait(2800);
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('[data-tab]')].find(x => x.getAttribute('data-tab') === 'checklist');
    b && b.click();
  });
  await wait(1500);

  const stored = await page.evaluate(async () => {
    const r = await fetch('/api/journal/storage/pa-review-notes', { credentials: 'same-origin' });
    const b = await r.json();
    return b.value ? JSON.parse(b.value) : null;
  });
  ok('هر دو مرور هفتگی ذخیره شده‌اند', stored && Object.keys(stored.weekly || {}).length === 2,
     JSON.stringify(stored && stored.weekly));
  ok('هر دو مرور ماهانه ذخیره شده‌اند', stored && Object.keys(stored.monthly || {}).length === 2,
     JSON.stringify(stored && stored.monthly));

  const checks = await page.evaluate(async () => {
    const r = await fetch('/api/journal/storage/pa-checklist-checks', { credentials: 'same-origin' });
    const b = await r.json();
    return b.value ? JSON.parse(b.value) : null;
  });
  ok('تیک روز گذشته بعد از رفرش هنوز روی سرور هست', checks && Object.keys(checks.daily || {}).length >= 1,
     JSON.stringify(checks && checks.daily));

  // آرشیو مرورها در UI
  const histCount = await page.evaluate(() => {
    const card = [...document.querySelectorAll('.pa-review-note-card')][0];
    const t = card.querySelector('.pa-note-hist-t');
    if (!t) return -1;
    t.click();
    return card.querySelectorAll('.pa-note-hist-i').length;
  });
  await wait(400);
  const histAfter = await page.$$eval('.pa-review-note-card .pa-note-hist-i', n => n.length);
  ok('فهرست آرشیو مرورهای هفتگی نمایش داده می‌شود', histAfter >= 2, 'count=' + histAfter);

  ok('هیچ خطای جاوااسکریپتی رخ نداد', errors.length === 0, errors.slice(0, 3).join(' | '));

  await browser.close();
  const pass_ = R.filter(r => r[0]).length, fail = R.length - pass_;
  console.log(`\n  ${pass_} قبول · ${fail} رد\n`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
