#!/usr/bin/env python3
"""
فونت‌ها را به woff2 محلی و سبک تبدیل می‌کند.

چرا محلی: سایت فونت را از fonts.googleapis.com می‌گرفت که در ایران کند یا بلاک
است؛ نتیجه‌اش رندر شدن با تاهوما و پریدن چیدمان بود.

چرا دوباره بهینه شد (اندازه‌گیری SPEED-NEXT.md):
  روی موبایل کند، ۱۲۸ کیلوبایت فونت در مسیر بحرانی بود. دو کار انجام شد:

  ۱) محدود کردن محور وزن فونت متغیر به همان چیزی که سایت واقعاً استفاده می‌کند.
     در کل پروژه هیچ متنی وزن کمتر از ۴۰۰ ندارد (تنها ۱۰۰های موجود، خودِ
     تعریف `font-weight:100 900` در @font-face بودند). با محدود کردن به
     ۴۰۰–۹۰۰ حجم وزیرمتن ۲۷٪ کم شد بدون هیچ تغییر ظاهری.
  ۲) JetBrains Mono فقط برای برچسب‌ها و اعداد لاتین است: جدول‌های OpenType
     (کرنینگ و لیگاتور) برایش لازم نیست و با حذفشان ۸۱٪ سبک‌تر شد.

     وزیرمتن                فارسی است و جدول‌های GSUB/GPOS برای اتصال حروف
     حیاتی‌اند؛ آن‌ها دست‌نخورده می‌مانند (`--layout-features=*`).

نتیجه:  vazirmatn ۸۴٫۴KB → ۶۱٫۶KB   ·   jetbrains ۴۵٫۶KB → ۸٫۹KB

اجرا:
    python3 scripts/build-fonts.py            # از روی فونت‌های فعلی public/fonts
    python3 scripts/build-fonts.py --src /tmp/fontdl   # از روی دانلود اصلی
"""
import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "public" / "fonts"
OUT.mkdir(parents=True, exist_ok=True)

# فارسی/عربی + لاتین + نشانه‌گذاری + نیم‌فاصله (U+200C)
VAZIR_UNICODES = ",".join([
    "U+0020-007E",            # لاتین پایه
    "U+00A0-00FF",            # لاتین-۱
    "U+0600-06FF",            # عربی/فارسی + ارقام فارسی
    "U+200C-200F",            # نیم‌فاصله و کنترل جهت
    "U+2010-2027",            # خط تیره و نقل‌قول
    "U+2030-205E",            # نشانه‌گذاری عمومی
    "U+20AC,U+FDFC",          # یورو، ریال
    "U+2190-2199",            # فلش‌ها (← → ↑ ↓)
    "U+2212,U+221E,U+2248",   # منها، بی‌نهایت، تقریباً مساوی
    "U+22EE,U+25CF,U+25CB",   # سه‌نقطه عمودی، دایره‌ها
    "U+2713,U+2714,U+2717",   # تیک و ضربدر
    "U+2605,U+2606",          # ستاره
    "U+FB50-FDFF",            # فرم‌های نمایشی عربی A (متن کپی‌شده از PDF)
    "U+FE70-FEFF",            # فرم‌های نمایشی عربی B
    # بلوک‌های «عربی تکمیلی» (U+0750-077F) و «عربی توسعه‌یافته» (U+08A0-08FF)
    # عمداً حذف شده‌اند: فارسی از آن‌ها استفاده نمی‌کند.
])

# فقط لاتین: این فونت برای شماره کارت، برچسب‌ها و متن‌های انگلیسی است
MONO_UNICODES = ",".join([
    "U+0020-007E",
    "U+00A0-00FF",
    "U+2010-2027",
    "U+2030-205E",
    "U+2022",                 # بولت •
])

#            نام            unicodes         محور وزن    جدول‌های OpenType
JOBS = [
    ("Vazirmatn",      "vazirmatn-var.woff2",     VAZIR_UNICODES, "400:900", "*"),
    ("JetBrains Mono", "jetbrains-mono-var.woff2", MONO_UNICODES, "400:800", ""),
]
# اگر از دانلود اصلی می‌سازید، نام فایل منبع فرق می‌کند:
ORIGINAL_SOURCES = {
    "vazirmatn-var.woff2": "vazir/fonts/webfonts/Vazirmatn[wght].woff2",
    "jetbrains-mono-var.woff2": "jb/fonts/variable/JetBrainsMono[wght].ttf",
}


def instance_axis(path: Path, axis_range: str, destination: Path) -> None:
    """محور وزن را به بازهٔ لازم محدود می‌کند (فونت متغیر می‌ماند)."""
    from fontTools.ttLib import TTFont
    with tempfile.TemporaryDirectory() as tmp:
        raw = Path(tmp) / "instanced.ttf"
        subprocess.run([sys.executable, "-m", "fontTools.varLib.instancer",
                        str(path), f"wght={axis_range}", "-o", str(raw)],
                       check=True, capture_output=True)
        font = TTFont(raw)
        font.flavor = "woff2"
        font.save(destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--src", default="", help="پوشهٔ فونت‌های اصلی دانلودشده")
    args = parser.parse_args()
    src_dir = Path(args.src) if args.src else None

    print("  فونت                 قبل        بعد        صرفه‌جویی")
    print("  " + "─" * 52)
    total_before = total_after = 0

    for name, filename, unicodes, axis, features in JOBS:
        target = OUT / filename
        if src_dir:
            source = src_dir / ORIGINAL_SOURCES[filename]
        else:
            source = target
        if not source.exists():
            raise SystemExit(f"!! فایل پیدا نشد: {source}")

        before = source.stat().st_size
        with tempfile.TemporaryDirectory() as tmp:
            subset = Path(tmp) / "subset.woff2"
            subprocess.run([
                "pyftsubset", str(source),
                f"--output-file={subset}",
                f"--unicodes={unicodes}",
                "--flavor=woff2",
                f"--layout-features={features}",
                "--no-hinting",
                "--desubroutinize",
                "--drop-tables+=DSIG",
                "--name-IDs=*",
            ], check=True, capture_output=True)
            if axis:
                instance_axis(subset, axis, target)
            else:
                shutil.copyfile(subset, target)

        after = target.stat().st_size
        total_before += before
        total_after += after
        print(f"  {name:<20} {before/1024:>7.1f}KB {after/1024:>9.1f}KB"
              f"   ‑{(1 - after / before) * 100:>4.0f}٪")

    print("  " + "─" * 52)
    print(f"  {'مجموع':<20} {total_before/1024:>7.1f}KB {total_after/1024:>9.1f}KB"
          f"   ‑{(1 - total_after / total_before) * 100:>4.0f}٪")
    print("\n  ⚠️ بازهٔ وزن در @font-faceها باید با محور فونت بخواند:")
    print("     Vazirmatn → font-weight:400 900 ، JetBrains Mono → font-weight:400 800")
    print("     (public/index.html با npm run build:split ، و shared-fonts.js / admin.css دستی)")


if __name__ == "__main__":
    main()
