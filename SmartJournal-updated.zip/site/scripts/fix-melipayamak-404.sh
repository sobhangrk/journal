#!/bin/bash
# ============================================================================
#   وصله‌ی فوری — خطای «ملی‌پیامک: 404» در عیب‌یابی درگاه پیامک
#
#   علت: تابع ساخت آدرس، بخش /SendSMS را از انتهای آدرسِ پیش‌فرض هم برمی‌داشت
#        و آدرس نهایی /api/GetCredit می‌شد، در حالی که همه‌ی متدهای REST
#        ملی‌پیامک زیر /api/SendSMS/ هستند.
#
#   اجرا روی سرور:  bash /root/fix-melipayamak-404.sh
# ============================================================================
set -u
APP="${APP_DIR:-/opt/smartjournal}"
g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; o=$'\033[0m'
ok(){ echo "  ${g}✓${o} $*"; }
die(){ echo "${r}✗ $*${o}"; exit 1; }

[ -f "$APP/server.js" ] || die "$APP/server.js پیدا نشد"
STAMP=$(date +%Y%m%d-%H%M%S)
BK="${BACKUP_DIR:-/root}"
cp "$APP/server.js"      "$BK/server.js.bak-$STAMP"      || die "پشتیبان‌گیری ناموفق بود (با root اجرا کنید)"
cp "$APP/sms-gateway.js" "$BK/sms-gateway.js.bak-$STAMP" || die "پشتیبان‌گیری ناموفق بود (با root اجرا کنید)"
ok "پشتیبان گرفته شد: $BK/*.bak-$STAMP"

node - "$APP" <<'NODE' || die "وصله اعمال نشد — فایل‌ها دست‌نخورده‌اند (پشتیبان: $BK)"
const fs = require('fs');
const path = require('path');
const APP = process.argv[2];

/* ---------- server.js ---------- */
const sp = path.join(APP, 'server.js');
let s = fs.readFileSync(sp, 'utf8');
let changed = 0;

if (!s.includes('function melipayamakRoot')) {
  const helper = `function melipayamakRoot(configUrl){
  let root=String(configUrl||'').trim().replace(/\\/+$/,'');
  if(!root)return 'https://rest.payamak-panel.com/api/SendSMS';
  root=root.replace(/\\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i,'');
  root=root.replace(/\\/SendSMS\\/SendSMS$/i,'/SendSMS');
  return root;
}
`;
  const anchor = 'async function deliverWithProvider(';
  if (s.includes(anchor)) { s = s.replace(anchor, helper + anchor); changed++; }
}

/* الگو نباید به کاما حساس باشد؛ آرگومان‌های replace خودشان کاما دارند. */
const bad = /const base=String\(config\.url\|\|'https:\/\/rest\.payamak-panel\.com\/api\/SendSMS'\)[\s\S]*?\.replace\(\/\\\/\$\/,''\),/;
if (bad.test(s)) { s = s.replace(bad, "const base=melipayamakRoot(config.url),"); changed++; }

if (changed) fs.writeFileSync(sp, s);
if (!s.includes('melipayamakRoot(config.url)')) {
  console.error('  ✗ نقطه‌ی فراخوانی در server.js پیدا/جایگزین نشد');
  process.exit(2);
}
console.log(changed ? '  ✓ server.js اصلاح شد' : '  ✓ server.js از قبل درست بود');

/* ---------- sms-gateway.js ---------- */
const gp = path.join(APP, 'sms-gateway.js');
let g = fs.readFileSync(gp, 'utf8');
const badG = /const base = String\(config\.url \|\| 'https:\/\/rest\.payamak-panel\.com\/api\/SendSMS'\)\s*\n\s*\.replace\([\s\S]*?\.replace\(\/\\\/\$\/, ''\);/;
if (badG.test(g)) {
  g = g.replace(badG,
`let base = String(config.url || '').trim().replace(/\\/+$/, '');
        if (!base) base = 'https://rest.payamak-panel.com/api/SendSMS';
        base = base.replace(/\\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i, '')
                   .replace(/\\/SendSMS\\/SendSMS$/i, '/SendSMS');`);
  fs.writeFileSync(gp, g);
  console.log('  ✓ sms-gateway.js اصلاح شد');
} else if (g.includes("if (!base) base = 'https://rest.payamak-panel.com/api/SendSMS'")) {
  console.log('  ✓ sms-gateway.js از قبل درست بود');
} else {
  console.log('  ! الگوی مورد انتظار در sms-gateway.js پیدا نشد — دستی بررسی کنید');
}
NODE

grep -q 'melipayamakRoot(config.url)' "$APP/server.js" || die "تأیید نهایی رد شد — از پشتیبان برگردانید: cp $BK/server.js.bak-$STAMP $APP/server.js"
ok "تأیید نهایی: نقطه‌ی فراخوانی درست است"

node --check "$APP/server.js"      || die "server.js خراب شد — پشتیبان: $BK/server.js.bak-$STAMP"
node --check "$APP/sms-gateway.js" || die "sms-gateway.js خراب شد — پشتیبان: $BK/sms-gateway.js.bak-$STAMP"
ok "سلامت نحوی هر دو فایل تایید شد"

echo
echo "آدرسی که از این به بعد ساخته می‌شود:"
node -e "
const src=require('fs').readFileSync('$APP/server.js','utf8');
const m=/function melipayamakRoot\(configUrl\)\{[\s\S]*?\n\}/.exec(src);
if(!m){console.log('  (تابع پیدا نشد)');process.exit(0)}
eval(m[0]);
console.log('  GetCredit         →', melipayamakRoot('')+'/GetCredit');
console.log('  BaseServiceNumber →', melipayamakRoot('')+'/BaseServiceNumber');
"

systemctl restart smartjournal 2>/dev/null && ok "سرویس ری‌استارت شد" || echo "  ${y}!${o} خودتان ری‌استارت کنید: systemctl restart smartjournal"
sleep 5
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 http://127.0.0.1/)
[ "$code" = "200" ] && ok "سایت سالم است ($code)" || echo "  ${y}!${o} سایت کد $code داد"

echo
echo "${g}تمام. حالا در پنل مدیریت دوباره «عیب‌یابی» را بزنید.${o}"
echo "برای بازگرداندن:  cp $BK/server.js.bak-$STAMP $APP/server.js && systemctl restart smartjournal"
