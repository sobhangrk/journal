/**
 * ممیزی تعاملی: پنل مدیریت (همه ۱۲ بخش) و اپ ژورنال (همه ۱۱ بخش)
 * با کلیک واقعی ماوس، و رصد خطای JS و درخواست‌های ناموفق.
 */
const puppeteer = require(process.env.PUPPETEER_PATH||'puppeteer');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const B = 'http://127.0.0.1:3000';
const bugs = [];

async function realClick(p, el) {
  await el.evaluate(e => e.scrollIntoView({ block: 'center' }));
  await new Promise(r => setTimeout(r, 300));
  const box = await el.boundingBox();
  if (!box) return false;
  await p.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  return true;
}

(async () => {
  const stamp = Date.now().toString(36);
  const db = new Database(process.env.DB_FILE || require('path').join(__dirname, '..', 'data', 'admin.db'));
  const username = 'nav' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_nav_' + stamp, 'ممیز ناوبری', username, '091' + String(Date.now()).slice(-8),
         bcrypt.hashSync('Nav@12345', 10), new Date().toISOString());
  ['user_otp_challenges', 'sms_logs'].forEach(t => { try { db.prepare('DELETE FROM ' + t).run(); } catch {} });
  db.close();

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  /* ══════════ پنل مدیریت ══════════ */
  console.log('════════ پنل مدیریت ════════');
  const a = await br.newPage(); await a.setViewport({ width: 1500, height: 1000 });
  const aErr = [], aBad = [];
  a.on('pageerror', e => aErr.push(String(e).slice(0, 150)));
  a.on('response', r => { if (r.status() >= 400 && !/\/api\/admin\/me/.test(r.url())) aBad.push(r.status() + ' ' + r.url().replace(B, '')); });

  await a.goto(B + '/admin', { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 2500));
  await a.type('#loginMobile', username, { delay: 8 });
  await a.type('#loginPassword', 'Nav@12345', { delay: 8 });
  await a.click('#loginSubmit');
  await new Promise(r => setTimeout(r, 5000));

  const views = await a.evaluate(() => [...document.querySelectorAll('[data-view]')].map(b => b.dataset.view));
  console.log('  بخش‌ها:', views.join('، '));

  for (const view of views) {
    const before = aErr.length, badBefore = aBad.length;
    const el = await a.$(`[data-view="${view}"]`);
    await realClick(a, el);
    await new Promise(r => setTimeout(r, 3200));
    const state = await a.evaluate(() => {
      const login = document.querySelector('#loginScreen');
      const onLogin = !!(login && !login.hidden && getComputedStyle(login).display !== 'none');
      const main = document.querySelector('.content,.main-area,#pageTitle')
        ? document.querySelector('.content') || document.body : document.body;
      const text = (main.innerText || '').trim();
      return { len: text.length, head: text.slice(0, 45).replace(/\n/g, ' '), onLogin };
    });
    if (state.onLogin) { console.log('  ✗ هنوز صفحه ورود است — بقیه بررسی بی‌معنی است'); bugs.push(['پنل', 'critical', 'ورود انجام نشد']); break; }
    const newErr = aErr.slice(before), newBad = [...new Set(aBad.slice(badBefore))];
    const status = newErr.length ? '✗ خطای JS' : newBad.length ? '⚠ ' + newBad[0] : state.len < 120 ? '⚠ محتوای کم' : '✓';
    console.log(`  ${status.padEnd(14)} ${view.padEnd(14)} ${state.len}ch  ${state.head}`);
    if (newErr.length) bugs.push(['پنل/' + view, 'critical', newErr.join(' | ')]);
    if (newBad.length) bugs.push(['پنل/' + view, 'high', newBad.join(' | ')]);
    if (state.len < 120) bugs.push(['پنل/' + view, 'medium', 'محتوای صفحه تقریباً خالی است']);
  }
  await a.screenshot({ path: '/tmp/audit-admin.png' });
  await a.close();

  /* ══════════ اپ ژورنال ══════════ */
  console.log('\n════════ اپ ژورنال ════════');
  const mobile = '0993' + String(Date.now()).slice(-7);
  const jar = [];
  const uReq = async (path, body) => {
    const r = await fetch(B + path, { method: 'POST', headers: { cookie: jar.join('; '), 'content-type': 'application/json' }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    let d = {}; try { d = await r.json(); } catch {}
    return { status: r.status, data: d };
  };
  const su = await uReq('/api/auth/signup', { name: 'کاربر ممیزی', mobile, password: 'Audit@12345',
    remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  const vr = await uReq('/api/auth/signup/verify', { challengeToken: su.data.challengeToken, code: su.data.devCode });
  if (vr.status !== 201) { console.log('  ✗ ثبت‌نام تست ناموفق:', vr.status, JSON.stringify(vr.data).slice(0, 120)); }

  const j = await br.newPage(); await j.setViewport({ width: 1500, height: 1000 });
  const jErr = [], jBad = [];
  j.on('pageerror', e => jErr.push(String(e).slice(0, 150)));
  j.on('response', r => { if (r.status() >= 400 && !/\/api\/journal\/storage\//.test(r.url())) jBad.push(r.status() + ' ' + r.url().replace(B, '')); });
  await j.setCookie(...jar.map(c => { const i = c.indexOf('='); return { name: c.slice(0, i), value: c.slice(i + 1), domain: '127.0.0.1', path: '/' }; }));
  await j.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 8000));

  // بستن ویزارد آنبوردینگ اگر باز است
  /* فقط دکمهٔ بستنِ خودِ ویزارد — قبلاً این regex به «بستن منو» هم می‌خورد،
     منوی کناری جمع می‌شد و بعد کلیک روی تب‌ها بی‌اثر بود (پاسِ کاذب). */
  await j.evaluate(() => {
    const wizard = document.querySelector('.pa-onb, .pa-onboarding, .pa-modal, [role="dialog"]');
    if (!wizard) return;
    const close = [...wizard.querySelectorAll('button')]
      .find(b => /تکمیل بعداً|بعداً|رد کردن|×/.test(b.innerText) && !/منو/.test(b.innerText));
    if (close) close.click();
  });
  await new Promise(r => setTimeout(r, 1500));

  const tabs = await j.evaluate(() => [...document.querySelectorAll('.pa-tab[data-tab],[data-tab]')]
    .filter(e => e.getClientRects().length).map(e => e.dataset.tab).filter(Boolean));
  console.log('  بخش‌ها:', [...new Set(tabs)].join('، ') || 'پیدا نشد');

  for (const tab of [...new Set(tabs)]) {
    const before = jErr.length, badBefore = jBad.length;
    const el = await j.$(`[data-tab="${tab}"]`);
    if (!el) continue;
    await realClick(j, el);
    await new Promise(r => setTimeout(r, 2200));
    const state = await j.evaluate(tab => {
      const t = (document.body.innerText || '').trim();
      const active = document.querySelector('.pa-tab.active')?.dataset.tab || null;
      return { len: t.length, head: t.slice(0, 40).replace(/\n/g, ' '), active, switched: active === tab };
    }, tab);
    if (!state.switched) bugs.push(['ژورنال/' + tab, 'high', 'کلیک روی تب، بخش را عوض نکرد (تب فعال: ' + state.active + ')']);
    const newErr = jErr.slice(before), newBad = [...new Set(jBad.slice(badBefore))];
    const status = newErr.length ? '✗ خطای JS' : !state.switched ? '✗ تب عوض نشد' : newBad.length ? '⚠ ' + newBad[0] : '✓';
    console.log(`  ${status.padEnd(14)} ${tab.padEnd(12)} ${state.len}ch  ${state.head}`);
    if (newErr.length) bugs.push(['ژورنال/' + tab, 'critical', newErr.join(' | ')]);
    if (newBad.length) bugs.push(['ژورنال/' + tab, 'high', newBad.join(' | ')]);
  }
  await j.screenshot({ path: '/tmp/audit-journal.png' });
  await j.close();

  console.log('\n════════ باگ‌ها ════════');
  if (!bugs.length) console.log('  هیچ باگی پیدا نشد.');
  bugs.forEach(([where, level, msg]) => console.log(`  [${level.toUpperCase()}] ${where}\n      ${msg}`));
  await br.close();
})();
