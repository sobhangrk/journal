/**
 * smoke-sms-melipayamak.js — تست واقعی مسیر ملی‌پیامک
 *
 * چرا لازم است: پیاده‌سازی قبلی فقط متد SendSMS (خط اختصاصی) را می‌زد.
 * کد ورود از خط عادی برای شماره‌های داخل «لیست سیاه مخابرات» نمی‌رسد و
 * ملی‌پیامک هم با خطای ۹ / ۳۵ برمی‌گرداند. مسیر درست برای OTP متد
 * BaseServiceNumber (خط خدماتی اشتراکی + کد متن الگو) است.
 *
 * پیش‌نیاز:
 *   node scripts/fake-melipayamak.js 4556 &
 *   node server.js   (روی 3000)
 *
 * اجرا:  node scripts/smoke-sms-melipayamak.js
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const FAKE = process.env.FAKE_MELI_URL || 'http://127.0.0.1:4556';
const BODY_ID = process.env.MP_BODYID || '12345';

const results = [];
const ok = (name, cond, extra = '') => { results.push([cond, name]); console.log((cond ? '  ✓ ' : '  ✗ ') + name + (extra ? '  — ' + extra : '')); };

const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: jar.join('; ') };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const response = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(response);
  let data = {}; try { data = await response.json(); } catch {}
  return { status: response.status, data };
}
const inboxAll = async () => (await fetch(FAKE + '/inbox')).json();
const inbox = async () => (await inboxAll()).rows;
const forceError = async code => fetch(FAKE + '/fail/' + code, { method: 'POST' });

(async () => {
  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const db = new Database(process.env.DATABASE_PATH || require('path').join(__dirname, '..', 'data', 'admin.db'));
  const stamp = Date.now().toString(36);
  const username = 'mpadmin' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run('adm_mp_' + stamp, 'مدیر تست ملی‌پیامک', username, '093' + String(Date.now()).slice(-8),
         bcrypt.hashSync('MpAdmin@12345', 10), new Date().toISOString());
  ['user_otp_challenges', 'sms_logs'].forEach(t => { try { db.prepare('DELETE FROM ' + t).run(); } catch {} });
  db.prepare("DELETE FROM sms_providers WHERE provider_key LIKE 'mptest-%'").run();
  db.prepare('UPDATE sms_providers SET is_enabled=0,is_primary=0').run();
  db.close();

  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'MpAdmin@12345' } });
  const csrf = login.data.csrfToken;
  ok('ورود مدیر', login.status === 200, 'status=' + login.status);
  await fetch(FAKE + '/reset', { method: 'POST' });

  // ---------------------------------------------------------------- ۱ ----
  console.log('\n── ۱) ثبت درگاه ملی‌پیامک با کد متن الگو ──');
  const create = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'melipayamak', name: 'ملی‌پیامک تست ' + stamp, providerKey: 'mptest-' + stamp,
    priority: 1, unitCost: 90, isEnabled: true,
    config: { url: FAKE + '/api/SendSMS', template: BODY_ID, sender: '' },
    credentials: { username: 'sjuser', password: 'sjpass' } } });
  ok('درگاه ملی‌پیامک ساخته شد', create.status === 201, JSON.stringify(create.data).slice(0, 140));
  const id = create.data.id;
  await req(`/api/admin/sms/providers/${id}`, { method: 'PATCH', csrf, body: { makePrimary: true } });
  const status = (await req('/api/admin/sms/status')).data;
  ok('پنل می‌گوید ارسال پیامک فعال است', status.ready === true, 'درگاه: ' + status.activeProvider);

  // ---------------------------------------------------------------- ۲ ----
  console.log('\n── ۲) تست ارسال از پنل → باید مسیر الگو برود ──');
  const test = await req('/api/admin/sms/test-otp', { method: 'POST', csrf, body: { mobile: '09121112233' } });
  ok('پنل ارسال را موفق گزارش کرد', test.status === 200 && test.data.ok === true, JSON.stringify(test.data).slice(0, 160));
  let box = await inbox();
  const first = box[box.length - 1] || {};
  ok('متد BaseServiceNumber صدا زده شد (نه SendSMS)', first.method === 'BaseServiceNumber', 'method=' + first.method);
  ok('کد متن الگو درست فرستاده شد', first.bodyId === String(BODY_ID), 'bodyId=' + first.bodyId);
  ok('متن ارسالی فقط کد شش‌رقمی است', /^\d{6}$/.test(String(first.text)), 'text=' + first.text);
  /* رگرسیون باگ واقعی: آدرس باید دقیقاً /api/SendSMS/BaseServiceNumber باشد.
     نسخه‌ی قبلی /api/BaseServiceNumber می‌ساخت و سرور واقعی ۴۰۴ می‌داد. */
  const paths = (await inboxAll()).paths || [];
  ok('آدرس دقیق متد درست است (نه ۴۰۴)',
     paths.includes('/api/SendSMS/BaseServiceNumber'), 'مسیرهای دیده‌شده: ' + paths.join(' , '));

  // ---------------------------------------------------------------- ۳ ----
  console.log('\n── ۳) ثبت‌نام واقعی کاربر ──');
  const mobile = '0991' + String(Date.now()).slice(-7);
  const userJar = [];
  const uReq = async (path, body) => {
    const r = await fetch(BASE + path, { method: 'POST', headers: { cookie: userJar.join('; '), 'content-type': 'application/json' }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => userJar.push(c.split(';')[0]));
    let d = {}; try { d = await r.json(); } catch {}
    return { status: r.status, data: d };
  };
  const signup = await uReq('/api/auth/signup', { name: 'کاربر ملی‌پیامک', mobile, password: 'MpUser@12345',
    remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  ok('ثبت‌نام پذیرفته شد (۲۰۲)', signup.status === 202, 'status=' + signup.status + ' ' + JSON.stringify(signup.data).slice(0, 130));
  ok('از درگاه ملی‌پیامک رفت (نه حالت توسعه)', signup.data.delivery && !/Development/i.test(signup.data.delivery), 'delivery=' + signup.data.delivery);
  box = await inbox();
  const otp = box[box.length - 1] || {};
  ok('کد برای همان شماره ارسال شد', otp.to === mobile, 'to=' + otp.to);
  ok('از مسیر الگو رفت', otp.method === 'BaseServiceNumber', 'method=' + otp.method);
  const code = String(otp.text || '');
  const verify = await uReq('/api/auth/signup/verify', { challengeToken: signup.data.challengeToken, code });
  ok('کاربر با همان کد ثبت‌نامش کامل شد', verify.status === 201, 'status=' + verify.status);

  // ---------------------------------------------------------------- ۴ ----
  console.log('\n── ۴) بدون کد متن الگو → مسیر خط اختصاصی ──');
  await req(`/api/admin/sms/providers/${id}`, { method: 'PATCH', csrf, body: {
    config: { url: FAKE + '/api/SendSMS', template: '', sender: '50004000' },
    credentials: { username: 'sjuser', password: 'sjpass' } } });
  const plain = await req('/api/admin/sms/test-otp', { method: 'POST', csrf, body: { mobile: '09121112233' } });
  box = await inbox();
  const plainMsg = box[box.length - 1] || {};
  ok('بدون bodyId متد SendSMS استفاده می‌شود', plain.status === 200 && plainMsg.method === 'SendSMS', 'method=' + plainMsg.method);
  ok('متن کامل فارسی ارسال شد', /\d{6}/.test(String(plainMsg.text)) && String(plainMsg.text).length > 10, String(plainMsg.text).slice(0, 40));

  // ---------------------------------------------------------------- ۵ ----
  console.log('\n── ۵) ترجمه فارسی کدهای خطای ملی‌پیامک ──');
  await req(`/api/admin/sms/providers/${id}`, { method: 'PATCH', csrf, body: {
    config: { url: FAKE + '/api/SendSMS', template: BODY_ID, sender: '' },
    credentials: { username: 'sjuser', password: 'sjpass' } } });
  const cases = [
    ['2', 'اعتبار'],
    ['-4', 'کد متن'],
    ['35', 'لیست سیاه'],
    ['-110', 'API Key'],
  ];
  for (const [errCode, needle] of cases) {
    await forceError(errCode);
    const r = await req('/api/admin/sms/test-otp', { method: 'POST', csrf, body: { mobile: '09121112233' } });
    const text = JSON.stringify(r.data);
    ok(`خطای ${errCode} به فارسی توضیح داده می‌شود`, r.status >= 400 && text.includes(needle), text.slice(0, 150));
  }

  // ---------------------------------------------------------------- ۶ ----
  console.log('\n── ۶) عیب‌یابی گام‌به‌گام ──');
  const diagnose = await req(`/api/admin/sms/providers/${id}/diagnose`, { method: 'POST', csrf, body: {} });
  const steps = diagnose.data.steps || [];
  const stepKeys = steps.map(s => s.key).join(',');
  ok('مرحله اعتبارسنجی نام کاربری/رمز اجرا شد', steps.some(s => s.key === 'auth'), stepKeys);
  const auth = steps.find(s => s.key === 'auth');
  ok('موجودی پنل خوانده شد', !!auth && auth.ok && /اعتبار/.test(auth.detail || ''), auth && auth.detail);
  const diagPaths = (await inboxAll()).paths || [];
  ok('عیب‌یابی هم آدرس درست GetCredit را می‌زند',
     diagPaths.includes('/api/SendSMS/GetCredit'), diagPaths.slice(-3).join(' , '));
  const template = steps.find(s => s.key === 'template');
  ok('وجود کد متن الگو بررسی می‌شود', !!template && template.ok, template && template.detail);

  await req(`/api/admin/sms/providers/${id}`, { method: 'PATCH', csrf, body: {
    config: { url: FAKE + '/api/SendSMS', template: '', sender: '50004000' } } });
  const diagnose2 = await req(`/api/admin/sms/providers/${id}/diagnose`, { method: 'POST', csrf, body: {} });
  const t2 = (diagnose2.data.steps || []).find(s => s.key === 'template');
  ok('نبود کد متن الگو هشدار می‌دهد', !!t2 && t2.ok === false && /لیست سیاه/.test(t2.detail || ''), t2 && String(t2.detail).slice(0, 80));

  await req(`/api/admin/sms/providers/${id}`, { method: 'DELETE', csrf, body: { force: true } });

  const failed = results.filter(r => !r[0]).length;
  console.log(`\n${results.length - failed}/${results.length} آزمون ملی‌پیامک پاس شد.`);
  process.exit(failed ? 1 : 0);
})().catch(error => { console.error('\nMELIPAYAMAK SMOKE FAILED:', error.stack || error); process.exit(1); });
