const db = require('../db');
const assert = require('assert');

console.log('── تست بخش مدیریت ژورنال‌ها و معاملات در پنل مدیریت ──');

// 1. Check stats DB queries directly
const totalAccounts = db.prepare("SELECT COUNT(*) AS count FROM journal_accounts WHERE deleted_at IS NULL").get().count;
const totalTrades = db.prepare("SELECT COUNT(*) AS count FROM journal_trades WHERE deleted_at IS NULL").get().count;

console.log(`  ✓ آمار کلی حساب‌ها (${totalAccounts}) و معاملات (${totalTrades}) قابل استعلام است.`);

// 2. Query top symbols
const topSymbols = db.prepare(`
  SELECT symbol, COUNT(*) AS count
  FROM journal_trades
  WHERE deleted_at IS NULL AND symbol IS NOT NULL AND symbol != ''
  GROUP BY symbol
  ORDER BY count DESC
  LIMIT 5
`).all();

console.log(`  ✓ استعلام نمادهای پرمعامله با موفقیت اجرا شد (${topSymbols.length} نماد).`);

// 3. Query accounts with user info
const accounts = db.prepare(`
  SELECT a.*, u.name AS user_name, u.mobile AS user_mobile
  FROM journal_accounts a
  LEFT JOIN users u ON u.id = a.user_id
  WHERE a.deleted_at IS NULL
  LIMIT 5
`).all();

console.log(`  ✓ استعلام لیست حساب‌های معاملاتی کاربران انجام شد (${accounts.length} حساب).`);

// 4. Query trades list
const trades = db.prepare(`
  SELECT t.*, u.name AS user_name, a.name AS account_name
  FROM journal_trades t
  LEFT JOIN users u ON u.id = t.user_id
  LEFT JOIN journal_accounts a ON a.id = t.account_id AND a.user_id = t.user_id
  WHERE t.deleted_at IS NULL
  LIMIT 5
`).all();

console.log(`  ✓ استعلام کاوشگر معاملات با موفقیت انجام شد (${trades.length} معامله).`);

console.log('\nتست بخش مدیریت ژورنال‌ها با موفقیت پاس شد.');
