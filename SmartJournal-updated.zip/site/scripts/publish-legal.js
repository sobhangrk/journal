#!/usr/bin/env node
'use strict';
/* ==========================================================================
   SmartJournal — انتشار اسناد حقوقی

   چرا لازم است؟
   ─────────────
   در حالت production، اسناد حقوقی فقط وقتی «منتشر» می‌شوند که هویت
   ارائه‌دهنده کامل باشد:

       LEGAL_OPERATOR_NAME
       LEGAL_OPERATOR_REGISTRATION
       LEGAL_OPERATOR_ADDRESS

   اگر خالی باشند، اسناد در حالت draft می‌مانند و ثبت‌نام کاربران با این
   خطا قفل می‌شود:

       «اسناد حقوقی لازم هنوز برای این محیط منتشر نشده‌اند.»

   این عمدی است — نباید قوانینی منتشر شود که پشتش هویت حقوقی واقعی نیست.

   استفاده
   ───────
     node scripts/publish-legal.js --status          وضعیت فعلی
     node scripts/publish-legal.js \
        --name "سبحان گورکانی" \
        --registration "0123456789" \
        --address "تهران، خیابان ...، پلاک ۱۲"

   بعد از اجرا، همان مقادیر در .env هم ذخیره می‌شوند تا با ری‌استارت
   یا به‌روزرسانی از بین نروند.
   ========================================================================== */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');
const ENV_FILE = path.join(ROOT, '.env');

/* --------------------------------------------------------- خواندن آرگومان */
function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? String(process.argv[i + 1] || '') : '';
}
const ONLY_STATUS = process.argv.includes('--status');

/* --------------------------------------------------- بارگذاری .env دستی */
function loadEnv() {
  if (!fs.existsSync(ENV_FILE)) return {};
  const out = {};
  for (const raw of fs.readFileSync(ENV_FILE, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return out;
}
const fileEnv = loadEnv();
for (const [k, v] of Object.entries(fileEnv)) {
  if (process.env[k] === undefined) process.env[k] = v;
}

const NAME    = arg('name')         || process.env.LEGAL_OPERATOR_NAME || '';
const REGNO   = arg('registration') || process.env.LEGAL_OPERATOR_REGISTRATION || '';
const ADDRESS = arg('address')      || process.env.LEGAL_OPERATOR_ADDRESS || '';

/* --------------------------------------------------------- اتصال دیتابیس */
let db;
try {
  db = require(path.join(ROOT, 'db.js'));
  if (db && db.db) db = db.db;
} catch (error) {
  console.error('✗ اتصال به دیتابیس ممکن نشد:', error.message);
  console.error('  مطمئن شوید در پوشه برنامه هستید و npm ci اجرا شده.');
  process.exit(1);
}

const { TYPES, TITLES, buildLegalDocuments } = require(path.join(ROOT, 'legal-content.js'));
const REQUIRED = ['terms', 'privacy', 'disclaimer'];
const iso = () => new Date().toISOString();

/* ------------------------------------------------------------- وضعیت فعلی */
function showStatus() {
  let rows = [];
  try {
    rows = db.prepare(
      'SELECT document_type, version, status, effective_at FROM legal_documents ORDER BY document_type'
    ).all();
  } catch (error) {
    console.error('✗ خواندن جدول legal_documents ناموفق:', error.message);
    process.exit(1);
  }
  console.log('\n  وضعیت اسناد حقوقی');
  console.log('  ─────────────────────────────────────────────');
  if (!rows.length) {
    console.log('  هیچ سندی در دیتابیس نیست.');
  } else {
    for (const r of rows) {
      const need = REQUIRED.includes(r.document_type) ? ' (لازم برای ثبت‌نام)' : '';
      const mark = r.status === 'published' ? '✅' : '⏸ ';
      console.log(`  ${mark} ${String(r.document_type).padEnd(12)} v${r.version}  ${r.status}${need}`);
    }
  }
  const missing = REQUIRED.filter(t => !rows.some(r => r.document_type === t && r.status === 'published'));
  console.log('  ─────────────────────────────────────────────');
  if (missing.length) {
    console.log(`  🔴 ثبت‌نام کاربران قفل است — منتشر نشده: ${missing.join('، ')}`);
  } else {
    console.log('  🟢 هر سه سند لازم منتشر شده‌اند؛ ثبت‌نام باز است.');
  }
  console.log('');
  return missing;
}

if (ONLY_STATUS) { showStatus(); process.exit(0); }

/* ------------------------------------------------------- اعتبارسنجی ورودی */
const problems = [];
if (NAME.trim().length < 3)    problems.push('--name  نام واقعی ارائه‌دهنده (شخص یا شرکت)');
if (REGNO.trim().length < 3)   problems.push('--registration  کد ملی یا شناسه ثبت شرکت');
if (ADDRESS.trim().length < 10) problems.push('--address  نشانی قانونی کامل');

if (problems.length) {
  console.log('\n  برای انتشار اسناد، هویت حقوقی واقعی لازم است:\n');
  problems.forEach(p => console.log('   ✗ ' + p));
  console.log(`
  نمونه:

    node scripts/publish-legal.js \\
      --name "سبحان گورکانی" \\
      --registration "0012345678" \\
      --address "تهران، خیابان ولیعصر، پلاک ۱۲، واحد ۳"

  ⚠️  این اطلاعات در صفحات قوانین سایت به کاربران نمایش داده می‌شود و
      مبنای قرارداد شما با آن‌هاست. اطلاعات ساختگی وارد نکنید.
`);
  showStatus();
  process.exit(1);
}

/* ------------------------------------------------------------- انتشار */
console.log('\n  انتشار اسناد حقوقی');
console.log('  ─────────────────────────────────────────────');
console.log('  ارائه‌دهنده :', NAME);
console.log('  شناسه       :', REGNO);
console.log('  نشانی       :', ADDRESS.slice(0, 60) + (ADDRESS.length > 60 ? '…' : ''));

const effectiveDate = process.env.LEGAL_EFFECTIVE_DATE || new Date().toISOString().slice(0, 10);
const documents = buildLegalDocuments({
  operatorName: NAME,
  operatorRegistration: REGNO,
  operatorAddress: ADDRESS,
  effectiveDate,
});

const owner = db.prepare("SELECT id FROM admins WHERE role='owner' LIMIT 1").get();
const now = iso();
let created = 0, updated = 0;

const run = db.transaction(() => {
  for (const type of TYPES) {
    const content = documents[type];
    if (!content) continue;
    const hash = crypto.createHash('sha256').update(content).digest('hex');
    const existing = db.prepare(
      'SELECT id, content_sha256, status FROM legal_documents WHERE document_type=? ORDER BY created_at DESC LIMIT 1'
    ).get(type);

    if (existing && existing.content_sha256 === hash) {
      if (existing.status !== 'published') {
        db.prepare("UPDATE legal_documents SET status='published', published_at=?, effective_at=? WHERE id=?")
          .run(now, now, existing.id);
        updated++;
      }
      continue;
    }
    // محتوا عوض شده → نسخه جدید تغییرناپذیر
    const version = existing ? bumpVersion(existing.id) : '1.0.0';
    const id = `legal_${type}_${version.replace(/\./g, '_')}_${Date.now().toString(36)}`;
    db.prepare(`INSERT INTO legal_documents
        (id,document_type,version,title,content,content_sha256,status,effective_at,created_at,published_at,created_by_admin_id)
        VALUES (?,?,?,?,?,?,'published',?,?,?,?)`)
      .run(id, type, version, TITLES[type], content, hash, now, now, now, owner ? owner.id : null);
    created++;
  }
  try {
    db.prepare("UPDATE system_settings SET terms_text=?, privacy_text=? WHERE id='default'")
      .run(documents.terms, documents.privacy);
  } catch {}
});

function bumpVersion(previousId) {
  const m = String(previousId).match(/_(\d+)_(\d+)_(\d+)/);
  if (!m) return '1.0.1';
  return `${m[1]}.${Number(m[2])}.${Number(m[3]) + 1}`;
}

try { run(); }
catch (error) { console.error('\n  ✗ انتشار ناموفق بود:', error.message); process.exit(1); }

console.log(`  ${created} سند جدید ساخته شد · ${updated} سند منتشر شد`);

/* --------------------------------------------- ذخیره هویت در فایل .env */
if (fs.existsSync(ENV_FILE)) {
  let text = fs.readFileSync(ENV_FILE, 'utf8');
  const set = (key, value) => {
    const line = `${key}=${value}`;
    const re = new RegExp(`^${key}=.*$`, 'm');
    text = re.test(text) ? text.replace(re, line) : text.trimEnd() + '\n' + line + '\n';
  };
  set('LEGAL_OPERATOR_NAME', NAME);
  set('LEGAL_OPERATOR_REGISTRATION', REGNO);
  set('LEGAL_OPERATOR_ADDRESS', ADDRESS);
  fs.writeFileSync(ENV_FILE, text);
  console.log('  ✓ هویت حقوقی در .env ذخیره شد (با ری‌استارت پاک نمی‌شود)');
}

showStatus();
console.log('  حالا سرویس را ری‌استارت کنید:\n    systemctl restart smartjournal\n');
