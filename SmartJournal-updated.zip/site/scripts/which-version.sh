#!/bin/bash
# ============================================================================
#   SmartJournal — روی سرور دقیقاً چه نسخه‌ای نصب است؟
#
#   اجرا:  bash /opt/smartjournal/scripts/which-version.sh
#
#   می‌گوید: تاریخ نصب، نسخه، مهر build، و اینکه کدام قابلیت‌های جدید
#   روی سرور هست و کدام نیست.
# ============================================================================
set -u
APP_DIR="${APP_DIR:-/opt/smartjournal}"

g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'

echo "==============================================="
echo "  نسخه نصب‌شده روی این سرور"
echo "==============================================="
[ -d "$APP_DIR" ] || { echo "${r}✗ $APP_DIR پیدا نشد${o}"; exit 1; }

echo
echo "${c}▶ کلیات${o}"
printf "  مسیر           : %s\n" "$APP_DIR"
printf "  نسخه package   : %s\n" \
  "$(node -e "try{console.log(require('$APP_DIR/package.json').version)}catch(e){console.log('؟')}" 2>/dev/null)"
printf "  آخرین تغییر کد : %s\n" "$(date -r "$APP_DIR/server.js" '+%Y-%m-%d %H:%M' 2>/dev/null || echo '؟')"
STAMP=$(grep -o 'name="pa-build" content="[^"]*"' "$APP_DIR/public/index.html" 2>/dev/null | head -1 | sed 's/.*content="//;s/"//')
printf "  مهر build سایت : %s\n" "${STAMP:-؟}"
SVC=$(systemctl is-active smartjournal 2>/dev/null); printf "  سرویس          : %s\n" "${SVC:-؟}"

echo
echo "${c}▶ قابلیت‌های نسخه‌های جدید${o}"
check_file() {  # check_file "توضیح" مسیر
  if [ -f "$APP_DIR/$2" ]; then echo "  ${g}✓${o} $1"; else echo "  ${r}✗${o} $1  ${y}(نصب نشده)${o}"; fi
}
check_pattern() {  # check_pattern "توضیح" مسیر الگو
  if grep -q "$3" "$APP_DIR/$2" 2>/dev/null; then echo "  ${g}✓${o} $1"
  else echo "  ${r}✗${o} $1  ${y}(نصب نشده)${o}"; fi
}

# check_app "توضیح" الگو
#   کدِ اپ ژورنال از نسخهٔ «جداسازی باندل» دیگر داخل public/index.html نیست و
#   به chunkهای public/app/*.js منتقل شده؛ پس هر سه جا را با هم می‌گردیم،
#   وگرنه قابلیت‌های سالم به‌اشتباه «نصب نشده» گزارش می‌شوند.
check_app() {
  if grep -qs "$2" "$APP_DIR/public/index.html" \
     || grep -qs "$2" "$APP_DIR"/public/app/*.js \
     || grep -qs "$2" "$APP_DIR/src-html/index.combined.html"; then
    echo "  ${g}✓${o} $1"
  else echo "  ${r}✗${o} $1  ${y}(نصب نشده)${o}"; fi
}

check_pattern "رفع قفل پنل مدیریت (z-index مودال)" "public/admin/admin.css" "modal-layer{position:fixed;inset:0;z-index:1200"
check_pattern "مسیر درست ملی‌پیامک (خط خدماتی/الگو)" "server.js" "BaseServiceNumber"
check_pattern "کوکی امن قابل تنظیم (COOKIE_SECURE)" "server.js" "COOKIE_SECURE"
check_file    "اسکریپت اتصال دامنه و SSL" "scripts/setup-domain.sh"
check_file    "اسکریپت انتشار اسناد حقوقی" "scripts/publish-legal.js"
check_file    "ابزار بازنشانی تأیید دومرحله‌ای" "scripts/admin-mfa.js"
check_file    "اسکرول‌بار هماهنگ با تم سایت" "shared-scrollbar.js"
check_file    "دکمه پشتیبانی شناور + شبکه‌های اجتماعی" "public/support-widget.js"
check_pattern "تب «راه‌های ارتباطی» در پنل" "public/admin/admin.js" "renderSocialTab"
check_pattern "رفع بحرانی ورود پیامکی (صف بدون worker)" "server.js" "sms_queue_fallback"
check_pattern "رفع قفل دائمی CAPTCHA" "server.js" "captchaConfigured"
check_pattern "ورود با رمز درست بدون پیامک (پیش‌فرض)" "db.js" "new_device_otp INTEGER NOT NULL DEFAULT 0"
check_app     "تب «رمز عبور و پروفایل» + تکرار رمز" "رمز عبور و پروفایل"
check_app     "رفع ایمپورت متاتریدر ۵ (سود/زیان واقعی)" "paSplitReportSections"
check_pattern "چیدمان دکمه‌های شناور موبایل" "public/journal-ux-runtime.js" "data-pa-view"
check_file    "اسکریپت نصب worker صف پیامک" "scripts/install-worker.sh"
check_pattern "تحویل به‌روزرسانی به مرورگر (کش SW نسخه‌دار)" "public/service-worker.js" "const BUILD"
check_pattern "مهر نسخهٔ SW در سرور تزریق می‌شود" "server.js" "swBuildStamp"
check_file    "کف اندازهٔ متن روی موبایل" "shared-mobile-type.js"
check_pattern "چیدمان تازهٔ موبایل (pa-dock)" "public/journal-ux-runtime.js" "pa-dock-b"
check_pattern "ایکون‌های برداری نوار پایین" "public/journal-ux-runtime.js" "paintNavIcons"
check_file    "تست رگرسیون چیدمان موبایل" "scripts/smoke-mobile-layout.js"
check_pattern "کنار رفتن دکمه‌ها هنگام اسکرول" "public/journal-ux-runtime.js" "pa-dock-away"
check_pattern "کف خوانایی متن داخل برنامه" "public/journal-ux-runtime.js" "readabilityPass"
check_file    "ابزار عیب‌یابی «چرا تغییر نکرد»" "scripts/why-not-updated.sh"
check_file    "اسکریپت نصب کاملاً تازه" "scripts/fresh-install.sh"

# ── نسخهٔ شهریور ۱۴۰۵ ─────────────────────────────────────────────
check_file    "جداسازی باندل صفحهٔ اصلی (سرعت لندینگ)" "scripts/split-landing-bundle.js"
check_pattern "لندینگ سبک (باندل جدا بارگذاری می‌شود)" "public/index.html" "app/journal-app"
check_file    "منطق تخفیف پلن‌ها" "plan-pricing.js"
check_pattern "قیمت خط‌خورده در صفحهٔ قیمت‌ها" "marketing-pages.js" "price-was"
check_pattern "مدیریت تخفیف در پنل مدیریت" "public/admin/admin.js" "discountPercent"
check_pattern "ستون‌های تخفیف در دیتابیس" "db.js" "discount_percent"
check_app     "کمیسیون و سواپ در ورود متاتریدر" "commission"
check_app     "سشن معاملاتی با ساعت واقعی بازار (DST)" "PA_SESSION_DEFS"
check_app     "انتخاب منطقهٔ زمانی سرور بروکر" "PA_IMPORT_TZ_OPTIONS"
check_pattern "فیلد پنهان فرم تماس واقعاً پنهان است" "marketing-pages.js" "hidden]{display:none"
check_pattern "favicon.ico دیگر ۴۰۴ نمی‌دهد" "server.js" "/favicon.ico"
check_pattern "انتخاب درست درگاه در دیده‌بان" "scripts/watchdog.js" "is_primary DESC, priority"
check_file    "گزارش ممیزی کامل سایت" "AUDIT-REPORT.md"
check_app     "انتخاب جدول Positions در گزارش MT5 (رفع Buy/Sell وارونه)" "isPositions"
check_file    "تست جهت و بخش‌های گزارش MetaTrader" "scripts/smoke-mt5-sections.js"
check_file    "مولد کارت تصویری استوری و کارنامه (Social Share Card)" "public/journal-share-card.js"
check_file    "تست تولید کارت تصویری معامله" "scripts/smoke-share-card.js"

echo
echo "${c}▶ اثر انگشت فایل‌ها (برای مقایسه با بسته‌ای که دارید)${o}"
for f in server.js site-content.js public/admin/admin.js public/admin/admin.css public/index.html; do
  [ -f "$APP_DIR/$f" ] && printf "  %-26s %s\n" "$f" "$(md5sum "$APP_DIR/$f" | cut -d' ' -f1)"
done

echo
echo "${c}▶ نسخه‌های پشتیبان موجود${o}"
ls -1dt /root/sj-backup-* 2>/dev/null | head -5 | sed 's/^/  /' || echo "  (هیچ)"

echo
echo "${c}▶ از بیرون هم می‌شود دید${o}"
DOMAIN=$(grep -oP '^PUBLIC_BASE_URL=\K.*' "$APP_DIR/.env" 2>/dev/null)
echo "  curl -s ${DOMAIN:-http://127.0.0.1}/ | grep -o 'pa-build[^>]*'"
echo
