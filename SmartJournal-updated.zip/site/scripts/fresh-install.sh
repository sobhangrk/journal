#!/bin/bash
# ============================================================================
#   SmartJournal — نصب کاملاً تازه (پاک کردن همه‌چیز و نصب از صفر)
#
#   روی سرور:
#       bash fresh-install.sh /root/SmartJournal-Platform.zip
#       bash fresh-install.sh /root/SmartJournal-Platform.zip --dry-run
#
#   ⚠️ این اسکریپت این‌ها را پاک می‌کند:
#        • کل پوشهٔ /opt/smartjournal
#        • دیتابیس smartjournal (همهٔ کاربران، معاملات، تیکت‌ها)
#        • فایل .env (کلیدهای رمزنگاری، رمز دیتابیس)
#        • سرویس systemd
#
#   ✅ این‌ها دست‌نخورده می‌مانند:
#        • گواهی HTTPS در /etc/letsencrypt  (دوباره صادر نمی‌شود)
#        • رکوردهای DNS دامنه
#
#   قبل از هر پاک‌کردنی، یک پشتیبان کامل در /root/sj-full-backup-<تاریخ>
#   گرفته می‌شود و بدون تأیید دستی هیچ‌چیز حذف نمی‌شود.
# ============================================================================
set -u
APP_DIR="/opt/smartjournal"
APP_USER="smartjournal"
DB_NAME="smartjournal"
DB_USER="sjuser"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/sj-full-backup-${STAMP}"
CONFIRM_WORD="PAK-KON"

g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'
say(){ echo; echo "${c}▶ $*${o}"; }
ok(){  echo "  ${g}✓${o} $*"; }
warn(){ echo "  ${y}!${o} $*"; }
die(){ echo; echo "${r}✗ $*${o}"; exit 1; }

DRY=0
ZIP=""
for a in "$@"; do
  case "$a" in
    --dry-run) DRY=1 ;;
    *) [ -z "$ZIP" ] && ZIP="$a" ;;
  esac
done

echo "==============================================="
echo "  نصب کاملاً تازهٔ SmartJournal — $(date '+%Y-%m-%d %H:%M')"
[ "$DRY" -eq 1 ] && echo "  ${y}(حالت بررسی — هیچ‌چیز پاک یا نصب نمی‌شود)${o}"
echo "==============================================="

[ "$(id -u)" -eq 0 ] || die "با root اجرا کنید:  sudo bash $0"

# ------------------------------------------------------- ۰) فایل نصب -------
say "۰) فایل نصب"
if [ -z "$ZIP" ]; then
  ZIP="$(ls -1t /root/SmartJournal-Platform.zip 2>/dev/null | head -1)"
fi
[ -n "$ZIP" ] && [ -f "$ZIP" ] || die "فایل zip پیدا نشد.
  اول از ویندوز آپلود کنید:
      scp SmartJournal-Platform.zip root@\$(hostname -I | awk '{print \$1}'):/root/
  بعد دوباره اجرا کنید:  bash $0 /root/SmartJournal-Platform.zip"
unzip -t "$ZIP" >/dev/null 2>&1 || die "فایل zip خراب است؛ دوباره آپلودش کنید."
ok "فایل: $ZIP  ($(du -h "$ZIP" | cut -f1))"
ok "MD5 : $(md5sum "$ZIP" | cut -d' ' -f1)"

# بررسی اینکه بستهٔ درستی است
rm -rf /tmp/sj-fresh && mkdir -p /tmp/sj-fresh
unzip -q -o "$ZIP" -d /tmp/sj-fresh || die "باز کردن zip ناموفق بود"
SRC="$(find /tmp/sj-fresh -maxdepth 3 -name server.js -printf '%h\n' 2>/dev/null | head -1)"
[ -n "$SRC" ] || die "داخل zip فایل server.js نبود — این بستهٔ SmartJournal نیست."
[ -f "$SRC/scripts/quick-install.sh" ] || die "scripts/quick-install.sh در بسته نیست."
ok "محتوای بسته سالم است"

# ------------------------------------------- ۱) آنچه از نصب فعلی می‌ماند ---
say "۱) خواندن تنظیمات نصب فعلی"
OLD_BASE=""; OLD_DOMAIN=""; OLD_EMAIL=""
OLD_LEGAL_NAME=""; OLD_LEGAL_REG=""; OLD_LEGAL_ADDR=""
if [ -f "$APP_DIR/.env" ]; then
  OLD_BASE="$(grep -oP '^PUBLIC_BASE_URL=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  OLD_EMAIL="$(grep -oP '^SUPPORT_EMAIL=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  OLD_LEGAL_NAME="$(grep -oP '^LEGAL_OPERATOR_NAME=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  OLD_LEGAL_REG="$(grep -oP '^LEGAL_OPERATOR_REGISTRATION=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  OLD_LEGAL_ADDR="$(grep -oP '^LEGAL_OPERATOR_ADDRESS=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  case "$OLD_BASE" in
    http://*|https://*) OLD_DOMAIN="$(echo "$OLD_BASE" | sed -E 's#^https?://##; s#/.*$##')" ;;
  esac
  ok "آدرس فعلی سایت: ${OLD_BASE:-—}"
  [ -n "$OLD_LEGAL_NAME" ] && ok "هویت حقوقی پیدا شد و منتقل می‌شود" || warn "هویت حقوقی در .env نبود"
else
  warn "$APP_DIR/.env وجود ندارد (شاید نصبی در کار نیست)"
fi

# آیا دامنه و گواهی داریم؟
HAS_CERT=0
if [ -n "$OLD_DOMAIN" ] && [ -d "/etc/letsencrypt/live/$OLD_DOMAIN" ]; then
  HAS_CERT=1
  ok "گواهی HTTPS برای $OLD_DOMAIN موجود است و حفظ می‌شود"
fi

# تنظیمات پیامک (فقط بخش غیرمحرمانه) تا بدانید چه چیزی را دوباره وارد کنید
SMS_NOTE="$BACKUP/sms-settings.txt"

# ------------------------------------------------------ ۲) پشتیبان کامل ---
say "۲) پشتیبان کامل قبل از هر پاک‌کردنی"
if [ "$DRY" -eq 1 ]; then
  echo "  (در حالت بررسی پشتیبان گرفته نمی‌شود؛ مسیر می‌شد: $BACKUP)"
else
  mkdir -p "$BACKUP" || die "ساخت پوشهٔ پشتیبان ناموفق بود"
  if [ -f "$APP_DIR/.env" ]; then cp -a "$APP_DIR/.env" "$BACKUP/.env"; ok ".env ذخیره شد"; fi
  if [ -d "$APP_DIR" ]; then
    tar -czf "$BACKUP/code.tar.gz" -C "$APP_DIR" --exclude=node_modules . 2>/dev/null
    ok "کد و داده‌ها: $BACKUP/code.tar.gz ($(du -h "$BACKUP/code.tar.gz" 2>/dev/null | cut -f1))"
  fi
  if [ -d "$APP_DIR/data/uploads" ]; then
    tar -czf "$BACKUP/uploads.tar.gz" -C "$APP_DIR/data" uploads 2>/dev/null
    ok "تصاویر کاربران: $BACKUP/uploads.tar.gz ($(du -h "$BACKUP/uploads.tar.gz" 2>/dev/null | cut -f1))"
  fi
  DBURL="$(grep -oP '^DATABASE_URL=\K.*' "$APP_DIR/.env" 2>/dev/null | tr -d '\r')"
  if [ -n "$DBURL" ] && command -v pg_dump >/dev/null 2>&1; then
    if pg_dump "$DBURL" > "$BACKUP/database.sql" 2>/dev/null; then
      ok "دیتابیس: $BACKUP/database.sql ($(du -h "$BACKUP/database.sql" | cut -f1))"
      # تنظیمات پیامک را از پشتیبان بیرون بکش تا بدانید چه بوده
      {
        echo "# تنظیمات پیامک نصب قبلی (برای وارد کردن دوباره در پنل مدیریت)"
        echo "# رمزها اینجا نیستند — فقط نام و شناسه‌ها."
        grep -o "melipayamak[^,)]*" "$BACKUP/database.sql" 2>/dev/null | sort -u | head -20
        grep -oE "'[0-9]{6}'" "$BACKUP/database.sql" 2>/dev/null | sort -u | head -10 | sed 's/^/# کد ۶ رقمی محتمل (bodyId): /'
      } > "$SMS_NOTE" 2>/dev/null
      ok "یادداشت تنظیمات پیامک: $SMS_NOTE"
    else
      warn "pg_dump ناموفق بود (شاید دیتابیس بالا نیست) — بدون پشتیبان دیتابیس ادامه می‌دهیم"
    fi
  else
    warn "DATABASE_URL یا pg_dump پیدا نشد — پشتیبان دیتابیس گرفته نشد"
  fi
  echo
  echo "  حجم کل پشتیبان: $(du -sh "$BACKUP" 2>/dev/null | cut -f1)"
fi

# ------------------------------------------------------------ ۳) تأیید ---
say "۳) تأیید پاک کردن"
cat <<TXT
  این‌ها ${r}برای همیشه پاک${o} می‌شوند:
     • $APP_DIR  (کل برنامه)
     • دیتابیس «$DB_NAME» — همهٔ کاربران، معاملات، تیکت‌ها، تنظیمات پیامک
     • فایل .env — کلیدهای رمزنگاری و رمز دیتابیس
     • سرویس systemd

  این‌ها ${g}می‌مانند${o}:
     • پشتیبان کامل در $BACKUP
     • گواهی HTTPS در /etc/letsencrypt
     • رکوردهای DNS دامنه

  بعد از نصب باید ${y}دوباره${o} انجام دهید:
     • وارد کردن اطلاعات ملی‌پیامک در پنل مدیریت (نام کاربری، رمز، کد الگو ۵۲۱۰۷۱)
     • انتشار اسناد حقوقی (اگر در .env نبوده)
     • رمز مدیر جدید در /root/smartjournal-info.txt نوشته می‌شود
TXT

if [ "$DRY" -eq 1 ]; then
  echo
  ok "حالت بررسی — تا اینجا همه‌چیز آماده بود. هیچ تغییری اعمال نشد."
  echo "  برای اجرای واقعی، بدون --dry-run دوباره بزنید."
  exit 0
fi

echo
printf "  برای ادامه دقیقاً این را تایپ کنید و Enter بزنید ⟵  ${y}%s${o}\n  > " "$CONFIRM_WORD"
read -r ANSWER
[ "$ANSWER" = "$CONFIRM_WORD" ] || die "تأیید نشد — هیچ‌چیز پاک نشد. پشتیبان در $BACKUP باقی ماند."

# ------------------------------------------------------------ ۴) پاک‌سازی --
say "۴) پاک کردن نصب قبلی"
systemctl stop smartjournal 2>/dev/null; ok "سرویس متوقف شد"
systemctl disable smartjournal 2>/dev/null
systemctl stop smartjournal-worker 2>/dev/null
systemctl disable smartjournal-worker 2>/dev/null
rm -f /etc/systemd/system/smartjournal.service /etc/systemd/system/smartjournal-worker.service
systemctl daemon-reload 2>/dev/null
ok "سرویس‌ها حذف شدند"

rm -rf "$APP_DIR"
ok "$APP_DIR پاک شد"

if command -v psql >/dev/null 2>&1; then
  sudo -u postgres psql -c "DROP DATABASE IF EXISTS ${DB_NAME};" >/dev/null 2>&1 \
    && ok "دیتابیس $DB_NAME حذف شد" || warn "حذف دیتابیس ناموفق بود"
  sudo -u postgres psql -c "DROP ROLE IF EXISTS ${DB_USER};" >/dev/null 2>&1 \
    && ok "کاربر دیتابیس $DB_USER حذف شد" || warn "حذف کاربر دیتابیس ناموفق بود"
else
  warn "psql پیدا نشد — دیتابیس دست‌نخورده ماند"
fi

# ------------------------------------------------------------- ۵) نصب ----
say "۵) نصب تازه"
export LEGAL_NAME="${OLD_LEGAL_NAME:-}"
export LEGAL_REG="${OLD_LEGAL_REG:-}"
export LEGAL_ADDR="${OLD_LEGAL_ADDR:-}"
bash "$SRC/scripts/quick-install.sh" "$ZIP" || die "نصب ناموفق بود.
  برای برگرداندن نسخهٔ قبلی:
     mkdir -p $APP_DIR && tar -xzf $BACKUP/code.tar.gz -C $APP_DIR
     cp -a $BACKUP/.env $APP_DIR/.env
     (و در صورت نیاز)  psql < $BACKUP/database.sql"

# --------------------------------------------------------- ۶) دامنه/HTTPS -
if [ -n "$OLD_DOMAIN" ] && [ "$OLD_DOMAIN" != "$(hostname -I | awk '{print $1}')" ]; then
  say "۶) برگرداندن دامنه و HTTPS روی $OLD_DOMAIN"
  if [ -f "$APP_DIR/scripts/setup-domain.sh" ]; then
    EMAIL_ARG=""
    case "${OLD_EMAIL:-}" in *@*) EMAIL_ARG="--email $OLD_EMAIL" ;; esac
    # shellcheck disable=SC2086
    bash "$APP_DIR/scripts/setup-domain.sh" "$OLD_DOMAIN" $EMAIL_ARG \
      && ok "دامنه و HTTPS برگشت" \
      || warn "اتصال دامنه خودکار انجام نشد؛ دستی اجرا کنید:
       bash $APP_DIR/scripts/setup-domain.sh $OLD_DOMAIN"
  else
    warn "setup-domain.sh در بسته نبود؛ دستی certbot را اجرا کنید."
  fi
else
  say "۶) دامنه"
  warn "دامنه‌ای در نصب قبلی ثبت نشده بود؛ سایت فعلاً با IP کار می‌کند."
fi

# ----------------------------------------------------------- ۷) خلاصه ----
echo
echo "==============================================="
echo "${g}✅ نصب تازه تمام شد${o}"
echo "==============================================="
echo "  آدرس سایت : ${OLD_BASE:-http://$(hostname -I | awk '{print $1}')}"
echo "  اطلاعات مدیر: /root/smartjournal-info.txt"
echo "  پشتیبان قبلی : $BACKUP"
echo
echo "  ${c}کارهای باقی‌مانده${o}"
echo "   ۱) رمز مدیر را ببینید:   cat /root/smartjournal-info.txt"
echo "   ۲) تنظیمات ملی‌پیامک را در پنل مدیریت دوباره وارد کنید"
echo "      (نام کاربری ۰۹۹۳۸۹۱۷۰۳۳ · کد الگو 521071)"
if [ -z "$OLD_LEGAL_NAME" ]; then
echo "   ۳) اسناد حقوقی را منتشر کنید تا ثبت‌نام باز شود:"
echo "      cd $APP_DIR && node scripts/publish-legal.js \\"
echo "        --name \"نام شما\" --registration \"کد ملی\" --address \"نشانی\""
echo "      systemctl restart smartjournal"
else
echo "   ۳) اسناد حقوقی از .env قبلی منتقل شد ✓"
fi
echo "   ۴) بررسی نهایی:  bash $APP_DIR/scripts/why-not-updated.sh"
echo "==============================================="
