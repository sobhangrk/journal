#!/usr/bin/env node
'use strict';
/* ==========================================================================
   SmartJournal — «پیامک ارسال شد ولی نرسید»

   وقتی ملی‌پیامک کد رهگیری (recId) برمی‌گرداند یعنی پیام را قبول کرده،
   ولی این هنوز به معنی رسیدن به گوشی نیست. این ابزار زنجیره را کامل می‌کند:

     ۱) موجودی پنل را می‌خواند   (GetCredit)
     ۲) یک پیامک واقعی می‌فرستد  (BaseServiceNumber یا SendSMS)
     ۳) موجودی را دوباره می‌خواند — اگر کم نشده باشد یعنی واقعاً ارسال نشده
     ۴) چند بار وضعیت تحویل را از مخابرات می‌پرسد (GetDeliveries2)

   اجرا روی سرور:
       cd /opt/smartjournal
       node scripts/sms-delivery.js 09120000000
       node scripts/sms-delivery.js 09120000000 --wait 60
       node scripts/sms-delivery.js --status 1234567890123456   (فقط پیگیری recId)
   ========================================================================== */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ROOT = path.resolve(__dirname, '..');

/* ------------------------------------------------------------- .env ---- */
const ENV_FILE = path.join(ROOT, '.env');
if (fs.existsSync(ENV_FILE)) {
  for (const raw of fs.readFileSync(ENV_FILE, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const k = line.slice(0, eq).trim();
    if (process.env[k] === undefined) process.env[k] = line.slice(eq + 1).trim();
  }
}

const argv = process.argv.slice(2);
const flag = (name, fallback = null) => {
  const i = argv.indexOf(name);
  return i > -1 ? (argv[i + 1] ?? true) : fallback;
};
const MOBILE = argv.find((a) => /^09\d{9}$/.test(a)) || null;
const ONLY_STATUS = flag('--status', null);
const WAIT_SECONDS = Number(flag('--wait', 45)) || 45;

if (!MOBILE && !ONLY_STATUS) {
  console.error('\nاستفاده:  node scripts/sms-delivery.js 09120000000  [--wait 60]');
  console.error('        node scripts/sms-delivery.js --status <recId>\n');
  process.exit(1);
}

/* --------------------------------------------------------- database ---- */
let db;
try {
  db = require(path.join(ROOT, 'db.js'));
  if (db && db.db) db = db.db;
} catch (error) {
  console.error('✗ اتصال به دیتابیس ممکن نشد:', error.message);
  process.exit(1);
}

/* رمزگشایی دقیقاً با همان روش سرور (aes-256-gcm، کلید = sha256 از APP_ENCRYPTION_KEY) */
const SECRET = process.env.APP_ENCRYPTION_KEY || '';
if (!SECRET) { console.error('✗ APP_ENCRYPTION_KEY در .env نیست.'); process.exit(1); }
const KEY = crypto.createHash('sha256').update(SECRET).digest();
function decryptSecret(value) {
  if (!value) return null;
  try {
    const raw = Buffer.from(value, 'base64url');
    const iv = raw.subarray(0, 12), tag = raw.subarray(12, 28), data = raw.subarray(28);
    const d = crypto.createDecipheriv('aes-256-gcm', KEY, iv);
    d.setAuthTag(tag);
    return JSON.parse(Buffer.concat([d.update(data), d.final()]).toString('utf8'));
  } catch { return null; }
}

const provider = db.prepare(
  "SELECT * FROM sms_providers WHERE provider_type='melipayamak' ORDER BY is_primary DESC, priority LIMIT 1").get();
if (!provider) { console.error('✗ هیچ درگاه ملی‌پیامکی در پنل تعریف نشده است.'); process.exit(1); }

const creds = decryptSecret(provider.credentials_encrypted);
if (!creds?.username) { console.error('✗ نام کاربری/رمز ملی‌پیامک ذخیره نشده یا قابل رمزگشایی نیست.'); process.exit(1); }
const config = (() => { try { return JSON.parse(provider.config_json || '{}'); } catch { return {}; } })();
const password = creds.password || creds.apiKey || '';
const bodyId = String(config.template || config.bodyId || '').trim();

function root(u) {
  let r = String(u || '').trim().replace(/\/+$/, '');
  if (!r) return 'https://rest.payamak-panel.com/api/SendSMS';
  r = r.replace(/\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i, '');
  return r.replace(/\/SendSMS\/SendSMS$/i, '/SendSMS');
}
const BASE = root(config.url);

async function call(method, payload) {
  const started = Date.now();
  const response = await fetch(`${BASE}/${method}`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: creds.username, password, ...payload }),
    signal: AbortSignal.timeout(20000),
  });
  const text = await response.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { http: response.status, ms: Date.now() - started, json, text: text.slice(0, 200) };
}

/* کدهای وضعیت تحویل ملی‌پیامک */
const DELIVERY = {
  '-1': 'رسید هنوز آماده نیست — کمی بعد دوباره بپرسید',
  0: 'در صف ارسال به مخابرات',
  1: '✅ به گوشی تحویل داده شد',
  2: '❌ به گوشی نرسید (خاموش، خارج از دسترس یا مسدود)',
  3: 'وضعیت نامشخص از سمت مخابرات',
  5: 'شماره گیرنده نامعتبر است',
  8: 'به مخابرات رسید (هنوز به گوشی نرسیده)',
  16: '❌ ارسال نشد — شماره در لیست سیاه یا خط مسدود',
  35: '❌ شماره در لیست سیاه مخابرات است',
  100: 'شناسه پیام نامعتبر است',
};

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const line = () => console.log('  ' + '─'.repeat(56));

(async () => {
  console.log('\n===============================================');
  console.log('  پیگیری واقعی تحویل پیامک — ملی‌پیامک');
  console.log('===============================================');
  console.log(`  درگاه       : ${provider.name}`);
  console.log(`  آدرس        : ${BASE}`);
  console.log(`  نام کاربری  : ${creds.username}`);
  console.log(`  کد متن الگو : ${bodyId || '(خالی — از خط اختصاصی استفاده می‌شود)'}`);

  let recId = ONLY_STATUS;

  if (!ONLY_STATUS) {
    line();
    console.log('  ▶ ۱) موجودی قبل از ارسال');
    const before = await call('GetCredit', {});
    if (before.http !== 200) { console.log(`  ✗ HTTP ${before.http} — ${before.text}`); process.exit(1); }
    const creditBefore = Number(before.json?.Value || 0);
    if (Number(before.json?.RetStatus) !== 1) {
      console.log(`  ✗ ${before.json?.StrRetStatus || before.text}`);
      console.log('    (معمولاً یعنی نام کاربری یا رمز اشتباه است)');
      process.exit(1);
    }
    console.log(`  ✓ اعتبار: ${creditBefore.toLocaleString('fa-IR')}`);

    line();
    console.log('  ▶ ۲) ارسال پیامک واقعی');
    const code = String(crypto.randomInt(100000, 1000000));
    const usePattern = !!bodyId;
    const sent = usePattern
      ? await call('BaseServiceNumber', { text: code, to: MOBILE, bodyId: Number(bodyId) || bodyId })
      : await call('SendSMS', { to: MOBILE, from: config.sender || '', text: `کد تست SmartJournal: ${code}`, isFlash: false });
    console.log(`  متد        : ${usePattern ? 'BaseServiceNumber (خط خدماتی/الگو)' : 'SendSMS (خط اختصاصی)'}`);
    console.log(`  گیرنده     : ${MOBILE}`);
    console.log(`  کد ارسالی  : ${code}`);
    console.log(`  پاسخ سرور  : HTTP ${sent.http} · ${JSON.stringify(sent.json || sent.text)}`);
    recId = String(sent.json?.Value ?? '');
    if (Number(sent.json?.RetStatus) !== 1 || !/^\d{10,}$/.test(recId)) {
      console.log('\n  ✗ ملی‌پیامک پیام را قبول نکرد. مقدار بازگشتی کد خطاست، نه کد رهگیری.');
      console.log('    معنی کدها: 0=نام کاربری/رمز غلط · 2=اعتبار کم · 12=مدارک ناقص');
      console.log('               -4=کد متن تأیید نشده · -5=تعداد متغیرها با الگو نمی‌خواند');
      process.exit(1);
    }
    console.log(`  ✓ کد رهگیری: ${recId}`);

    line();
    console.log('  ▶ ۳) موجودی بعد از ارسال');
    await wait(1500);
    const after = await call('GetCredit', {});
    const creditAfter = Number(after.json?.Value || 0);
    const diff = creditBefore - creditAfter;
    console.log(`  اعتبار: ${creditAfter.toLocaleString('fa-IR')}  (تفاوت: ${diff.toLocaleString('fa-IR')})`);
    if (diff <= 0) {
      console.log('  ⚠ از اعتبار کم نشد — یعنی پیام واقعاً روانه‌ی مخابرات نشده.');
      console.log('    معمولاً به‌خاطر ناقص بودن مدارک حساب یا تأیید نشدن الگوست.');
    } else {
      console.log('  ✓ از اعتبار کم شد — پیام وارد صف ارسال شده.');
    }
  }

  line();
  console.log(`  ▶ ۴) وضعیت تحویل (تا ${WAIT_SECONDS} ثانیه پیگیری می‌شود)`);
  const deadline = Date.now() + WAIT_SECONDS * 1000;
  let last = null;
  while (Date.now() < deadline) {
    const d = await call('GetDeliveries2', { recId: Number(recId) || recId });
    const value = d.json?.Value;
    const status = Array.isArray(value) ? value[0] : value;
    if (status !== undefined && String(status) !== last) {
      last = String(status);
      const label = DELIVERY[last] || `کد ${last}`;
      console.log(`  [${new Date().toLocaleTimeString('fa-IR')}]  ${label}`);
      if (['1', '2', '5', '16', '35'].includes(last)) break;
    }
    await wait(5000);
  }
  if (last === null) console.log('  (پاسخی از سرویس وضعیت گرفته نشد)');

  line();
  console.log('  اگر وضعیت «تحویل داده شد» است ولی پیامکی روی گوشی نیست:');
  console.log('    • پوشه‌ی اسپم/پیام‌های فیلترشده‌ی گوشی را ببینید');
  console.log('    • ممکن است شماره «لغو۱۱» زده باشد — با خط خدماتی هم گاهی رخ می‌دهد');
  console.log('    • همان گزارش را در پنل ملی‌پیامک، بخش «گزارش ارسال» مقایسه کنید');
  console.log('');
  process.exit(0);
})().catch((error) => { console.error('\n✗ خطا:', error.message); process.exit(1); });
