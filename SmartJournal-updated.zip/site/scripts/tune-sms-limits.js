#!/usr/bin/env node
/* ==========================================================================
   tune-sms-limits.js — بالا بردن سقف پیامک برای اینترنت ایران (NAT شدید)
   --------------------------------------------------------------------------
   مشکل: در ایران چند کاربر پشت یک IP مشترک هستند. سقف پیش‌فرض «۱۲ کد در
   ۱۰ دقیقه از هر IP» یعنی یک ساختمان یا کافینت با اینترنت مشترک خیلی زود
   قفل می‌شود و ثبت‌نام/ورود با ۴۲۹ شکست می‌خورد.

   این اسکریپت فقط یک‌بار سقف‌های پیش‌فرض را بالا می‌برد؛ اگر شما قبلاً در
   پنل مدیریت مقدار را عوض کرده باشید، دست نمی‌زند.

   مقادیر جدید (متعادل):
     - هر شماره:  ۱۰ کد در ۱۰ دقیقه  (قبلاً ۵)
     - هر IP:     ۶۰ کد در ۱۰ دقیقه  (قبلاً ۱۲)
   سقف هر شماره کم می‌ماند تا حملهٔ هدف‌دار به یک شماره همچنان بسته باشد.
   ========================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const APP_DIR = process.env.APP_DIR || '/opt/smartjournal';
const Database = require(path.join(APP_DIR, 'node_modules', 'better-sqlite3'));
const db = new Database(process.env.DATABASE_PATH || path.join(APP_DIR, 'data', 'admin.db'));

const row = db.prepare("SELECT * FROM sms_settings WHERE id='default'").get();
if (!row) { console.log('✗ تنظیمات پیامک پیدا نشد.'); process.exit(1); }

const current = { mobile: Number(row.mobile_limit_count), ip: Number(row.ip_limit_count), window: Number(row.rate_window_minutes) };
console.log(`قبل : هر شماره ${current.mobile} کد · هر IP ${current.ip} کد · پنجره ${current.window} دقیقه`);

/* فقط وقتی هنوز پیش‌فرض است دست می‌زنیم (۱۲ و ۵) */
const isDefault = current.mobile === 5 && current.ip === 12;
if (!isDefault) {
  console.log('• مقدارها قبلاً تغییر کرده‌اند؛ چیزی عوض نشد.');
  console.log('  اگر می‌خواهید باز هم بالا ببرید، از پنل مدیریت (تنظیمات سیستم → محدودیت‌های عمومی) عوض کنید.');
  process.exit(0);
}

const mobile = Number(process.env.OTP_MOBILE_LIMIT || 10);
const ip = Number(process.env.OTP_IP_LIMIT || 60);
const windowMin = Number(process.env.OTP_WINDOW_MIN || 10);
db.prepare("UPDATE sms_settings SET mobile_limit_count=?,ip_limit_count=?,rate_window_minutes=?,updated_at=? WHERE id='default'")
  .run(mobile, ip, windowMin, new Date().toISOString());
console.log(`بعد : هر شماره ${mobile} کد · هر IP ${ip} کد · پنجره ${windowMin} دقیقه ✅`);
console.log('توجه: سقف هر شماره فقط ۲ برابر شد تا حمله به یک شمارهٔ خاص همچنان مسدود بماند.');
