'use strict';
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
import math, random

# 1080x1920 High Resolution Canvas
W, H = 1080, 1920

# Create Base RGBA Image (Deep Obsidian Background)
img = Image.new('RGBA', (W, H), (1, 3, 5, 255))

# --- LAYER 1: Deep Radial Gradients & Lighting Aura ---
bg_lighting = Image.new('RGBA', (W, H), (0, 0, 0, 0))
bg_draw = ImageDraw.Draw(bg_lighting)

# Central Mint Electric Glow
for r in range(550, 0, -8):
    pct = 1.0 - (r / 550.0)
    alpha = int(85 * (pct ** 2.2))
    bg_draw.ellipse([W//2 - r, 780 - r, W//2 + r, 780 + r], fill=(20, 230, 130, alpha))

# Floor Horizon Glow
for r in range(600, 0, -10):
    pct = 1.0 - (r / 600.0)
    alpha = int(70 * (pct ** 2.5))
    bg_draw.ellipse([W//2 - r, 1680 - r//2, W//2 + r, 1680 + r//2], fill=(15, 220, 120, alpha))

img = Image.alpha_composite(img, bg_lighting)
draw = ImageDraw.Draw(img)

# --- LAYER 2: 3D Perspective Grid & Floor Reflection ---
floor_y_start = 1420
grid_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
g_draw = ImageDraw.Draw(grid_layer)

# Perspective Longitudinal Lines
vanish_x, vanish_y = W//2, 1200
for i in range(-20, 21):
    x_bottom = vanish_x + i * 85
    g_draw.line([(vanish_x + i * 15, vanish_y), (x_bottom, H)], fill=(29, 228, 123, 30), width=1)

# Horizontal Floor Lines (Exponential Spacing)
for step in range(25):
    y = floor_y_start + int(15 * (1.18 ** step))
    if y >= H: break
    alpha = int(10 + 40 * (step / 25.0))
    g_draw.line([(0, y), (W, y)], fill=(29, 228, 123, alpha), width=1)

img = Image.alpha_composite(img, grid_layer)
draw = ImageDraw.Draw(img)

# --- LAYER 3: Background Candlestick Charts (Left & Right Depth) ---
chart_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
c_draw = ImageDraw.Draw(chart_layer)

# Left Side Candlesticks
left_data = [
    (60, 620, 750, 640, 720),
    (95, 580, 710, 600, 680),
    (130, 540, 660, 560, 630),
    (165, 500, 610, 520, 580)
]
for x, top, bot, ctop, cbot in left_data:
    c_draw.line([(x, top), (x, bot)], fill=(29, 228, 123, 75), width=2)
    c_draw.rectangle([x - 9, ctop, x + 9, cbot], fill=(29, 228, 123, 75))

# Right Side Ascending Candlesticks (Staircase)
right_data = [
    (915, 880, 1020, 900, 990),
    (950, 800, 940, 820, 910),
    (985, 720, 860, 740, 830),
    (1020, 640, 780, 660, 750)
]
for x, top, bot, ctop, cbot in right_data:
    c_draw.line([(x, top), (x, bot)], fill=(29, 228, 123, 85), width=2)
    c_draw.rectangle([x - 9, ctop, x + 9, cbot], fill=(29, 228, 123, 85))

chart_layer = chart_layer.filter(ImageFilter.GaussianBlur(1.5))
img = Image.alpha_composite(img, chart_layer)
draw = ImageDraw.Draw(img)

# --- LAYER 4: Floating Dust / Bokeh Sparks ---
sparks_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
s_draw = ImageDraw.Draw(sparks_layer)
random.seed(42)
for _ in range(35):
    sx = random.randint(100, 980)
    sy = random.randint(200, 1700)
    sr = random.randint(2, 5)
    sa = random.randint(40, 180)
    s_draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(29, 228, 123, sa))
sparks_layer = sparks_layer.filter(ImageFilter.GaussianBlur(1.0))
img = Image.alpha_composite(img, sparks_layer)
draw = ImageDraw.Draw(img)

# --- FONTS SETUP ---
font_bold = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
font_reg = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

f_title = ImageFont.truetype(font_bold, 48)
f_sub = ImageFont.truetype(font_bold, 16)
f_symbol = ImageFont.truetype(font_bold, 54)
f_sym_sub = ImageFont.truetype(font_bold, 18)
f_label = ImageFont.truetype(font_bold, 20)
f_profit = ImageFont.truetype(font_bold, 96)
f_buy = ImageFont.truetype(font_bold, 42)
f_value = ImageFont.truetype(font_bold, 48)
f_unit = ImageFont.truetype(font_bold, 28)
f_handle = ImageFont.truetype(font_bold, 24)
f_footer = ImageFont.truetype(font_bold, 36)
f_domain = ImageFont.truetype(font_bold, 22)

# --- LAYER 5: Top Header Branding ---
s_cx, s_cy = W//2, 100
# Stylized Hexagon S Logo
draw.polygon([(s_cx - 22, s_cy - 28), (s_cx + 16, s_cy - 28), (s_cx + 26, s_cy - 14), (s_cx - 4, s_cy - 2), (s_cx - 22, s_cy + 6)], fill=(29, 228, 123, 255))
draw.polygon([(s_cx + 22, s_cy + 28), (s_cx - 16, s_cy + 28), (s_cx - 26, s_cy + 14), (s_cx + 4, s_cy + 2), (s_cx + 22, s_cy - 6)], fill=(29, 228, 123, 255))

draw.text((W//2, 150), "SmartJournal", font=f_title, fill=(255, 255, 255, 255), anchor="mm")
draw.text((W//2, 192), "T R A D I N G   J O U R N A L", font=f_sub, fill=(100, 116, 139, 255), anchor="mm")

# --- LAYER 6: Central Glassmorphism Card ---
card_x1, card_y1, card_x2, card_y2 = 180, 250, 900, 1380
card_w = card_x2 - card_x1
card_h = card_y2 - card_y1

# Card Multi-pass Neon Aura Shadow
aura_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
a_draw = ImageDraw.Draw(aura_layer)
a_draw.rounded_rectangle([card_x1 - 12, card_y1 - 12, card_x2 + 12, card_y2 + 12], radius=52, outline=(29, 228, 123, 160), width=6)
a_draw.rounded_rectangle([card_x1 - 24, card_y1 - 24, card_x2 + 24, card_y2 + 24], radius=60, fill=(0, 0, 0, 190))
aura_layer = aura_layer.filter(ImageFilter.GaussianBlur(22))
img = Image.alpha_composite(img, aura_layer)
draw = ImageDraw.Draw(img)

# Card Body
draw.rounded_rectangle([card_x1, card_y1, card_x2, card_y2], radius=44, fill=(4, 13, 17, 240), outline=(29, 228, 123, 255), width=3)

# Gloss Reflection Edge
draw.rounded_rectangle([card_x1 + 3, card_y1 + 3, card_x2 - 3, card_y1 + 110], radius=41, fill=(255, 255, 255, 10))

# Inside Card Metrics
inner_x = card_x1 + 50
inner_y = card_y1 + 50
inner_w = card_w - 100

# 1. Gold Symbol Header
badge_cx, badge_cy = inner_x + 50, inner_y + 50
draw.ellipse([badge_cx - 48, badge_cy - 48, badge_cx + 48, badge_cy + 48], fill=(10, 28, 20, 255), outline=(212, 175, 55, 255), width=2)

# High Quality Metallic 3D Gold Bars Stack
# Bottom Gold Bar
draw.polygon([(badge_cx - 24, badge_cy + 8), (badge_cx, badge_cy - 8), (badge_cx + 24, badge_cy + 8), (badge_cx, badge_cy + 24)], fill=(255, 215, 0))
draw.polygon([(badge_cx - 24, badge_cy + 8), (badge_cx, badge_cy + 24), (badge_cx, badge_cy + 34), (badge_cx - 24, badge_cy + 18)], fill=(212, 175, 55))
draw.polygon([(badge_cx, badge_cy + 24), (badge_cx + 24, badge_cy + 8), (badge_cx + 24, badge_cy + 18), (badge_cx, badge_cy + 34)], fill=(184, 134, 11))

# Top Left Gold Bar
draw.polygon([(badge_cx - 14, badge_cy - 8), (badge_cx + 8, badge_cy - 24), (badge_cx + 30, badge_cy - 8), (badge_cx + 8, badge_cy + 8)], fill=(255, 235, 100))
draw.polygon([(badge_cx - 14, badge_cy - 8), (badge_cx + 8, badge_cy + 8), (badge_cx + 8, badge_cy + 18), (badge_cx - 14, badge_cy + 2)], fill=(230, 184, 0))
draw.polygon([(badge_cx + 8, badge_cy + 8), (badge_cx + 30, badge_cy - 8), (badge_cx + 30, badge_cy + 2), (badge_cx + 8, badge_cy + 18)], fill=(199, 156, 0))

# Symbol Text
draw.text((inner_x + 120, inner_y + 18), "XAUUSD", font=f_symbol, fill=(255, 255, 255, 255))
draw.text((inner_x + 120, inner_y + 80), "GOLD / U.S. DOLLAR", font=f_sym_sub, fill=(100, 116, 139, 255))

# Divider Line
draw.line([(inner_x, inner_y + 130), (inner_x + inner_w, inner_y + 130)], fill=(255, 255, 255, 22), width=1)

# 2. Profit Display
cur_y = inner_y + 165
draw.text((inner_x, cur_y), "PROFIT", font=f_label, fill=(100, 116, 139, 255))

cur_y += 38
# Multi-pass Text Glow for Profit Amount
profit_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
pg_draw = ImageDraw.Draw(profit_glow)
pg_draw.text((inner_x, cur_y), "+$68.17", font=f_profit, fill=(29, 228, 123, 255))
profit_glow = profit_glow.filter(ImageFilter.GaussianBlur(12))
img = Image.alpha_composite(img, profit_glow)
draw = ImageDraw.Draw(img)

draw.text((inner_x, cur_y), "+$68.17", font=f_profit, fill=(29, 228, 123, 255))

# Sparkline Financial Chart
cur_y += 125
spark_pts = [
    (inner_x, cur_y + 40),
    (inner_x + 100, cur_y + 52),
    (inner_x + 200, cur_y + 36),
    (inner_x + 300, cur_y + 48),
    (inner_x + 400, cur_y + 18),
    (inner_x + 500, cur_y + 28),
    (inner_x + inner_w, cur_y - 32)
]
for i in range(len(spark_pts) - 1):
    draw.line([spark_pts[i], spark_pts[i+1]], fill=(29, 228, 123, 255), width=4)

# Glowing End Orb
end_x, end_y = spark_pts[-1]
orb_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
og_draw = ImageDraw.Draw(orb_glow)
for r in range(30, 0, -2):
    alpha = int(140 * (1 - r / 30.0))
    og_draw.ellipse([end_x - r, end_y - r, end_x + r, end_y + r], fill=(29, 228, 123, alpha))
orb_glow = orb_glow.filter(ImageFilter.GaussianBlur(4))
img = Image.alpha_composite(img, orb_glow)
draw = ImageDraw.Draw(img)

draw.ellipse([end_x - 6, end_y - 6, end_x + 6, end_y + 6], fill=(255, 255, 255, 255))

# 3. BUY Badge Button
cur_y += 75
buy_w, buy_h = inner_w, 96
draw.rounded_rectangle([inner_x, cur_y, inner_x + buy_w, cur_y + buy_h], radius=24, fill=(4, 38, 22, 240), outline=(29, 228, 123, 130), width=2)

# Double Up Chevrons Icon
chevron_x = inner_x + buy_w//2 - 65
chevron_y = cur_y + buy_h//2
draw.line([(chevron_x - 18, chevron_y + 8), (chevron_x, chevron_y - 10), (chevron_x + 18, chevron_y + 8)], fill=(29, 228, 123, 255), width=5)
draw.line([(chevron_x - 18, chevron_y + 18), (chevron_x, chevron_y), (chevron_x + 18, chevron_y + 18)], fill=(29, 228, 123, 255), width=5)

draw.text((inner_x + buy_w//2 + 30, cur_y + buy_h//2), "BUY", font=f_buy, fill=(29, 228, 123, 255), anchor="mm")

# 4. 2x2 Grid Container
cur_y += 130
grid_h = 360
draw.rounded_rectangle([inner_x, cur_y, inner_x + inner_w, cur_y + grid_h], radius=28, fill=(5, 17, 21, 210), outline=(255, 255, 255, 16), width=1)

mid_x = inner_x + inner_w // 2
mid_y = cur_y + grid_h // 2
draw.line([(mid_x, cur_y + 20), (mid_x, cur_y + grid_h - 20)], fill=(255, 255, 255, 16), width=1)
draw.line([(inner_x + 20, mid_y), (inner_x + inner_w - 20, mid_y)], fill=(255, 255, 255, 16), width=1)

# Cell 1: VOLUME
draw.text((inner_x + 40, cur_y + 35), "VOLUME", font=f_label, fill=(100, 116, 139, 255))
draw.text((inner_x + 40, cur_y + 90), "0.17", font=f_value, fill=(29, 228, 123, 255))
draw.text((inner_x + 155, cur_y + 106), "LOT", font=f_unit, fill=(100, 116, 139, 255))

# Cell 2: RISK
draw.text((mid_x + 40, cur_y + 35), "RISK", font=f_label, fill=(100, 116, 139, 255))
draw.text((mid_x + 40, cur_y + 90), "1%", font=f_value, fill=(29, 228, 123, 255))

# Cell 3: TIMEFRAME
draw.text((inner_x + 40, mid_y + 35), "TIMEFRAME", font=f_label, fill=(100, 116, 139, 255))
draw.text((inner_x + 40, mid_y + 90), "15M", font=f_value, fill=(29, 228, 123, 255))

# Cell 4: Analog Clock Icon
clock_cx, clock_cy = mid_x + 160, mid_y + 90
draw.ellipse([clock_cx - 36, clock_cy - 36, clock_cx + 36, clock_cy + 36], outline=(29, 228, 123, 255), width=3)
draw.ellipse([clock_cx - 4, clock_cy - 4, clock_cx + 4, clock_cy + 4], fill=(255, 255, 255, 255))
draw.line([(clock_cx, clock_cy), (clock_cx - 12, clock_cy - 16)], fill=(29, 228, 123, 255), width=3)
draw.line([(clock_cx, clock_cy), (clock_cx + 18, clock_cy - 10)], fill=(29, 228, 123, 255), width=3)

# --- LAYER 7: Handle Pill Below Card ---
handle_y = card_y2 + 80
handle_w, handle_h = 320, 64
handle_x = W//2 - handle_w//2

draw.rounded_rectangle([handle_x, handle_y, handle_x + handle_w, handle_y + handle_h], radius=32, fill=(6, 18, 23, 235), outline=(29, 228, 123, 90), width=1)

# User silhouette icon + @trader_pro
u_cx, u_cy = handle_x + 70, handle_y + handle_h//2
draw.ellipse([u_cx - 10, u_cy - 14, u_cx + 10, u_cy + 6], outline=(255, 255, 255, 255), width=2)
draw.arc([u_cx - 18, u_cy + 2, u_cx + 18, u_cy + 22], start=180, end=360, fill=(255, 255, 255, 255), width=2)

draw.text((handle_x + 180, handle_y + handle_h//2), "@trader_pro", font=f_handle, fill=(255, 255, 255, 255), anchor="mm")

# Glowing Mint Hanging Dot
dot_y = handle_y + 100
dot_glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
dg_draw = ImageDraw.Draw(dot_glow)
for r in range(16, 0, -2):
    alpha = int(180 * (1 - r / 16.0))
    dg_draw.ellipse([W//2 - r, dot_y - r, W//2 + r, dot_y + r], fill=(29, 228, 123, alpha))
dot_glow = dot_glow.filter(ImageFilter.GaussianBlur(3))
img = Image.alpha_composite(img, dot_glow)
draw = ImageDraw.Draw(img)

draw.ellipse([W//2 - 3, dot_y - 3, W//2 + 3, dot_y + 3], fill=(255, 255, 255, 255))

# --- LAYER 8: Footer Branding ---
footer_y = H - 120
s_cx, s_cy = W//2 - 120, footer_y
draw.polygon([(s_cx - 12, s_cy - 15), (s_cx + 8, s_cy - 15), (s_cx + 15, s_cy - 7), (s_cx - 3, s_cy - 1), (s_cx - 12, s_cy + 3)], fill=(29, 228, 123, 255))
draw.polygon([(s_cx + 12, s_cy + 15), (s_cx - 8, s_cy + 15), (s_cx - 15, s_cy + 7), (s_cx + 3, s_cy + 1), (s_cx + 12, s_cy - 3)], fill=(29, 228, 123, 255))

draw.text((W//2 + 10, footer_y), "SmartJournal", font=f_footer, fill=(255, 255, 255, 255), anchor="mm")

# Globe Icon + smarttradejournal.ir
globe_y = footer_y + 45
g_cx = W//2 - 140
draw.ellipse([g_cx - 12, globe_y - 12, g_cx + 12, globe_y + 12], outline=(29, 228, 123, 255), width=2)
draw.line([(g_cx - 12, globe_y), (g_cx + 12, globe_y)], fill=(29, 228, 123, 255), width=1)
draw.ellipse([g_cx - 6, globe_y - 12, g_cx + 6, globe_y + 12], outline=(29, 228, 123, 255), width=1)

draw.text((W//2 + 10, globe_y), "smarttradejournal.ir", font=f_domain, fill=(29, 228, 123, 255), anchor="mm")

# Save Ultra Quality PNG
img.save('/home/user/smartjournal-story-card.png', 'PNG')
print('Successfully saved ultra-enhanced /home/user/smartjournal-story-card.png')
