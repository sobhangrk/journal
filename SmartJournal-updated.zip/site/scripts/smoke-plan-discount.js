'use strict';
/* ==========================================================================
   smoke-plan-discount.js — «قیمت خط‌خورده + قیمت با تخفیف» از پنل تا سایت
   --------------------------------------------------------------------------
   مسیر کامل: ادمین تخفیف را ذخیره می‌کند → API عمومی قیمت جدید را می‌دهد →
   صفحهٔ قیمت‌گذاری (SSR) و لندینگ (کلاینت) قیمت قبلی را خط می‌زنند →
   مبلغ قابل پرداخت هم همان قیمت تخفیف‌خورده است → با رسیدن تاریخ انقضا
   تخفیف خودکار خاموش می‌شود.
   ========================================================================== */
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const { payablePrice, planPricing } = require('../plan-pricing');

const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '../data/admin.db');
const stamp = String(Date.now());
const fixture = { start: new Date().toISOString(), adminId: 'adm_disc_' + stamp, user: 'discown_' + stamp.slice(-7), mobile: '097' + stamp.slice(-8), secret: null, plan: null, original: null };

let passed = 0;
const ok = (name, extra = '') => { passed += 1; console.log('  ✓ ' + name + (extra ? '  — ' + extra : '')); };
const fa = value => new Intl.NumberFormat('fa-IR').format(Number(value || 0));

function cookieOf(response) {
  const values = typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [response.headers.get('set-cookie')].filter(Boolean);
  return values.flatMap(v => String(v).split(/,(?=\s*[^;,]+=)/)).map(v => v.trim().split(';')[0]).join('; ');
}
function base32Decode(value) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const ch of String(value).replace(/=+$/, '').toUpperCase()) bits += chars.indexOf(ch).toString(2).padStart(5, '0');
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}
function totp(secret) {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 30000)));
  const digest = crypto.createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 15;
  return String((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(6, '0');
}
async function request(session, url, { method = 'GET', body, expected = 200 } = {}) {
  const headers = {};
  if (session) { headers.cookie = session.cookie; if (method !== 'GET') headers['x-csrf-token'] = session.csrf; }
  if (body !== undefined) headers['content-type'] = 'application/json';
  const response = await fetch(BASE + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await response.text();
  let data; try { data = JSON.parse(text) } catch { data = text }
  assert.equal(response.status, expected, `${method} ${url}: ${response.status} ${typeof data === 'string' ? data.slice(0, 160) : JSON.stringify(data)}`);
  return data;
}

function cleanup() {
  const db = new Database(DB_PATH);
  try {
    if (fixture.plan && fixture.original) {
      db.prepare('UPDATE plans SET discount_percent=?,discount_price=?,discount_label=?,discount_until=? WHERE id=?')
        .run(fixture.original.discount_percent || 0, fixture.original.discount_price ?? null, fixture.original.discount_label ?? null, fixture.original.discount_until ?? null, fixture.plan);
    }
    for (const table of ['admin_sessions', 'admin_totp', 'admin_passkeys', 'admin_recovery_codes', 'admin_auth_challenges']) {
      try { db.prepare(`DELETE FROM ${table} WHERE admin_id=?`).run(fixture.adminId) } catch {}
    }
    db.prepare('DELETE FROM admins WHERE id=?').run(fixture.adminId);
    db.prepare('DELETE FROM audit_logs WHERE created_at>=?').run(fixture.start);
  } finally { db.close() }
}

(async () => {
  const db = new Database(DB_PATH);
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'owner','active',?,1)`)
    .run(fixture.adminId, 'Owner تخفیف', fixture.user, fixture.mobile, bcrypt.hashSync('OwnerDisc@12345', 10), fixture.start);
  db.close();

  /* ---------------------------------------------------------- ورود ادمین */
  let response = await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ identifier: fixture.user, password: 'OwnerDisc@12345' }) });
  let body = await response.json();
  assert.equal(response.status, 200, 'login: ' + JSON.stringify(body));
  const session = { cookie: cookieOf(response), csrf: body.csrfToken };
  if (body.mfaSetupRequired) {
    const setup = await request(session, '/api/admin/mfa/totp/setup', { method: 'POST', body: {} });
    fixture.secret = setup.secret;
    await request(session, '/api/admin/mfa/totp/verify', { method: 'POST', body: { code: totp(fixture.secret) } });
  }
  ok('ورود مدیر و آماده‌سازی');

  /* ------------------------------------------------- پلن پولی برای آزمون */
  const before = await request(session, '/api/admin/plans');
  const plan = before.rows.find(row => Number(row.price_monthly) > 0);
  assert(plan, 'پلن پولی برای آزمون پیدا نشد');
  fixture.plan = plan.id;
  fixture.original = { discount_percent: plan.discount_percent || 0, discount_price: plan.discount_price ?? null, discount_label: plan.discount_label ?? null, discount_until: plan.discount_until ?? null };
  const price = Number(plan.price_monthly);
  ok('پلن پولی انتخاب شد', `${plan.name_fa} · ${fa(price)}`);

  /* ------------------------------------------------------ ۱) تخفیف درصدی */
  const until = new Date(Date.now() + 20 * 86400000).toISOString().slice(0, 10);
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 30, discountPrice: null, discountLabel: 'جشنوارهٔ آزمون', discountUntil: until } });
  const expected30 = Math.round(price * 70 / 100);

  let publicPlans = await (await fetch(BASE + '/api/public/plans')).json();
  let row = publicPlans.rows.find(item => item.id === plan.id);
  assert.equal(row.discount.active, true);
  assert.equal(row.discount.final_price, expected30);
  assert.equal(row.discount.percent, 30);
  assert.equal(row.effective_price, expected30);
  assert.equal(row.price_monthly, price, 'قیمت اصلی باید دست‌نخورده بماند');
  assert.equal(row.discount.label, 'جشنوارهٔ آزمون');
  ok('API عمومی: تخفیف ۳۰٪ با قیمت اصلی و قیمت جدید', `${fa(price)} → ${fa(expected30)}`);

  /* --------------------------------------- ۲) صفحهٔ قیمت‌گذاری سمت سرور */
  const pricingHtml = await (await fetch(BASE + '/pricing')).text();
  assert(pricingHtml.includes('class="price-was"'), 'قیمت خط‌خورده در SSR نیست');
  assert(pricingHtml.includes(fa(expected30)), 'قیمت جدید در SSR نیست');
  assert(pricingHtml.includes('٪ تخفیف'), 'برچسب درصد تخفیف در SSR نیست');
  assert(pricingHtml.includes('جشنوارهٔ آزمون'), 'متن دلخواه تخفیف در SSR نیست');
  ok('صفحهٔ /pricing: قیمت خط‌خورده + قیمت جدید + برچسب');

  /* ------------------------------------------------- ۳) لندینگ (کلاینت) */
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 900 });
  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await page.waitForFunction(() => !!document.querySelector('.pa-l-price-was'), { timeout: 20000 }).catch(() => {});
  const card = await page.evaluate(planName => {
    const el = document.querySelector(`.pa-l-price-card[data-public-plan="${planName}"]`);
    if (!el) return null;
    const was = el.querySelector('.pa-l-price-was'), off = el.querySelector('.pa-l-price-off'), b = el.querySelector('.pa-l-price-value b'), note = el.querySelector('.pa-l-price-note');
    const style = was ? getComputedStyle(was.querySelector('s') || was) : null;
    return { was: was && was.textContent.trim(), lineThrough: style ? style.textDecorationLine : '', off: off && off.textContent.trim(), now: b && b.textContent.trim(), note: note && note.textContent.trim() };
  }, plan.name);
  assert(card, 'کارت پلن در لندینگ پیدا نشد');
  assert.equal(card.was, fa(price));
  assert(card.lineThrough.includes('line-through'), 'قیمت قبلی واقعاً خط نخورده: ' + card.lineThrough);
  assert.equal(card.now, fa(expected30));
  assert(card.off.includes(fa(30)), 'برچسب درصد: ' + card.off);
  assert(card.note && card.note.includes('جشنوارهٔ آزمون'), 'یادداشت تخفیف: ' + card.note);
  ok('لندینگ: قیمت قبلی خط‌خورده کنار قیمت جدید', `${card.was} → ${card.now} · ${card.off}`);

  /* ------------------------------------------------- ۴) مبلغ قابل پرداخت */
  const liveDb = new Database(DB_PATH, { readonly: true });
  const planRow = liveDb.prepare('SELECT * FROM plans WHERE id=?').get(plan.id);
  liveDb.close();
  assert.equal(payablePrice(planRow), expected30, 'مبلغ فیش/پرداخت باید تخفیف‌خورده باشد');
  ok('مبلغ قابل پرداخت = قیمت تخفیف‌خورده', fa(expected30));

  /* --------------------------------------------------- ۵) قیمت جدید دستی */
  const manual = Math.round(price * 0.55);
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 0, discountPrice: manual } });
  publicPlans = await (await fetch(BASE + '/api/public/plans')).json();
  row = publicPlans.rows.find(item => item.id === plan.id);
  assert.equal(row.discount.final_price, manual);
  assert.equal(row.discount.percent, 45);
  ok('قیمت با تخفیفِ دستی هم کار می‌کند و درصد را خودش حساب می‌کند', `${fa(manual)} · ${fa(45)}٪`);

  /* ------------------------------------------------------ ۶) اعتبارسنجی */
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 120 }, expected: 400 });
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 0, discountPrice: price + 1000 }, expected: 400 });
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountUntil: 'دیروز' }, expected: 400 });
  ok('ورودی نامعتبر (درصد >۹۵، قیمت بزرگ‌تر از اصلی، تاریخ خراب) رد می‌شود');

  /* ------------------------------------------------ ۷) انقضای خودکار */
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 40, discountPrice: null, discountUntil: '2020-01-01' } });
  publicPlans = await (await fetch(BASE + '/api/public/plans')).json();
  row = publicPlans.rows.find(item => item.id === plan.id);
  assert.equal(row.discount.active, false, 'تخفیف منقضی نباید فعال بماند');
  assert.equal(row.effective_price, price);
  const expiredHtml = await (await fetch(BASE + '/pricing', { headers: { 'cache-control': 'no-cache' } })).text();
  assert(!expiredHtml.includes('class="price-was"'), 'بعد از انقضا نباید قیمت خط‌خورده در صفحهٔ قیمت‌گذاری بماند');
  /* لندینگ داده را از /api/public/plans می‌گیرد که ۶۰ ثانیه کش عمومی دارد؛
     پس کش مرورگر را خاموش می‌کنیم تا حالت واقعیِ بعد از انقضا دیده شود. */
  await page.setCacheEnabled(false);
  await page.goto(BASE + '/?nocache=' + Date.now(), { waitUntil: 'networkidle2', timeout: 60000 });
  const landing = await page.evaluate(planName => {
    const el = document.querySelector(`.pa-l-price-card[data-public-plan="${planName}"]`);
    return el ? !!el.querySelector('.pa-l-price-was') : null;
  }, plan.name);
  assert.equal(landing, false, 'بعد از انقضا نباید قیمت خط‌خورده بماند');
  ok('با گذشتن تاریخ پایان، تخفیف خودکار خاموش می‌شود');

  /* ------------------------------------------------------ ۸) خاموش کردن */
  await request(session, `/api/admin/plans/${plan.id}`, { method: 'PATCH', body: { discountPercent: 0, discountPrice: null, discountLabel: '', discountUntil: null } });
  publicPlans = await (await fetch(BASE + '/api/public/plans')).json();
  row = publicPlans.rows.find(item => item.id === plan.id);
  assert.equal(row.discount.active, false);
  assert.equal(row.effective_price, price);
  assert.equal(planPricing(row).final_price, price);
  ok('حذف تخفیف، همه‌چیز را به قیمت اصلی برمی‌گرداند');

  await browser.close();
  console.log(`\n${passed}/${passed} آزمون تخفیف پلن پاس شد.`);
})().catch(error => { console.error('\n✗ ' + (error && error.message)); process.exitCode = 1 })
  .finally(() => { try { cleanup() } catch (error) { console.error('cleanup:', error.message) } });
