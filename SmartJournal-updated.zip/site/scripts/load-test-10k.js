/**
 * load-test-10k.js — شبیه‌سازی ۱۰٬۰۰۰ کاربر روی SmartJournal
 * ------------------------------------------------------------------
 * فازها:
 *   ۰) سلامت اولیه + شمارش کاربران
 *   ۱) Seed: ساخت کاربران + نشست + اشتراک رایگان (مستقیم در DB، سریع)
 *   ۲) بار ترکیبی: هر کاربر یک جلسهٔ واقعی API (خلاصه، حساب، معامله، ذخیره…)
 *      + سنجش مداوم قفلِ event loop از راه /api/health/live
 *   ۳) طوفان ورود: ۶۰ ورود همزمان bcrypt (۳۰ درست + ۳۰ غلط)
 *   ۴) مرورگر واقعی: ۶ صفحهٔ /journal همزمان + ۲ صفحهٔ اصلی
 *   ۵) مقیاس: کوئری‌های پنل با ۱۰هزار کاربر + کاربری با ۳۰۰ معامله
 *
 * اجرا:  node scripts/load-test-10k.js [--skip-seed] [--seed-only] [--phase=2]
 * پیش‌نیاز: سرور روی 127.0.0.1:3000 روشن باشد (SMOKE_BASE_URL قابل تغییر)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const ROOT = path.resolve(__dirname, '..');
const USERS = Number(process.env.LOAD_USERS || 10000);
const CONCURRENCY = Number(process.env.LOAD_CONCURRENCY || 50);
const TOKENS_FILE = path.join(ROOT, 'data', 'loadtest-tokens.json');
const args = new Set(process.argv.slice(2));
const ONLY = [...args].find(a => a.startsWith('--phase='));
const SKIP_SEED = args.has('--skip-seed');
const SEED_ONLY = args.has('--seed-only');
const CLEANUP = args.has('--cleanup');

const sha = v => crypto.createHash('sha256').update(String(v)).digest('hex');
const wait = ms => new Promise(r => setTimeout(r, ms));
const pct = (arr, p) => { if (!arr.length) return 0; const s = [...arr].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const fmt = ms => ms >= 1000 ? (ms / 1000).toFixed(2) + 's' : Math.round(ms) + 'ms';

let okc = 0, badc = 0;
const ok = (c, n, x = '') => { if (c) okc++; else badc++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const note = t => console.log('  • ' + t);

const stats = { ok: 0, fail: 0, byStatus: {}, lat: [] };
function record(status, ms) {
  if (status >= 200 && status < 400) stats.ok++; else { stats.fail++; stats.byStatus[status] = (stats.byStatus[status] || 0) + 1; }
  stats.lat.push(ms);
}
function printStats(label) {
  const l = stats.lat;
  console.log(`\n  ${label}`);
  console.log(`    درخواست‌ها : ${stats.ok + stats.fail}  (موفق ${stats.ok} · ناموفق ${stats.fail})`);
  if (Object.keys(stats.byStatus).length) console.log('    وضعیت‌ها  :', Object.entries(stats.byStatus).map(([k, v]) => `${k}×${v}`).join(' · '));
  console.log(`    تأخیر     : p50=${fmt(pct(l, .5))} · p90=${fmt(pct(l, .9))} · p95=${fmt(pct(l, .95))} · p99=${fmt(pct(l, .99))} · بیشینه=${fmt(Math.max(...l))}`);
}

/* ─────────── فاز ۱: seed ─────────── */
async function seedUsers() {
  const bcrypt = require('bcryptjs');
  const dbMod = require(path.join(ROOT, 'db.js'));
  const db = dbMod.db || dbMod;
  const count = db.prepare('SELECT COUNT(*) c FROM users WHERE deleted_at IS NULL').get().c;
  let tokens = [];
  try { tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8')); } catch (e) { tokens = []; }
  const need = USERS - tokens.length;
  if (need <= 0) { note(`فایل توکن‌ها ${tokens.length} کاربر دارد؛ seed لازم نیست (DB: ${count} کاربر)`); return tokens; }
  console.log(`\n── فاز ۱) ساخت ${need.toLocaleString('fa-IR')} کاربر (DB فعلی: ${count.toLocaleString('fa-IR')}) ──`);
  const t0 = Date.now();
  const hash = bcrypt.hashSync('LoadTest#123', 12);
  const free = db.prepare("SELECT id,duration_days FROM plans WHERE name='free' LIMIT 1").get();
  const now = new Date().toISOString();
  const exp = new Date(Date.now() + 30 * 86400000).toISOString();
  const freeExp = free && Number(free.duration_days) > 0 ? new Date(Date.now() + Number(free.duration_days) * 86400000).toISOString() : null;
  const insUser = db.prepare(`INSERT INTO users (id,name,mobile,password_hash,status,created_at,updated_at,last_seen_at,mobile_verified_at,require_2fa) VALUES (?,?,?,?,'active',?,?,?,?,0)`);
  const insSess = db.prepare(`INSERT INTO user_sessions (id,user_id,token_hash,csrf_token,device,ip,user_agent,device_id,auth_method,mfa_verified,created_at,last_seen_at,expires_at,revoked_at) VALUES (?,?,?,?,?,?,?,NULL,'password',0,?,?,?,NULL)`);
  const insSub = db.prepare(`INSERT INTO subscriptions (id,user_id,plan_id,status,started_at,expires_at,auto_renew,coupon_id,discount_amount,updated_at) VALUES (?,?,?,'active',?,?,0,NULL,0,?)`);
  const uuid = () => crypto.randomUUID();
  const start = tokens.length;
  db.transaction(() => {
    for (let i = 0; i < need; i++) {
      const n = start + i;
      const uid = 'usr_' + uuid();
      const mobile = '0912' + String(n).padStart(7, '0');
      const token = 'lt-' + n + '-' + crypto.randomBytes(12).toString('base64url');
      insUser.run(uid, 'کاربر ' + String(n + 1), mobile, hash, now, now, now, now);
      insSess.run('uses_' + uuid(), uid, sha(token), 'csrf-' + n, 'LoadTest', '127.0.0.1', 'load-test-10k', now, now, exp);
      if (free) insSub.run('sub_' + uuid(), uid, free.id, now, freeExp, now);
      tokens.push({ i: n, token, csrf: 'csrf-' + n, mobile });
    }
  })();
  fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens));
  const total = db.prepare('SELECT COUNT(*) c FROM users WHERE deleted_at IS NULL').get().c;
  note(`seed تمام شد: ${total.toLocaleString('fa-IR')} کاربر در ${((Date.now() - t0) / 1000).toFixed(1)} ثانیه`);
  return tokens;
}

/* ─────────── ابزار درخواست ─────────── */
function mkReq(t) {
  const cookie = `pa_user_session=${t.token}`;
  const headers = { cookie };
  return {
    get: async (p) => { const s = Date.now(); const r = await fetch(B + p, { headers, signal: AbortSignal.timeout(15000) }); await r.text(); record(r.status, Date.now() - s); return r; },
    post: async (p, body) => { const s = Date.now(); const r = await fetch(B + p, { method: 'POST', headers: { ...headers, 'content-type': 'application/json', 'x-csrf-token': t.csrf }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) }); await r.text(); record(r.status, Date.now() - s); return r; },
    put: async (p, body) => { const s = Date.now(); const r = await fetch(B + p, { method: 'PUT', headers: { ...headers, 'content-type': 'application/json', 'x-csrf-token': t.csrf }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000) }); await r.text(); record(r.status, Date.now() - s); return r; },
  };
}

/* ─────────── فاز ۲: بار ترکیبی ─────────── */
async function mixedLoad(tokens) {
  console.log(`\n── فاز ۲) بار ترکیبی: ${tokens.length.toLocaleString('fa-IR')} جلسهٔ واقعی · ${CONCURRENCY} کاربر همزمان ──`);
  let cursor = 0;
  const next = () => { const i = cursor++; return i < tokens.length ? tokens[i] : null; };
  const t0 = Date.now();
  let healthMax = 0, healthN = 0, healthStop = false;
  const healthProbe = (async () => {
    while (!healthStop) {
      const t = Date.now();
      try { await fetch(B + '/api/health/live', { signal: AbortSignal.timeout(4000) }); }
      catch (e) {}
      const d = Date.now() - t;
      if (d > healthMax) healthMax = d;
      healthN++;
      await wait(100);
    }
  })();

  const symbols = ['XAU/USD', 'EUR/USD', 'BTC/USD', 'NAS100', 'USD/JPY'];
  const dirs = ['buy', 'sell'];
  let doneFlows = 0;
  const worker = async () => {
    let t;
    while ((t = next())) {
      const r = mkReq(t);
      await r.get('/api/auth/me');
      await r.get('/api/journal/summary');
      await r.get('/api/journal/entitlements');
      await r.get('/api/journal/accounts');
      /* ساخت حساب + گرفتن id واقعی از پاسخ (مطابق قرارداد کلاینت واقعی) */
      const accS = Date.now();
      const accRes = await fetch(B + '/api/journal/accounts', {
        method: 'POST',
        headers: { cookie: `pa_user_session=${t.token}`, 'content-type': 'application/json', 'x-csrf-token': t.csrf },
        body: JSON.stringify({ name: 'حساب اصلی', startingBalance: 10000 }),
        signal: AbortSignal.timeout(15000),
      });
      const accText = await accRes.text();
      record(accRes.status, Date.now() - accS);
      let accountId = null;
      try { accountId = JSON.parse(accText).account?.id || null; } catch (e) {}
      if (accountId) {
        const n = Math.random() < 0.2 ? 6 : 3; /* ۲۰٪ کاربران فعال‌تر */
        for (let k = 0; k < n; k++) {
          await r.post('/api/journal/trades', {
            id: 'trade_lt_' + t.i + '_' + k,
            accountId,
            entryDate: new Date(Date.now() - k * 86400000).toISOString(),
            symbol: symbols[k % symbols.length], direction: dirs[k % 2],
            resultType: k % 3 === 0 ? 'loss' : 'profit', amount: 100 + k * 5,
            entryPrice: 2450.2 + k, exitPrice: 2455 + k, plannedRR: 2,
            riskPercent: 1, emotionBefore: 'آرام', notes: 'معامله آزمایشی بار ۱۰هزار نفره',
          });
        }
      }
      await r.get('/api/journal/trades?limit=100');
      await r.put('/api/journal/storage/pa-notes', { value: '{"note":"یادداشت بار"}' });
      if (Math.random() < 0.1) await r.get('/api/journal/support/tickets');
      doneFlows++;
      if (doneFlows % 1000 === 0) {
        const el = (Date.now() - t0) / 1000;
        console.log(`    ${doneFlows.toLocaleString('fa-IR')} جلسه · ${el.toFixed(0)}s · ${Math.round((stats.ok + stats.fail) / el)} درخواست/ثانیه · healthMax=${fmt(healthMax)}`);
      }
    }
  };
  await Promise.all(Array.from({ length: CONCURRENCY }, () => worker()));
  healthStop = true;
  await wait(200);
  const elapsed = (Date.now() - t0) / 1000;
  printStats(`پایان بار ترکیبی در ${elapsed.toFixed(0)} ثانیه (${Math.round((stats.ok + stats.fail) / elapsed)} درخواست/ثانیه)`);
  ok(stats.fail === 0, 'هیچ درخواست ناموفقی در بار ترکیبی نبود', stats.fail ? JSON.stringify(stats.byStatus) : 'پاک');
  ok(healthMax < 1500, 'event loop در طول بار ترکیبی پاسخگو ماند', 'بیشینهٔ پاسخ health: ' + fmt(healthMax));
  ok(pct(stats.lat, .95) < 800, 'p95 تأخیر زیر ۸۰۰ms است', 'p95=' + fmt(pct(stats.lat, .95)));
  return { elapsed, healthMax };
}

/* ─────────── فاز ۳: طوفان ورود ─────────── */
async function loginStorm(tokens) {
  console.log(`\n── فاز ۳) طوفان ورود: ۶۰ ورود همزمان (۳۰ درست + ۳۰ غلط) ──`);
  let healthMax = 0, healthN = 0, healthStop = false;
  const healthProbe = (async () => {
    while (!healthStop) {
      const t = Date.now();
      try { await fetch(B + '/api/health/live', { signal: AbortSignal.timeout(4000) }); } catch (e) {}
      const d = Date.now() - t;
      if (d > healthMax) healthMax = d;
      healthN++;
      await wait(40);
    }
  })();
  const t0 = Date.now();
  const storm = [];
  for (let k = 0; k < 30; k++) {
    const t = tokens[k * 331 % tokens.length];
    storm.push((async () => {
      const s = Date.now();
      const r = await fetch(B + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ mobile: t.mobile, password: 'LoadTest#123' }), signal: AbortSignal.timeout(30000) });
      await r.text(); record(r.status, Date.now() - s); return r.status;
    })());
    storm.push((async () => {
      const s = Date.now();
      const r = await fetch(B + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ mobile: t.mobile, password: 'WrongPass#999' }), signal: AbortSignal.timeout(30000) });
      await r.text(); record(r.status, Date.now() - s); return r.status;
    })());
  }
  const results = await Promise.all(storm);
  healthStop = true;
  await wait(200);
  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
  const okLogin = results.filter(x => x === 200).length;
  const badLogin = results.filter(x => x === 401).length;
  console.log(`    ${elapsed}s · ورود موفق: ${okLogin} · رد صحیح رمز غلط: ${badLogin} · health بیشینه: ${fmt(healthMax)} (${healthN} پایش)`);
  ok(okLogin === 30, 'هر ۳۰ ورود درست موفق بود', okLogin + '/30');
  ok(badLogin === 30, 'هر ۳۰ رمز غلط با 401 رد شد', badLogin + '/30');
  ok(healthMax < 1500, 'event loop در طوفان ورود قفل نشد', 'بیشینهٔ health: ' + fmt(healthMax));
  return { healthMax, elapsed };
}

/* ─────────── فاز ۴: مرورگر واقعی ─────────── */
async function browserPhase(tokens) {
  console.log(`\n── فاز ۴) مرورگر واقعی: ۶ صفحهٔ ژورنال + ۲ صفحهٔ اصلی همزمان ──`);
  const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const jobs = [];
  const pick = i => tokens[Math.floor(i * tokens.length / 8)];
  for (let k = 0; k < 6; k++) jobs.push({ kind: 'journal', t: pick(k), viewport: k % 2 ? [390, 844] : [1366, 768] });
  jobs.push({ kind: 'landing', viewport: [390, 844] }, { kind: 'landing', viewport: [1366, 768] });
  const evalSafe = async (p, fn, tries = 3) => {
    for (let i = 0; i < tries; i++) {
      try { return await p.evaluate(fn); }
      catch (e) { if (i === tries - 1) throw e; await wait(600); }
    }
  };
  const results = await Promise.all(jobs.map(async job => {
    const p = await br.newPage();
    await p.setViewport({ width: job.viewport[0], height: job.viewport[1], isMobile: job.viewport[0] < 700, hasTouch: job.viewport[0] < 700 });
    const errors = [];
    const badUrls = [];
    p.on('response', r => {
      if (r.status() >= 400) badUrls.push(r.status() + ' ' + r.url());
    });
    p.on('pageerror', e => errors.push(String(e)));
    p.on('console', m => {
      if (m.type() !== 'error') return;
      const txt = String(m.text());
      /* «Failed to load resource 404» فقط وقتی خطاست که منبعِ آن واقعاً
         جزء ۴۰۴های عمدی (کلید خالی storage یا me بدون نشست) نباشد */
      if (/Failed to load resource/.test(txt) && badUrls.every(u => {
        if (u.startsWith('404') && u.includes('/api/journal/storage/')) return true;
        if (job.kind === 'landing' && u.startsWith('401') && u.includes('/api/auth/me')) return true;
        return false;
      })) return;
      errors.push(txt.slice(0, 160));
    });
    const t0 = Date.now();
    try {
      if (job.kind === 'journal' && job.t) {
        await p.setCookie({ name: 'pa_user_session', value: job.t.token, domain: '127.0.0.1', path: '/' });
        await p.goto(B + '/journal', { waitUntil: 'domcontentloaded', timeout: 60000 });
        let rendered = false;
        try { await p.waitForSelector('.pa-app', { visible: true, timeout: 30000 }); rendered = true; } catch (e) {}
        if (!rendered) rendered = await evalSafe(p, () => !!document.querySelector('.pa-app'));
        await wait(1200);
        return { kind: 'journal', w: job.viewport[0], ms: Date.now() - t0, errors, rendered, badUrls };
      }
      await p.goto(B + '/', { waitUntil: 'domcontentloaded', timeout: 60000 });
      let rendered = false;
      try { await p.waitForSelector('#pa-landing .pa-l-nav, .pa-l-nav', { visible: true, timeout: 30000 }); rendered = true; } catch (e) {}
      if (!rendered) rendered = await evalSafe(p, () => !!document.querySelector('#pa-landing'));
      await wait(1200);
      return { kind: 'landing', w: job.viewport[0], ms: Date.now() - t0, errors, rendered, badUrls };
    } finally {
      await p.close().catch(() => {});
    }
  }));
  await br.close();
  for (const r of results) {
    const unexpected = (r.badUrls || []).filter(u => !(u.startsWith('404') && u.includes('/api/journal/storage/')) && !(r.kind === 'landing' && u.startsWith('401') && u.includes('/api/auth/me')));
    ok(r.rendered && r.errors.length === 0 && unexpected.length === 0,
      `${r.kind} ${r.w}px در ${(r.ms / 1000).toFixed(1)}s رندر شد`,
      [r.errors.slice(0, 2).join(' | '), unexpected.slice(0, 2).join(' | ')].filter(Boolean).join(' · ') || 'بدون خطا');
  }
  return results;
}

/* ─────────── فاز ۵: مقیاس ─────────── */
async function scalePhase(tokens) {
  console.log(`\n── فاز ۵) مقیاس: پنل مدیریت با ۱۰هزار کاربر + کاربری با ۳۰۰ معامله ──`);
  const dbMod = require(path.join(ROOT, 'db.js'));
  const db = dbMod.db || dbMod;
  const t0 = Date.now();
  const usersCount = db.prepare('SELECT COUNT(*) c FROM users WHERE deleted_at IS NULL').get().c;
  const sessionsCount = db.prepare('SELECT COUNT(*) c FROM user_sessions WHERE revoked_at IS NULL AND expires_at>?').get(new Date().toISOString()).c;
  const ms1 = Date.now() - t0;
  note(`کاربر: ${usersCount.toLocaleString('fa-IR')} · نشست فعال: ${sessionsCount.toLocaleString('fa-IR')} (شمارش در ${ms1}ms)`);

  /* کوئری شبیه صفحهٔ «کاربران» پنل */
  const t1 = Date.now();
  db.prepare(`SELECT u.id,u.name,u.mobile,u.status,u.created_at FROM users u WHERE u.deleted_at IS NULL ORDER BY u.created_at DESC LIMIT 300`).all();
  const usersPageMs = Date.now() - t1;
  ok(usersPageMs < 200, 'کوئری فهرست کاربران پنل زیر ۲۰۰ms است', usersPageMs + 'ms');

  /* کاربر با ۳۰۰ معامله — مثل کاربر واقعی پرکار */
  const t = tokens[Math.floor(tokens.length / 2)];
  const r = mkReq(t);
  const big = await r.post('/api/journal/accounts', { name: 'حساب سنگین', startingBalance: 50000 });
  const bigMs = [];
  for (let k = 0; k < 300; k++) {
    const s = Date.now();
    await r.post('/api/journal/trades', {
      symbol: 'XAU/USD', direction: k % 2 ? 'short' : 'long', resultType: 'profit',
      entryDate: new Date(Date.now() - k * 3600000).toISOString(), entryPrice: 2400 + (k % 40),
      exitPrice: 2405 + (k % 40), riskPercent: 1, notes: 'مقیاس',
    });
    bigMs.push(Date.now() - s);
  }
  const readS = Date.now();
  await r.get('/api/journal/trades?limit=500');
  const readMs = Date.now() - readS;
  console.log(`    نوشتن ۳۰۰ معامله: اولین=${fmt(bigMs[0])} · آخرین=${fmt(bigMs[bigMs.length - 1])} · میانگین=${fmt(bigMs.reduce((a, b) => a + b, 0) / bigMs.length)}`);
  console.log(`    خواندن ۳۰۰ معامله: ${fmt(readMs)}`);
  ok(bigMs[bigMs.length - 1] < 2000, 'نوشتن معاملهٔ ۳۰۰اُم زیر ۲ ثانیه است', fmt(bigMs[bigMs.length - 1]));
  ok(readMs < 2000, 'خواندن ۳۰۰ معامله زیر ۲ ثانیه است', fmt(readMs));
}

/* ─────────── پاکسازی کاربران بار (فقط ردیف‌های همین تست) ─────────── */
function cleanupLoadUsers() {
  const dbMod = require(path.join(ROOT, 'db.js'));
  const db = dbMod.db || dbMod;
  const t0 = Date.now();
  const rows = db.prepare(`SELECT u.id,u.mobile FROM users u JOIN user_sessions s ON s.user_id=u.id WHERE s.user_agent='load-test-10k'`).all();
  if (!rows.length) { note('چیزی برای پاکسازی نبود.'); return; }
  const userIds = [...new Set(rows.map(r => r.id))];
  const mobiles = [...new Set(rows.map(r => r.mobile))];
  const marks = userIds.map(() => '?').join(',');
  const reqIds = db.prepare(`SELECT id FROM support_requests WHERE user_id IN (${marks})`).all(...userIds).map(r => r.id);
  const reqMarks = reqIds.map(() => '?').join(',');
  db.transaction(() => {
    if (reqMarks) db.prepare(`DELETE FROM support_messages WHERE request_id IN (${reqMarks})`).run(...reqIds);
    if (marks) {
      db.prepare(`DELETE FROM support_requests WHERE user_id IN (${marks})`).run(...userIds);
      for (const table of ['journal_media_refs', 'media_files', 'journal_trades', 'journal_accounts',
        'journal_preferences', 'journal_sync_versions', 'user_legal_acceptances', 'subscriptions',
        'user_sessions', 'user_trusted_devices', 'user_security_events']) {
        db.prepare(`DELETE FROM ${table} WHERE user_id IN (${marks})`).run(...userIds);
      }
      db.prepare(`DELETE FROM users WHERE id IN (${marks})`).run(...userIds);
    }
    const mm = mobiles.map(() => '?').join(',');
    if (mm) db.prepare(`DELETE FROM user_otp_challenges WHERE mobile IN (${mm})`).run(...mobiles);
  })();
  try { fs.unlinkSync(TOKENS_FILE); } catch (e) {}
  const left = db.prepare('SELECT COUNT(*) c FROM users WHERE deleted_at IS NULL').get().c;
  note(`پاکسازی تمام شد: ${left.toLocaleString('fa-IR')} کاربر باقی ماند در ${((Date.now() - t0) / 1000).toFixed(1)} ثانیه`);
}

/* ─────────── اجرا ─────────── */
(async () => {
  console.log('SmartJournal — شبیه‌سازی ۱۰٬۰۰۰ کاربر');
  console.log('سرور:', B, '· هدف:', USERS.toLocaleString('fa-IR'), 'کاربر · همزمانی:', CONCURRENCY, '\n');
  if (CLEANUP) { cleanupLoadUsers(); process.exit(0); }
  let tokens = [];
  if (!SKIP_SEED) tokens = await seedUsers();
  else { try { tokens = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8')); } catch (e) { tokens = []; } }
  if (SEED_ONLY) process.exit(0);
  if (!tokens.length) { console.error('هیچ نشستی در دسترس نیست؛ اول seed کنید.'); process.exit(1); }
  const phase = ONLY ? Number(ONLY.split('=')[1]) : 0;
  if (!phase || phase === 2) await mixedLoad(tokens);
  if (!phase || phase === 3) await loginStorm(tokens);
  if (!phase || phase === 4) await browserPhase(tokens);
  if (!phase || phase === 5) await scalePhase(tokens);
  const fiveX = Object.keys(stats.byStatus).filter(s => Number(s) >= 500);
  ok(fiveX.length === 0, 'هیچ خطای سروری (5xx) در کل تست رخ نداد', fiveX.length ? fiveX.join(' · ') : 'پاک');
  console.log(`\n${'═'.repeat(50)}`);
  console.log(`نتیجه: ${okc}/${okc + badc} بررسی پاس شد.`);
  process.exit(badc ? 1 : 0);
})().catch(e => { console.error('LOAD TEST FAILED:', e.stack || e); process.exit(1); });
