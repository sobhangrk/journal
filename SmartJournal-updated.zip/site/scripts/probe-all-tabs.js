/**
 * probe-all-tabs.js — همهٔ تب‌های ژورنال روی موبایل
 * ابتدا فهرست تب‌ها را از خود صفحه کشف می‌کند، بعد یکی‌یکی می‌رود و می‌سنجد.
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));
const ov = (a, b) => !(a[0] + a[2] <= b[0] || b[0] + b[2] <= a[0] || a[1] + a[3] <= b[1] || b[1] + b[3] <= a[1]);

const COLLECT = () => {
  const vis = el => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) < .05) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6) return null;
    return r;
  };
  const label = el => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') +
    (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
  const clipped = el => {
    let p = el.parentElement;
    while (p && p !== document.body) {
      const c = getComputedStyle(p);
      if (/auto|scroll|hidden/.test(c.overflowY) || /auto|scroll|hidden/.test(c.overflowX)) return true;
      p = p.parentElement;
    }
    return false;
  };
  const floaters = [], roots = [];
  document.querySelectorAll('body *').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
    const r = vis(el); if (!r) return;
    let par = el.parentElement, nested = false;
    while (par && par !== document.body) { const pc = getComputedStyle(par); if (pc.position === 'fixed' || pc.position === 'sticky') { nested = true; break } par = par.parentElement }
    if (nested) return;
    roots.push(el);
    floaters.push({ name: label(el), owner: label(el), rect: [r.left, r.top, r.width, r.height].map(Math.round) });
  });
  roots.forEach(root => {
    const rr = root.getBoundingClientRect();
    root.querySelectorAll('*').forEach(ch => {
      if (clipped(ch)) return;
      const r = vis(ch); if (!r) return;
      if (!(r.left < rr.left - 6 || r.top < rr.top - 6 || r.right > rr.right + 6 || r.bottom > rr.bottom + 6)) return;
      floaters.push({ name: label(root) + ' ▸ ' + label(ch), owner: label(root), rect: [r.left, r.top, r.width, r.height].map(Math.round) });
    });
  });
  const covered = [];
  document.querySelectorAll('button,a[href],input,select,textarea,[role="button"]').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) return;
    let f = el; while (f && f !== document.body) { const c = getComputedStyle(f); if (c.position === 'fixed' || c.position === 'sticky') return; f = f.parentElement }
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (!hit || hit === el || el.contains(hit) || hit.contains(el)) return;
    let g = hit, fx = null;
    while (g && g !== document.body) { const c = getComputedStyle(g); if (c.position === 'fixed' || c.position === 'sticky') { fx = g; break } g = g.parentElement }
    covered.push({ el: label(el), txt: (el.innerText || el.value || '').replace(/\s+/g, ' ').trim().slice(0, 24), by: label(fx || hit) });
  });
  /* سرریز افقی: چیزی از عرض صفحه بیرون زده؟ */
  const wide = [];
  document.querySelectorAll('body *').forEach(el => {
    const r = vis(el); if (!r) return;
    if (getComputedStyle(el).position === 'fixed') return;
    if (r.width > innerWidth + 2 || r.right > innerWidth + 2) {
      if (clipped(el)) return;
      wide.push(label(el) + ' w=' + Math.round(r.width) + ' right=' + Math.round(r.right));
    }
  });
  const small = [];
  document.querySelectorAll('button,a[href],[role="button"]').forEach(el => {
    const r = vis(el); if (!r) return;
    if (r.bottom < 0 || r.top > innerHeight * 6) return;
    if (r.width < 32 || r.height < 32) small.push(label(el) + ' ' + Math.round(r.width) + '×' + Math.round(r.height) + ' «' + (el.innerText || '').trim().slice(0, 14) + '»');
  });
  const tiny = [];
  document.querySelectorAll('p,li,span,small,button,a,label,td,th').forEach(el => {
    if (el.children.length) return;                 /* فقط برگ متنی */
    const t = (el.innerText || '').trim();
    if (t.length < 12) return;
    const r = vis(el); if (!r) return;              /* فقط چیزی که واقعاً دیده می‌شود */
    if (r.bottom < 0 || r.top > innerHeight * 6) return;
    const cs = getComputedStyle(el);
    if (parseFloat(cs.fontSize) < 11) tiny.push(label(el) + ' @' + parseFloat(cs.fontSize) + ' «' + t.slice(0, 22) + '»');
  });
  return {
    floaters, covered,
    wide: [...new Set(wide)].slice(0, 6),
    small: [...new Set(small)].slice(0, 6),
    tiny: [...new Set(tiny)].slice(0, 6),
    scrollW: document.documentElement.scrollWidth
  };
};

(async () => {
  const jar = [];
  const post = async (p, body) => {
    const r = await fetch(B + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie: jar.join('; ') }, body: JSON.stringify(body) });
    (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  const mobile = '0993' + String(Date.now()).slice(-7);
  const s1 = await post('/api/auth/signup', { name: 'کاربر تب‌ها', mobile, password: 'Lay@12345678', remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true });
  if (!s1.data.challengeToken) { console.log('signup failed', s1.status, JSON.stringify(s1.data).slice(0, 200)); process.exit(1); }
  await post('/api/auth/signup/verify', { challengeToken: s1.data.challengeToken, code: s1.data.devCode });

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const W = 390, H = 844;
  const p = await br.newPage();
  await p.setViewport({ width: W, height: H, isMobile: true, hasTouch: true });
  await p.goto(B + '/journal', { waitUntil: 'domcontentloaded' });
  for (const c of jar) { const [n, ...v] = c.split('='); await p.setCookie({ name: n, value: v.join('='), domain: '127.0.0.1', path: '/' }); }
  await p.goto(B + '/journal', { waitUntil: 'networkidle2', timeout: 60000 });
  await wait(5000);

  const tabs = await p.evaluate(() => [...document.querySelectorAll('.pa-header .pa-tab')]
    .map((t, i) => ({ i, label: (t.getAttribute('title') || t.getAttribute('aria-label') || t.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 22) })));
  console.log('تب‌های کشف‌شده:', tabs.map(t => t.i + ':' + t.label).join(' · '));

  for (const t of tabs) {
    await p.evaluate(i => { const el = document.querySelectorAll('.pa-header .pa-tab')[i]; if (el) el.click(); }, t.i);
    await wait(1600);
    await p.evaluate(() => window.scrollTo(0, 0)); await wait(350);
    const dTop = await p.evaluate(COLLECT);
    await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await wait(700);
    const dBot = await p.evaluate(COLLECT);
    await p.evaluate(() => window.scrollTo(0, 0)); await wait(300);
    const botKeys = new Set(dBot.covered.map(c => c.el + '|' + c.txt));
    const d = Object.assign({}, dTop, { covered: dTop.covered.filter(c => botKeys.has(c.el + '|' + c.txt)) });
    const cl = [];
    for (let i = 0; i < d.floaters.length; i++) for (let j = i + 1; j < d.floaters.length; j++) {
      const a = d.floaters[i], b = d.floaters[j];
      if (a.owner === b.owner) continue;
      if (ov(a.rect, b.rect)) cl.push(a.name + ' ✕ ' + b.name);
    }
    const bad = cl.length + d.covered.length + d.wide.length + d.small.length + d.tiny.length + (d.scrollW > W ? 1 : 0);
    console.log(`\n${bad ? '✗' : '✓'} [${t.i}] ${t.label}`);
    if (cl.length) console.log('    همپوشانی شناور:', cl.join(' | '));
    if (d.covered.length) console.log('    محتوای پوشیده:', d.covered.map(c => c.el + ' «' + c.txt + '» ← ' + c.by).join(' | '));
    if (d.scrollW > W) console.log('    اسکرول افقی: scrollWidth=' + d.scrollW + ' > ' + W);
    if (d.wide.length) console.log('    عریض‌تر از صفحه:', d.wide.join(' | '));
    if (d.small.length) console.log('    دکمهٔ کوچک:', d.small.join(' | '));
    if (d.tiny.length) console.log('    متن ریز:', d.tiny.join(' | '));
  }
  await p.close();
  await br.close();
})();
