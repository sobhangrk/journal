#!/bin/bash
# ============================================================================
#   SmartJournal — به‌روزرسانی امن سایت
#
#   روی سرور:   bash update.sh  [مسیر فایل zip]
#   اگر مسیر ندهید، خودش دنبال هر فایل zip در /root می‌گردد.
#
#   ✅ فایل .env (رمز دیتابیس و کلیدها) حفظ می‌شود
#   ✅ پوشه data/uploads (تصاویر کاربران) دست نمی‌خورد
#   ✅ اگر خطا داد، نسخه قبلی برمی‌گردد
# ============================================================================
set -u
APP_DIR="/opt/smartjournal"
APP_USER="smartjournal"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/sj-backup-${STAMP}"

c_ok="\033[1;32m"; c_no="\033[1;31m"; c_hi="\033[1;36m"; c_off="\033[0m"
say()  { echo -e "\n${c_hi}▶ $*${c_off}"; }
ok()   { echo -e "  ${c_ok}✓${c_off} $*"; }
die()  { echo -e "\n${c_no}✗ $*${c_off}"; exit 1; }

echo "==============================================="
echo "  به‌روزرسانی SmartJournal — $(date)"
echo "==============================================="
[ "$(id -u)" -eq 0 ] || die "با root اجرا کنید:  sudo bash $0"
[ -d "$APP_DIR" ] || die "$APP_DIR وجود ندارد. اول quick-install.sh را اجرا کنید."

# ------------------------------------------------ ۱) پیدا کردن فایل zip ---
say "پیدا کردن فایل جدید"
ZIP="${1:-}"
if [ -z "$ZIP" ]; then
  mapfile -t FOUND < <(ls -1t /root/*.zip 2>/dev/null)
  [ "${#FOUND[@]}" -gt 0 ] || die "هیچ فایل zip در /root پیدا نشد.
  اول از کامپیوترتان آپلود کنید:
      scp اسم-فایل.zip root@$(hostname -I | awk '{print $1}'):/root/"
  if [ "${#FOUND[@]}" -gt 1 ]; then
    echo "  چند فایل پیدا شد؛ جدیدترین انتخاب می‌شود:"
    for f in "${FOUND[@]}"; do echo "     - $f"; done
  fi
  ZIP="${FOUND[0]}"
fi
[ -f "$ZIP" ] || die "فایل پیدا نشد: $ZIP"
ok "فایل: $ZIP  ($(du -h "$ZIP" | cut -f1))"

unzip -t "$ZIP" >/dev/null 2>&1 || die "فایل zip خراب است. دوباره آپلودش کنید."
ok "سلامت آرشیو تایید شد"

# --------------------------------------------------- ۲) استخراج و بررسی ---
say "باز کردن فایل"
rm -rf /tmp/sj-update && mkdir -p /tmp/sj-update
unzip -q -o "$ZIP" -d /tmp/sj-update || die "باز کردن zip ناموفق بود"
SRC=$(find /tmp/sj-update -maxdepth 3 -name server.js -printf '%h\n' 2>/dev/null | head -1)
[ -n "$SRC" ] || die "داخل zip فایل server.js نبود — این نسخه SmartJournal نیست"
[ -f "$SRC/package.json" ] || die "package.json پیدا نشد"
NEWVER=$(node -e "try{console.log(require('$SRC/package.json').version)}catch(e){console.log('?')}" 2>/dev/null)
OLDVER=$(node -e "try{console.log(require('$APP_DIR/package.json').version)}catch(e){console.log('?')}" 2>/dev/null)
ok "نسخه فعلی: $OLDVER   ←   نسخه جدید: $NEWVER"

# ------------------------------------------------------- ۳) پشتیبان‌گیری ---
say "پشتیبان‌گیری از نسخه فعلی"
mkdir -p "$BACKUP"
cp -a "$APP_DIR/.env" "$BACKUP/.env" 2>/dev/null && ok "فایل .env ذخیره شد"
tar -czf "$BACKUP/code.tar.gz" -C "$APP_DIR" \
  --exclude=node_modules --exclude=data . 2>/dev/null
ok "کد قبلی: $BACKUP/code.tar.gz"

if command -v pg_dump >/dev/null 2>&1; then
  DBURL=$(grep -oP '^DATABASE_URL=\K.*' "$APP_DIR/.env" 2>/dev/null)
  if [ -n "$DBURL" ]; then
    pg_dump "$DBURL" > "$BACKUP/database.sql" 2>/dev/null \
      && ok "دیتابیس: $BACKUP/database.sql ($(du -h "$BACKUP/database.sql" | cut -f1))" \
      || echo "  ! پشتیبان دیتابیس گرفته نشد (ادامه می‌دهیم)"
  fi
fi

# ------------------------------------------------------- ۴) جایگزین کردن ---
say "توقف سرویس و جایگزینی فایل‌ها"
systemctl stop smartjournal 2>/dev/null
ok "سرویس متوقف شد"

command -v rsync >/dev/null 2>&1 || { DEBIAN_FRONTEND=noninteractive apt-get install -y -qq rsync >/dev/null 2>&1; }
# فقط کد را عوض می‌کنیم؛ data و .env و node_modules دست‌نخورده می‌مانند
rsync -a --delete \
  --exclude='.env' --exclude='data' --exclude='node_modules' \
  "$SRC"/ "$APP_DIR"/ 2>/dev/null || {
    cp -r "$SRC"/. "$APP_DIR"/ || die "کپی فایل‌ها ناموفق بود"
  }
cp -a "$BACKUP/.env" "$APP_DIR/.env" 2>/dev/null
mkdir -p "$APP_DIR/data/uploads"
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
ok "فایل‌های جدید جایگزین شد (.env و data حفظ شدند)"

# ------------------------------------------------------- ۵) وابستگی‌ها ---
say "به‌روزرسانی وابستگی‌ها"
cd "$APP_DIR" || die "ورود به $APP_DIR ناموفق"
if ! sudo -u "$APP_USER" npm ci --omit=dev --no-audit --no-fund; then
  echo "  ! npm ci ناموفق — با رجیستری داخلی دوباره تلاش می‌کنم"
  sudo -u "$APP_USER" npm config set registry https://registry.npmmirror.com
  sudo -u "$APP_USER" npm ci --omit=dev --no-audit --no-fund || die "نصب وابستگی‌ها ناموفق بود"
fi
ok "وابستگی‌ها آماده"

# ----------------------------------------------------------- ۶) راه‌اندازی ---
say "راه‌اندازی دوباره"
systemctl start smartjournal
sleep 7
if ! systemctl is-active --quiet smartjournal; then
  echo -e "\n${c_no}سرویس بالا نیامد — آخرین خطاها:${c_off}"
  journalctl -u smartjournal -n 30 --no-pager
  echo -e "\n${c_hi}بازگرداندن نسخه قبلی…${c_off}"
  tar -xzf "$BACKUP/code.tar.gz" -C "$APP_DIR"
  cp -a "$BACKUP/.env" "$APP_DIR/.env"
  chown -R "$APP_USER:$APP_USER" "$APP_DIR"
  systemctl start smartjournal
  sleep 5
  systemctl is-active --quiet smartjournal \
    && die "به‌روزرسانی ناموفق بود؛ نسخه قبلی برگردانده شد و سایت بالاست." \
    || die "به‌روزرسانی ناموفق بود و بازگردانی هم مشکل داشت. لاگ: journalctl -u smartjournal -n 50"
fi
ok "سرویس در حال اجراست"

# ------------------------------------------- ۶-ب) نگهداری خودکار ------------
say "نگهداری خودکار (دیده‌بان، سقف پیامک، پاکسازی تصاویر)"
if [ -f "$APP_DIR/scripts/tune-sms-limits.js" ]; then
  sudo -u "$APP_USER" APP_DIR="$APP_DIR" node "$APP_DIR/scripts/tune-sms-limits.js" >/dev/null 2>&1 \
    && ok "سقف پیامک برای اینترنت ایران تنظیم شد (فقط بار اول)" || echo -e "  ${c_hi}• سقف پیامک بررسی نشد (در پنل مدیریت قابل تنظیم است)${c_off}"
fi
if [ -f "$APP_DIR/scripts/enable-auto-cleanup.js" ]; then
  sudo -u "$APP_USER" APP_DIR="$APP_DIR" node "$APP_DIR/scripts/enable-auto-cleanup.js" >/dev/null 2>&1 \
    && ok "پاکسازی خودکار تصاویر یتیم روشن شد" || echo -e "  ${c_hi}• پاکسازی خودکار روشن نشد${c_off}"
fi
if [ -f "$APP_DIR/scripts/install-watchdog.sh" ] && [ "$(id -u)" = "0" ]; then
  APP_DIR="$APP_DIR" bash "$APP_DIR/scripts/install-watchdog.sh" >/dev/null 2>&1 \
    && ok "دیده‌بان خودکار نصب شد (هر ۱۵ دقیقه)" || echo -e "  ${c_hi}• زمان‌بند دیده‌بان نصب نشد — دستی: bash $APP_DIR/scripts/install-watchdog.sh${c_off}"
fi

# ----------------------------------------------------------- ۷) تست نهایی ---
say "تست"
sleep 2

BASEURL=$(grep -oP '^PUBLIC_BASE_URL=\K.*' "$APP_DIR/.env" 2>/dev/null)
APPPORT=$(grep -oP '^PORT=\K[0-9]+' "$APP_DIR/.env" 2>/dev/null); APPPORT="${APPPORT:-3000}"
# نام میزبان از PUBLIC_BASE_URL (بدون https:// و بدون مسیر)
VHOST=$(echo "${BASEURL:-}" | sed -E 's#^https?://##; s#/.*$##')
[ -n "$VHOST" ] || VHOST="127.0.0.1"

# ۷-الف) خود اپلیکیشن (بدون Nginx) — این تست اصلی است
APP_FAIL=0
for path in / /journal /admin /pricing; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 \
         -H "Host: ${VHOST}" "http://127.0.0.1:${APPPORT}${path}")
  if [ "$code" = "200" ]; then ok "اپلیکیشن ${path} → ${code}"
  else echo -e "  ${c_no}✗${c_off} اپلیکیشن ${path} → ${code}"; APP_FAIL=1; fi
done

# ۷-ب) از مسیر Nginx — با نام دامنه، نه 127.0.0.1
#     توجه: اگر HTTPS فعال باشد، certbot برای Host نامرتبط عمداً 404 برمی‌گرداند،
#     و برای دامنه 301 به https می‌دهد. پس 200/301/302 همگی سالم‌اند.
ncode=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 -H "Host: ${VHOST}" "http://127.0.0.1/")
case "$ncode" in
  200|301|302) ok "Nginx (${VHOST}) → ${ncode}" ;;
  *) echo -e "  ${c_no}✗${c_off} Nginx (${VHOST}) → ${ncode}" ;;
esac

# ۷-ج) اگر دامنه و HTTPS داریم، از بیرونی‌ترین لایه هم تست کن
case "${BASEURL:-}" in
  https://*)
    scode=$(curl -sk -o /dev/null -w '%{http_code}' --max-time 25 \
            --resolve "${VHOST}:443:127.0.0.1" "https://${VHOST}/")
    [ "$scode" = "200" ] && ok "HTTPS ${BASEURL} → ${scode}" \
      || echo -e "  ${c_no}✗${c_off} HTTPS ${BASEURL} → ${scode}"
    ;;
esac

if [ "$APP_FAIL" -eq 1 ]; then
  echo -e "\n  ${c_no}اپلیکیشن جواب ۲۰۰ نداد — ۳۰ خط آخر لاگ:${c_off}"
  journalctl -u smartjournal -n 30 --no-pager
fi

IPADDR="$BASEURL"
echo ""
echo "==============================================="
echo -e "  ${c_ok}✅ به‌روزرسانی تمام شد${c_off}   ($OLDVER → $NEWVER)"
echo "==============================================="
echo "   سایت : ${IPADDR:-http://$(hostname -I | awk '{print $1}')}"
echo "   پشتیبان نسخه قبلی: $BACKUP"
echo ""
echo "   برای بازگرداندن دستی:"
echo "     systemctl stop smartjournal"
echo "     tar -xzf $BACKUP/code.tar.gz -C $APP_DIR"
echo "     systemctl start smartjournal"
echo "==============================================="
