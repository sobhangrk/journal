#!/bin/bash
# ============================================================================
#   check-ssl-renew.sh — بررسی تمدید خودکار SSL (Let's Encrypt / certbot)
#   اجرا روی سرور:  bash /opt/smartjournal/scripts/check-ssl-renew.sh
# ============================================================================
g=$'\033[1;32m'; r=$'\033[1;31m'; y=$'\033[1;33m'; c=$'\033[1;36m'; o=$'\033[0m'

echo "${c}▶ ۱) وضعیت گواهی فعلی${o}"
for DOMAIN in $(ls /etc/letsencrypt/live 2>/dev/null); do
  CERT="/etc/letsencrypt/live/$DOMAIN/cert.pem"
  [ -f "$CERT" ] || continue
  END_DATE="$(openssl x509 -enddate -noout -in "$CERT" 2>/dev/null | cut -d= -f2)"
  if [ -n "$END_DATE" ]; then
    EXPIRY_EPOCH="$(date -d "$END_DATE" +%s 2>/dev/null || true)"
    NOW_EPOCH="$(date +%s)"
    if [ -n "$EXPIRY_EPOCH" ]; then
      DAYS=$(( (EXPIRY_EPOCH - NOW_EPOCH) / 86400 ))
      if [ "$DAYS" -gt 15 ]; then echo "  ${g}✓${o} $DOMAIN — انقضا: $END_DATE ($DAYS روز مانده)"
      else echo "  ${y}⚠${o} $DOMAIN — انقضا: $END_DATE (${r}فقط $DAYS روز!${o})"; fi
    else echo "  • $DOMAIN — انقضا: $END_DATE"; fi
  fi
done
[ -d /etc/letsencrypt/live ] || echo "  ${r}✗ /etc/letsencrypt/live پیدا نشد — SSL با certbot نصب نشده؟${o}"

echo
echo "${c}▶ ۲) زمان‌بند تمدید خودکار${o}"
if command -v systemctl >/dev/null 2>&1; then
  TIMER="$(systemctl list-timers 2>/dev/null | grep -iE 'certbot|snap.certbot' | head -3 || true)"
  if [ -n "$TIMER" ]; then
    echo "$TIMER"
    echo "  ${g}✓ زمان‌بند تمدید خودکار فعال است${o}"
  else
    echo "  ${r}✗ هیچ زمان‌بندی برای certbot پیدا نشد!${o}"
    echo "  نصبش کنید:"
    echo "    apt install -y certbot python3-certbot-nginx"
    echo "    systemctl enable --now certbot-renew.timer   (یا: snap install certbot --classic)"
  fi
else
  echo "  • systemd در دسترس نیست"
fi

echo
echo "${c}▶ ۳) تست خشک تمدید (بدون تغییر واقعی)${o}"
if command -v certbot >/dev/null 2>&1; then
  certbot renew --dry-run 2>&1 | tail -5
else
  echo "  ${y}• certbot پیدا نشد — فقط بررسی گواهی و زمان‌بند انجام شد.${o}"
fi

echo
echo "${c}نکته:${o} دیده‌بان خودکار سایت هم انقضای گواهی را هر ۱۵ دقیقه چک می‌کند و اگر زیر ۱۰ روز بماند پیامک می‌دهد."
