#!/usr/bin/env node
'use strict';
/* ============================================================================
   optimize-icons.js — فشرده‌سازی آیکون‌های PWA/فاوآیکون

   چرا: اندازه‌گیری موبایل (SPEED-NEXT.md) نشان داد `smartjournal-logo-192.png`
   با ۴۸٫۶ کیلوبایت روی صفحهٔ اصلی دانلود می‌شود — برای یک آیکون ۱۹۲ پیکسلی
   بسیار زیاد است (نسخهٔ WebP همان تصویر ۳٫۵ کیلوبایت بود). PNGها ۳۲ بیتی و
   بدون کوانتیزه‌سازی ذخیره شده بودند.

   این اسکریپت همان تصویر را با پالت ۸ بیتی و فشرده‌سازی حداکثری بازنویسی
   می‌کند. کیفیت دیداری آیکون تغییر محسوسی نمی‌کند (ابعاد و آلفا حفظ می‌شود).

   اجرا:  npm run media:icons
========================================================================== */
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const MEDIA = path.join(__dirname, '..', 'public', 'media');
/* ۱۲۸ رنگ نقطهٔ شکست اندازه است: بالاتر از آن حجم سه برابر می‌شود ولی چشم
   در اندازهٔ آیکون تفاوتی نمی‌بیند (فقط پس‌زمینهٔ تیره کمی دانه‌دار می‌شود). */
const TARGETS = [
  ['smartjournal-logo-192.png', 128],
  ['smartjournal-logo-512.png', 128],
  ['smartjournal-logo-original.png', 128],
];
const kb = n => (n / 1024).toFixed(1) + 'KB';

(async () => {
  let before = 0, after = 0;
  for (const [name, colours] of TARGETS) {
    const file = path.join(MEDIA, name);
    if (!fs.existsSync(file)) { console.log(`  ⏭  ${name} پیدا نشد`); continue; }
    const original = fs.statSync(file).size;
    const buffer = await sharp(file).png({
      palette: true, colours, effort: 10, compressionLevel: 9,
    }).toBuffer();
    if (buffer.length >= original) { console.log(`  ⏭  ${name} از قبل بهینه است`); before += original; after += original; continue; }
    fs.writeFileSync(file, buffer);
    before += original; after += buffer.length;
    console.log(`  ✅ ${name.padEnd(34)} ${kb(original).padStart(9)} → ${kb(buffer.length).padStart(9)}  ‑${Math.round((1 - buffer.length / original) * 100)}٪`);
  }
  console.log(`\n  مجموع: ${kb(before)} → ${kb(after)}  (‑${Math.round((1 - after / before) * 100)}٪)\n`);
})();
