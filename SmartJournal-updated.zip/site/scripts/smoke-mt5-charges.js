/**
 * smoke-mt5-charges.js — رگرسیون «کمیسیون/سواپ و جهت Buy/Sell در ورود متاتریدر»
 *
 * سه چیزی که این تست تضمین می‌کند:
 *   ۱) کمیسیون هر پوزیشن = مجموع Commission + Fee دیل‌های ورود و خروج آن.
 *   ۲) سواپ هر پوزیشن = مجموع Swap دیل‌های آن.
 *   ۳) جهت معامله برعکس نشود؛ در جدول Deals نوعِ دیلِ خروج مخالف پوزیشن است
 *      و باید هنگام ورود برگردانده شود.
 *
 * بدون مرورگر اجرا می‌شود: توابع ورودِ داده از src-html/index.combined.html
 * استخراج و در یک sandbox اجرا می‌شوند.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = path.join(__dirname, '..', 'src-html', 'index.combined.html');
const src = fs.readFileSync(SRC, 'utf8');
const R = [];
const ok = (n, c, x = '') => { R.push([c, n]); console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };

function grab(name) {
  const start = src.indexOf('\nfunction ' + name + '(');
  if (start < 0) throw new Error('تابع پیدا نشد: ' + name);
  const end = src.indexOf('\n}\n', start);
  return src.slice(start + 1, end + 3);
}
function grabConst(name) {
  const start = src.indexOf('\nconst ' + name + ' = [');
  if (start < 0) throw new Error('ثابت پیدا نشد: ' + name);
  const end = src.indexOf('\n}];\n', start);
  return src.slice(start + 1, end + 4);
}

const names = ['paDigits', 'paKey', 'paNumber', 'paDate', 'paZoneParts', 'paZoneOffsetMinutes',
  'paNaiveToInstant', 'paHeaderScore', 'paTableFromMatrix',
  'paSplitReportSections', 'paPickReportSection', 'paSectionHeader', 'paDealsLedger',
  'paApplyDealCharges', 'paMergeEntryCharges', 'paGuessMap', 'paDirection', 'paResultSign',
  'paBuildImportedTrade'];
const code = grabConst('paImportFields') + '\nconst paZoneCache = {};\n' + names.map(grab).join('\n') +
  '\nconst xl = { pre: {}, post: {} };\nfunction Lu(){ return "id" + Math.random().toString(36).slice(2) }\n';
const ctx = { console };
vm.createContext(ctx);
vm.runInContext(code, ctx, { filename: 'import-fns.js' });

/* ── ماتریس جدول‌ها را مستقیم از HTML بیرون می‌کشیم (بدون DOMParser) ── */
function matrixOf(html) {
  return [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
    .map(m => [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => c[1].replace(/<[^>]+>/g, '').replace(/&nbsp;|\u00a0/g, ' ').replace(/\s+/g, ' ').trim()))
    .filter(r => r.length > 2);
}
function tableOf(html, { merge = false } = {}) {
  const matrix = matrixOf(html);
  const sections = ctx.paSplitReportSections(matrix);
  const picked = sections.length > 1 ? ctx.paPickReportSection(sections) : null;
  const rows = picked && picked.rows.length > 1 ? picked.rows : matrix;
  const table = ctx.paTableFromMatrix(rows, 'MetaTrader HTML' + (picked && picked.name ? ' — ' + picked.name : ''));
  const isDeals = /deal/i.test((picked && picked.name) || '') || table.columns.some(c => c.norm === 'direction');
  return { table: isDeals ? ctx.paMergeEntryCharges(table) : ctx.paApplyDealCharges(table, sections), picked, isDeals };
}
function tradesOf(table) {
  const map = ctx.paGuessMap(table.columns, table.rows);
  return table.rows.map(r => ctx.paBuildImportedTrade(r, map, { accountId: 'acc', source: 'mt5', format: 'test', fileName: 'x.html' }));
}

/* ── ۱) گزارش ساختگی MT5 با Positions + Deals و کمیسیون/سواپ ناصفر ── */
const tr = cells => '<tr>' + cells.map(c => '<td>' + c + '</td>').join('') + '</tr>';
const POS_HEAD = ['Time', 'Position', 'Symbol', 'Type', 'Volume', 'Price', 'S / L', 'T / P', 'Time', 'Price', 'Commission', 'Swap', 'Profit'];
const DEAL_HEAD = ['Time', 'Deal', 'Symbol', 'Type', 'Direction', 'Volume', 'Price', 'Order', 'Cost', 'Commission', 'Fee', 'Swap', 'Profit', 'Balance', 'Comment'];
const synth = `<html><body><table>
${tr(['Trade History Report', '', ''])}
${tr(['Positions', '', ''])}
${tr(POS_HEAD)}
${tr(['2026.02.02 10:00:00', '5001', 'EURUSD', 'buy', 'my comment', '1.00', '1.1000', '', '', '2026.02.02 11:00:00', '1.1050', '0.00', '0.00', '500.00'])}
${tr(['2026.02.03 10:00:00', '5002', 'XAUUSD', 'sell', '', '2.00', '2400.00', '', '', '2026.02.03 12:00:00', '2410.00', '0.00', '0.00', '-200.00'])}
${tr(['Deals', '', ''])}
${tr(DEAL_HEAD)}
${tr(['2026.02.01 09:00:00', '9000', '', 'balance', '', '', '', '', '', '0.00', '0.00', '0.00', '10 000.00', '10 000.00', 'Start balance'])}
${tr(['2026.02.02 10:00:00', '9001', 'EURUSD', 'buy', 'in', '1.00', '1.1000', '5001', '', '-3.50', '-0.50', '0.00', '0.00', '10 000.00', ''])}
${tr(['2026.02.02 11:00:00', '9002', 'EURUSD', 'sell', 'out', '1.00', '1.1050', '5010', '', '-3.50', '0.00', '-1.25', '500.00', '10 491.25', ''])}
${tr(['2026.02.03 10:00:00', '9003', 'XAUUSD', 'sell', 'in', '2.00', '2400.00', '5002', '', '-7.00', '0.00', '0.00', '0.00', '10 484.25', ''])}
${tr(['2026.02.03 12:00:00', '9004', 'XAUUSD', 'buy', 'out', '2.00', '2410.00', '5011', '', '-7.00', '0.00', '-4.00', '-200.00', '10 266.25', ''])}
</table></body></html>`;

{
  const { table, picked } = tableOf(synth);
  ok('بخش Positions انتخاب می‌شود', /position/i.test(picked && picked.name || ''), picked && picked.name);
  const trades = tradesOf(table).filter(t => t.trade).map(t => t.trade);
  ok('هر دو پوزیشن وارد می‌شوند', trades.length === 2, 'count=' + trades.length);
  const eur = trades.find(t => t.symbol === 'EURUSD') || {};
  const xau = trades.find(t => t.symbol === 'XAUUSD') || {};
  ok('کمیسیون EURUSD = |−3.5 −0.5 −3.5| = 7.5', Math.abs(eur.commission - 7.5) < 1e-6, String(eur.commission));
  ok('سواپ EURUSD = −1.25', Math.abs(eur.swap + 1.25) < 1e-6, String(eur.swap));
  ok('کمیسیون XAUUSD = 14', Math.abs(xau.commission - 14) < 1e-6, String(xau.commission));
  ok('سواپ XAUUSD = −4', Math.abs(xau.swap + 4) < 1e-6, String(xau.swap));
  ok('جهت EURUSD = buy', eur.direction === 'buy', String(eur.direction));
  ok('جهت XAUUSD = sell', xau.direction === 'sell', String(xau.direction));
  ok('سود EURUSD مثبت ۵۰۰', eur.resultType === 'profit' && Math.abs(eur.amount - 500) < 1e-6, eur.amount + '/' + eur.resultType);
}

/* ── ۲) گزارشی که فقط Deals دارد: جهت باید برعکسِ نوعِ دیلِ خروج شود ── */
const dealsOnly = `<html><body><table>
${tr(['Deals', '', ''])}
${tr(DEAL_HEAD)}
${tr(['2026.02.02 10:00:00', '9001', 'EURUSD', 'buy', 'in', '1.00', '1.1000', '5001', '', '-3.50', '-0.50', '0.00', '0.00', '10 000.00', ''])}
${tr(['2026.02.02 11:00:00', '9002', 'EURUSD', 'sell', 'out', '1.00', '1.1050', '5010', '', '-3.50', '0.00', '-1.25', '500.00', '10 491.25', ''])}
${tr(['2026.02.03 10:00:00', '9003', 'XAUUSD', 'sell', 'in', '2.00', '2400.00', '5002', '', '-7.00', '0.00', '0.00', '0.00', '10 484.25', ''])}
${tr(['2026.02.03 12:00:00', '9004', 'XAUUSD', 'buy', 'out', '2.00', '2410.00', '5011', '', '-7.00', '0.00', '-4.00', '-200.00', '10 266.25', ''])}
</table></body></html>`;
{
  const { table, isDeals } = tableOf(dealsOnly);
  ok('جدول Deals تشخیص داده می‌شود', isDeals);
  const built = tradesOf(table);
  const trades = built.filter(t => t.trade).map(t => t.trade);
  ok('فقط دیل‌های خروج وارد می‌شوند', trades.length === 2, 'count=' + trades.length);
  const eur = trades.find(t => t.symbol === 'EURUSD') || {};
  const xau = trades.find(t => t.symbol === 'XAUUSD') || {};
  ok('EURUSD با دیل خروجِ sell باید buy ثبت شود', eur.direction === 'buy', String(eur.direction));
  ok('XAUUSD با دیل خروجِ buy باید sell ثبت شود', xau.direction === 'sell', String(xau.direction));
  ok('کمیسیون EURUSD (ورود+خروج) = 7.5', Math.abs(eur.commission - 7.5) < 1e-6, String(eur.commission));
  ok('کمیسیون XAUUSD (ورود+خروج) = 14', Math.abs(xau.commission - 14) < 1e-6, String(xau.commission));
  ok('سواپ XAUUSD = −4', Math.abs(xau.swap + 4) < 1e-6, String(xau.swap));
}

/* ── ۳) فایل واقعی نمونه: نباید چیزی خراب شود ── */
const SAMPLE = path.join(__dirname, '..', 'seed', 'samples', 'mt5-report-sample.html');
if (fs.existsSync(SAMPLE)) {
  const buf = fs.readFileSync(SAMPLE);
  const html = (buf[0] === 0xff && buf[1] === 0xfe) ? buf.toString('utf16le') : buf.toString('utf8');
  const { table, picked } = tableOf(html);
  const trades = tradesOf(table).filter(t => t.trade).map(t => t.trade);
  const net = trades.reduce((s, t) => s + (t.resultType === 'profit' ? t.amount : -t.amount) - t.commission + t.swap, 0);
  const posRows = matrixOf(html).filter(r => r.length === 14 && /^\d{4}\./.test(r[0]));
  const num = v => Number(String(v).replace(/[\s,]/g, '')) || 0;
  const gross = posRows.reduce((s, r) => s + num(r[13]), 0);
  const charges = posRows.reduce((s, r) => s + num(r[11]) + num(r[12]), 0);
  ok('نمونهٔ واقعی: ستون Direction ندارد (بخش Positions)', !table.columns.some(c => c.norm === 'direction'));
  ok('نمونهٔ واقعی: تعداد معاملات > ۲۰', trades.length > 20, 'count=' + trades.length);
  ok('نمونهٔ واقعی: کمیسیون‌ها وارد می‌شوند', Math.abs(trades.reduce((s, t) => s + t.commission, 0) - Math.abs(charges)) < 0.01,
    trades.reduce((s, t) => s + t.commission, 0).toFixed(2));
  ok('نمونهٔ واقعی: خالص = سود − کمیسیون + سواپ', Math.abs(net - (gross + charges)) < 0.01, net.toFixed(2) + ' vs ' + (gross + charges).toFixed(2));
  const dirs = new Set(trades.map(t => t.direction));
  ok('نمونهٔ واقعی: هر دو جهت دیده می‌شود', dirs.has('buy') && dirs.has('sell'), [...dirs].join(','));
} else {
  console.log('  (فایل نمونه نیست — بخش سوم رد شد)');
}

const bad = R.filter(([c]) => !c).length;
console.log(`\n${R.length - bad}/${R.length} تست موفق`);
process.exit(bad ? 1 : 0);
