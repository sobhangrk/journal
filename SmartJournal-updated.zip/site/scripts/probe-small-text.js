/**
 * probe-small-text.js — کدام متن‌ها روی موبایل زیر ۱۱ پیکسل‌اند؟
 */
const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const B = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const wait = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  for (const [name, w] of [['iPhone 14', 390], ['iPad', 768]]) {
    const p = await br.newPage();
    await p.setViewport({ width: w, height: 844, isMobile: w < 500, hasTouch: w < 500 });
    await p.goto(B + '/', { waitUntil: 'networkidle2', timeout: 60000 });
    await wait(2500);
    const list = await p.evaluate(() => {
      const out = [];
      document.querySelectorAll('body *').forEach(el => {
        if (el.children.length) return;
        const t = (el.textContent || '').trim();
        if (!t) return;
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden') return;
        const r = el.getBoundingClientRect();
        if (!r.width || !r.height) return;
        const fs = parseFloat(cs.fontSize);
        if (fs >= 11) return;
        const cls = (typeof el.className === 'string' ? el.className : '').trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
        const chain = [];
        let q = el.parentElement, n = 0;
        while (q && q !== document.body && n < 3) {
          const c = (typeof q.className === 'string' ? q.className : '').trim().split(/\s+/).filter(Boolean)[0];
          chain.push(q.tagName.toLowerCase() + (c ? '.' + c : ''));
          q = q.parentElement; n++;
        }
        out.push({ sel: el.tagName.toLowerCase() + (cls ? '.' + cls : ''), parent: chain.join(' < '), fs: +fs.toFixed(1), txt: t.slice(0, 30) });
      });
      return out;
    });
    console.log(`\n═══ ${name} (${w}px) — ${list.length} مورد ═══`);
    const byGroup = {};
    list.forEach(i => { const k = i.sel + ' @' + i.fs + '  ⟨' + i.parent + '⟩'; (byGroup[k] = byGroup[k] || []).push(i.txt); });
    Object.entries(byGroup).forEach(([k, v]) => console.log('  ', v.length + '× «' + v[0] + '»  ', k));
    await p.close();
  }
  await br.close();
})();
