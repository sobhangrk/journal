/**
 * smoke-bcrypt-pool.js — درستی و پاسخگویی استخر هش bcrypt
 *   ۱) هش/مقایسهٔ رفت‌وبرگشتی با bcryptjs اصلی یکسان است
 *   ۲) زیر ۲۰ هش موازی (cost=12)، حلقهٔ رویداد آزاد می‌ماند
 *      (پیش از این: gap تا ۲ ثانیه — سایت با چند ورود همزمان یخ می‌زد)
 */
const bcrypt = require('bcryptjs');
const pool = require('../bcrypt-pool');

let okc = 0, badc = 0;
const ok = (c, n, x = '') => { if (c) okc++; else badc++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (x ? '  — ' + x : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  /* ۱) درستی */
  const pw = 'Test#Password123';
  const h1 = await pool.hash(pw, 12);
  const h2 = bcrypt.hashSync(pw, 12);
  ok(typeof h1 === 'string' && h1.startsWith('$2'), 'هش با فرمت bcrypt ساخته شد', String(h1).slice(0, 7) + '…');
  ok(await pool.compare(pw, h1), 'مقایسهٔ رمز درست → true');
  ok(!(await pool.compare('wrong-password', h1)), 'مقایسهٔ رمز غلط → false');
  ok(await pool.compare(pw, h2), 'سازگار با هش‌های قدیمیِ bcryptjs', '');

  /* ۲) پاسخگویی: ۲۰ هش موازی + پایش gap حلقهٔ رویداد */
  let last = Date.now(), maxGap = 0;
  const timer = setInterval(() => { const now = Date.now(); const g = now - last; last = now; if (g > maxGap) maxGap = g; }, 1);
  const t0 = Date.now();
  await Promise.all(Array.from({ length: 20 }, () => pool.hash(pw, 12)));
  const elapsed = Date.now() - t0;
  clearInterval(timer);
  await wait(20);
  console.log(`    ۲۰ هش موازی در ${elapsed}ms · بیشینهٔ gap حلقهٔ رویداد: ${maxGap}ms (قبل از اصلاح: تا ۲۰۰۰ms)`);
  ok(maxGap < 100, 'حلقهٔ رویداد زیر بار هش آزاد ماند', 'gap=' + maxGap + 'ms');

  /* ۳) ۲۰ مقایسهٔ موازی هم همین‌طور */
  last = Date.now(); maxGap = 0;
  const timer2 = setInterval(() => { const now = Date.now(); const g = now - last; last = now; if (g > maxGap) maxGap = g; }, 1);
  await Promise.all(Array.from({ length: 20 }, () => pool.compare(pw, h1)));
  clearInterval(timer2);
  await wait(20);
  ok(maxGap < 100, 'حلقهٔ رویداد زیر بار مقایسه آزاد ماند', 'gap=' + maxGap + 'ms');

  console.log(`\n${okc}/${okc + badc} بررسی استخر bcrypt پاس شد.`);
  process.exit(badc ? 1 : 0);
})().catch(e => { console.error('BCRYPT POOL FAILED:', e); process.exit(1); });
