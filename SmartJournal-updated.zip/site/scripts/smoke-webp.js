'use strict';
/* آزمون تبدیل خودکار تصاویر آپلودی به WebP روی Backend واقعی */

const assert = require('node:assert/strict');
const path = require('node:path');
const Database = require('better-sqlite3');
const sharp = require('sharp');

const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '../data/admin.db');
const db = new Database(DB_PATH);
const stamp = String(Date.now());
const fixture = { userId: null, mobile: '091' + stamp.slice(-8) };
let passed = 0;
const ok = (n) => { passed += 1; console.log('✓ ' + n); };

function cookies(res) {
  const v = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie() : [res.headers.get('set-cookie')].filter(Boolean);
  return v.flatMap(x => String(x).split(/,(?=\s*[^;,]+=)/)).map(x => x.trim().split(';')[0]).join('; ');
}

async function req(url, { method = 'GET', body, cookie, csrf, status = 200 } = {}) {
  const headers = { 'user-agent': 'PA WebP Smoke' };
  if (cookie) headers.cookie = cookie;
  if (body !== undefined) {
    headers['content-type'] = 'application/json';
    if (csrf) headers['x-csrf-token'] = csrf;
  }
  const res = await fetch(BASE + url, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  assert.equal(res.status, status, `${method} ${url}: ${res.status} ${JSON.stringify(data).slice(0, 200)}`);
  return { res, data };
}

function cleanup() {
  try {
    db.pragma('foreign_keys = OFF');
    if (fixture.userId) {
      for (const t of ['media_files', 'payment_receipts', 'payments', 'subscriptions',
        'user_sessions', 'user_trusted_devices', 'user_security_events', 'user_otp_challenges',
        'user_activity_logs', 'user_contacts', 'user_legal_acceptances', 'journal_preferences',
        'journal_sync_versions', 'journal_trades', 'journal_accounts', 'journal_media_refs', 'sms_logs']) {
        try { db.prepare(`DELETE FROM ${t} WHERE user_id=?`).run(fixture.userId); } catch {}
      }
      db.prepare('DELETE FROM users WHERE id=?').run(fixture.userId);
    }
  } finally { db.close(); }
}

(async () => {
  // ---------- build genuine test images in several formats ----------
  const base = sharp({ create: { width: 900, height: 600, channels: 3, background: { r: 12, g: 24, b: 38 } } })
    .composite([{
      input: Buffer.from(
        `<svg width="900" height="600"><rect width="900" height="600" fill="#0b1622"/>
         <circle cx="300" cy="300" r="220" fill="#22d3ee" opacity="0.55"/>
         <circle cx="620" cy="330" r="180" fill="#46e39b" opacity="0.45"/></svg>`),
      top: 0, left: 0,
    }]);
  const pngBuf = await base.clone().png().toBuffer();
  const jpgBuf = await base.clone().jpeg({ quality: 92 }).toBuffer();
  const gifBuf = await base.clone().gif().toBuffer();
  const tifBuf = await base.clone().tiff().toBuffer();
  console.log(`  test images — png ${(pngBuf.length / 1024).toFixed(0)}KB · `
    + `jpg ${(jpgBuf.length / 1024).toFixed(0)}KB · gif ${(gifBuf.length / 1024).toFixed(0)}KB · `
    + `tiff ${(tifBuf.length / 1024).toFixed(0)}KB\n`);

  // ---------- real user ----------
  const signup = await req('/api/auth/signup', {
    method: 'POST', status: 202,
    body: {
      name: 'کاربر WebP', mobile: fixture.mobile, password: 'Webp@12345', remember: true,
      acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false,
    },
  });
  const verified = await req('/api/auth/signup/verify', {
    method: 'POST', status: 201,
    body: { challengeToken: signup.data.challengeToken, code: signup.data.devCode },
  });
  fixture.userId = verified.data.user.id;
  const user = { cookie: cookies(verified.res), csrf: verified.data.csrfToken };
  ok('کاربر آزمایشی ساخته شد');

  // ---------- upload each format and check what got stored ----------
  const cases = [['PNG', pngBuf, 'image/png'], ['JPEG', jpgBuf, 'image/jpeg'],
                 ['GIF', gifBuf, 'image/gif'], ['TIFF', tifBuf, 'image/tiff']];

  for (const [label, buf, mime] of cases) {
    const dataUrl = `data:${mime};base64,${buf.toString('base64')}`;
    const up = await req('/api/journal/media', {
      method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
      body: { data: dataUrl },
    });
    const fileId = up.data.id || up.data.fileId || (up.data.files && up.data.files[0]);
    const row = db.prepare('SELECT mime_type,size_bytes,storage_key FROM media_files WHERE id=?').get(fileId);
    assert.ok(row, `${label}: media row missing`);
    assert.equal(row.mime_type, 'image/webp', `${label} stored as ${row.mime_type}`);
    assert.match(row.storage_key, /\.webp$/, `${label} key ${row.storage_key}`);
    const saved = Math.round(100 - (row.size_bytes * 100) / buf.length);
    ok(`${label.padEnd(4)} → WebP ذخیره شد  (${(buf.length / 1024).toFixed(0)}KB → `
      + `${(row.size_bytes / 1024).toFixed(0)}KB، ${saved}% کمتر)`);
  }

  // ---------- the stored bytes really are WebP ----------
  const last = db.prepare('SELECT id FROM media_files WHERE user_id=? ORDER BY uploaded_at DESC LIMIT 1')
    .get(fixture.userId);
  const img = await fetch(`${BASE}/api/journal/media/${last.id}`, { headers: { cookie: user.cookie } });
  const bytes = Buffer.from(await img.arrayBuffer());
  assert.equal(img.headers.get('content-type'), 'image/webp');
  assert.equal(bytes.slice(0, 4).toString('latin1'), 'RIFF');
  assert.equal(bytes.slice(8, 12).toString('latin1'), 'WEBP');
  ok('بایت‌های تحویلی واقعاً WebP هستند (هدر RIFF/WEBP)');

  // ---------- an image that is already WebP must not be re-encoded ----------
  const webpBuf = await base.clone().webp({ quality: 82 }).toBuffer();
  const upWebp = await req('/api/journal/media', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: { data: `data:image/webp;base64,${webpBuf.toString('base64')}` },
  });
  const wid = upWebp.data.id || upWebp.data.fileId || (upWebp.data.files && upWebp.data.files[0]);
  const wrow = db.prepare('SELECT mime_type,size_bytes FROM media_files WHERE id=?').get(wid);
  assert.equal(wrow.mime_type, 'image/webp');
  assert.equal(wrow.size_bytes, webpBuf.length, 'existing webp should be stored untouched');
  ok('تصویری که از قبل WebP است دوباره فشرده نمی‌شود');

  // ---------- a receipt image also becomes WebP ----------
  const plans = await req('/api/public/plans');
  const paid = plans.data.rows.find(p => Number(p.price_monthly) > 0);
  const rc = await req('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: { planId: paid.id, trackingCode: 'WEBP' + stamp.slice(-6),
            receipt: `data:image/png;base64,${pngBuf.toString('base64')}` },
  });
  const rrow = db.prepare('SELECT receipt_mime,receipt_size FROM payment_receipts WHERE id=?').get(rc.data.id);
  assert.equal(rrow.receipt_mime, 'image/webp');
  ok(`فیش واریز هم WebP ذخیره شد (${(pngBuf.length / 1024).toFixed(0)}KB → `
    + `${(rrow.receipt_size / 1024).toFixed(0)}KB)`);

  // ---------- a PDF receipt must stay a PDF ----------
  const pdf = Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(400, 0x20), Buffer.from('\n%%EOF\n')]);
  const rc2 = await req('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: { planId: paid.id, trackingCode: 'PDF' + stamp.slice(-6),
            receipt: `data:application/pdf;base64,${pdf.toString('base64')}` },
  });
  const prow = db.prepare('SELECT receipt_mime FROM payment_receipts WHERE id=?').get(rc2.data.id);
  assert.equal(prow.receipt_mime, 'application/pdf');
  ok('فیش PDF دست‌نخورده می‌ماند (تبدیل نمی‌شود)');

  // ---------- a fake image must still be rejected ----------
  await req('/api/journal/media', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 400,
    body: { data: 'data:image/png;base64,' + Buffer.from('not really a png').toString('base64') },
  });
  ok('فایل جعلی همچنان رد می‌شود (تبدیل، اعتبارسنجی را دور نمی‌زند)');

  console.log(`\n${passed} آزمون تبدیل WebP با موفقیت پاس شد.`);
})()
  .then(() => cleanup())
  .catch((e) => { cleanup(); console.error('\n✗ ' + e.message); process.exit(1); });
