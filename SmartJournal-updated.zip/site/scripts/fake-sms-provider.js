/**
 * درگاه پیامک قلابی برای تست — دقیقاً مثل یک پنل پیامک واقعی رفتار می‌کند:
 * یک POST با Bearer token می‌گیرد و پیام را ثبت می‌کند.
 * با این می‌شود بدون خرید اعتبار، «کل مسیر واقعی» را تست کرد.
 */
const http = require('http');
const inbox = [];
let failNext = 0;

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url.startsWith('/inbox')) {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify(inbox));
  }
  if (req.method === 'POST' && req.url === '/fail-next') {
    failNext = 1;
    res.writeHead(200); return res.end('ok');
  }
  let body = '';
  req.on('data', c => { body += c; });
  req.on('end', () => {
    if (failNext) { failNext = 0; res.writeHead(500, {'content-type':'application/json'}); return res.end('{"error":"PROVIDER_DOWN"}'); }
    const auth = req.headers.authorization || '';
    if (!/^Bearer\s+TEST-SECRET-KEY$/.test(auth)) {
      res.writeHead(401, { 'content-type': 'application/json' });
      return res.end('{"error":"BAD_TOKEN"}');
    }
    let parsed = {};
    try { parsed = JSON.parse(body); } catch {}
    inbox.push({ at: new Date().toISOString(), ...parsed });
    console.log('📨 پیامک دریافت شد →', JSON.stringify(parsed));
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end('{"status":"ok","messageId":"fake-' + inbox.length + '"}');
  });
});
server.listen(4555, '127.0.0.1', () => console.log('fake SMS provider on http://127.0.0.1:4555'));
