#!/usr/bin/env node
'use strict';
/* ==========================================================================
   SmartJournal — وضعیت و بازنشانی تأیید دومرحله‌ای مدیر (TOTP)

   کاربر owner برای امنیت، اجباراً باید کد دومرحله‌ای فعال کند.
   اگر در این مرحله گیر کردید (گوشی عوض شده، اپ پاک شده، QR را رد کرده‌اید)
   با این ابزار می‌شود وضعیت را دید یا از نو شروع کرد.

       node scripts/admin-mfa.js --status
       node scripts/admin-mfa.js --reset owner
   ========================================================================== */

const path = require('path');
const fs = require('fs');
const ROOT = path.resolve(__dirname, '..');

/* بارگذاری .env */
const ENV_FILE = path.join(ROOT, '.env');
if (fs.existsSync(ENV_FILE)) {
  for (const raw of fs.readFileSync(ENV_FILE, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const k = line.slice(0, eq).trim();
    if (process.env[k] === undefined) process.env[k] = line.slice(eq + 1).trim();
  }
}

let db;
try {
  db = require(path.join(ROOT, 'db.js'));
  if (db && db.db) db = db.db;
} catch (error) {
  console.error('✗ اتصال به دیتابیس ممکن نشد:', error.message);
  process.exit(1);
}

const RESET = (() => {
  const i = process.argv.indexOf('--reset');
  return i > -1 ? String(process.argv[i + 1] || 'owner') : null;
})();

function rows() {
  return db.prepare(`
    SELECT a.username, a.name, a.role, a.status, a.mfa_required,
           t.enabled AS totp_enabled, t.verified_at,
           (t.pending_secret_encrypted IS NOT NULL) AS pending
      FROM admins a
      LEFT JOIN admin_totp t ON t.admin_id = a.id
     ORDER BY CASE a.role WHEN 'owner' THEN 0 ELSE 1 END, a.username
  `).all();
}

function show() {
  const list = rows();
  console.log('\n  وضعیت تأیید دومرحته‌ای مدیران');
  console.log('  ────────────────────────────────────────────────────');
  if (!list.length) { console.log('  هیچ مدیری وجود ندارد!'); return; }
  for (const r of list) {
    const st = r.totp_enabled ? '✅ فعال و تأییدشده'
             : r.pending      ? '⏳ شروع شده ولی تأیید نشده (QR اسکن نشده)'
             :                  '⚪ هنوز فعال نشده';
    console.log(`  ${String(r.username).padEnd(14)} ${String(r.role).padEnd(8)} ${st}`);
  }
  console.log('  ────────────────────────────────────────────────────');
  const owner = list.find(r => r.role === 'owner');
  if (owner && !owner.totp_enabled) {
    console.log(`
  ℹ️  کاربر owner هنوز کد دومرحله‌ای فعال نکرده.
     وارد پنل شوید؛ بعد از زدن رمز، صفحه‌ای با QR code باز می‌شود.
     با اپ Google Authenticator اسکنش کنید و کد ۶ رقمی را وارد کنید.
`);
  }
  console.log('');
}

if (!RESET) { show(); process.exit(0); }

/* ------------------------------------------------------------- بازنشانی */
const admin = db.prepare('SELECT id, username, role FROM admins WHERE username=?').get(RESET);
if (!admin) {
  console.error(`\n  ✗ مدیری با نام کاربری «${RESET}» پیدا نشد.\n`);
  show();
  process.exit(1);
}

const before = db.prepare('SELECT enabled FROM admin_totp WHERE admin_id=?').get(admin.id);
db.prepare('DELETE FROM admin_totp WHERE admin_id=?').run(admin.id);
try { db.prepare('DELETE FROM admin_recovery_codes WHERE admin_id=?').run(admin.id); } catch {}
try { db.prepare('DELETE FROM admin_sessions WHERE admin_id=?').run(admin.id); } catch {}
try { db.prepare('UPDATE admins SET failed_login_count=0 WHERE id=?').run(admin.id); } catch {}

console.log(`
  ✓ تأیید دومرحله‌ای «${admin.username}» بازنشانی شد${before ? ' (قبلاً ' + (before.enabled ? 'فعال' : 'نیمه‌کاره') + ' بود)' : ''}
  ✓ نشست‌های باز بسته شد
  ✓ شمارنده تلاش ناموفق صفر شد

  حالا دوباره وارد پنل شوید:
    ۱) رمز را بزنید
    ۲) صفحه QR باز می‌شود
    ۳) با Google Authenticator اسکن کنید
    ۴) کد ۶ رقمی را وارد کنید
    ۵) کدهای بازیابی را جایی امن ذخیره کنید
`);
show();
