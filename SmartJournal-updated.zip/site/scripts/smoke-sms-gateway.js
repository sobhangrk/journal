/**
 * تست کامل درگاه پیامک — از پنل مدیریت تا ثبت‌نام واقعی کاربر.
 *
 * سناریو:
 *   ۱) وضعیت اولیه: هیچ درگاهی تنظیم نشده ⇒ باید «کار نمی‌کند» گزارش شود
 *   ۲) مدیر از API پنل یک درگاه واقعی اضافه می‌کند (webhook با Bearer token)
 *   ۳) تست ارسال از پنل ⇒ پیام باید واقعاً به درگاه برسد
 *   ۴) کاربر ثبت‌نام می‌کند ⇒ کد باید از همان درگاه ارسال شود
 *   ۵) کاربر همان کد را وارد می‌کند ⇒ حساب ساخته می‌شود
 *   ۶) غیرفعال کردن درگاه ⇒ محافظ «تنها درگاه فعال» باید جلو را بگیرد
 *   ۷) با force غیرفعال شود ⇒ وضعیت دوباره «کار نمی‌کند»
 */
const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const FAKE = 'http://127.0.0.1:4555';
const results = [];
const ok = (name, cond, extra = '') => {
  results.push([cond, name]);
  console.log((cond ? '  ✓ ' : '  ✗ ') + name + (extra ? '  — ' + extra : ''));
};

const jar = [];
const absorb = r => (r.headers.getSetCookie?.() || []).forEach(c => jar.push(c.split(';')[0]));
const cookie = () => jar.join('; ');

async function req(path, { method = 'GET', body, csrf } = {}) {
  const headers = { cookie: cookie() };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (csrf) headers['x-csrf-token'] = csrf;
  const response = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  absorb(response);
  let data = {};
  try { data = await response.json(); } catch {}
  return { status: response.status, data };
}

const inbox = async () => (await fetch(FAKE + '/inbox')).json();

(async () => {
  // ---------- ورود مدیر ----------
  const Database = require('better-sqlite3');
  const bcrypt = require('bcryptjs');
  const db = new Database(process.env.DATABASE_PATH || require('path').join(__dirname, '..', 'data', 'admin.db'));
  const stamp = Date.now().toString(36);
  const adminId = 'adm_sms_' + stamp, username = 'smsadmin' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'admin','active',?,0)`)
    .run(adminId, 'مدیر تست پیامک', username, '093' + String(Date.now()).slice(-8),
         bcrypt.hashSync('SmsAdmin@12345', 10), new Date().toISOString());
  // پاکسازی محدودیت OTP
  ['user_otp_challenges', 'sms_logs'].forEach(t => { try { db.prepare('DELETE FROM ' + t).run(); } catch {} });
  db.prepare("DELETE FROM sms_providers WHERE provider_key LIKE 'test-%'").run();
  db.prepare("UPDATE sms_providers SET is_enabled=0,is_primary=0").run();
  db.close();

  const login = await req('/api/admin/login', { method: 'POST', body: { identifier: username, password: 'SmsAdmin@12345' } });
  const csrf = login.data.csrfToken;
  ok('ورود مدیر به پنل', login.status === 200, 'status=' + login.status);

  // ---------- ۱) وضعیت اولیه ----------
  console.log('\n── ۱) وضعیت وقتی هیچ درگاهی تنظیم نیست ──');
  let st = (await req('/api/admin/sms/status')).data;
  ok('پنل می‌گوید ارسال پیامک کار نمی‌کند', st.ready === false);
  ok('دلیلش را دقیق می‌گوید', (st.problems || []).some(p => p.level === 'critical'),
     (st.problems || []).map(p => p.code).join(','));

  // ---------- ۲) افزودن درگاه واقعی از پنل ----------
  console.log('\n── ۲) مدیر از پنل یک درگاه اضافه می‌کند ──');
  const create = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'generic_webhook',
    name: 'درگاه تست ' + stamp,
    providerKey: 'test-' + stamp,
    priority: 1,
    unitCost: 120,
    isEnabled: true,
    config: { url: FAKE + '/send', sender: '10008663' },
    credentials: { bearerToken: 'TEST-SECRET-KEY' },
  }});
  ok('درگاه ساخته شد', create.status === 201, JSON.stringify(create.data).slice(0, 160));
  const providerId = create.data.id;

  await req(`/api/admin/sms/providers/${providerId}`, { method: 'PATCH', csrf, body: { makePrimary: true } });
  st = (await req('/api/admin/sms/status')).data;
  ok('حالا پنل می‌گوید ارسال فعال است', st.ready === true, 'درگاه: ' + st.activeProvider);

  // ---------- ۳) تست ارسال از پنل ----------
  console.log('\n── ۳) دکمه «تست ارسال واقعی» در پنل ──');
  const before = (await inbox()).length;
  const test = await req('/api/admin/sms/test-otp', { method: 'POST', csrf, body: { mobile: '09121112233' } });
  ok('پنل ارسال را موفق گزارش کرد', test.status === 200 && test.data.ok === true, JSON.stringify(test.data).slice(0, 200));
  const afterTest = await inbox();
  ok('پیام واقعاً به درگاه رسید', afterTest.length === before + 1,
     afterTest.length ? JSON.stringify(afterTest[afterTest.length - 1]).slice(0, 140) : 'inbox خالی');

  // ---------- ۴) ثبت‌نام واقعی کاربر ----------
  console.log('\n── ۴) کاربر واقعی ثبت‌نام می‌کند ──');
  const mobile = '0991' + String(Date.now()).slice(-7);
  const userJar = [];
  const uAbsorb = r => (r.headers.getSetCookie?.() || []).forEach(c => userJar.push(c.split(';')[0]));
  const uReq = async (path, body) => {
    const r = await fetch(BASE + path, { method: 'POST',
      headers: { cookie: userJar.join('; '), 'content-type': 'application/json' }, body: JSON.stringify(body) });
    uAbsorb(r); let d = {}; try { d = await r.json(); } catch {}
    return { status: r.status, data: d };
  };
  const signup = await uReq('/api/auth/signup', {
    name: 'کاربر پیامک', mobile, password: 'SmsUser@12345', remember: true,
    acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false });
  ok('ثبت‌نام پذیرفته شد (۲۰۲)', signup.status === 202, 'status=' + signup.status + ' ' + JSON.stringify(signup.data).slice(0, 140));
  ok('درگاه واقعی استفاده شد (نه حالت توسعه)', signup.data.delivery && !/Development/i.test(signup.data.delivery),
     'delivery=' + signup.data.delivery);
  ok('کد در پاسخ API لو نرفت', signup.data.devCode === undefined);

  const box = await inbox();
  const last = box[box.length - 1] || {};
  ok('پیامک کد برای همان شماره ارسال شد', last.mobile === mobile, 'to=' + last.mobile);
  const code = String(last.code || (String(last.message || '').match(/\d{6}/) || [])[0] || '');
  ok('کد شش‌رقمی داخل متن پیامک هست', /^\d{6}$/.test(code), 'code=' + code + ' | متن: ' + String(last.message || '').slice(0, 60));

  // ---------- ۵) کاربر کد را وارد می‌کند ----------
  console.log('\n── ۵) کاربر همان کد را وارد می‌کند ──');
  const verify = await uReq('/api/auth/signup/verify', { challengeToken: signup.data.challengeToken, code });
  ok('حساب با کد پیامکی ساخته شد', verify.status === 201, 'status=' + verify.status + ' ' + JSON.stringify(verify.data).slice(0, 120));

  const wrong = await uReq('/api/auth/signup/verify', { challengeToken: signup.data.challengeToken, code: '000000' });
  ok('کد اشتباه پذیرفته نمی‌شود', wrong.status >= 400, 'status=' + wrong.status);

  // ---------- ۶) محافظ غیرفعال‌سازی ----------
  console.log('\n── ۶) محافظ «تنها درگاه فعال» ──');
  const disable = await req(`/api/admin/sms/providers/${providerId}/disable`, { method: 'POST', csrf, body: {} });
  ok('جلوی خاموش کردن ناخواسته گرفته شد', disable.status === 409 && disable.data.needsForce === true,
     'status=' + disable.status + ' ' + String(disable.data.error || '').slice(0, 90));

  // ---------- ۷) غیرفعال با تایید ----------
  console.log('\n── ۷) غیرفعال کردن با تایید صریح ──');
  const forced = await req(`/api/admin/sms/providers/${providerId}/disable`, { method: 'POST', csrf, body: { force: true } });
  ok('با force غیرفعال شد', forced.status === 200);
  st = (await req('/api/admin/sms/status')).data;
  ok('وضعیت دوباره «کار نمی‌کند» شد', st.ready === false);

  // ---------- ۸) فعال کردن دوباره + حذف ----------
  console.log('\n── ۸) فعال کردن دوباره و حذف ──');
  const reEnable = await req(`/api/admin/sms/providers/${providerId}/enable`, { method: 'POST', csrf, body: {} });
  ok('دوباره فعال شد', reEnable.status === 200 && reEnable.data.status.ready === true);
  const del = await req(`/api/admin/sms/providers/${providerId}`, { method: 'DELETE', csrf, body: { force: true } });
  ok('درگاه حذف شد', del.status === 200);

  // ---------- ۹) failover ----------
  console.log('\n── ۹) وقتی درگاه اصلی خطا می‌دهد ──');
  const p1 = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'generic_webhook', name: 'اصلی خراب ' + stamp, providerKey: 'test-bad-' + stamp,
    priority: 1, isEnabled: true, config: { url: FAKE + '/send' }, credentials: { bearerToken: 'WRONG-KEY' } } });
  const p2 = await req('/api/admin/sms/providers', { method: 'POST', csrf, body: {
    providerType: 'generic_webhook', name: 'جایگزین سالم ' + stamp, providerKey: 'test-good-' + stamp,
    priority: 2, isEnabled: true, config: { url: FAKE + '/send' }, credentials: { bearerToken: 'TEST-SECRET-KEY' } } });
  await req(`/api/admin/sms/providers/${p1.data.id}`, { method: 'PATCH', csrf, body: { makePrimary: true } });
  const failoverTest = await req('/api/admin/sms/test-otp', { method: 'POST', csrf, body: { mobile: '09121112233' } });
  ok('با وجود خرابی درگاه اصلی، پیام تحویل شد', failoverTest.status === 200 && failoverTest.data.ok === true,
     'مسیر: ' + (failoverTest.data.attempts || []).map(a => `${a.provider}=${a.ok ? 'ok' : 'fail'}`).join(' → '));
  ok('خطای درگاه اول ثبت شد', (failoverTest.data.attempts || []).some(a => !a.ok));

  // پاکسازی
  await req(`/api/admin/sms/providers/${p1.data.id}`, { method: 'DELETE', csrf, body: { force: true } });
  await req(`/api/admin/sms/providers/${p2.data.id}`, { method: 'DELETE', csrf, body: { force: true } });

  const failed = results.filter(r => !r[0]).length;
  console.log(`\n${results.length - failed}/${results.length} آزمون درگاه پیامک پاس شد.`);
  process.exit(failed ? 1 : 0);
})().catch(error => { console.error('\nSMS GATEWAY SMOKE FAILED:', error.stack || error); process.exit(1); });
