'use strict';
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math

W, H = 1080, 1920

# Create RGBA Image
img = Image.new('RGBA', (W, H), (1, 4, 6, 255))
draw = ImageDraw.Draw(img)

# Colors
MINT = (29, 228, 123, 255)
MINT_LIGHT = (45, 213, 120, 255)
MINT_GLOW = (29, 228, 123, 80)
MINT_DIM = (15, 80, 45, 255)
DARK_BG = (5, 15, 19, 255)
CARD_BG = (4, 12, 16, 235)
GRAY_TEXT = (100, 116, 139, 255)
WHITE = (255, 255, 255, 255)

# 1. Background Radial Glows
glow_layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
glow_draw = ImageDraw.Draw(glow_layer)

# Center card glow
for r in range(400, 0, -10):
    alpha = int(60 * (1 - r / 400.0))
    glow_draw.ellipse([W//2 - r, 800 - r, W//2 + r, 800 + r], fill=(29, 228, 123, alpha))

# Floor glow
for r in range(500, 0, -15):
    alpha = int(45 * (1 - r / 500.0))
    glow_draw.ellipse([W//2 - r, 1700 - r//2, W//2 + r, 1700 + r//2], fill=(29, 228, 123, alpha))

img = Image.alpha_composite(img, glow_layer)
draw = ImageDraw.Draw(img)

# 2. Floor Perspective Grid
floor_y_start = 1450
for i in range(-12, 13):
    x_top = W//2 + i * 35
    x_bot = W//2 + i * 110
    draw.line([(x_top, floor_y_start), (x_bot, H)], fill=(29, 228, 123, 25), width=1)

for y in range(floor_y_start, H, 35):
    draw.line([(0, y), (W, y)], fill=(29, 228, 123, 20), width=1)

# 3. Background Candlesticks
# Left Candlesticks
left_candles = [
    (80, 600, 720, 620, 690, True),
    (120, 560, 680, 580, 650, True),
    (160, 520, 630, 540, 600, True)
]
for x, top, bot, ctop, cbot, is_green in left_candles:
    col = (29, 228, 123, 70) if is_green else (220, 50, 50, 70)
    draw.line([(x, top), (x, bot)], fill=col, width=2)
    draw.rectangle([x - 8, ctop, x + 8, cbot], fill=col)

# Right Candlesticks (Ascending Stairs)
right_candles = [
    (920, 880, 1020, 900, 980, True),
    (960, 800, 940, 820, 910, True),
    (1000, 720, 860, 740, 830, True),
    (1040, 640, 780, 660, 750, True)
]
for x, top, bot, ctop, cbot, is_green in right_candles:
    col = (29, 228, 123, 80) if is_green else (220, 50, 50, 80)
    draw.line([(x, top), (x, bot)], fill=col, width=2)
    draw.rectangle([x - 8, ctop, x + 8, cbot], fill=col)

# Fonts
font_bold_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
font_regular_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

try:
    f_title = ImageFont.truetype(font_bold_path, 46)
    f_subtitle = ImageFont.truetype(font_bold_path, 16)
    f_symbol = ImageFont.truetype(font_bold_path, 52)
    f_sym_sub = ImageFont.truetype(font_bold_path, 18)
    f_label = ImageFont.truetype(font_bold_path, 20)
    f_profit = ImageFont.truetype(font_bold_path, 94)
    f_buy = ImageFont.truetype(font_bold_path, 42)
    f_value = ImageFont.truetype(font_bold_path, 46)
    f_unit = ImageFont.truetype(font_bold_path, 26)
    f_handle = ImageFont.truetype(font_bold_path, 24)
    f_footer = ImageFont.truetype(font_bold_path, 34)
    f_domain = ImageFont.truetype(font_bold_path, 22)
except Exception as e:
    print('Font load fallback:', e)
    f_title = f_subtitle = f_symbol = f_sym_sub = f_label = f_profit = f_buy = f_value = f_unit = f_handle = f_footer = f_domain = ImageFont.load_default()

# 4. Top Header Branding
# Green S Logo
s_cx, s_cy = W//2, 100
draw.polygon([(s_cx - 20, s_cy - 25), (s_cx + 15, s_cy - 25), (s_cx + 25, s_cy - 12), (s_cx - 5, s_cy - 2), (s_cx - 20, s_cy + 5)], fill=MINT)
draw.polygon([(s_cx + 20, s_cy + 25), (s_cx - 15, s_cy + 25), (s_cx - 25, s_cy + 12), (s_cx + 5, s_cy + 2), (s_cx + 20, s_cy - 5)], fill=MINT)

# Header Title Text
draw.text((W//2, 150), "SmartJournal", font=f_title, fill=WHITE, anchor="mm")
draw.text((W//2, 190), "T R A D I N G   J O U R N A L", font=f_subtitle, fill=GRAY_TEXT, anchor="mm")

# 5. Central Glassmorphism Card
card_x1, card_y1, card_x2, card_y2 = 180, 260, 900, 1380
card_w = card_x2 - card_x1
card_h = card_y2 - card_y1

# Card Shadow & Glow
card_shadow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
cs_draw = ImageDraw.Draw(card_shadow)
cs_draw.rounded_rectangle([card_x1 - 10, card_y1 - 10, card_x2 + 10, card_y2 + 10], radius=50, fill=(0, 0, 0, 180))
cs_draw.rounded_rectangle([card_x1, card_y1, card_x2, card_y2], radius=44, outline=(29, 228, 123, 140), width=4)
card_shadow = card_shadow.filter(ImageFilter.GaussianBlur(15))
img = Image.alpha_composite(img, card_shadow)
draw = ImageDraw.Draw(img)

# Main Card Body
draw.rounded_rectangle([card_x1, card_y1, card_x2, card_y2], radius=44, fill=CARD_BG, outline=MINT, width=3)

# Top Gloss Reflection
draw.rounded_rectangle([card_x1 + 4, card_y1 + 4, card_x2 - 4, card_y1 + 100], radius=40, fill=(255, 255, 255, 8))

# Inside Card Elements
inner_x = card_x1 + 50
inner_y = card_y1 + 50
inner_w = card_w - 100

# 6. Symbol Header
badge_cx, badge_cy = inner_x + 50, inner_y + 50
draw.ellipse([badge_cx - 48, badge_cy - 48, badge_cx + 48, badge_cy + 48], fill=(13, 31, 24, 255), outline=(212, 175, 55, 255), width=2)

# Gold Bars Stack Icon (3D)
draw.polygon([(badge_cx - 20, badge_cy + 5), (badge_cx, badge_cy - 10), (badge_cx + 20, badge_cy + 5), (badge_cx, badge_cy + 20)], fill=(255, 215, 0))
draw.polygon([(badge_cx - 20, badge_cy + 5), (badge_cx, badge_cy + 20), (badge_cx, badge_cy + 30), (badge_cx - 20, badge_cy + 15)], fill=(212, 175, 55))
draw.polygon([(badge_cx, badge_cy + 20), (badge_cx + 20, badge_cy + 5), (badge_cx + 20, badge_cy + 15), (badge_cx, badge_cy + 30)], fill=(184, 134, 11))

draw.polygon([(badge_cx - 5, badge_cy - 10), (badge_cx + 15, badge_cy - 25), (badge_cx + 35, badge_cy - 10), (badge_cx + 15, badge_cy + 5)], fill=(255, 224, 102))
draw.polygon([(badge_cx - 5, badge_cy - 10), (badge_cx + 15, badge_cy + 5), (badge_cx + 15, badge_cy + 15), (badge_cx - 5, badge_cy)], fill=(230, 184, 0))
draw.polygon([(badge_cx + 15, badge_cy + 5), (badge_cx + 35, badge_cy - 10), (badge_cx + 35, badge_cy), (badge_cx + 15, badge_cy + 15)], fill=(199, 156, 0))

# Symbol Text
draw.text((inner_x + 120, inner_y + 20), "XAUUSD", font=f_symbol, fill=WHITE)
draw.text((inner_x + 120, inner_y + 78), "GOLD / U.S. DOLLAR", font=f_sym_sub, fill=GRAY_TEXT)

# Horizontal Line
draw.line([(inner_x, inner_y + 130), (inner_x + inner_w, inner_y + 130)], fill=(255, 255, 255, 20), width=1)

# 7. Profit Section
cur_y = inner_y + 170
draw.text((inner_x, cur_y), "PROFIT", font=f_label, fill=GRAY_TEXT)

cur_y += 40
draw.text((inner_x, cur_y), "+$68.17", font=f_profit, fill=MINT)

cur_y += 120
# Sparkline
spark_pts = [
    (inner_x, cur_y + 40),
    (inner_x + 100, cur_y + 50),
    (inner_x + 200, cur_y + 35),
    (inner_x + 300, cur_y + 45),
    (inner_x + 400, cur_y + 20),
    (inner_x + 500, cur_y + 30),
    (inner_x + inner_w, cur_y - 30)
]
for i in range(len(spark_pts) - 1):
    draw.line([spark_pts[i], spark_pts[i+1]], fill=MINT, width=4)

# Glowing Orb at Sparkline End
end_x, end_y = spark_pts[-1]
for r in range(25, 0, -3):
    alpha = int(120 * (1 - r / 25.0))
    draw.ellipse([end_x - r, end_y - r, end_x + r, end_y + r], fill=(29, 228, 123, alpha))
draw.ellipse([end_x - 6, end_y - 6, end_x + 6, end_y + 6], fill=WHITE)

# 8. BUY Badge
cur_y += 80
buy_w, buy_h = inner_w, 96
draw.rounded_rectangle([inner_x, cur_y, inner_x + buy_w, cur_y + buy_h], radius=24, fill=(5, 36, 22, 230), outline=(29, 228, 123, 120), width=2)

# Double Up Chevrons Icon + BUY
chevron_x = inner_x + buy_w//2 - 60
chevron_y = cur_y + buy_h//2
# Double Chevron Lines
draw.line([(chevron_x - 18, chevron_y + 8), (chevron_x, chevron_y - 10), (chevron_x + 18, chevron_y + 8)], fill=MINT, width=5)
draw.line([(chevron_x - 18, chevron_y + 18), (chevron_x, chevron_y), (chevron_x + 18, chevron_y + 18)], fill=MINT, width=5)

draw.text((inner_x + buy_w//2 + 30, cur_y + buy_h//2), "BUY", font=f_buy, fill=MINT, anchor="mm")

# 9. 2x2 Grid Container
cur_y += 130
grid_h = 360
draw.rounded_rectangle([inner_x, cur_y, inner_x + inner_w, cur_y + grid_h], radius=28, fill=(6, 16, 20, 200), outline=(255, 255, 255, 15), width=1)

mid_x = inner_x + inner_w // 2
mid_y = cur_y + grid_h // 2
draw.line([(mid_x, cur_y + 20), (mid_x, cur_y + grid_h - 20)], fill=(255, 255, 255, 15), width=1)
draw.line([(inner_x + 20, mid_y), (inner_x + inner_w - 20, mid_y)], fill=(255, 255, 255, 15), width=1)

# Cell 1: VOLUME
draw.text((inner_x + 40, cur_y + 35), "VOLUME", font=f_label, fill=GRAY_TEXT)
draw.text((inner_x + 40, cur_y + 90), "0.17", font=f_value, fill=MINT)
draw.text((inner_x + 150, cur_y + 105), "LOT", font=f_unit, fill=GRAY_TEXT)

# Cell 2: RISK
draw.text((mid_x + 40, cur_y + 35), "RISK", font=f_label, fill=GRAY_TEXT)
draw.text((mid_x + 40, cur_y + 90), "1%", font=f_value, fill=MINT)

# Cell 3: TIMEFRAME
draw.text((inner_x + 40, mid_y + 35), "TIMEFRAME", font=f_label, fill=GRAY_TEXT)
draw.text((inner_x + 40, mid_y + 90), "15M", font=f_value, fill=MINT)

# Cell 4: Clock Dial Icon
clock_cx, clock_cy = mid_x + 160, mid_y + 90
draw.ellipse([clock_cx - 36, clock_cy - 36, clock_cx + 36, clock_cy + 36], outline=MINT, width=3)
draw.ellipse([clock_cx - 4, clock_cy - 4, clock_cx + 4, clock_cy + 4], fill=WHITE)
# Clock Hands pointing to 10:10
draw.line([(clock_cx, clock_cy), (clock_cx - 12, clock_cy - 16)], fill=MINT, width=3)
draw.line([(clock_cx, clock_cy), (clock_cx + 18, clock_cy - 10)], fill=MINT, width=3)

# 10. Handle Badge Below Card
handle_y = card_y2 + 80
handle_w, handle_h = 320, 64
handle_x = W//2 - handle_w//2

draw.rounded_rectangle([handle_x, handle_y, handle_x + handle_w, handle_y + handle_h], radius=32, fill=(7, 18, 23, 230), outline=(29, 228, 123, 80), width=1)

# User silhouette icon + @trader_pro
u_cx, u_cy = handle_x + 70, handle_y + handle_h//2
draw.ellipse([u_cx - 10, u_cy - 14, u_cx + 10, u_cy + 6], outline=WHITE, width=2)
draw.arc([u_cx - 18, u_cy + 2, u_cx + 18, u_cy + 22], start=180, end=360, fill=WHITE, width=2)

draw.text((handle_x + 180, handle_y + handle_h//2), "@trader_pro", font=f_handle, fill=WHITE, anchor="mm")

# Tiny Glowing Mint Dot
dot_y = handle_y + 100
for r in range(12, 0, -2):
    alpha = int(180 * (1 - r / 12.0))
    draw.ellipse([W//2 - r, dot_y - r, W//2 + r, dot_y + r], fill=(29, 228, 123, alpha))
draw.ellipse([W//2 - 3, dot_y - 3, W//2 + 3, dot_y + 3], fill=WHITE)

# 11. Footer Branding
footer_y = H - 120
s_cx, s_cy = W//2 - 120, footer_y
draw.polygon([(s_cx - 12, s_cy - 15), (s_cx + 8, s_cy - 15), (s_cx + 15, s_cy - 7), (s_cx - 3, s_cy - 1), (s_cx - 12, s_cy + 3)], fill=MINT)
draw.polygon([(s_cx + 12, s_cy + 15), (s_cx - 8, s_cy + 15), (s_cx - 15, s_cy + 7), (s_cx + 3, s_cy + 1), (s_cx + 12, s_cy - 3)], fill=MINT)

draw.text((W//2 + 10, footer_y), "SmartJournal", font=f_footer, fill=WHITE, anchor="mm")

# Globe Icon + smarttradejournal.ir
globe_y = footer_y + 45
g_cx = W//2 - 140
draw.ellipse([g_cx - 12, globe_y - 12, g_cx + 12, globe_y + 12], outline=MINT, width=2)
draw.line([(g_cx - 12, globe_y), (g_cx + 12, globe_y)], fill=MINT, width=1)
draw.ellipse([g_cx - 6, globe_y - 12, g_cx + 6, globe_y + 12], outline=MINT, width=1)

draw.text((W//2 + 10, globe_y), "smarttradejournal.ir", font=f_domain, fill=MINT, anchor="mm")

# Save PNG
img.save('/home/user/smartjournal-story-card.png', 'PNG')
print('Successfully generated pixel-perfect /home/user/smartjournal-story-card.png')
