/* ==========================================================================
   sms-alert.js — ارسال پیامک هشدار برای مدیر (مستقل از سرور)
   --------------------------------------------------------------------------
   دیده‌بان خودکار بیرون از فرایند سرور اجرا می‌شود، برای همین نمی‌تواند از
   توابع داخلی server.js استفاده کند. این ماژول دقیقاً همان منطق ارسال
   «deliverWithProvider» را تکرار می‌کند (ملی‌پیامک SendSMS ساده + کاوه‌نگار +
   ثبت در sms_logs) تا رفتار یکی باشد و چیزی دور زده نشود.
   ========================================================================== */
'use strict';
const crypto = require('crypto');

function encryptionKey() {
  const secret = String(process.env.APP_ENCRYPTION_SECRET || '');
  return crypto.createHash('sha256').update(secret).digest();
}

function decryptSecret(value) {
  if (!value) return null;
  try {
    const raw = Buffer.from(value, 'base64url');
    const iv = raw.subarray(0, 12), tag = raw.subarray(12, 28), encrypted = raw.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey(), iv);
    decipher.setAuthTag(tag);
    return JSON.parse(Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8'));
  } catch { return null; }
}

function melipayamakRoot(url) {
  let root = String(url || '').trim().replace(/\/+$/, '');
  if (!root) root = 'https://rest.payamak-panel.com/api/SendSMS';
  root = root.replace(/\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i, '')
             .replace(/\/SendSMS\/SendSMS$/i, '/SendSMS');
  return root;
}

function melipayamakError(value, result) {
  const map = { '0': 'نام کاربری یا رمز اشتباه', '2': 'اعتبار کافی نیست', '3': 'محدودیت ارسال روزانه', '5': 'شماره فرستنده معتبر نیست', '9': 'ارسال با خط خدماتی نیاز به الگو دارد', '10': 'کاربر غیرفعال', '11': 'پیام ارسال نشد', '12': 'مدارک حساب کامل نیست', '16': 'گیرنده یافت نشد', '17': 'متن خالی', '18': 'گیرنده نامعتبر', '19': 'محدودیت ساعتی', '35': 'گیرنده در لیست سیاه', '-108': 'IP مسدود', '-109': 'IP در فهرست مجاز نیست', '-110': 'باید API Key بدهید', '-111': 'IP نامعتبر' };
  return `ملی‌پیامک: ${map[String(value)] || result?.StrRetStatus || `کد ${value}`}`;
}

async function deliverWith(provider, mobile, message) {
  const credentials = decryptSecret(provider.credentials_encrypted);
  let config = {};
  try { config = JSON.parse(provider.config_json || '{}') || {}; } catch {}
  if (!credentials) throw new Error('اطلاعات اتصال ارائه‌دهنده تنظیم نشده است.');
  const timeout = AbortSignal.timeout(10000);
  if (provider.provider_type === 'kavenegar') {
    const params = new URLSearchParams({ receptor: mobile, message, ...(config.sender ? { sender: config.sender } : {}) });
    const response = await fetch(`https://api.kavenegar.com/v1/${encodeURIComponent(credentials.apiKey)}/sms/send.json`, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: params, signal: timeout });
    if (!response.ok) throw new Error(`KAVENEGAR_${response.status}`);
    return await response.json();
  }
  if (provider.provider_type === 'melipayamak') {
    const base = melipayamakRoot(config.url);
    const secret = credentials.password || credentials.apiKey || '';
    const payload = { username: credentials.username, password: secret, to: mobile, from: config.sender || '', text: message, isFlash: false };
    const response = await fetch(`${base}/SendSMS`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload), signal: timeout });
    if (!response.ok) throw new Error(`ملی‌پیامک پاسخ HTTP ${response.status} داد`);
    const result = await response.json();
    const value = String(result?.Value ?? result?.value ?? '');
    if (Number(result?.RetStatus) === 1 && /^\d{15,}$/.test(value)) return result;
    throw new Error(melipayamakError(value, result));
  }
  if (provider.provider_type === 'development') return { development: true };
  throw new Error('نوع ارائه‌دهنده پشتیبانی نمی‌شود.');
}

/**
 * ارسال پیامک هشدار به شمارهٔ مدیر. تلاش روی همهٔ درگاه‌های فعال، ثبت در sms_logs.
 * برمی‌گرداند: { ok, provider?, error? }
 */
async function sendAlert(db, phone, message, type = 'watchdog') {
  const providers = db.prepare("SELECT * FROM sms_providers WHERE is_enabled=1 AND provider_type!='development' ORDER BY is_primary DESC, CASE status WHEN 'healthy' THEN 0 WHEN 'degraded' THEN 1 ELSE 2 END, priority").all();
  if (!providers.length) return { ok: false, error: 'هیچ درگاه پیامکی واقعی فعال نیست.' };
  let lastError = null;
  for (const provider of providers) {
    if (!provider.credentials_encrypted) continue;
    try {
      await deliverWith(provider, phone, message);
      db.prepare(`INSERT INTO sms_logs (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at) VALUES (?,NULL,?,?, 'sent',?,?,NULL,NULL,0,NULL,?)`)
        .run(`sms_${crypto.randomUUID()}`, phone, type, provider.name, Number(provider.unit_cost || 0), new Date().toISOString());
      return { ok: true, provider: provider.name };
    } catch (error) {
      lastError = error;
      db.prepare(`INSERT INTO sms_logs (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at) VALUES (?,NULL,?,?, 'failed',?,?,?,NULL,0,NULL,?)`)
        .run(`sms_${crypto.randomUUID()}`, phone, type, provider.name, 0, String(error.message || error).slice(0, 120), new Date().toISOString());
    }
  }
  return { ok: false, error: String(lastError && lastError.message || lastError) };
}

module.exports = { sendAlert, decryptSecret, encryptionKey };
