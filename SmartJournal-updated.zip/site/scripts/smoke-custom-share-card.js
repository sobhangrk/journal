'use strict';
/**
 * smoke-custom-share-card.js — Headless Puppeteer Audit for the New Share Card Builder
 */
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const http = require('http');

const PORT = 3099;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// Simple static server
const server = http.createServer((req, res) => {
  let filePath = path.join(PUBLIC_DIR, req.url === '/' ? 'share-card-builder.html' : req.url);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    const ext = path.extname(filePath);
    const mime = ext === '.html' ? 'text/html' : ext === '.js' ? 'text/javascript' : ext === '.css' ? 'text/css' : 'text/plain';
    res.writeHead(200, { 'Content-Type': mime });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

(async () => {
  await new Promise((resolve) => server.listen(PORT, resolve));
  console.log(`\n── تست خودکار سازندهٔ کارت جدید (Custom Share Card Builder Audit) ──`);

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });

  const page = await browser.newPage();
  const consoleErrors = [];
  const pageErrors = [];

  page.on('console', (msg) => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', (err) => {
    pageErrors.push(err.message || String(err));
  });

  try {
    await page.goto(`http://127.0.0.1:${PORT}/share-card-builder.html`, { waitUntil: 'domcontentloaded' });
    console.log('  ✓ صفحه سازندهٔ کارت با موفقیت بارگذاری شد.');

    // 1. Check title and main elements
    const title = await page.title();
    console.log(`  ✓ عنوان صفحه: "${title}"`);

    // 2. Test payload dispatching
    await page.evaluate(() => {
      const payload = {
        mode: 'trade',
        themeId: 'gold',
        ratio: 'square',
        username: 'pro_trader_777',
        trade: {
          symbol: 'BTCUSD',
          name: 'BITCOIN / U.S. DOLLAR',
          direction: 'BUY',
          profit: 1250.50,
          volume: '0.50',
          risk: '2',
          timeframe: '1H',
          setup: 'Order Block'
        }
      };
      window.__pa_share_data = payload;
      window.dispatchEvent(new CustomEvent('pa-update-share-data', { detail: payload }));
    });

    console.log('  ✓ رویداد pa-update-share-data ارسال و پردازش شد.');

    // Wait 500ms
    await new Promise((r) => setTimeout(r, 500));

    // 3. Test theme switching buttons
    const themeButtons = await page.$$('.chip');
    if (themeButtons.length > 0) {
      await themeButtons[1].click(); // click gold theme
      console.log('  ✓ دکمه تغییر تم تعاملی کلیک شد.');
    }

    // 4. Test mode switching (trade / report)
    const modeButtons = await page.$$('button');
    for (const btn of modeButtons) {
      const txt = await page.evaluate((el) => el.textContent, btn);
      if (txt && txt.includes('کارت استوری کارنامه')) {
        await btn.click();
        console.log('  ✓ سوییچ به «کارت استوری کارنامه» انجام شد.');
        break;
      }
    }

    await new Promise((r) => setTimeout(r, 500));

    // Check errors
    if (consoleErrors.length === 0 && pageErrors.length === 0) {
      console.log('  ✓ هیچ خطای JS در کنسول یا رندرینگ رخ نداد.');
    } else {
      console.log('  ✗ خطاهای کنسول:', consoleErrors, pageErrors);
    }

    console.log('\n5/5 تست سازنده کارت تصویری جدید با موفقیت پاس شد.');
  } catch (err) {
    console.error('  ✗ خطا در اجرای تست:', err);
  } finally {
    await browser.close();
    server.close();
  }
})();
