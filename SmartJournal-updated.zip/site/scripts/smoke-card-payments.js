'use strict';
/* ==========================================================================
   آزمون یکپارچه پرداخت کارت‌به‌کارت روی Backend واقعی
   کارت بانکی → ثبت فیش توسط کاربر → تایید مدیر → اشتراک و پرداخت واقعی
   الگوی fixture/cleanup مطابق سایر smokeهای پروژه.
   ========================================================================== */

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const BASE = process.env.SMOKE_BASE_URL || 'http://127.0.0.1:3000';
const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '../data/admin.db');
const db = new Database(DB_PATH);

const stamp = String(Date.now());
const fixture = {
  start: new Date().toISOString(),
  ownerId: 'adm_ctc_owner_' + stamp,
  ownerUser: 'ctcowner_' + stamp.slice(-7),
  ownerMobile: '093' + stamp.slice(-8),
  financeId: 'adm_ctc_fin_' + stamp,
  financeUser: 'ctcfin_' + stamp.slice(-7),
  financeMobile: '094' + stamp.slice(-8),
  userMobile: '096' + stamp.slice(-8),
  userId: null,
  cardIds: [],
  receiptIds: [],
};


/* a unique, Luhn-valid card number per run so repeats never collide */
function luhnComplete(prefix15) {
  for (let d = 0; d <= 9; d += 1) {
    const candidate = prefix15 + String(d);
    let sum = 0;
    for (let i = 0; i < 16; i += 1) {
      let v = Number(candidate[15 - i]);
      if (i % 2 === 1) { v *= 2; if (v > 9) v -= 9; }
      sum += v;
    }
    if (sum % 10 === 0) return candidate;
  }
  throw new Error('luhn');
}
const CARD = luhnComplete(('610433' + stamp).slice(0, 15));
const CARD_BAD = CARD.slice(0, 15) + String((Number(CARD[15]) + 1) % 10);

let passed = 0;
const ok = (name) => { passed += 1; console.log('✓ ' + name); };

function cookies(response) {
  const values = typeof response.headers.getSetCookie === 'function'
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')].filter(Boolean);
  return values.flatMap((v) => String(v).split(/,(?=\s*[^;,]+=)/))
    .map((v) => v.trim().split(';')[0]).join('; ');
}

async function request(url, { method = 'GET', body, cookie, csrf, status = 200, userAgent = 'PA Card Payments Smoke' } = {}) {
  const headers = { 'user-agent': userAgent };
  if (cookie) headers.cookie = cookie;
  if (body !== undefined) {
    headers['content-type'] = 'application/json';
    if (csrf) headers['x-csrf-token'] = csrf;
  }
  const response = await fetch(BASE + url, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  assert.equal(response.status, status, `${method} ${url}: ${response.status} ${JSON.stringify(data)}`);
  return { response, data };
}

function base32Decode(value) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const ch of String(value).replace(/=+$/, '').toUpperCase()) {
    bits += chars.indexOf(ch).toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

function totp(secret, stepOffset = 0) {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 30000) + stepOffset));
  const digest = crypto.createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 15;
  return String((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(6, '0');
}

function cleanup() {
  try {
    db.pragma('foreign_keys = OFF');
    if (fixture.userId) {
      for (const table of ['payment_receipts', 'payments', 'subscriptions', 'user_sessions',
        'user_trusted_devices', 'user_security_events', 'user_otp_challenges',
        'user_activity_logs', 'user_contacts', 'user_legal_acceptances',
        'journal_preferences', 'journal_sync_versions', 'sms_logs']) {
        try { db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(fixture.userId); } catch {}
      }
      db.prepare('DELETE FROM users WHERE id=?').run(fixture.userId);
    }
    for (const id of fixture.cardIds) {
      try { db.prepare('DELETE FROM bank_cards WHERE id=?').run(id); } catch {}
    }
    for (const adminId of [fixture.ownerId, fixture.financeId]) {
      for (const table of ['admin_sessions', 'admin_totp', 'admin_passkeys',
        'admin_recovery_codes', 'admin_auth_challenges']) {
        try { db.prepare(`DELETE FROM ${table} WHERE admin_id=?`).run(adminId); } catch {}
      }
      db.prepare('DELETE FROM admins WHERE id=?').run(adminId);
    }
    db.prepare('DELETE FROM audit_logs WHERE created_at>=?').run(fixture.start);
  } finally { db.close(); }
}

(async () => {
  /* --------------------------------------------------- fixtures in DB --- */
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'owner','active',?,1)`)
    .run(fixture.ownerId, 'Owner آزمون کارت', fixture.ownerUser, fixture.ownerMobile,
         bcrypt.hashSync('OwnerCtc@12345', 10), fixture.start);
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'finance','active',?,0)`)
    .run(fixture.financeId, 'مدیر مالی آزمون', fixture.financeUser, fixture.financeMobile,
         bcrypt.hashSync('FinanceCtc@12345', 10), fixture.start);

  /* ------------------------------------------------------ admin + MFA --- */
  const login = await request('/api/admin/login', {
    method: 'POST', body: { identifier: fixture.ownerUser, password: 'OwnerCtc@12345' },
  });
  let admin = { cookie: cookies(login.response), csrf: login.data.csrfToken };
  ok('ورود مدیر با رمز واقعی (bcrypt)');

  await request('/api/admin/bank-cards', { cookie: admin.cookie, status: 403 });
  ok('Owner بدون MFA حتی به کارت‌های بانکی دسترسی ندارد (fail-closed)');

  const setup = await request('/api/admin/mfa/totp/setup', {
    method: 'POST', body: {}, cookie: admin.cookie, csrf: admin.csrf,
  });
  await request('/api/admin/mfa/totp/verify', {
    method: 'POST', body: { code: totp(setup.data.secret) }, cookie: admin.cookie, csrf: admin.csrf,
  });
  ok('فعال‌سازی TOTP و عبور از MFA اجباری');

  /* ----------------------------------------------------- bank cards ----- */
  const card = await request('/api/admin/bank-cards', {
    method: 'POST', cookie: admin.cookie, csrf: admin.csrf, status: 201,
    body: { bankName: 'بانک ملت', holder: 'شرکت اسمارت ژورنال', cardNumber: CARD.replace(/(.{4})(?=.)/g, '$1-') },
  });
  fixture.cardIds.push(card.data.row.id);
  assert.equal(card.data.row.card_number, CARD);
  ok('افزودن کارت بانکی معتبر (جداکننده‌ها پاک می‌شوند)');

  await request('/api/admin/bank-cards', {
    method: 'POST', cookie: admin.cookie, csrf: admin.csrf, status: 400,
    body: { bankName: 'غلط', cardNumber: CARD_BAD },
  });
  ok('رد شماره کارت با یک رقم اشتباه (کنترل Luhn)');

  await request('/api/admin/bank-cards', {
    method: 'POST', cookie: admin.cookie, csrf: admin.csrf, status: 409,
    body: { bankName: 'تکراری', cardNumber: CARD },
  });
  ok('جلوگیری از ثبت کارت تکراری');

  await request('/api/admin/bank-cards', {
    method: 'POST', cookie: admin.cookie, status: 403,
    body: { bankName: 'بدون CSRF', cardNumber: '6219861234567898' },
  });
  ok('درخواست بدون توکن CSRF رد شد');

  /* ---------------------------------------------------------- user ------ */
  const signup = await request('/api/auth/signup', {
    method: 'POST', status: 202, userAgent: 'PA Card Signup Device',
    body: {
      name: 'سارا محمدی', mobile: fixture.userMobile, password: 'UserCtc@12345',
      remember: true, acceptTerms: true, acceptPrivacy: true, acceptDisclaimer: true, marketingConsent: false,
    },
  });
  const verified = await request('/api/auth/signup/verify', {
    method: 'POST', status: 201, userAgent: 'PA Card Signup Device',
    body: { challengeToken: signup.data.challengeToken, code: signup.data.devCode },
  });
  fixture.userId = verified.data.user.id;
  const user = { cookie: cookies(verified.response), csrf: verified.data.csrfToken };
  ok('ثبت‌نام واقعی کاربر با تأیید OTP موبایل');

  const visible = await request('/api/billing/bank-cards', { cookie: user.cookie });
  assert.ok(visible.data.rows.length >= 1);
  assert.equal(visible.data.rows.find(r => r.id === fixture.cardIds[0]).card_number, CARD);
  ok('کاربر شماره کارت را برای واریز می‌بیند');

  await request('/api/billing/bank-cards', { status: 401 });
  ok('کاربر ناشناس شماره کارت را نمی‌بیند');

  /* ------------------------------------------------------- receipts ----- */
  const plans = await request('/api/public/plans');
  const paidPlan = plans.data.rows.find((p) => Number(p.price_monthly) > 0);
  const png = 'iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNk+M9Qz0AEYBxVSF+FABJADveWkH6oAAAAAElFTkSuQmCC';
  const receiptData = `data:image/png;base64,${png}`;

  const submitted = await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: {
      planId: paidPlan.id, bankCardId: fixture.cardIds[0],
      trackingCode: '۲۵۴۸۹۱۷۳۶', note: 'واریز از کارت همسرم', receipt: receiptData,
    },
  });
  fixture.receiptIds.push(submitted.data.id);
  ok('ثبت فیش با کد پیگیری فارسی (ارقام خودکار تبدیل شد)');

  await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 409,
    body: { planId: paidPlan.id, trackingCode: '254891736', receipt: receiptData },
  });
  ok('جلوگیری از ثبت کد پیگیری تکراری');

  await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 400,
    body: { planId: paidPlan.id, trackingCode: '77712', receipt: 'data:image/png;base64,SGVsbG8gd29ybGQ=' },
  });
  ok('رد فایلی که ادعای PNG دارد ولی PNG نیست (تشخیص MIME از بایت‌ها)');

  await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 400,
    body: { planId: paidPlan.id, trackingCode: '', receipt: receiptData },
  });
  ok('کد پیگیری اجباری است');

  const mine = await request('/api/billing/receipts', { cookie: user.cookie });
  assert.equal(mine.data.rows[0].status, 'pending');
  ok('کاربر وضعیت «در انتظار بررسی» را می‌بیند');

  /* --------------------------------------------------- receipt privacy -- */
  await request(`/api/admin/receipts/${submitted.data.id}/image`, { status: 401 });
  ok('دسترسی ناشناس به تصویر فیش مسدود است');

  const financeLogin = await request('/api/admin/login', {
    method: 'POST', body: { identifier: fixture.financeUser, password: 'FinanceCtc@12345' },
  });
  const finance = { cookie: cookies(financeLogin.response), csrf: financeLogin.data.csrfToken };
  const financeList = await request('/api/admin/receipts?status=pending', { cookie: finance.cookie });
  assert.ok(financeList.data.rows.length >= 1);
  assert.match(financeList.data.rows.find(r => r.id === submitted.data.id).card_number, /••••/);
  ok('نقش مالی فیش را می‌بیند و شماره کارت ماسک شده است');

  /* ---------------------------------------------------------- approve --- */
  const before = db.prepare('SELECT COUNT(*) c FROM payments').get().c;
  const approved = await request(`/api/admin/receipts/${submitted.data.id}/approve`, {
    method: 'POST', cookie: finance.cookie, csrf: finance.csrf,
    body: { days: 30, note: 'با تشکر، اشتراک فعال شد.' },
  });
  assert.equal(approved.data.days, 30);
  assert.match(approved.data.invoice, /^INV-CTC-/);
  ok(`تایید فیش → اشتراک تا ${String(approved.data.expiresAt).slice(0, 10)} و فاکتور ${approved.data.invoice}`);

  await request(`/api/admin/receipts/${submitted.data.id}/approve`, {
    method: 'POST', cookie: finance.cookie, csrf: finance.csrf, body: {}, status: 409,
  });
  ok('جلوگیری از تایید دوباره (پرداخت تکراری ساخته نمی‌شود)');

  assert.equal(db.prepare('SELECT COUNT(*) c FROM payments').get().c, before + 1);
  const payment = db.prepare('SELECT * FROM payments WHERE invoice_number=?').get(approved.data.invoice);
  assert.equal(payment.status, 'paid');
  assert.equal(payment.provider, 'card_to_card');
  assert.equal(payment.tracking_code, '254891736');
  assert.equal(payment.user_id, fixture.userId);
  ok('یک پرداخت رسمی paid با provider=card_to_card در جدول payments ثبت شد');

  const sub = db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(fixture.userId);
  assert.equal(sub.status, 'active');
  assert.equal(sub.plan_id, paidPlan.id);
  assert.ok(new Date(sub.expires_at) > new Date());
  ok('اشتراک واقعی کاربر در جدول subscriptions فعال شد');

  const ent = await request('/api/journal/entitlements', { cookie: user.cookie });
  const planName = ent.data.plan?.name || ent.data.planName || ent.data.plan;
  assert.equal(String(planName), String(paidPlan.name));
  ok('entitlement ژورنال کاربر به پلن پولی ارتقا یافت');

  const afterUser = await request('/api/billing/receipts', { cookie: user.cookie });
  assert.equal(afterUser.data.rows[0].status, 'approved');
  assert.equal(afterUser.data.rows[0].granted_days, 30);
  ok('کاربر وضعیت «تایید شده» و مدت اعتبار را می‌بیند');

  /* ------------------------------------------------ renewal stacking ---- */
  const second = await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: { planId: paidPlan.id, bankCardId: fixture.cardIds[0], trackingCode: '778899', receipt: receiptData },
  });
  const firstExpiry = new Date(sub.expires_at);
  const renewed = await request(`/api/admin/receipts/${second.data.id}/approve`, {
    method: 'POST', cookie: finance.cookie, csrf: finance.csrf, body: { days: 30 },
  });
  const gap = (new Date(renewed.data.expiresAt) - firstExpiry) / 86400000;
  assert.ok(gap > 29 && gap < 31, `expected +30 days on top, got ${gap}`);
  ok('تمدید به انتهای اعتبار قبلی اضافه شد، نه از امروز');

  /* ------------------------------------------------------------ RBAC --- */
  const supportId = 'adm_ctc_sup_' + stamp;
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,'support','active',?,0)`)
    .run(supportId, 'پشتیبان آزمون', 'ctcsup_' + stamp.slice(-7), '095' + stamp.slice(-8),
         bcrypt.hashSync('SupportCtc@12345', 10), fixture.start);
  const supLogin = await request('/api/admin/login', {
    method: 'POST', body: { identifier: 'ctcsup_' + stamp.slice(-7), password: 'SupportCtc@12345' },
  });
  const support = { cookie: cookies(supLogin.response), csrf: supLogin.data.csrfToken };
  await request('/api/admin/receipts', { cookie: support.cookie, status: 403 });
  ok('نقش پشتیبانی به فیش‌های مالی دسترسی ندارد (RBAC)');
  await request(`/api/admin/receipts/${second.data.id}/approve`, {
    method: 'POST', cookie: support.cookie, csrf: support.csrf, body: {}, status: 403,
  });
  ok('نقش پشتیبانی نمی‌تواند فیش را تایید کند');
  for (const table of ['admin_sessions', 'admin_auth_challenges']) {
    try { db.prepare(`DELETE FROM ${table} WHERE admin_id=?`).run(supportId); } catch {}
  }
  db.prepare('DELETE FROM admins WHERE id=?').run(supportId);

  /* ----------------------------------------------------------- reject --- */
  const third = await request('/api/billing/receipts', {
    method: 'POST', cookie: user.cookie, csrf: user.csrf, status: 201,
    body: { planId: paidPlan.id, bankCardId: fixture.cardIds[0], trackingCode: '556677', receipt: receiptData },
  });
  await request(`/api/admin/receipts/${third.data.id}/reject`, {
    method: 'POST', cookie: finance.cookie, csrf: finance.csrf,
    body: { note: 'کد پیگیری در سامانه بانک یافت نشد.' },
  });
  const rejected = await request('/api/billing/receipts', { cookie: user.cookie });
  const rejectedRow = rejected.data.rows.find((r) => r.id === third.data.id);
  assert.equal(rejectedRow.status, 'rejected');
  assert.match(rejectedRow.admin_note, /یافت نشد/);
  ok('رد فیش با دلیل، و نمایش دلیل به کاربر');

  await request(`/api/admin/receipts/${submitted.data.id}/reject`, {
    method: 'POST', cookie: finance.cookie, csrf: finance.csrf, body: {}, status: 409,
  });
  ok('فیش تاییدشده را نمی‌توان بی‌سروصدا رد کرد');

  /* ------------------------------------------------------ audit trail --- */
  const audit = await request('/api/admin/audit', { cookie: admin.cookie });
  const actions = (audit.data.rows || []).map((row) => row.action);
  for (const needed of ['BANK_CARD_CREATED', 'PAYMENT_RECEIPT_SUBMITTED',
    'PAYMENT_RECEIPT_APPROVED', 'PAYMENT_RECEIPT_REJECTED']) {
    assert.ok(actions.includes(needed), `audit missing ${needed}`);
  }
  ok('ثبت کارت، ارسال فیش، تایید و رد همگی در Audit Log ثبت شدند');

  const summary = await request('/api/admin/receipts-summary', { cookie: finance.cookie });
  assert.ok(summary.data.approved >= 2);
  assert.ok(summary.data.rejected >= 1);
  ok('خلاصه آماری فیش‌ها درست محاسبه شد');

  console.log(`\n${passed} آزمون پرداخت کارت‌به‌کارت با موفقیت پاس شد.`);
})()
  .then(() => cleanup())
  .catch((error) => { cleanup(); console.error('\n✗ ' + error.message); process.exit(1); });
