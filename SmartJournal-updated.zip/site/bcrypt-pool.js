/* ==========================================================================
   bcrypt-pool.js — استخر نخ برای bcryptjs
   --------------------------------------------------------------------------
   مشکل: bcryptjs جاوااسکریپت خالص است و حتی حالت async آن روی نخ اصلی
   CPU می‌سوزاند. با ۲۰ ورود همزمان (cost=12)، event loop تا ۲ ثانیه قفل
   می‌شد و با ۶۰ ورود تا ۴ ثانیه — یعنی با ۱۰ هزار کاربر، کل سایت یخ می‌زد.

   راه‌حل: هش/مقایسه در worker_thread های جدا انجام می‌شود؛ نخ اصلی آزاد
   می‌ماند. بدون وابستگی خارجی (بدون نیاز به کامپایل روی سرور) و با همان
   الگوریتم bcrypt — امنیت هیچ تغییری نمی‌کند.

   اندازهٔ استخر = min(۴, تعداد هسته‌ها). اگر worker_threads در دسترس نبود،
   همان bcryptjs مستقیم استفاده می‌شود.
   ========================================================================== */
'use strict';
const path = require('path');
const os = require('os');
const bcrypt = require('bcryptjs');

let Worker = null;
try { ({ Worker } = require('worker_threads')); } catch (e) { /* دسترس نیست */ }

const MAX_WORKERS = Math.max(2, Math.min(4, (os.availableParallelism && os.availableParallelism()) || os.cpus().length || 2));
const WORKER_PATH = path.join(__dirname, 'bcrypt-worker.js');

const workers = [];
const queue = [];
let seq = 0;

function ensureWorker() {
  if (!Worker || workers.length >= MAX_WORKERS) return null;
  const worker = new Worker(WORKER_PATH);
  worker.unref();
  workers.push(worker);
  return worker;
}

function dispatch(op, password, arg) {
  if (!Worker) {
    /* fallback: همان رفتار قبلی (روی نخ اصلی) */
    try {
      const value = op === 'hash' ? bcrypt.hashSync(password, arg) : bcrypt.compareSync(password, arg);
      return Promise.resolve(value);
    } catch (e) { return Promise.reject(e); }
  }
  return new Promise((resolve, reject) => {
    const worker = workers.find(w => w.busy === false) || (workers.length < MAX_WORKERS ? ensureWorker() : null);
    const job = { id: ++seq, op, password, arg, resolve, reject };
    const run = w => {
      w.busy = true;
      const onMsg = m => {
        if (!m || m.id !== job.id) return;
        w.off('message', onMsg);
        w.off('error', onErr);
        w.busy = false;
        if (m.ok) resolve(m.value); else reject(new Error(m.error));
        pump();
      };
      const onErr = e => {
        w.off('message', onMsg);
        w.off('error', onErr);
        w.busy = false;
        try { w.terminate(); } catch (err) {}
        const idx = workers.indexOf(w);
        if (idx >= 0) workers.splice(idx, 1);
        reject(e);
        pump();
      };
      w.on('message', onMsg);
      w.on('error', onErr);
      w.postMessage({ id: job.id, op, password, cost: op === 'hash' ? arg : undefined, hash: op === 'compare' ? arg : undefined });
    };
    if (worker) run(worker);
    else queue.push(run);
  });
}

function pump() {
  while (queue.length) {
    const free = workers.find(w => !w.busy);
    if (!free) return;
    const run = queue.shift();
    run(free);
  }
}

module.exports = {
  hash: (password, cost) => dispatch('hash', String(password), Number(cost) || 12),
  compare: (password, hash) => dispatch('compare', String(password), String(hash)),
  hashSync: (password, cost) => bcrypt.hashSync(password, cost), /* فقط مسیرهای یک‌بارهٔ نصب */
  poolSize: MAX_WORKERS,
};
