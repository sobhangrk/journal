'use strict';
/* ==========================================================================
   اسکرول‌بار و رنگ‌بندی عناصر بومی مرورگر — مشترک همه صفحات

   باگی که کاربر دید: نوار اسکرول اصلی صفحه، سفیدِ ویندوزی با دو فلش بود و
   کنار طراحی تیره‌ی سایت زشت می‌زد.

   دو علت داشت:
     ۱) همه‌ی قوانین ::-webkit-scrollbar داخل `.pa-app` محدود شده بودند،
        یعنی فقط اسکرول‌های داخلی برنامه استایل داشتند نه اسکرول خود صفحه.
     ۲) <meta name="color-scheme" content="dark light"> به مرورگر می‌گفت
        صفحه هر دو تم را پشتیبانی می‌کند؛ ویندوزِ کاربر روی تم روشن بود،
        پس مرورگر اسکرول‌بار و کنترل‌های بومی را روشن می‌کشید.

   اینجا هر دو را درست می‌کنیم و برای حالت روشن سایت (html.pa-light) هم
   نسخه‌ی متناسب می‌گذاریم.
   ========================================================================== */

const SCROLLBAR_CSS = `
:root{color-scheme:dark}
html.pa-light{color-scheme:light}

/* فایرفاکس */
html{scrollbar-width:thin;scrollbar-color:#2b3c55 transparent}
html.pa-light{scrollbar-color:#c9d2dd transparent}

/* کروم / اج / سافاری */
::-webkit-scrollbar{width:10px;height:10px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{
  border:2px solid transparent;border-radius:20px;
  background:#2b3c55;background-clip:content-box;
}
::-webkit-scrollbar-thumb:hover{background:#3c5375;background-clip:content-box}
::-webkit-scrollbar-thumb:active{background:#22d3ee;background-clip:content-box}
::-webkit-scrollbar-corner{background:transparent}
/* فلش‌های بالا و پایین نوار اسکرول ویندوز حذف شوند */
::-webkit-scrollbar-button{display:none;width:0;height:0}

html.pa-light ::-webkit-scrollbar-thumb{background:#c9d2dd;background-clip:content-box}
html.pa-light ::-webkit-scrollbar-thumb:hover{background:#aab7c7;background-clip:content-box}

@media (max-width:820px){::-webkit-scrollbar{width:6px;height:6px}}
`.trim();

/** بلوک <style> آماده برای گذاشتن داخل <head> */
function styleTag() {
  return `<style id="pa-shared-scrollbar">${SCROLLBAR_CSS}</style>`;
}

module.exports = { SCROLLBAR_CSS, styleTag };
