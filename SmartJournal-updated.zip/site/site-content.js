'use strict';
/* ==========================================================================
   محتوای سایت — متن‌ها و اعتمادسازی

   ۱) site_texts   : هر متن قابل‌مشاهده‌ی صفحه اصلی با کلید و سلکتور پایدار،
                     تا مدیر بدون دست زدن به کد همه را عوض کند.
   ۲) testimonials : نظرات کاربران برای اعتمادسازی.
   ۳) trust_badges : آمار و تضمین‌های صفحه اصلی.
   ========================================================================== */

const fs = require('fs');
const path = require('path');

const SEED_TEXTS = path.join(__dirname, 'seed', 'site-texts.json');

const SEED_TESTIMONIALS = [
  { name: 'سارا محمدی', role: 'معامله‌گر فارکس · ۳ سال سابقه', rating: 5,
    body: 'قبلاً معاملاتم را در اکسل می‌نوشتم و هیچ‌وقت مرورشان نمی‌کردم. اینجا بعد از یک ماه فهمیدم بیشتر ضررهایم در معاملات بعد از ساعت ۲۲ است. همان یک بینش، ماه بعد را نجات داد.' },
  { name: 'امیرحسین کریمی', role: 'پراپ‌تریدر', rating: 5,
    body: 'بخش قوانین پراپ‌فرم دقیقاً چیزی بود که کم داشتم. محدودیت ضرر روزانه را وارد کردم و دیگر ناخواسته از حدم رد نشدم.' },
  { name: 'نازنین حسینی', role: 'معامله‌گر ارز دیجیتال', rating: 5,
    body: 'اینکه می‌توانم تصویر چارت قبل و بعد از معامله را کنار یادداشتم داشته باشم، بازبینی هفتگی را کاملاً عوض کرد. دیگر حدس نمی‌زنم چه فکری می‌کردم.' },
  { name: 'محمد طاهری', role: 'معامله‌گر سهام', rating: 4,
    body: 'رابط فارسی و راست‌چین بدون مشکل، و همگام‌سازی بین موبایل و لپ‌تاپ واقعاً کار می‌کند. چیزی که در ابزارهای خارجی همیشه اذیتم می‌کرد.' },
  { name: 'پارسا اکبری', role: 'معامله‌گر طلا و انس', rating: 5,
    body: 'گزارش وین‌ریت و فاکتور سود را که دیدم، فهمیدم استراتژی‌ای که فکر می‌کردم بهترین است در عمل بدترین بوده. عدد دروغ نمی‌گوید.' },
  { name: 'مهسا جعفری', role: 'معامله‌گر پاره‌وقت', rating: 5,
    body: 'وقت زیادی ندارم، ولی ثبت هر معامله کمتر از یک دقیقه طول می‌کشد. همین باعث شد برای اولین بار یک عادت پایدار بسازم.' },
];

const SEED_BADGES = [
  { key: 'users',   icon: '👥', value: '۲٬۴۰۰+', label: 'معامله‌گر فعال', sort_order: 10 },
  { key: 'trades',  icon: '📊', value: '۱۸۰٬۰۰۰+', label: 'معامله ثبت‌شده', sort_order: 20 },
  { key: 'uptime',  icon: '⚡', value: '۹۹.۹٪', label: 'در دسترس بودن سرویس', sort_order: 30 },
  { key: 'support', icon: '💬', value: 'کمتر از ۲ ساعت', label: 'میانگین پاسخ پشتیبانی', sort_order: 40 },
];

function install(ctx) {
  const { app, db, id, iso, clean, logAudit, clientIp, allowPermissions } = ctx;

  /* ------------------------------------------------------------ schema -- */
  db.exec(`
    CREATE TABLE IF NOT EXISTS site_texts (
      id            TEXT PRIMARY KEY,
      text_key      TEXT NOT NULL UNIQUE,
      group_label   TEXT NOT NULL DEFAULT '',
      selector      TEXT NOT NULL,
      default_value TEXT NOT NULL DEFAULT '',
      value         TEXT NOT NULL DEFAULT '',
      sort_order    INTEGER NOT NULL DEFAULT 0,
      updated_at    TEXT NOT NULL,
      updated_by_admin_id TEXT
    );
    CREATE TABLE IF NOT EXISTS testimonials (
      id           TEXT PRIMARY KEY,
      name         TEXT NOT NULL,
      role         TEXT NOT NULL DEFAULT '',
      body         TEXT NOT NULL,
      rating       INTEGER NOT NULL DEFAULT 5,
      avatar_url   TEXT NOT NULL DEFAULT '',
      is_published INTEGER NOT NULL DEFAULT 1,
      sort_order   INTEGER NOT NULL DEFAULT 0,
      created_at   TEXT NOT NULL,
      updated_at   TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS trust_badges (
      id           TEXT PRIMARY KEY,
      badge_key    TEXT NOT NULL UNIQUE,
      icon         TEXT NOT NULL DEFAULT '',
      value        TEXT NOT NULL DEFAULT '',
      label        TEXT NOT NULL DEFAULT '',
      is_published INTEGER NOT NULL DEFAULT 1,
      sort_order   INTEGER NOT NULL DEFAULT 0,
      updated_at   TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS social_links (
      id            TEXT PRIMARY KEY,
      platform      TEXT NOT NULL DEFAULT 'custom',
      label         TEXT NOT NULL DEFAULT '',
      handle        TEXT NOT NULL DEFAULT '',
      url           TEXT NOT NULL DEFAULT '',
      is_published  INTEGER NOT NULL DEFAULT 0,
      show_widget   INTEGER NOT NULL DEFAULT 1,
      sort_order    INTEGER NOT NULL DEFAULT 0,
      created_at    TEXT NOT NULL,
      updated_at    TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_site_texts_group ON site_texts(group_label, sort_order);
    CREATE INDEX IF NOT EXISTS idx_social_links_order ON social_links(sort_order);
  `);

  /* -------------------------------------------------------------- seed -- */
  const textCount = Number(db.prepare('SELECT COUNT(*) c FROM site_texts').get().c);
  if (textCount === 0 && fs.existsSync(SEED_TEXTS)) {
    const rows = JSON.parse(fs.readFileSync(SEED_TEXTS, 'utf8'));
    const insert = db.prepare(`INSERT INTO site_texts
      (id,text_key,group_label,selector,default_value,value,sort_order,updated_at)
      VALUES (?,?,?,?,?,?,?,?)`);
    db.transaction(() => {
      rows.forEach((r) => insert.run(id('txt'), r.key, r.group, r.selector, r.value, r.value, r.sort, iso()));
    })();
  }

  if (Number(db.prepare('SELECT COUNT(*) c FROM testimonials').get().c) === 0) {
    const insert = db.prepare(`INSERT INTO testimonials
      (id,name,role,body,rating,avatar_url,is_published,sort_order,created_at,updated_at)
      VALUES (?,?,?,?,?,'',1,?,?,?)`);
    db.transaction(() => {
      SEED_TESTIMONIALS.forEach((t, i) =>
        insert.run(id('tst'), t.name, t.role, t.body, t.rating, (i + 1) * 10, iso(), iso()));
    })();
  }

  if (Number(db.prepare('SELECT COUNT(*) c FROM trust_badges').get().c) === 0) {
    const insert = db.prepare(`INSERT INTO trust_badges
      (id,badge_key,icon,value,label,is_published,sort_order,updated_at) VALUES (?,?,?,?,?,1,?,?)`);
    db.transaction(() => {
      SEED_BADGES.forEach((b) => insert.run(id('bdg'), b.key, b.icon, b.value, b.label, b.sort_order, iso()));
    })();
  }

  /* راه‌های ارتباطی: خالی و خاموش ساخته می‌شوند تا مدیر آدرس واقعی را بگذارد.
     هیچ لینک ساختگی روی سایت منتشر نمی‌شود. */
  if (Number(db.prepare('SELECT COUNT(*) c FROM social_links').get().c) === 0) {
    const insert = db.prepare(`INSERT INTO social_links
      (id,platform,label,handle,url,is_published,show_widget,sort_order,created_at,updated_at)
      VALUES (?,?,?,'','',0,1,?,?,?)`);
    db.transaction(() => {
      [['telegram', 'تلگرام'], ['instagram', 'اینستاگرام']]
        .forEach((row, i) => insert.run(id('soc'), row[0], row[1], (i + 1) * 10, iso(), iso()));
    })();
  }

  /* ------------------------------------------------------ public API ---- */
  /* پاسخ را با ETag می‌فرستیم نه max-age: تغییر مدیر بلافاصله دیده می‌شود،
     ولی وقتی چیزی عوض نشده مرورگر ۳۰۴ می‌گیرد و ترافیکی مصرف نمی‌شود. */
  function sendRevalidated(req, res, payload) {
    const body = JSON.stringify(payload);
    const etag = '"' + require('crypto').createHash('sha1').update(body).digest('base64').slice(0, 27) + '"';
    res.setHeader('ETag', etag);
    res.setHeader('Cache-Control', 'no-cache');
    if (req.headers['if-none-match'] === etag) return res.status(304).end();
    res.type('json').send(body);
  }


  app.get('/api/public/site-texts', (req, res) => {
    // only the ones the admin actually changed need shipping to the browser
    const rows = db.prepare(
      'SELECT text_key, selector, value FROM site_texts WHERE value <> default_value ORDER BY sort_order').all();
    sendRevalidated(req, res, { rows });
  });

  app.get('/api/public/testimonials', (req, res) => {
    const rows = db.prepare(
      `SELECT id,name,role,body,rating,avatar_url FROM testimonials
       WHERE is_published=1 ORDER BY sort_order, created_at`).all();
    const badges = db.prepare(
      'SELECT badge_key,icon,value,label FROM trust_badges WHERE is_published=1 ORDER BY sort_order').all();
    sendRevalidated(req, res, { rows, badges });
  });

  app.get('/api/public/social-links', (req, res) => {
    const rows = db.prepare(
      `SELECT id,platform,label,handle,url,show_widget FROM social_links
       WHERE is_published=1 AND url <> '' ORDER BY sort_order, created_at`).all()
      .map((r) => ({ ...r, show_widget: !!r.show_widget }));
    sendRevalidated(req, res, { rows });
  });

  /* ------------------------------------------------------- admin API ---- */
  app.get('/api/admin/site-texts', allowPermissions('content.view', 'content.manage', 'cms.manage'), (req, res) => {
    const q = clean(req.query.q, 60).toLowerCase();
    let rows = db.prepare(
      `SELECT id,text_key,group_label,selector,default_value,value,sort_order,updated_at
       FROM site_texts ORDER BY sort_order`).all();
    if (q) {
      rows = rows.filter((r) => r.value.toLowerCase().includes(q)
        || r.default_value.toLowerCase().includes(q) || r.text_key.includes(q));
    }
    const groups = [...new Set(rows.map((r) => r.group_label))];
    const changed = rows.filter((r) => r.value !== r.default_value).length;
    res.json({ rows, groups, changed, total: rows.length });
  });

  app.patch('/api/admin/site-texts/:id', allowPermissions('content.manage', 'cms.manage'), (req, res, next) => {
    try {
      const row = db.prepare('SELECT * FROM site_texts WHERE id=?').get(req.params.id);
      if (!row) return res.status(404).json({ error: 'این متن پیدا نشد.' });
      const value = String(req.body?.value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').slice(0, 600);
      if (!value.trim()) return res.status(400).json({ error: 'متن نمی‌تواند خالی باشد.' });
      db.prepare('UPDATE site_texts SET value=?,updated_at=?,updated_by_admin_id=? WHERE id=?')
        .run(value, iso(), req.admin.id, row.id);
      logAudit({
        adminId: req.admin.id, action: 'SITE_TEXT_UPDATED', entityType: 'site_text', entityId: row.id,
        details: { key: row.text_key, from: row.value.slice(0, 60), to: value.slice(0, 60) }, ip: clientIp(req),
      });
      res.json({ ok: true, row: db.prepare('SELECT * FROM site_texts WHERE id=?').get(row.id) });
    } catch (error) { next(error); }
  });

  app.post('/api/admin/site-texts/:id/reset', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const row = db.prepare('SELECT * FROM site_texts WHERE id=?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'این متن پیدا نشد.' });
    db.prepare('UPDATE site_texts SET value=default_value,updated_at=?,updated_by_admin_id=? WHERE id=?')
      .run(iso(), req.admin.id, row.id);
    logAudit({
      adminId: req.admin.id, action: 'SITE_TEXT_RESET', entityType: 'site_text', entityId: row.id,
      details: { key: row.text_key }, ip: clientIp(req),
    });
    res.json({ ok: true, value: row.default_value });
  });

  /* ---- نظرات کاربران ---- */
  app.get('/api/admin/testimonials', allowPermissions('content.view', 'content.manage', 'cms.manage'), (req, res) => {
    res.json({
      rows: db.prepare('SELECT * FROM testimonials ORDER BY sort_order, created_at').all(),
      badges: db.prepare('SELECT * FROM trust_badges ORDER BY sort_order').all(),
    });
  });

  const testimonialBody = (b) => ({
    name: clean(b.name, 60),
    role: clean(b.role, 90),
    body: clean(b.body, 600),
    rating: Math.max(1, Math.min(5, Math.round(Number(b.rating) || 5))),
    avatar_url: clean(b.avatarUrl, 300),
    is_published: b.isPublished === false ? 0 : 1,
  });

  app.post('/api/admin/testimonials', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const v = testimonialBody(req.body || {});
    if (!v.name || !v.body) return res.status(400).json({ error: 'نام و متن نظر الزامی است.' });
    const count = Number(db.prepare('SELECT COUNT(*) c FROM testimonials').get().c);
    const rowId = id('tst');
    db.prepare(`INSERT INTO testimonials
      (id,name,role,body,rating,avatar_url,is_published,sort_order,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(rowId, v.name, v.role, v.body, v.rating, v.avatar_url, v.is_published,
           (count + 1) * 10, iso(), iso());
    logAudit({
      adminId: req.admin.id, action: 'TESTIMONIAL_CREATED', entityType: 'testimonial',
      entityId: rowId, details: { name: v.name }, ip: clientIp(req),
    });
    res.status(201).json({ ok: true, row: db.prepare('SELECT * FROM testimonials WHERE id=?').get(rowId) });
  });

  app.patch('/api/admin/testimonials/:id', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const cur = db.prepare('SELECT * FROM testimonials WHERE id=?').get(req.params.id);
    if (!cur) return res.status(404).json({ error: 'نظر پیدا نشد.' });
    const b = req.body || {};
    const v = testimonialBody({ ...cur, avatarUrl: cur.avatar_url, isPublished: !!cur.is_published, ...b });
    if (!v.name || !v.body) return res.status(400).json({ error: 'نام و متن نظر الزامی است.' });
    db.prepare(`UPDATE testimonials SET name=?,role=?,body=?,rating=?,avatar_url=?,is_published=?,
                sort_order=?,updated_at=? WHERE id=?`)
      .run(v.name, v.role, v.body, v.rating, v.avatar_url, v.is_published,
           b.sortOrder === undefined ? cur.sort_order : Number(b.sortOrder) || 0, iso(), cur.id);
    logAudit({
      adminId: req.admin.id, action: 'TESTIMONIAL_UPDATED', entityType: 'testimonial',
      entityId: cur.id, details: { name: v.name }, ip: clientIp(req),
    });
    res.json({ ok: true, row: db.prepare('SELECT * FROM testimonials WHERE id=?').get(cur.id) });
  });

  app.delete('/api/admin/testimonials/:id', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const cur = db.prepare('SELECT * FROM testimonials WHERE id=?').get(req.params.id);
    if (!cur) return res.status(404).json({ error: 'نظر پیدا نشد.' });
    db.prepare('DELETE FROM testimonials WHERE id=?').run(cur.id);
    logAudit({
      adminId: req.admin.id, action: 'TESTIMONIAL_DELETED', entityType: 'testimonial',
      entityId: cur.id, details: { name: cur.name }, ip: clientIp(req),
    });
    res.json({ ok: true });
  });

  app.patch('/api/admin/trust-badges/:id', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const cur = db.prepare('SELECT * FROM trust_badges WHERE id=?').get(req.params.id);
    if (!cur) return res.status(404).json({ error: 'آمار پیدا نشد.' });
    const b = req.body || {};
    db.prepare('UPDATE trust_badges SET icon=?,value=?,label=?,is_published=?,updated_at=? WHERE id=?')
      .run(b.icon === undefined ? cur.icon : clean(b.icon, 8),
           b.value === undefined ? cur.value : clean(b.value, 40),
           b.label === undefined ? cur.label : clean(b.label, 60),
           b.isPublished === undefined ? cur.is_published : (b.isPublished ? 1 : 0),
           iso(), cur.id);
    logAudit({
      adminId: req.admin.id, action: 'TRUST_BADGE_UPDATED', entityType: 'trust_badge',
      entityId: cur.id, details: { key: cur.badge_key }, ip: clientIp(req),
    });
    res.json({ ok: true, row: db.prepare('SELECT * FROM trust_badges WHERE id=?').get(cur.id) });
  });


  /* -------------------------------------------- راه‌های ارتباطی (شبکه‌ها) -- */
  /* آدرس‌ها را اعتبارسنجی می‌کنیم تا کسی نتواند javascript: یا data: تزریق کند
     و لینکِ خرابِ سایتِ عمومی بسازد. */
  const SOCIAL_PLATFORMS = ['telegram', 'instagram', 'whatsapp', 'eitaa', 'bale', 'rubika',
    'youtube', 'x', 'linkedin', 'aparat', 'email', 'phone', 'website', 'custom'];

  function normalizeSocialUrl(platform, raw) {
    let value = String(raw || '').trim();
    if (!value) return '';
    if (platform === 'email') {
      const mail = value.replace(/^mailto:/i, '').trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail)) return null;
      return 'mailto:' + mail;
    }
    if (platform === 'phone') {
      const tel = value.replace(/^tel:/i, '').replace(/[^\d+]/g, '');
      if (tel.length < 6) return null;
      return 'tel:' + tel;
    }
    /* @username یا username تنها را به آدرس کامل تبدیل کن */
    if (!/^https?:\/\//i.test(value)) {
      const handle = value.replace(/^@/, '').replace(/^\/+/, '');
      if (/[\s]/.test(handle)) return null;
      if (platform === 'telegram')  value = 'https://t.me/' + handle;
      else if (platform === 'instagram') value = 'https://instagram.com/' + handle;
      else if (platform === 'whatsapp')  value = 'https://wa.me/' + handle.replace(/[^\d]/g, '');
      else if (platform === 'eitaa')     value = 'https://eitaa.com/' + handle;
      else if (platform === 'bale')      value = 'https://ble.ir/' + handle;
      else if (platform === 'rubika')    value = 'https://rubika.ir/' + handle;
      else if (platform === 'aparat')    value = 'https://aparat.com/' + handle;
      else if (platform === 'youtube')   value = 'https://youtube.com/@' + handle;
      else if (platform === 'x')         value = 'https://x.com/' + handle;
      else if (platform === 'linkedin')  value = 'https://linkedin.com/in/' + handle;
      else value = 'https://' + handle;
    }
    try {
      const parsed = new URL(value);
      if (!['http:', 'https:'].includes(parsed.protocol)) return null;
      return parsed.toString();
    } catch { return null; }
  }

  function socialBody(b, current = {}) {
    const platform = SOCIAL_PLATFORMS.includes(b.platform) ? b.platform
      : (current.platform || 'custom');
    const url = b.url === undefined ? (current.url || '') : normalizeSocialUrl(platform, b.url);
    if (url === null) return { error: 'آدرس معتبر نیست. یا لینک کامل بگذارید یا فقط نام کاربری.' };
    const label = clean(b.label ?? current.label ?? '', 40);
    if (!label.trim()) return { error: 'عنوان را وارد کنید (مثلاً تلگرام).' };
    return {
      platform, label, url,
      handle: clean(b.handle ?? current.handle ?? '', 60),
      is_published: (b.isPublished === undefined ? current.is_published : (b.isPublished ? 1 : 0)) ? 1 : 0,
      show_widget: (b.showWidget === undefined ? (current.show_widget ?? 1) : (b.showWidget ? 1 : 0)) ? 1 : 0,
      sort_order: Number.isFinite(Number(b.sortOrder)) ? Number(b.sortOrder)
        : Number(current.sort_order || 0),
    };
  }

  app.get('/api/admin/social-links',
    allowPermissions('content.view', 'content.manage', 'cms.manage'), (req, res) => {
      res.json({ rows: db.prepare('SELECT * FROM social_links ORDER BY sort_order, created_at').all(),
        platforms: SOCIAL_PLATFORMS });
    });

  app.post('/api/admin/social-links', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const v = socialBody(req.body || {});
    if (v.error) return res.status(400).json({ error: v.error });
    const next = Number(db.prepare('SELECT COALESCE(MAX(sort_order),0) m FROM social_links').get().m) + 10;
    const rowId = id('soc');
    db.prepare(`INSERT INTO social_links
      (id,platform,label,handle,url,is_published,show_widget,sort_order,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(rowId, v.platform, v.label, v.handle, v.url, v.is_published, v.show_widget,
           v.sort_order || next, iso(), iso());
    logAudit({ adminId: req.admin.id, action: 'SOCIAL_LINK_CREATED', entityType: 'social_link',
      entityId: rowId, details: { platform: v.platform, url: v.url }, ip: clientIp(req) });
    res.status(201).json({ ok: true, row: db.prepare('SELECT * FROM social_links WHERE id=?').get(rowId) });
  });

  app.patch('/api/admin/social-links/:id', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const row = db.prepare('SELECT * FROM social_links WHERE id=?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'این راه ارتباطی پیدا نشد.' });
    const v = socialBody(req.body || {}, row);
    if (v.error) return res.status(400).json({ error: v.error });
    if (v.is_published && !v.url) {
      return res.status(400).json({ error: 'برای انتشار، اول آدرس را وارد کنید.' });
    }
    db.prepare(`UPDATE social_links SET platform=?,label=?,handle=?,url=?,is_published=?,
      show_widget=?,sort_order=?,updated_at=? WHERE id=?`)
      .run(v.platform, v.label, v.handle, v.url, v.is_published, v.show_widget, v.sort_order, iso(), row.id);
    logAudit({ adminId: req.admin.id, action: 'SOCIAL_LINK_UPDATED', entityType: 'social_link',
      entityId: row.id, details: { platform: v.platform, url: v.url, published: !!v.is_published },
      ip: clientIp(req) });
    res.json({ ok: true, row: db.prepare('SELECT * FROM social_links WHERE id=?').get(row.id) });
  });

  app.delete('/api/admin/social-links/:id', allowPermissions('content.manage', 'cms.manage'), (req, res) => {
    const row = db.prepare('SELECT * FROM social_links WHERE id=?').get(req.params.id);
    if (!row) return res.status(404).json({ error: 'این راه ارتباطی پیدا نشد.' });
    db.prepare('DELETE FROM social_links WHERE id=?').run(row.id);
    logAudit({ adminId: req.admin.id, action: 'SOCIAL_LINK_DELETED', entityType: 'social_link',
      entityId: row.id, details: { platform: row.platform, label: row.label }, ip: clientIp(req) });
    res.json({ ok: true });
  });

  return { seededTexts: Number(db.prepare('SELECT COUNT(*) c FROM site_texts').get().c) };
}


module.exports = { install };
