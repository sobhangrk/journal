'use strict';
const crypto=require('node:crypto');
const {monitorEventLoopDelay}=require('node:perf_hooks');
const pino=require('pino');
const client=require('prom-client');
const Sentry=require('@sentry/node');
const service=process.env.SERVICE_NAME||'pa-journal';
const environment=process.env.APP_ENV||process.env.NODE_ENV||'development';
const logger=pino({level:process.env.LOG_LEVEL||'info',base:{service,environment,version:require('./package.json').version},timestamp:pino.stdTimeFunctions.isoTime,redact:{paths:['password','currentPassword','newPassword','code','token','secret','apiKey','bearerToken','req.headers.authorization','req.headers.cookie','headers.authorization','headers.cookie'],censor:'[REDACTED]'}});
if(process.env.SENTRY_DSN){Sentry.init({dsn:process.env.SENTRY_DSN,environment,release:process.env.APP_RELEASE||`pa-journal@${require('./package.json').version}`,sendDefaultPii:false,tracesSampleRate:Math.max(0,Math.min(1,Number(process.env.SENTRY_TRACES_SAMPLE_RATE||0.05))),beforeSend(event){if(event.request){delete event.request.cookies;if(event.request.headers){delete event.request.headers.cookie;delete event.request.headers.authorization}}return event}});logger.info({event:'sentry_initialized'},'Sentry error tracking enabled')}
const register=new client.Registry();client.collectDefaultMetrics({register,prefix:'pa_journal_',labels:{service,environment}});
const requestTotal=new client.Counter({name:'pa_journal_http_requests_total',help:'Total HTTP requests',labelNames:['method','route','status_class'],registers:[register]});
const requestDuration=new client.Histogram({name:'pa_journal_http_request_duration_seconds',help:'HTTP response duration',labelNames:['method','route','status_class'],buckets:[0.01,0.025,0.05,0.1,0.25,0.5,1,2,5,10],registers:[register]});
const activeRequests=new client.Gauge({name:'pa_journal_http_active_requests',help:'Active HTTP requests',registers:[register]});
const slowRequests=new client.Counter({name:'pa_journal_http_slow_requests_total',help:'Requests slower than configured threshold',labelNames:['method','route'],registers:[register]});
const errorsTotal=new client.Counter({name:'pa_journal_application_errors_total',help:'Application errors captured by the global handler',labelNames:['source'],registers:[register]});
const readinessGauge=new client.Gauge({name:'pa_journal_readiness',help:'Readiness of runtime dependencies',labelNames:['dependency'],registers:[register]});
const eventLoopGauge=new client.Gauge({name:'pa_journal_event_loop_lag_seconds',help:'Event loop delay p99 in seconds',registers:[register]});
const lag=monitorEventLoopDelay({resolution:20});lag.enable();
function normalizedRoute(req){const route=req.route&&req.route.path,base=req.baseUrl||'';if(route)return `${base}${Array.isArray(route)?route[0]:route}`.slice(0,160);const clean=String(req.path||req.originalUrl||'unknown').replace(/\b[0-9a-f]{8}-[0-9a-f-]{27,}\b/gi,':id').replace(/\/(usr|adm|file|uses|udev|cms_[a-z]+)_[^/?]+/g,'/:id');return clean.slice(0,160)}
function requestId(value){const candidate=String(value||'');return /^[A-Za-z0-9._:-]{8,100}$/.test(candidate)?candidate:crypto.randomUUID()}
function requestObservability(req,res,next){const id=requestId(req.get('x-request-id')),started=process.hrtime.bigint();req.id=id;res.setHeader('X-Request-ID',id);activeRequests.inc();let completed=false;const complete=()=>{if(completed)return;completed=true;activeRequests.dec();const duration=Number(process.hrtime.bigint()-started)/1e9,route=normalizedRoute(req),statusClass=`${Math.floor(res.statusCode/100)}xx`,labels={method:req.method,route,status_class:statusClass};requestTotal.inc(labels);requestDuration.observe(labels,duration);const level=res.statusCode>=500?'error':res.statusCode>=400?'warn':'info',data={event:'http_request',requestId:id,method:req.method,route,statusCode:res.statusCode,durationMs:Math.round(duration*1000),ip:req.ip,userAgent:String(req.get('user-agent')||'').slice(0,180)};logger[level](data,'HTTP request completed');const threshold=Math.max(100,Number(process.env.SLOW_REQUEST_MS||750));if(duration*1000>=threshold){slowRequests.inc({method:req.method,route});logger.warn({...data,event:'slow_request',thresholdMs:threshold},'Slow request detected')}};res.once('finish',complete);res.once('close',complete);next()}
function captureError(error,context={}){errorsTotal.inc({source:String(context.source||'application').slice(0,80)});logger.error({event:'application_error',err:error,requestId:context.requestId,route:context.route,method:context.method,source:context.source},error&&error.message||'Application error');if(process.env.SENTRY_DSN)Sentry.captureException(error,{tags:{source:context.source||'application'},extra:{requestId:context.requestId,route:context.route,method:context.method}})}
function setReadiness(dependency,ready){readinessGauge.set({dependency},ready?1:0)}
async function metrics(){eventLoopGauge.set(Number(lag.percentile(99)||0)/1e9);lag.reset();return register.metrics()}
function setupSentryErrorHandler(app){if(process.env.SENTRY_DSN&&typeof Sentry.setupExpressErrorHandler==='function')Sentry.setupExpressErrorHandler(app)}
module.exports={logger,requestObservability,captureError,setReadiness,metrics,metricsContentType:register.contentType,setupSentryErrorHandler};
