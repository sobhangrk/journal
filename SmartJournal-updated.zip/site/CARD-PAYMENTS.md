# پرداخت کارت‌به‌کارت + واقعی‌سازی پنل مدیریت

## ۱) پنل مدیریت واقعی شد

`SmartJournal-Admin.html` که قبلاً داشتید، در واقع `public/admin/index.html` بود که
`admin.css` + `admin.js` + **`mock-api.js`** داخلش inline شده بود. همان `mock-api.js`
با بازنویسی `window.fetch` تمام `/api/admin/*` را می‌بلعید و داده‌های ساختگی
`localStorage` را برمی‌گرداند — به همین دلیل پنل «قلابی» بود.

`public/admin/index.html` از نو ساخته شد: mock **حذف** و به `admin.js` و `admin.css`
واقعی لینک شد. حالا پنل با Backend خودتان کار می‌کند: bcrypt، نشست سروری، CSRF،
RBAC، MFA اجباری Owner و Audit Log.

بازسازی مجدد در صورت نیاز:

```bash
python3 scripts/rebuild-html.py     # uploads/*.html → public/
```

## ۲) کارت‌به‌کارت به Backend اضافه شد

دیتابیس شما پرداخت درگاهی داشت ولی کارت بانکی و فیش نداشت. ماژول `bank-payments.js`
دو جدول اضافه می‌کند و به دامنه‌ی موجود وصل می‌شود:

- `bank_cards` — شماره کارت‌هایی که به کاربر نمایش داده می‌شود
- `payment_receipts` — فیش‌ها با وضعیت `pending / approved / rejected`

**تایید هر فیش یک عملیات اتمیک است:** اشتراک در `subscriptions` تمدید می‌شود و یک
ردیف رسمی در `payments` با `provider='card_to_card'` و `status='paid'` و شماره فاکتور
`INV-CTC-xxxxxx` ثبت می‌گردد. اگر کاربر اشتراک فعال داشته باشد، روزهای جدید به
**انتهای** اعتبار قبلی اضافه می‌شود نه از امروز.

### مسیرها

| نقش | متد | مسیر |
|---|---|---|
| کاربر | GET | `/api/billing/bank-cards` |
| کاربر | POST | `/api/billing/receipts` |
| کاربر | GET | `/api/billing/receipts` |
| کاربر | GET | `/api/billing/receipts/:id/image` |
| `billing.view` | GET | `/api/admin/bank-cards` · `/api/admin/receipts` · `/api/admin/receipts-summary` · `/api/admin/receipts/:id/image` |
| `billing.manage` | POST/PATCH/DELETE | `/api/admin/bank-cards[/:id]` |
| `billing.manage` | POST | `/api/admin/receipts/:id/approve` · `/api/admin/receipts/:id/reject` |

### کنترل‌های امنیتی

- کنترل **Luhn** روی شماره کارت؛ رقم اشتباه همان‌جا رد می‌شود
- نوع واقعی فیش از بایت‌های فایل تشخیص داده می‌شود (فایل با پسوند جعلی رد می‌شود)
- سقف ۸ مگابایت، فقط JPG/PNG/WebP/PDF
- کد پیگیری در کل سیستم **یکتا** است؛ ثبت دوباره ۴۰۹ می‌گیرد
- حداکثر ۳ فیش در انتظار برای هر کاربر
- تصویر فیش فقط برای صاحبش یا مدیرِ دارای `billing.view`؛ خارج از پوشه public و با
  هدر `sandbox` و `nosniff` سرو می‌شود
- شماره کارت در لیست مدیریت **ماسک** می‌شود
- تایید دوباره و رد فیشِ تاییدشده مسدود است (پرداخت تکراری ساخته نمی‌شود)
- ثبت کارت، ارسال فیش، تایید و رد همگی در Audit Log

## ۳) رابط کاربری

- **پنل مدیریت** → منوی «کارت بانکی و فیش‌های واریز»: تب‌های در انتظار/تاییدشده/ردشده،
  جستجو، مشاهده فیش در اندازه بزرگ، دکمه تایید (با تعیین روز) و رد (با دلیل)
- **سمت کاربر** (`public/journal-card-payment.js`): دکمه شناور «خرید / تمدید»،
  انتخاب کارت با دکمه کپی، آپلود فیش با پیش‌نمایش، و تب «وضعیت پرداخت‌های من»
  که دلیل رد را هم نشان می‌دهد

## ۴) آزمون

```bash
npm run smoke:cards     # ۳۰ آزمون کارت‌به‌کارت
npm run smoke:admin     # ۳۹
npm run smoke:auth      # ۲۶
npm run smoke:journal   # ۲۶
```

اگر `smoke:auth` یا `smoke:journal` خطای «تعداد درخواست کد بیش از حد مجاز» داد،
rate limit پیامک است نه باگ؛ چند دقیقه صبر کنید یا `user_otp_challenges` را خالی کنید.
