'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {pipeline}=require('node:stream/promises');
const {S3Client,PutObjectCommand,GetObjectCommand,DeleteObjectCommand,HeadBucketCommand}=require('@aws-sdk/client-s3');
const {Upload}=require('@aws-sdk/lib-storage');
const {logger}=require('./observability');
const backend=String(process.env.STORAGE_BACKEND||'local').toLowerCase(),s3Enabled=['s3','hybrid'].includes(backend);
let client=null;
function s3(){if(!s3Enabled)throw new Error('S3 storage is disabled.');if(!process.env.S3_BUCKET)throw new Error('S3_BUCKET is required for S3 storage.');if(!client){const secretAccessKey=process.env.S3_SECRET_ACCESS_KEY||(process.env.S3_SECRET_ACCESS_KEY_FILE?fs.readFileSync(process.env.S3_SECRET_ACCESS_KEY_FILE,'utf8').trim():'');client=new S3Client({region:process.env.S3_REGION||'us-east-1',endpoint:process.env.S3_ENDPOINT||undefined,forcePathStyle:String(process.env.S3_FORCE_PATH_STYLE||'false')==='true',credentials:process.env.S3_ACCESS_KEY_ID?{accessKeyId:process.env.S3_ACCESS_KEY_ID,secretAccessKey}:undefined})}return client}
function objectKey(storageKey){return [String(process.env.S3_PREFIX||'journal-media').replace(/^\/+|\/+$/g,''),String(storageKey).replace(/^\/+/, '')].filter(Boolean).join('/')}
async function uploadFile(storageKey,filePath,mimeType,checksum){if(!s3Enabled)return {backend:'local',key:storageKey};const key=objectKey(storageKey),uploader=new Upload({client:s3(),params:{Bucket:process.env.S3_BUCKET,Key:key,Body:fs.createReadStream(filePath),ContentType:mimeType,CacheControl:'private, max-age=3600, immutable',ServerSideEncryption:process.env.S3_SERVER_SIDE_ENCRYPTION||undefined,SSEKMSKeyId:process.env.S3_KMS_KEY_ID||undefined,Metadata:checksum?{sha256:checksum}:undefined},queueSize:2,partSize:5*1024*1024,leavePartsOnError:false});await uploader.done();logger.info({event:'media_uploaded_to_s3',key},'Media uploaded to object storage');return {backend:'s3',key}}
async function streamObject(storageKey,res,mimeType,sizeBytes){const response=await s3().send(new GetObjectCommand({Bucket:process.env.S3_BUCKET,Key:objectKey(storageKey)}));res.setHeader('Cache-Control','private, max-age=3600, immutable');res.setHeader('Content-Type',response.ContentType||mimeType);if(response.ContentLength!==undefined)res.setHeader('Content-Length',String(response.ContentLength));else if(sizeBytes)res.setHeader('Content-Length',String(sizeBytes));await pipeline(response.Body,res)}
async function deleteObject(storageKey){if(!s3Enabled)return false;await s3().send(new DeleteObjectCommand({Bucket:process.env.S3_BUCKET,Key:objectKey(storageKey)}));return true}
async function health(){if(!s3Enabled)return {enabled:false,ready:true,backend};try{await s3().send(new HeadBucketCommand({Bucket:process.env.S3_BUCKET}));return {enabled:true,ready:true,backend}}catch(error){return {enabled:true,ready:false,backend,error:error.name||error.message}}}
module.exports={backend,s3Enabled,uploadFile,streamObject,deleteObject,health};
