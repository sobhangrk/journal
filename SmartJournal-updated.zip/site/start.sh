#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# SmartJournal — اجرای سایت با یک دستور
#   Linux / macOS:   bash start.sh
# ---------------------------------------------------------------------------
set -u
cd "$(dirname "$0")"

PORT="${PORT:-3000}"
say() { printf '\n\033[1;36m%s\033[0m\n' "$*"; }
err() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*"; }
ok()  { printf '\033[1;32m✓ %s\033[0m\n' "$*"; }

say "SmartJournal — راه‌اندازی"

# ۱) Node.js
if ! command -v node >/dev/null 2>&1; then
  err "Node.js نصب نیست."
  echo "  از https://nodejs.org نسخه LTS (۲۰ یا بالاتر) را نصب کنید و دوباره اجرا کنید."
  exit 1
fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  err "نسخه Node شما $(node -v) است؛ حداقل ۱۸ (ترجیحاً ۲۰) لازم است."
  exit 1
fi
ok "Node $(node -v)"

# ۲) وابستگی‌ها
if [ ! -d node_modules ] || [ ! -d node_modules/express ]; then
  say "نصب وابستگی‌ها (فقط بار اول، ~۱ دقیقه)…"
  npm install --no-audit --no-fund || { err "npm install ناموفق بود."; exit 1; }
fi
ok "وابستگی‌ها آماده است"

# ۳) پورت آزاد؟
if command -v lsof >/dev/null 2>&1 && lsof -ti tcp:"$PORT" >/dev/null 2>&1; then
  err "پورت $PORT همین حالا اشغال است."
  echo "  یا برنامه قبلی را ببندید، یا با پورت دیگر اجرا کنید:  PORT=3001 bash start.sh"
  exit 1
fi

# ۴) اجرا
say "در حال اجرا…"
echo "  سایت:        http://localhost:$PORT"
echo "  پنل مدیریت:  http://localhost:$PORT/admin"
echo "  (برای توقف: Ctrl + C)"
echo
PORT="$PORT" HOST=0.0.0.0 npm start
