(function(){
  'use strict';
  if(window.__PA_UX_RUNTIME__)return;window.__PA_UX_RUNTIME__=true;
  var ONBOARDING_PENDING='pa_onboarding_pending',ONBOARDING_DONE='pa_onboarding_done_v1',TOUR_DONE='pa_product_tour_done_v1',currentTour=-1,tourTarget=null;
  var style=document.createElement('style');style.id='pa-ux-runtime-styles';style.textContent=`
.pa-ux-overlay{position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;padding:20px;background:rgba(2,7,13,.82);backdrop-filter:blur(16px)}.pa-ux-dialog{width:min(690px,100%);overflow:hidden;border:1px solid #29405a;border-radius:23px;color:#eaf5fa;background:linear-gradient(145deg,#101c2b,#080f19);box-shadow:0 40px 120px #000;font-family:Vazirmatn,Tahoma,sans-serif}.pa-ux-dialog header{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;padding:25px 28px 18px;border-bottom:1px solid rgba(148,163,184,.15)}.pa-ux-eyebrow{color:#67e8f9;font:800 9px JetBrains Mono,monospace;letter-spacing:.12em}.pa-ux-dialog h2{margin:7px 0 0;font-size:clamp(21px,4vw,30px)}.pa-ux-close{width:44px;height:44px;border:1px solid #31455e;border-radius:12px;color:#9fb0c1;background:#111d2b;font-size:22px;cursor:pointer}.pa-ux-progress{height:3px;background:#15263a}.pa-ux-progress i{display:block;height:100%;width:var(--progress);background:linear-gradient(90deg,#22d3ee,#67e8f9);transition:width .25s}.pa-ux-body{padding:26px 28px}.pa-ux-body p{margin:0;color:#9eb0c2;font-size:12px;line-height:2}.pa-ux-step-list,.pa-ux-goals{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:20px}.pa-ux-goals button,.pa-ux-mini-card{min-height:112px;padding:16px;border:1px solid #273a51;border-radius:14px;color:#c8d4df;background:#0b1521;text-align:right;font:700 11px/1.8 Vazirmatn;cursor:pointer}.pa-ux-goals button span,.pa-ux-mini-card span{display:block;margin-top:6px;color:#7f91a5;font-size:9px;font-weight:500}.pa-ux-goals button.active{border-color:#4ddde9;color:#b9f8fc;background:rgba(34,211,238,.08);box-shadow:0 0 0 3px rgba(34,211,238,.08)}.pa-ux-mini-card{cursor:default}.pa-ux-mini-card b{display:grid;place-items:center;width:30px;height:30px;margin-bottom:9px;border-radius:9px;color:#06171c;background:#67e8f9}.pa-ux-actions{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:18px 28px 24px}.pa-ux-actions>div{display:flex;gap:8px}.pa-ux-btn{min-height:44px;padding:0 16px;border:1px solid #30465f;border-radius:11px;color:#b6c6d6;background:#111d2c;font:800 10px Vazirmatn;cursor:pointer}.pa-ux-btn.primary{border-color:#67e8f9;color:#04161b;background:linear-gradient(135deg,#67e8f9,#22d3ee)}.pa-ux-btn.text{border-color:transparent;color:#8092a6;background:transparent}.pa-ux-help{position:fixed;left:18px;bottom:92px;z-index:9995;display:none;width:46px;height:46px;border:1px solid rgba(103,232,249,.36);border-radius:50%;color:#b8f7fb;background:rgba(9,18,29,.94);box-shadow:0 16px 40px -18px #000;font:900 17px Vazirmatn;cursor:pointer}.pa-ux-help.is-visible{display:grid;place-items:center}.pa-ux-highlight{position:fixed;z-index:2147482001;border:3px solid #67e8f9;border-radius:14px;box-shadow:0 0 0 9999px rgba(1,6,11,.76),0 0 34px rgba(34,211,238,.38);pointer-events:none;transition:all .22s}.pa-ux-tour{position:fixed;z-index:2147482002;width:min(340px,calc(100vw - 28px));padding:18px;border:1px solid #38506b;border-radius:16px;color:#eaf5fa;background:#0d1825;box-shadow:0 24px 70px #000;font-family:Vazirmatn,Tahoma,sans-serif}.pa-ux-tour small{color:#67e8f9;font:700 8px JetBrains Mono}.pa-ux-tour h3{margin:7px 0;font-size:16px}.pa-ux-tour p{margin:0;color:#98a9ba;font-size:10px;line-height:1.9}.pa-ux-tour footer{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:15px}.pa-ux-tour footer div{display:flex;gap:6px}.pa-ux-live{position:fixed;z-index:2147483600;right:50%;bottom:22px;max-width:min(480px,calc(100vw - 30px));transform:translateX(50%);padding:11px 15px;border:1px solid rgba(70,227,155,.3);border-radius:11px;color:#b9f5d2;background:rgba(9,30,23,.96);box-shadow:0 18px 55px #000;font:700 10px/1.8 Vazirmatn;opacity:0;visibility:hidden;transition:.2s}.pa-ux-live.show{opacity:1;visibility:visible}.pa-ux-live.error{border-color:rgba(255,102,122,.35);color:#ffc1ca;background:rgba(40,14,22,.96)}.pa-ux-empty-enhanced{position:relative!important;min-height:180px!important;display:flex!important;align-items:center!important;justify-content:center!important;flex-direction:column!important;gap:9px!important;padding:28px!important;border:1px dashed rgba(103,232,249,.24)!important;border-radius:15px!important;background:linear-gradient(145deg,rgba(34,211,238,.035),rgba(15,23,36,.5))!important;text-align:center!important}.pa-ux-empty-enhanced:before{content:'＋';display:grid;place-items:center;width:42px;height:42px;margin-bottom:4px;border-radius:13px;color:#67e8f9;background:rgba(34,211,238,.09);font-size:21px}.pa-ux-empty-cta{min-height:42px;margin-top:7px;padding:0 14px;border:1px solid rgba(103,232,249,.35);border-radius:10px;color:#06171b;background:#67e8f9;font:800 9px Vazirmatn;cursor:pointer}.pa-ux-skeleton{position:relative!important;min-height:120px!important;overflow:hidden!important;color:transparent!important;border-radius:14px!important;background:linear-gradient(110deg,#101a27 8%,#172638 18%,#101a27 33%)!important;background-size:220% 100%!important;animation:paUxShimmer 1.25s linear infinite!important}.pa-ux-skeleton *{visibility:hidden!important}@keyframes paUxShimmer{to{background-position-x:-220%}}[aria-busy=true].pa-a-submit,[aria-busy=true].pa-btn{cursor:wait!important}.pa-ux-offline{position:fixed;z-index:2147483500;top:12px;right:50%;transform:translateX(50%);padding:8px 13px;border:1px solid rgba(245,189,84,.35);border-radius:999px;color:#f6d58f;background:#2c210d;font:700 9px Vazirmatn}.pa-l-lite .pa-l-canvas,.pa-l-lite .pa-l-cinematic,.pa-l-lite .pa-l-cursor-light,.pa-l-lite .pa-l-beam{display:none!important}.pa-l-lite .pa-l-aurora,.pa-l-lite .pa-l-ticker-track,.pa-l-lite .pa-l-final:before{animation:none!important}.pa-l-lite .pa-l-terminal-wrap{transform:none!important}@media(max-width:650px){.pa-ux-overlay{padding:0}.pa-ux-dialog{height:100%;border:0;border-radius:0;overflow:auto}.pa-ux-step-list,.pa-ux-goals{grid-template-columns:1fr}.pa-ux-actions{align-items:stretch;flex-direction:column-reverse}.pa-ux-actions>div{display:grid;grid-template-columns:1fr 1fr}.pa-ux-btn{width:100%}.pa-ux-tour{right:14px!important;left:14px!important;bottom:78px!important;top:auto!important;width:auto}.pa-ux-help{left:12px;bottom:84px}}@media(prefers-reduced-motion:reduce){.pa-ux-progress i,.pa-ux-highlight,.pa-ux-live{transition:none}.pa-ux-skeleton{animation:none!important;background:#152235!important}}
`;document.head.appendChild(style);
  function appReady(){return !!document.querySelector('.pa-app')&&!document.documentElement.classList.contains('pa-landing-active')&&!document.documentElement.classList.contains('pa-auth-active')}
  function visible(node){return !!(node&&node.isConnected&&!node.hidden&&node.getAttribute('aria-hidden')!=='true'&&node.getClientRects().length)}
  function safeStorage(type,key,value){try{var store=type==='session'?sessionStorage:localStorage;if(value===undefined)return store.getItem(key);if(value===null)store.removeItem(key);else store.setItem(key,value)}catch(_){}return null}
  function feedback(message,type){var host=document.getElementById('pa-ux-live');if(!host){host=document.createElement('div');host.id='pa-ux-live';host.className='pa-ux-live';host.setAttribute('role','status');host.setAttribute('aria-live','polite');document.body.appendChild(host)}host.textContent=message;host.className='pa-ux-live '+(type==='error'?'error ':'')+'show';host.setAttribute('role',type==='error'?'alert':'status');clearTimeout(host._timer);host._timer=setTimeout(function(){host.classList.remove('show')},4200)}
  var onboardingSteps=[
    {title:'خوش آمدی؛ اول هدفت را انتخاب کن',body:'این انتخاب فقط مسیر راهنما را شخصی‌تر می‌کند و روی داده‌های معامله یا پلن شما اثری ندارد.',kind:'goals'},
    {title:'حساب معاملاتی‌ات آماده است',body:'برای هر حساب، موجودی شروع و برداشت‌ها مستقل می‌مانند. بعداً از تنظیمات › حساب‌ها می‌توانی حساب جدید اضافه یا نام آن را اصلاح کنی.',kind:'cards',cards:[['۱','نام حساب','مثلاً حساب شخصی یا چالش اول'],['۲','موجودی شروع','مبنای محاسبه رشد و افت سرمایه'],['۳','برداشت‌ها','جدا از سود و زیان معامله']]},
    {title:'اولین معامله را برای بازبینی ثبت کن',body:'نماد و نتیجه کافی نیست؛ درصد ریسک، دلیل ورود، احساس و تصویر قبل یا بعد باعث می‌شوند معامله بعداً قابل یادگیری باشد.',kind:'cards',cards:[['۱','تصمیم','دلیل ورود و ستاپ'],['۲','ریسک','درصد ریسک و حد ضرر'],['۳','مدرک','تصویر و یادداشت بعد از خروج']]},
    {title:'حلقه بازخورد را کامل کن',body:'پس از چند معامله، داشبورد و بخش ریسک را مرور کن و فقط یک اقدام مشخص برای دوره بعد انتخاب کن.',kind:'cards',cards:[['۱','ثبت','بدون بازنویسی تاریخچه'],['۲','مرور','آمار و رفتار کنار هم'],['۳','اقدام','یک تغییر قابل اندازه‌گیری']]}
  ];
  function openOnboarding(){if(document.getElementById('pa-ux-onboarding'))return;var step=0,goal=safeStorage('local','pa_onboarding_goal')||'';var overlay=document.createElement('div');overlay.id='pa-ux-onboarding';overlay.className='pa-ux-overlay';overlay.innerHTML='<section class="pa-ux-dialog" role="dialog" aria-modal="true" aria-labelledby="pa-ux-title"><header><div><span class="pa-ux-eyebrow">GUIDED ONBOARDING</span><h2 id="pa-ux-title"></h2></div><button type="button" class="pa-ux-close" aria-label="بستن و تکمیل بعداً">×</button></header><div class="pa-ux-progress"><i></i></div><div class="pa-ux-body"></div><footer class="pa-ux-actions"><button type="button" class="pa-ux-btn text" data-onboarding-skip>تکمیل بعداً</button><div><button type="button" class="pa-ux-btn" data-onboarding-prev>مرحله قبل</button><button type="button" class="pa-ux-btn primary" data-onboarding-next>مرحله بعد</button></div></footer></section>';document.body.appendChild(overlay);function close(done){if(done){safeStorage('local',ONBOARDING_DONE,'1');safeStorage('local',ONBOARDING_PENDING,null)}else safeStorage('local','pa_onboarding_skipped','1');overlay.remove();document.querySelector('.pa-ux-help')?.focus()}function render(){var item=onboardingSteps[step],body=overlay.querySelector('.pa-ux-body');overlay.querySelector('#pa-ux-title').textContent=item.title;overlay.querySelector('.pa-ux-progress i').style.setProperty('--progress',((step+1)/onboardingSteps.length*100)+'%');body.innerHTML='<p>'+item.body+'</p>'+(item.kind==='goals'?'<div class="pa-ux-goals"><button type="button" data-goal="review">بازبینی منظم<span>ساخت روتین هفتگی و استخراج اقدام</span></button><button type="button" data-goal="risk">کنترل ریسک<span>دیدن افت سرمایه و اندازه ریسک واقعی</span></button><button type="button" data-goal="discipline">انضباط اجرایی<span>تشخیص خطاهای رفتاری و خارج از پلن</span></button></div>':'<div class="pa-ux-step-list">'+item.cards.map(function(card){return '<article class="pa-ux-mini-card"><b>'+card[0]+'</b>'+card[1]+'<span>'+card[2]+'</span></article>'}).join('')+'</div>');Array.prototype.forEach.call(body.querySelectorAll('[data-goal]'),function(button){button.classList.toggle('active',button.dataset.goal===goal);button.addEventListener('click',function(){goal=button.dataset.goal;safeStorage('local','pa_onboarding_goal',goal);render()})});overlay.querySelector('[data-onboarding-prev]').disabled=step===0;overlay.querySelector('[data-onboarding-next]').textContent=step===onboardingSteps.length-1?'پایان و رفتن به حساب‌ها':'مرحله بعد'}overlay.querySelector('[data-onboarding-prev]').addEventListener('click',function(){if(step>0){step--;render()}});overlay.querySelector('[data-onboarding-next]').addEventListener('click',function(){if(step<onboardingSteps.length-1){step++;render();return}close(true);var settings=document.querySelector('.pa-tab[data-tab="settings"]');if(settings){settings.click();setTimeout(function(){var account=Array.prototype.find.call(document.querySelectorAll('.pa-set-nav-btn'),function(node){return /حساب/.test(node.textContent)});if(account)account.click()},350)}});overlay.querySelector('[data-onboarding-skip]').addEventListener('click',function(){close(false)});overlay.querySelector('.pa-ux-close').addEventListener('click',function(){close(false)});overlay.addEventListener('keydown',function(event){if(event.key==='Escape')close(false)});render();setTimeout(function(){overlay.querySelector('.pa-ux-close').focus()},30)}
  var tourSteps=[
    {selector:'.pa-tab[data-tab="dashboard"]',activate:true,title:'داشبورد و نمای کلی',body:'از این بخش موجودی حساب، سود و زیان، نرخ برد، منحنی سرمایه، معاملات اخیر و تصویر کلی عملکردت را بررسی کن.'},
    {selector:'.pa-tab[data-tab="new"]',activate:true,title:'ثبت معامله جدید',body:'نماد، جهت، زمان، نتیجه، اندازه موقعیت، ریسک، دلیل ورود، احساسات و یادداشت معامله را کامل ثبت کن تا بعداً قابل تحلیل باشد.'},
    {selector:'.pa-tab[data-tab="history"]',activate:true,title:'تاریخچه معاملات',body:'همه معاملات را جست‌وجو، فیلتر و ویرایش کن. برای بازبینی دقیق، هر معامله را باز کن و جزئیات و تصاویرش را ببین.'},
    {selector:'.pa-tab[data-tab="calendar"]',activate:true,title:'تقویم و Heatmap',body:'توزیع نتیجه‌ها را در روزها و هفته‌ها ببین و روزهای پرتکرار سود، زیان یا معامله بیش‌ازحد را پیدا کن.'},
    {selector:'.pa-tab[data-tab="prop"]',activate:true,title:'قوانین پراپ‌فرم',body:'محدودیت افت روزانه، افت کل، هدف سود و قوانین حساب چالش را ثبت کن تا وضعیت عبور یا نقض قوانین همیشه مشخص باشد.'},
    {selector:'.pa-tab[data-tab="risk"]',activate:true,title:'ریسک و بینش هوشمند',body:'افت سرمایه، میانگین ریسک، توزیع حجم، امید ریاضی و الگوهای خطرناک را مرور کن و برای دوره بعد اقدام مشخص بساز.'},
    {selector:'.pa-tab[data-tab="checklist"]',activate:true,title:'چک‌لیست معاملاتی',body:'شرایط قبل از ورود و قوانین بعد از معامله را تعریف کن. قبل از ثبت معامله، رعایت موارد چک‌لیست را کنترل کن.'},
    {selector:'.pa-tab[data-tab="documents"]',activate:true,title:'مستندات و گالری',body:'تصویر قبل و بعد معامله، سناریو، خطوط تحلیلی و شواهد اجرای پلن را کنار همان معامله نگهداری و مقایسه کن.'},
    {selector:'.pa-tab[data-tab="import"]',activate:true,title:'ورود اطلاعات',body:'فایل CSV یا خروجی MetaTrader را وارد کن، ستون‌ها را تطبیق بده و قبل از ثبت نهایی، داده‌های شناسایی‌شده را بازبینی کن.'},
    {selector:'.pa-tab[data-tab="settings"]',activate:true,title:'حساب‌ها و تنظیمات',body:'حساب‌های معاملاتی، موجودی شروع، برداشت‌ها، ظاهر، نسخه پشتیبان، امنیت و تنظیمات شخصی ژورنال را مدیریت کن.'},
    {selector:'.pa-tab[data-tab="pwa"]',activate:true,title:'اپ همراه و نصب PWA',body:'SmartJournal را روی موبایل یا دسکتاپ نصب کن تا مانند اپ مستقل باز شود و دسترسی سریع‌تری به ژورنال داشته باشی.'},
    {selector:'.pa-plan-access-pill',title:'پلن و زمان باقی‌مانده',body:'نام پلن فعال و روزهای باقی‌مانده اینجا نمایش داده می‌شود. بخش‌هایی که پلنت اجازه ندهد به‌صورت خودکار مخفی می‌شوند.'},
    {selector:'.pa-support-launcher',title:'پشتیبانی و تیکت‌ها',body:'برای ساخت تیکت، دیدن وضعیت، خواندن پاسخ مدیر و ادامه گفتگو روی دکمه «پشتیبانی» بزن. پاسخ مدیر همین‌جا نمایش داده می‌شود.'},
    {selector:'.pa-ux-help',title:'اجرای دوباره آموزش جامع',body:'هر زمان نیاز داشتی، با زدن همین علامت سؤال آموزش کامل همه بخش‌های در دسترس ژورنال را دوباره اجرا کن.'}
  ];
  function closeTour(done){document.getElementById('pa-ux-highlight')?.remove();document.getElementById('pa-ux-tour')?.remove();tourTarget=null;currentTour=-1;if(done)safeStorage('local',TOUR_DONE,'1');document.querySelector('.pa-ux-help')?.focus()}
  function positionTour(target,tip,highlight){var rect=target.getBoundingClientRect(),pad=7;highlight.style.cssText='top:'+(rect.top-pad)+'px;left:'+(rect.left-pad)+'px;width:'+(rect.width+pad*2)+'px;height:'+(rect.height+pad*2)+'px';var mobile=innerWidth<650;if(!mobile){var left=Math.max(14,Math.min(innerWidth-354,rect.right+18)),top=Math.max(14,Math.min(innerHeight-tip.offsetHeight-14,rect.top));if(rect.right+370>innerWidth)left=Math.max(14,rect.left-tip.offsetWidth-18);tip.style.left=left+'px';tip.style.top=top+'px'}}
  function showTour(index,direction){direction=direction||1;var item,target;while(index>=0&&index<tourSteps.length){item=tourSteps[index];target=document.querySelector(item.selector);if(visible(target))break;index+=direction}if(index<0||index>=tourSteps.length)return closeTour(true);currentTour=index;if(item.activate&&target.matches('.pa-tab[data-tab]'))target.click();target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});setTimeout(function(){if(!visible(target))return showTour(index+direction,direction);var highlight=document.getElementById('pa-ux-highlight')||document.body.appendChild(Object.assign(document.createElement('div'),{id:'pa-ux-highlight',className:'pa-ux-highlight'})),tip=document.getElementById('pa-ux-tour')||document.body.appendChild(Object.assign(document.createElement('section'),{id:'pa-ux-tour',className:'pa-ux-tour'}));tip.setAttribute('role','dialog');tip.setAttribute('aria-label','آموزش جامع ژورنال');tip.innerHTML='<small>مرحله '+(index+1)+' از '+tourSteps.length+'</small><h3>'+item.title+'</h3><p>'+item.body+'</p><footer><button class="pa-ux-btn text" data-tour-close>بستن</button><div><button class="pa-ux-btn" data-tour-prev '+(index===0?'disabled':'')+'>قبلی</button><button class="pa-ux-btn primary" data-tour-next>'+(index===tourSteps.length-1?'پایان':'بعدی')+'</button></div></footer>';tip.querySelector('[data-tour-close]').onclick=function(){closeTour(false)};tip.querySelector('[data-tour-prev]').onclick=function(){showTour(index-1,-1)};tip.querySelector('[data-tour-next]').onclick=function(){showTour(index+1,1)};tourTarget=target;positionTour(target,tip,highlight);tip.querySelector('[data-tour-next]').focus()},item.activate?420:180)}
  function openTour(){closeTour(false);showTour(0)}
  function installHelp(){if(document.querySelector('.pa-ux-help'))return;var button=document.createElement('button');button.type='button';button.className='pa-ux-help';button.setAttribute('aria-label','آموزش جامع همه بخش‌های ژورنال');button.title='آموزش جامع ژورنال';button.textContent='؟';button.addEventListener('click',openTour);document.body.appendChild(button)}
  function enhanceEmptyStates(){Array.prototype.forEach.call(document.querySelectorAll('.pa-empty,.pa-checklist-empty,.pa-compare-empty,.pa-security-empty'),function(node){if(node.dataset.uxEnhanced||!visible(node)||/در حال|loading/i.test(node.textContent))return;node.dataset.uxEnhanced='1';node.classList.add('pa-ux-empty-enhanced');if(node.querySelector('button,a'))return;var text=node.textContent,action=null,label='شروع کن';if(/معامله|تاریخچه|نمودار|ستاپ/.test(text)){action='new';label='ثبت اولین معامله'}else if(/حساب/.test(text)){action='settings';label='مدیریت حساب‌ها'}else if(/چک.?لیست/.test(text)){action='checklist';label='ساخت چک‌لیست'}if(!action)return;var button=document.createElement('button');button.type='button';button.className='pa-ux-empty-cta';button.textContent=label;button.onclick=function(){var target=document.querySelector('.pa-tab[data-tab="'+action+'"]')||document.querySelector('.pa-mobile-nav button[aria-label*="ثبت"]');if(target)target.click()};node.appendChild(button)})}
  function enhanceLoading(){Array.prototype.forEach.call(document.querySelectorAll('.pa-app *'),function(node){if(node.children.length||node.dataset.uxLoading)return;var text=(node.textContent||'').trim();if(!/^در حال (بارگذاری|دریافت|همگام)/.test(text))return;node.dataset.uxLoading='1';node.classList.add('pa-ux-skeleton');node.setAttribute('role','status');node.setAttribute('aria-label',text)})}
  function updateVisibility(){var ready=appReady(),help=document.querySelector('.pa-ux-help');if(help)help.classList.toggle('is-visible',ready);if(ready&&safeStorage('local',ONBOARDING_PENDING)==='1'&&safeStorage('local',ONBOARDING_DONE)!=='1')openOnboarding()}
  function offlineBanner(){var banner=document.querySelector('.pa-ux-offline');if(!navigator.onLine){if(!banner){banner=document.createElement('div');banner.className='pa-ux-offline';banner.setAttribute('role','status');banner.textContent='اتصال اینترنت قطع است؛ تغییرات پس از اتصال دوباره همگام می‌شوند.';document.body.appendChild(banner)}}else if(banner){banner.remove();feedback('اتصال اینترنت دوباره برقرار شد.')}}
  installHelp();offlineBanner();window.addEventListener('online',offlineBanner);window.addEventListener('offline',offlineBanner);window.addEventListener('resize',function(){var tip=document.getElementById('pa-ux-tour'),highlight=document.getElementById('pa-ux-highlight');if(tip&&highlight&&tourTarget)positionTour(tourTarget,tip,highlight)},{passive:true});document.addEventListener('keydown',function(event){if(event.key==='Escape'&&currentTour>=0)closeTour(false)});window.addEventListener('unhandledrejection',function(event){var message=String(event.reason&&event.reason.message||'');if(/fetch|network|ارتباط|Failed to fetch/i.test(message))feedback('ارتباط با سرور کامل نشد. اتصال اینترنت را بررسی و دوباره تلاش کن.','error')});document.addEventListener('pa-operation-feedback',function(event){feedback(event.detail&&event.detail.message||'عملیات انجام شد.',event.detail&&event.detail.type)});
  var timer=0;function schedule(){clearTimeout(timer);timer=setTimeout(function(){updateVisibility();enhanceEmptyStates();enhanceLoading();Array.prototype.forEach.call(document.querySelectorAll('[aria-busy="true"],.is-loading'),function(node){if(node.matches('button,[role="button"]'))node.setAttribute('aria-label',(node.textContent||'عملیات').trim()+'؛ در حال انجام')})},120)}new MutationObserver(schedule).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','hidden','aria-busy']});schedule();setInterval(updateVisibility,900);
  window.PAUX={feedback:feedback,onboarding:openOnboarding,tour:openTour};
})();

/* ==========================================================================
   چیدمان عناصر شناور و ظاهر حرفه‌ای موبایل  (pa-dock)
   --------------------------------------------------------------------------
   نسخهٔ قبلی فقط پنج عنصر مشخص را می‌چید و سه چیز را ندیده بود:

     ۱) نوار «ثبت معامله جدید / پاک کردن فرم» (.pa-form-actions-bar) که
        روی موبایل دقیقاً روی نوار پایین و دکمه‌های شناور می‌افتاد.
     ۲) دکمهٔ گرد «+» که ۳۰ پیکسل از نوار پایین بیرون می‌زند و روی
        دکمهٔ پشتیبانی می‌نشست (چون فرزندِ یک عنصر fixed بود، از چشم
        تست قبلی پنهان ماند).
     ۳) حباب اشتراک (.ctcu-fab) که روی دسکتاپ روی ستون کناری می‌افتاد —
        حالا طبق خواستهٔ کاربر بالای صفحه (سمت چپ هدر) می‌نشیند و در
        موبایل هم همان‌جا می‌ماند، فقط جمع‌وجورتر.

   حالا همه چیز از یک «قرارداد» واحد پیروی می‌کند:

     --pa-nav-h    ارتفاع نوار پایین
     --pa-fab-out  مقداری که دکمهٔ + بیرون می‌زند
     --pa-dock-b   فاصلهٔ ردیف دکمه‌های کمکی از پایین (بالای دکمهٔ +)
     --pa-rail-w   عرض واقعی ستون کناری روی دسکتاپ (با JS اندازه‌گیری می‌شود)

   و محتوای صفحه به اندازهٔ کل این ارتفاع padding می‌گیرد تا هیچ دکمه‌ای
   زیر عناصر شناور پنهان نشود.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__PA_FLOAT_LAYOUT__) return;
  window.__PA_FLOAT_LAYOUT__ = true;

  var css = `
:root{
  --pa-safe-b: env(safe-area-inset-bottom, 0px);
  --pa-actionbar-h: 0px;
  --pa-nav-gap: 8px;
  --pa-nav-h: 64px;
  --pa-fab-out: 26px;
  --pa-dock-btn: 46px;
  --pa-dock-b: calc(var(--pa-nav-gap) + var(--pa-nav-h) + var(--pa-fab-out) + 10px + var(--pa-safe-b));
  --pa-rail-w: 0px;
  --pa-topbar-h: 57px;
}

/* ═══════════ دسکتاپ: یک ستون مرتب در گوشهٔ پایین‌چپ ═══════════ */
html body .pa-auth-userbar{bottom:16px!important;max-width:236px}
.pa-auth-userbar .pa-auth-usercopy span{display:none}
html body .pa-support-launcher{bottom:78px!important;width:126px;height:44px;font-size:9.5px}
html body .pa-ux-help{bottom:78px!important;width:44px;height:44px;font-size:16px}
html body #pa-auth-manage,html body #pa-auth-logout{min-width:40px;min-height:40px}

/* حباب اشتراک بالای صفحه می‌نشیند (کنار هدر، سمت چپ)؛ نه پایین، نه روی ستون کناری */
html body .ctcu-fab{top:12px!important;left:12px!important;right:auto!important;bottom:auto!important}

/* ═══════════ کنار رفتن ستون شناور هنگام اسکرول (همهٔ اندازه‌ها) ═══════════
   درخواست کاربر: «در دسکتاپ هم مثل موبایل، دکمه‌های پایین‌چپ با اسکرول
   کنار بروند». پایه اینجاست تا هر دو حالت یک رفتار داشته باشند؛ مقدار
   جابه‌جایی موبایل داخل مدیا-کوئری پایین‌تر بازنویسی می‌شود. */
html body .pa-auth-userbar,
html body .pa-support-launcher,
html body .pa-ux-help{transition:transform .22s ease, opacity .22s ease;will-change:transform}
html.pa-dock-away body .pa-auth-userbar,
html.pa-dock-away body .pa-support-launcher,
html.pa-dock-away body .pa-ux-help{
  transform:translateY(170px);opacity:0;pointer-events:none}
@media (prefers-reduced-motion: reduce){
  html body .pa-auth-userbar,
  html body .pa-support-launcher,
  html body .pa-ux-help{transition:none}
}

/* تا وقتی فرم «معامله جدید» باز است، صفحه سه چیز هم‌زمان پایین دارد:
   نوار ثبت، ریل خلاصه، و (روی موبایل) نوار پایین. جا برای دکمه‌های کمکی
   نمی‌ماند و هر جا بگذاریمشان روی یک فیلد یا دکمه می‌افتند — با اندازه‌گیری
   در ۶ اندازهٔ صفحه ثابت شد. پس در تمام اندازه‌ها موقتاً کنار می‌روند و
   به‌محض خروج از فرم برمی‌گردند. رفتار یکدست، بدون تداخل. */
html.pa-actionbar body .pa-auth-userbar,
html.pa-actionbar body .pa-support-launcher,
html.pa-actionbar body .pa-ux-help{display:none!important}

/* ریلِ کناری فرم تا روی دکمه‌های شناور نیاید */
#pa-new-trade-form > .pa-form-rail{
  max-height:calc(100vh - 190px - var(--pa-actionbar-h));
  overflow-y:auto;
  overscroll-behavior:contain;
  padding-inline-end:2px;
}

/* ═══════════ کشوی کناری دسکتاپ: دکمهٔ باز و بسته شدن ═══════════
   درخواست کاربر: «برای دسکتاپ توی بخش ژورنال، کشوی بغل صفحه رو باتن
   باز و بسته شدن بزار». دکمهٔ «بستن منو» داخل ردیف برند می‌نشیند و با
   کشو می‌رود؛ موقع بسته بودن، یک دستگیرهٔ باریک لبهٔ راست صفحه می‌ماند. */
.pa-rail-toggle{
  display:none;align-items:center;gap:6px;margin-inline-start:auto;flex:none;
  min-height:30px;padding:0 10px;border-radius:9px;cursor:pointer;
  border:1px solid rgba(137,158,190,.22);background:rgba(255,255,255,.035);
  color:#93a5b9;font:600 9.5px/1 Vazirmatn,Tahoma,sans-serif;
  transition:border-color .2s ease, color .2s ease, background .2s ease;
}
.pa-rail-toggle:hover{border-color:rgba(37,213,237,.45);color:#bdf4ff;background:rgba(37,213,237,.08)}
.pa-rail-toggle svg{width:14px;height:14px;flex:none}
.pa-rail-open-handle{
  display:none;position:fixed;z-index:2147483490;top:50%;right:0;
  transform:translateY(-50%);width:26px;height:64px;align-items:center;justify-content:center;
  border:1px solid rgba(37,213,237,.32);border-right:0;border-radius:14px 0 0 14px;
  background:linear-gradient(180deg, rgba(15,24,38,.97), rgba(9,14,23,.97));
  color:#9ceefc;cursor:pointer;box-shadow:-12px 0 34px -16px #000;
}
.pa-rail-open-handle svg{width:17px;height:17px}
@media(min-width:901px){
  .pa-rail-toggle{display:inline-flex}
  .pa-header,.pa-app{transition:transform .3s ease, padding-inline-start .3s ease}
  .pa-header{will-change:transform}
  html.pa-rail-closed .pa-header{transform:translateX(100%)}
  html.pa-rail-closed .pa-app{padding-inline-start:0}
  html.pa-rail-closed .pa-rail-open-handle{display:flex}
}

/* ═══════════ موبایل ═══════════ */
@media (max-width:760px){

  /* — نوار پایین: اندازهٔ ایکون‌ها و هدف لمسی استاندارد — */
  html body .pa-mobile-nav{
    height:var(--pa-nav-h)!important;
    bottom:calc(var(--pa-nav-gap) + var(--pa-safe-b))!important;
    padding:5px 6px!important;border-radius:20px!important;
  }
  .pa-mobile-nav > button{font-size:9.5px!important;gap:4px!important;border-radius:14px!important;letter-spacing:0}
  .pa-mobile-nav > button > span{font-size:20px!important;line-height:1!important}
  .pa-mobile-nav > button > span[data-pa-icon]{font-size:0!important;display:grid;place-items:center;height:21px}
  .pa-mobile-nav > button > span[data-pa-icon] svg{width:21px;height:21px;display:block}
  .pa-mobile-nav .pa-mobile-quick > span{
    width:54px!important;height:54px!important;
    margin-top:calc(-1 * var(--pa-fab-out))!important;
    border-width:3px!important;font-size:27px!important;
  }
  .pa-mobile-nav .pa-mobile-quick > span[data-pa-icon] svg{width:26px;height:26px;stroke-width:2.4}
  .pa-mobile-nav .pa-mobile-quick > b{font-size:9px!important;margin-top:3px!important}

  /* — ردیف دکمه‌های کمکی: چپ = کاربر، راست = پشتیبانی و راهنما — */
  html body .pa-auth-userbar{
    box-sizing:border-box;
    left:10px!important;right:auto!important;
    bottom:var(--pa-dock-b)!important;
    max-width:none!important;width:auto!important;
    height:var(--pa-dock-btn);gap:5px!important;padding:4px 6px!important;
  }
  .pa-auth-userbar .pa-auth-usercopy{display:none!important}
  .pa-auth-userbar .pa-auth-avatar{width:36px;height:36px;font-size:11px;flex:none}
  #pa-auth-manage,#pa-auth-logout{
    width:40px;min-width:40px;height:40px;padding:0!important;
    display:grid!important;place-items:center;
  }
  #pa-auth-manage > span{display:none!important}
  #pa-auth-manage svg,#pa-auth-logout svg{width:17px;height:17px}

  html body .pa-support-launcher{
    left:auto!important;right:calc(var(--pa-dock-btn) + 18px)!important;
    bottom:var(--pa-dock-b)!important;
    width:var(--pa-dock-btn)!important;height:var(--pa-dock-btn)!important;
    padding:0!important;justify-content:center!important;
  }
  .pa-support-launcher > span{display:none!important}
  .pa-support-launcher svg{width:21px;height:21px}
  html body .pa-ux-help{
    left:auto!important;right:10px!important;
    bottom:var(--pa-dock-b)!important;
    width:var(--pa-dock-btn)!important;height:var(--pa-dock-btn)!important;
    font-size:17px!important;
  }

  /* حباب اشتراک روی موبایل: فقط در داشبورد می‌ماند (همان جایی که کاربر خواست).
     در تب‌های محتوایی (تقویم، ریسک، چک‌لیست، تنظیمات…) متنِ سربرگ کل عرض را
     می‌گیرد و هر جایگاه ثابتی با آن تداخل می‌کند — با اندازه‌گیری مرورگر ثابت شد.
     در داشبورد هم دقیقاً زیر نوار چسبانِ حساب‌ها می‌نشیند (--pa-topbar-h). */
  html body .ctcu-fab{display:none!important}
  html[data-pa-view="dashboard"] body .ctcu-fab{display:flex!important;top:calc(var(--pa-topbar-h,57px) + 8px)!important;left:8px!important;gap:6px!important;padding:6px 9px!important;border-radius:12px!important}
  html[data-pa-view="dashboard"] body .ctcu-fab .ctcu-buy{min-height:27px;padding:0 10px}

  /* هنگام اسکرول به پایین، سه دکمهٔ کمکی نرم کنار می‌روند تا جلوی محتوا
     را نگیرند؛ با اسکرول به بالا یا ابتدای صفحه برمی‌گردند. اندازه‌گیری
     در ۱۱ تب نشان داد در «تقویم»، «چک‌لیست» و «اپ همراه» این دکمه‌ها
     دقیقاً روی دکمه‌های صفحه می‌نشستند. */
  html body .pa-auth-userbar,
  html body .pa-support-launcher,
  html body .pa-ux-help{transition:transform .22s ease, opacity .22s ease;will-change:transform}
  html.pa-dock-away body .pa-auth-userbar,
  html.pa-dock-away body .pa-support-launcher,
  html.pa-dock-away body .pa-ux-help{
    transform:translateY(calc(var(--pa-dock-btn) + 22px));opacity:0;pointer-events:none}
  @media (prefers-reduced-motion: reduce){
    html body .pa-auth-userbar,
    html body .pa-support-launcher,
    html body .pa-ux-help{transition:none}
  }

  /* — کف اندازهٔ متن داخل برنامه —
     اندازه‌گیری در ۱۱ تب: برچسب‌هایی از ۷٫۵ تا ۱۰٫۵ پیکسل که روی گوشی
     خوانا نیستند. این‌ها برچسب‌اند نه متن انبوه، پس ۱۱ پیکسل کافی است. */
  .pa-feature-eyebrow,.pa-feature-kicker,
  .pa-form-hero-eyebrow,.pa-check-hero-eyebrow,
  .pa-offline-badge,.pa-acc-metric-l,.pa-check-stat-l,
  .pa-metric-f,.pa-hero-pill,.pa-autosave-pill{font-size:11px!important}

  /* هدف لمسی دکمهٔ جست‌وجوی نماد (۳۱ پیکسل بود) */
  .pa-symbol-search-toggle{min-width:44px!important}

  /* کف خوانایی: کلاسی که پویشگر پایین روی برچسب‌های زیر ۱۱ پیکسل می‌گذارد */
  .pa-min-text{font-size:11px!important}

  /* — نوار ثبت فرم بالای دکمهٔ + بنشیند، و دکمه‌های کمکی موقتاً کنار بروند — */
  html body .pa-form-actions-bar,
  html body #pa-new-trade-form .pa-form-actions-bar{bottom:var(--pa-dock-b)!important}
  html.pa-actionbar .pa-auth-userbar,
  html.pa-actionbar .pa-support-launcher,
  html.pa-actionbar .pa-ux-help{display:none!important}

  /* — محتوا هیچ‌وقت زیر عناصر شناور پنهان نشود — */
  body main{padding-bottom:calc(var(--pa-dock-b) + var(--pa-dock-btn) + 14px)!important}

  /* — نوار حساب‌ها: یک ردیف قابل کشیدن، نه سه ردیف چیده‌شده — */
  html body .pa-accounts-bar{
    flex-wrap:nowrap!important;overflow-x:auto!important;
    min-height:0!important;padding:8px 12px!important;gap:6px!important;
    scrollbar-width:none;-webkit-overflow-scrolling:touch;
  }
  .pa-accounts-bar::-webkit-scrollbar{display:none}
  .pa-accounts-bar > *{flex:0 0 auto!important}

  /* ریل فرم روی موبایل ارتفاع آزاد دارد */
  #pa-new-trade-form > .pa-form-rail{max-height:none;overflow:visible}
}

/* — عرض‌های میانی (۷۶۱ تا ۹۰۰): همان منطق موبایل؛ حباب فقط در داشبورد،
     روی بخش خالیِ نوار حساب‌ها — چون در تب‌های محتوایی متن سربرگ تداخل دارد — */
@media (min-width:761px) and (max-width:900px){
  html body .ctcu-fab{display:none!important}
  html[data-pa-view="dashboard"] body .ctcu-fab{display:flex!important;top:12px!important;left:12px!important}
}

/* دسکتاپ باریک (۹۰۱ تا ۱۱۵۰): حباب همیشه هست؛ فقط نقطهٔ وضعیت حذف می‌شود
   تا لبهٔ آن به متنِ سربرگِ «ریسک» و «چک‌لیست» نرسد (اندازه‌گیری مرورگر) */
@media (min-width:901px) and (max-width:1150px){
  html body .ctcu-fab .ctcu-dot{display:none!important}
}

/* — نوار حساب‌ها فقط در داشبورد — */
html[data-pa-view="other"] .pa-accounts-bar{display:none!important}

/* ═══════════ چاپ گزارش ═══════════
   قوانین این شیت با specificity «html body .x» و !important نوشته شده‌اند،
   پس بلوک چاپِ استایل‌شیت اصلی نمی‌تواند خاموششان کند. ضمناً باید آخرین
   قانونِ همین فایل باشد، وگرنه media queryهای بالاتر دوباره حباب اشتراک را
   با display:flex!important برمی‌گردانند. بدون این بلوک، حباب «۷ روز مانده»
   و دکمه‌های شناور روی هر صفحهٔ PDF چاپ می‌شدند. */
@media print{
  html body .ctcu-fab,
  html body .ctcu-ov,
  html[data-pa-view="dashboard"] body .ctcu-fab,
  html body .pa-ux-help,
  html body .pa-support-launcher,
  html body .pa-support-panel,
  html body .pa-auth-userbar,
  html body .pa-mobile-nav,
  html body .pa-mobile-dock,
  html body .pa-float-col,
  html body .pa-accounts-bar,
  html body #pa-auth-manage,
  html body #pa-auth-logout{display:none!important}
  html body main{padding-bottom:0!important}
}
`;

  function inject() {
    if (document.getElementById('pa-float-layout')) return;
    var st = document.createElement('style');
    st.id = 'pa-float-layout';
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }
  inject();

  /* ───────── ایکون‌های برداری نوار پایین ─────────
     قبلاً از حروف «⌂ ≡ ▦ ⋯» استفاده می‌شد؛ این‌ها روی اندروید و آیفون
     با فونت‌های متفاوت و اندازه‌های ناهماهنگ رندر می‌شوند. حالا SVG
     یکدست با ضخامت و اندازهٔ ثابت. */
  var ICONS = {
    dashboard: '<path d="M3 10.6 12 3.2l9 7.4"/><path d="M5.4 9.4V20.4h13.2V9.4"/><path d="M9.8 20.4v-6h4.4v6"/>',
    history: '<circle cx="12" cy="12" r="8.6"/><path d="M12 6.9V12l3.4 2.1"/>',
    quick: '<path d="M12 5.2v13.6M5.2 12h13.6"/>',
    calendar: '<rect x="3.4" y="5.2" width="17.2" height="15.4" rx="2.6"/><path d="M8.2 3v4.2M15.8 3v4.2M3.4 10.6h17.2"/>',
    more: '<circle cx="5.2" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18.8" cy="12" r="1.7"/>'
  };
  function iconFor(label) {
    if (/داشبورد|خانه/.test(label)) return ICONS.dashboard;
    if (/تاریخچه|معاملات/.test(label)) return ICONS.history;
    if (/ثبت|سریع|جدید/.test(label)) return ICONS.quick;
    if (/تقویم|ماه/.test(label)) return ICONS.calendar;
    if (/بیشتر|منو/.test(label)) return ICONS.more;
    return null;
  }
  function paintNavIcons() {
    var nav = document.querySelector('.pa-mobile-nav');
    if (!nav) return;
    Array.prototype.forEach.call(nav.children, function (btn) {
      var glyph = btn.querySelector(':scope > span');
      if (!glyph || glyph.getAttribute('data-pa-icon')) return;
      var path = iconFor((btn.innerText || '').replace(/\s+/g, ' ').trim());
      if (!path) return;
      glyph.setAttribute('data-pa-icon', '1');
      glyph.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>';
    });
  }

  /* ───────── وضعیت صفحه ───────── */
  function currentView() {
    var tabs = [].slice.call(document.querySelectorAll('.pa-header .pa-tab')), idx = -1;
    for (var i = 0; i < tabs.length; i++) if (/\bactive\b/.test(tabs[i].className)) { idx = i; break }
    if (idx >= 0) {
      var t = tabs[idx],
        label = t.getAttribute('title') || t.getAttribute('aria-label') || (t.textContent || '');
      return (idx === 0 || /داشبورد/.test(label)) ? 'dashboard' : 'other';
    }
    var m = document.querySelector('.pa-mobile-nav button.active');
    if (m) return /داشبورد/.test(m.innerText || '') ? 'dashboard' : 'other';
    return 'dashboard';
  }

  function shown(el) {
    if (!el) return false;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    var r = el.getBoundingClientRect();
    return r.width > 8 && r.height > 8;
  }

  /* عرض واقعی ستون کناری روی دسکتاپ، تا حباب اشتراک رویش نیفتد */
  function railWidth() {
    var head = document.querySelector('.pa-header');
    if (!head || innerWidth <= 760) return 0;
    var cs = getComputedStyle(head);
    if (cs.position !== 'fixed' && cs.position !== 'sticky') return 0;
    var r = head.getBoundingClientRect();
    if (r.left >= innerWidth - 4 || r.right <= 4) return 0;   /* کشویی و بیرون از دید */
    if (r.width >= innerWidth - 40) return 0;                  /* تمام‌صفحه */
    return Math.max(0, Math.round(innerWidth - r.left));
  }

  var lastView = null, lastBar = null, lastRail = null, lastBarH = null, lastTopH = null;
  function sync() {
    var root = document.documentElement;

    var view = currentView();
    if (view !== lastView) { lastView = view; root.setAttribute('data-pa-view', view); }

    var barEl = document.querySelector('.pa-form-actions-bar');
    var bar = shown(barEl);
    if (bar !== lastBar) { lastBar = bar; root.classList.toggle('pa-actionbar', bar); }
    var barH = 0;
    if (bar) {
      var br = barEl.getBoundingClientRect();
      barH = Math.max(0, Math.round(innerHeight - br.top));
    }
    if (barH !== lastBarH) { lastBarH = barH; root.style.setProperty('--pa-actionbar-h', barH + 'px'); }

    var rw = railWidth();
    if (rw !== lastRail) { lastRail = rw; root.style.setProperty('--pa-rail-w', rw + 'px'); }

    /* ارتفاع نوار حساب‌ها (نوار چسبانِ بالای موبایل) — حباب اشتراک زیر آن
       می‌نشیند. آخرین مقدار غیرصفر نگه داشته می‌شود تا وقتی نوار در تب‌های
       دیگر پنهان است حباب ناگهان بالا نپرد. */
    var accEl = document.querySelector('.pa-accounts-bar');
    var accH = (accEl && accEl.getClientRects().length) ? Math.ceil(accEl.getBoundingClientRect().height) : 0;
    if (accH > 0 && accH !== lastTopH) { lastTopH = accH; root.style.setProperty('--pa-topbar-h', accH + 'px'); }

    paintNavIcons();
    installRailToggle();
    readabilityPass();
  }
  /* ───────── کشوی کناری دسکتاپ: دکمهٔ باز/بسته —─────────
     دکمهٔ «بستن منو» داخل ردیف برندِ کشو می‌نشیند؛ وقتی کشو بسته است یک
     دستگیرهٔ باریک لبهٔ راست می‌ماند. وضعیت در localStorage ذخیره می‌شود.
     اگر رندر React دکمه را بردارد، در پاس بعدی دوباره اضافه می‌شود. */
  function setRailClosed(closed) {
    document.documentElement.classList.toggle('pa-rail-closed', closed);
    try { localStorage.setItem('pa_rail_closed', closed ? '1' : '0'); } catch (e) {}
    var handle = document.querySelector('.pa-rail-open-handle');
    if (handle) handle.setAttribute('aria-expanded', closed ? 'false' : 'true');
  }
  function installRailToggle() {
    if (innerWidth < 901) return;
    var head = document.querySelector('.pa-header');
    var brand = head && head.querySelector('.pa-brand');
    if (!brand || document.querySelector('.pa-rail-toggle')) return;
    var closed = false;
    try { closed = localStorage.getItem('pa_rail_closed') === '1'; } catch (e) {}
    setRailClosed(closed);

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pa-rail-toggle';
    btn.title = 'بستن منوی کناری';
    btn.setAttribute('aria-label', 'بستن منوی کناری');
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" aria-hidden="true"><path d="m9 18 6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg><span>بستن منو</span>';
    btn.onclick = function () { setRailClosed(true); };
    brand.appendChild(btn);

    if (document.querySelector('.pa-rail-open-handle')) return;
    var handle = document.createElement('button');
    handle.type = 'button';
    handle.className = 'pa-rail-open-handle';
    handle.setAttribute('aria-label', 'باز کردن منوی کناری');
    handle.setAttribute('aria-expanded', closed ? 'false' : 'true');
    handle.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" aria-hidden="true"><path d="m15 18-6-6 6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    handle.onclick = function () { setRailClosed(false); };
    document.body.appendChild(handle);
  }
  /* ───────── کف خوانایی متن داخل برنامه (فقط موبایل) ─────────
     چرا با JS و نه CSS؟ CSS «حداقل اندازهٔ فونت» ندارد و این برچسب‌ها ده‌ها
     کلاس مختلف (و بعضاً بی‌کلاس) دارند. اندازه‌گیری در ۱۱ تب: مقادیری از
     ۷٫۵ تا ۱۰٫۵ پیکسل. اینجا فقط برگ‌های متنی داخل .pa-app بررسی می‌شوند،
     عناصر تزئینی و نوار پایین کنار گذاشته می‌شوند، و سقف ۸۰۰ عنصر در هر
     پویش رعایت می‌شود تا هزینه‌ای روی رندر نگذارد. */
  var SKIP = '.pa-mobile-nav, .pa-l-terminal, .pa-l-ticker, .pa-l-hud-rail, .pa-min-text';
  var seen = (typeof WeakSet === 'function') ? new WeakSet() : null;
  function readabilityPass() {
    if (innerWidth > 760) return;
    var app = document.querySelector('.pa-app');
    if (!app) return;
    var nodes = app.querySelectorAll('span,small,p,label,b,td,th,button,a,div');
    var n = 0;
    for (var i = 0; i < nodes.length && n < 800; i++) {
      var el = nodes[i];
      if (seen && seen.has(el)) continue;
      if (el.children.length) continue;                       /* فقط برگ متنی */
      var txt = el.textContent;
      if (!txt || !txt.trim()) continue;
      if (el.closest && el.closest(SKIP)) continue;
      n++;
      if (seen) seen.add(el);
      var fs = parseFloat(getComputedStyle(el).fontSize);
      if (fs && fs < 11) el.classList.add('pa-min-text');
    }
  }

  /* ───────── کنار رفتن دکمه‌های کمکی هنگام اسکرول به پایین ───────── */
  var lastY = 0, dockAway = false, ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      var y = window.scrollY || document.documentElement.scrollTop || 0;
      var down = y > lastY + 6, up = y < lastY - 6;
      lastY = y;
      var want = (y > 90 && down) ? true : ((up || y <= 90) ? false : dockAway);
      if (want !== dockAway) {
        dockAway = want;
        document.documentElement.classList.toggle('pa-dock-away', want);
      }
    });
  }
  addEventListener('scroll', onScroll, { passive: true });

  sync();
  /* بررسی سبک و زمان‌بندی‌شده — نه MutationObserver روی کل درخت
     (یک‌بار همین اشتباه اپ ری‌اکت را قفل کرد). */
  setInterval(sync, 500);
  document.addEventListener('click', function () { setTimeout(sync, 120); }, true);
  addEventListener('resize', function () { lastRail = null; sync(); }, { passive: true });
})();

/* ==========================================================================
   به‌روزرسانی خودکار Service Worker
   --------------------------------------------------------------------------
   باگ: نسخهٔ قبلی SW فایل‌های JS را «اول کش» سرو می‌کرد و نام کش هم ثابت بود،
   پس مرورگر کاربر تا ابد کد قدیمی را اجرا می‌کرد؛ هر رفع‌باگی که آپلود می‌شد
   عملاً به دست کاربر نمی‌رسید و ما فکر می‌کردیم فایل درست نصب نشده.

   حالا: هر بار که SW تازه‌ای کنترل را می‌گیرد، صفحه یک‌بار (و فقط یک‌بار در
   هر نشست) نو می‌شود تا کد جدید واقعاً اجرا شود.
   ========================================================================== */
(function () {
  'use strict';
  if (!('serviceWorker' in navigator)) return;
  var RELOADED = 'pa_sw_reloaded_v1';

  navigator.serviceWorker.addEventListener('controllerchange', function () {
    var already;
    try { already = sessionStorage.getItem(RELOADED); } catch (_) { already = '1'; }
    if (already) return;
    try { sessionStorage.setItem(RELOADED, '1'); } catch (_) {}
    location.reload();
  });

  function check() {
    navigator.serviceWorker.getRegistration().then(function (reg) {
      if (!reg) return;
      reg.update().catch(function () {});
      if (reg.waiting) reg.waiting.postMessage('pa-skip-waiting');
    }).catch(function () {});
  }
  addEventListener('load', function () { setTimeout(check, 1500); });
  setInterval(check, 15 * 60 * 1000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) check(); });
})();

