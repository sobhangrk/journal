'use strict';
/* ============================================================================
   SmartJournal — Service Worker

   ⚠️ باگ نسخه‌های قبل: نام کش ثابت بود («smartjournal-shell-v19») و فایل‌های
   JS با استراتژی «اول کش» سرو می‌شدند. یعنی هر مرورگری که یک‌بار سایت را باز
   کرده بود، تا ابد همان JS قدیمی را اجرا می‌کرد — هر چقدر هم روی سرور نسخهٔ
   جدید آپلود می‌شد. Ctrl+Shift+R هم روی موبایل چاره نبود.

   حالا:
     • نام کش از مهر build ساخته می‌شود (BUILD در زمان ساخت جایگزین می‌شود)
       → هر نسخهٔ جدید، کش قبلی را کاملاً دور می‌ریزد.
     • JS و HTML: «اول شبکه» (network-first) با برگشت به کش در حالت آفلاین
       → کاربر همیشه آخرین کد را می‌گیرد.
     • فونت و تصویر: «اول کش» (این‌ها تغییر نمی‌کنند و سنگین‌اند).
     • هر کش ناشناختهٔ قدیمی هم پاک می‌شود.
   ========================================================================== */

const BUILD = 'dev';                                   /* build:stamp */
const CACHE = 'smartjournal-' + BUILD;

/* فایل‌هایی که برای کارکرد آفلاین لازم‌اند */
const CODE = [
  '/journal-cloud.js', '/journal-cloud-auth.js', '/journal-ux-runtime.js',
  '/journal-plan-support.js', '/smartjournal-brand.js', '/site-accessibility.js',
  '/journal-card-payment.js', '/support-widget.js', '/manifest.webmanifest'
];
const STATIC = [
  '/fonts/vazirmatn-var.woff2', '/fonts/jetbrains-mono-var.woff2',
  '/media/smartjournal-logo-192.webp'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(STATIC).catch(() => null))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  if (event.data === 'pa-skip-waiting') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/admin') ||
      url.pathname.startsWith('/internal/') || url.pathname.startsWith('/journal/media/')) return;

  const isJournal = url.pathname.replace(/\/$/, '') === '/journal';

  /* صفحه‌ها: همیشه شبکه؛ کش فقط برای آفلاینِ /journal */
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).then(response => {
        if (response.ok && isJournal) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put('/journal', copy));
        }
        return response;
      }).catch(async () => {
        if (!isJournal) throw new Error('offline');
        const cached = await caches.match('/journal');
        if (!cached) throw new Error('offline');
        return cached;
      })
    );
    return;
  }

  /* کد برنامه: اول شبکه — تا به‌روزرسانی‌ها همیشه برسند */
  if (CODE.includes(url.pathname)) {
    event.respondWith(
      fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put(request, copy));
        }
        return response;
      }).catch(() => caches.match(request).then(c => {
        if (c) return c;
        throw new Error('offline');
      }))
    );
    return;
  }

  /* chunkهای برنامه (/app/journal-app.<hash>.js): نامشان hash محتواست، پس
     محتوایشان هرگز عوض نمی‌شود ⇒ «اول کش». هر نسخهٔ جدید نام جدید دارد و
     نسخهٔ قدیمی هم با تغییر نام کش در activate پاک می‌شود. این همان چیزی است
     که ورود دوبارهٔ کاربر به ژورنال را روی اینترنت موبایل آنی می‌کند. */
  if (/^\/app\/journal-(?:app|auth)\.[0-9a-f]{8}\.js$/.test(url.pathname)) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put(request, copy));
        }
        return response;
      }))
    );
    return;
  }

  /* فونت و لوگو: اول کش */
  if (STATIC.includes(url.pathname)) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put(request, copy));
        }
        return response;
      }))
    );
  }
});
