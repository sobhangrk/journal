/* ==========================================================================
   SmartJournal — خرید و تمدید اشتراک با کارت‌به‌کارت (سمت کاربر)
   شماره کارت را نشان می‌دهد، فیش و کد پیگیری می‌گیرد و به پنل مدیریت می‌فرستد.
   با نشست و CSRF واقعی همان Backend کار می‌کند.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__PA_CARD_PAYMENT__) return;
  window.__PA_CARD_PAYMENT__ = true;
  if (location.protocol === 'file:') return;

  var state = { auth: null, cards: [], plans: [], entitlement: null, tab: 'pay', file: null, busy: false };

  /* ------------------------------------------------------------ utils -- */
  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function fa(v) { try { return Number(v).toLocaleString('fa-IR'); } catch (e) { return v; } }
  function groupCard(v) { return String(v || '').replace(/(.{4})(?=.)/g, '$1-'); }
  function dateFa(v) {
    if (!v) return '—';
    try { return new Date(v).toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }); }
    catch (e) { return v; }
  }

  function json(url, options) {
    options = options || {};
    var headers = options.headers || {};
    if (options.body !== undefined) {
      headers['content-type'] = 'application/json';
      if (state.auth && state.auth.csrfToken) headers['x-csrf-token'] = state.auth.csrfToken;
    }
    return fetch(url, {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    }).then(function (response) {
      return response.text().then(function (text) {
        var data = {};
        try { data = JSON.parse(text); } catch (e) { data = {}; }
        if (!response.ok) {
          throw new Error(data.error || 'ارتباط با سرور برقرار نشد. کمی بعد دوباره تلاش کنید.');
        }
        return data;
      });
    });
  }

  function loadAuth() {
    return json('/api/auth/me')
      .then(function (d) { state.auth = d; return d; })
      .catch(function () { state.auth = null; return null; });
  }

  /* ----------------------------------------------------------- styles -- */
  if (!document.getElementById('pa-ctc-user-styles')) {
    var style = document.createElement('style');
    style.id = 'pa-ctc-user-styles';
    style.textContent = [
      '.ctcu-fab{position:fixed;top:12px;left:12px;z-index:2147483500;display:flex;align-items:center;gap:9px;',
      'padding:9px 13px;border-radius:14px;border:1px solid rgba(37,213,237,.34);background:rgba(11,17,26,.96);',
      'color:#dff6ff;font:400 11px/1.4 Vazirmatn,Tahoma,sans-serif;box-shadow:0 18px 46px -20px #000;',
      '-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}',
      '.ctcu-dot{width:8px;height:8px;border-radius:50%;background:#46e39b;box-shadow:0 0 9px #46e39b;flex:none}',
      '.ctcu-fab.off .ctcu-dot{background:#ff667a;box-shadow:0 0 9px #ff667a}',
      '.ctcu-meta{display:flex;flex-direction:column;line-height:1.45}',
      '.ctcu-meta small{font-size:8px;color:#7d8fa5}.ctcu-meta b{font-size:10.5px;color:#dff6ff}',
      '.ctcu-buy{min-height:29px;padding:0 12px;border-radius:9px;cursor:pointer;font:700 9.5px Vazirmatn;',
      'border:1px solid rgba(37,213,237,.55);background:rgba(37,213,237,.16);color:#bdf4ff}',
      '.ctcu-buy:hover{background:rgba(37,213,237,.3)}',
      '.ctcu-ov{position:fixed;inset:0;z-index:2147483600;display:flex;align-items:center;justify-content:center;padding:18px;',
      'background:rgba(4,7,12,.78);-webkit-backdrop-filter:blur(9px);backdrop-filter:blur(9px);',
      'font-family:Vazirmatn,Tahoma,sans-serif;direction:rtl}',
      '.ctcu-box{width:min(560px,100%);max-height:92vh;display:flex;flex-direction:column;overflow:hidden;border-radius:20px;',
      'border:1px solid rgba(37,213,237,.22);background:linear-gradient(180deg,#0d1420,#080c14);box-shadow:0 40px 100px -30px #000}',
      '.ctcu-head{display:flex;gap:12px;align-items:flex-start;padding:17px 20px 14px;border-bottom:1px solid rgba(137,158,190,.14)}',
      '.ctcu-head h3{margin:0;font:700 15px Vazirmatn;color:#f6f9ff}.ctcu-head>div{flex:1}',
      '.ctcu-eyebrow{display:block;font:600 8.5px/1 monospace;letter-spacing:.16em;color:#25d5ed;margin-bottom:7px}',
      '.ctcu-x{width:30px;height:30px;border-radius:9px;border:1px solid rgba(137,158,190,.2);background:rgba(255,255,255,.03);',
      'color:#93a2b8;font-size:17px;cursor:pointer;flex:none}',
      '.ctcu-body{padding:17px 20px 20px;overflow:auto}',
      '.ctcu-tabs{display:flex;gap:6px;padding:4px;margin-bottom:15px;border-radius:12px;background:rgba(137,158,190,.07)}',
      '.ctcu-tab{flex:1;min-height:33px;border:0;border-radius:9px;background:transparent;color:#8d9cb2;font:600 10.5px Vazirmatn;cursor:pointer}',
      '.ctcu-tab.on{background:rgba(37,213,237,.14);color:#8ceaf9;box-shadow:0 0 0 1px rgba(37,213,237,.26) inset}',
      '.ctcu-step{margin:0 0 4px;font:600 8.5px/1 monospace;letter-spacing:.14em;color:#5f7288}',
      '.ctcu-title{margin:0 0 5px;font:700 13px Vazirmatn;color:#eaf2ff}',
      '.ctcu-sub{margin:0 0 14px;font:400 10.5px/1.85 Vazirmatn;color:#8497aa}',
      '.ctcu-card{display:flex;align-items:center;gap:11px;margin-bottom:9px;padding:12px 13px;border-radius:14px;cursor:pointer;',
      'border:1px solid rgba(137,158,190,.16);background:rgba(255,255,255,.022)}',
      '.ctcu-card:hover{border-color:rgba(37,213,237,.34)}',
      '.ctcu-card.sel{border-color:rgba(37,213,237,.6);background:rgba(37,213,237,.09)}',
      '.ctcu-ic{flex:none;display:grid;place-items:center;width:36px;height:36px;border-radius:11px;color:#cfefff;font:700 14px Vazirmatn;',
      'background:linear-gradient(140deg,rgba(37,213,237,.2),rgba(132,108,255,.2))}',
      '.ctcu-cm{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
      '.ctcu-cm b{font:600 10.5px Vazirmatn;color:#e8f1ff}',
      '.ctcu-cm span{font:600 14px/1.2 monospace;color:#7ce7f8;direction:ltr;text-align:left;letter-spacing:.09em;unicode-bidi:embed}',
      '.ctcu-cm small{font:400 9px Vazirmatn;color:#6f8096}',
      '.ctcu-copy{flex:none;min-height:29px;padding:0 11px;border-radius:9px;cursor:pointer;font:600 9.5px Vazirmatn;',
      'border:1px solid rgba(37,213,237,.35);background:rgba(37,213,237,.1);color:#9ceefc}',
      '.ctcu-copy.done{border-color:rgba(70,227,155,.5);background:rgba(70,227,155,.16);color:#8df3c3}',
      '.ctcu-fields{display:grid;gap:11px;margin:15px 0 12px}',
      '.ctcu-fields label{display:flex;flex-direction:column;gap:6px;font:500 9.5px Vazirmatn;color:#8497aa}',
      '.ctcu-in,.ctcu-area{width:100%;min-height:38px;padding:9px 11px;border-radius:11px;box-sizing:border-box;outline:none;',
      'border:1px solid rgba(137,158,190,.2);background:rgba(6,10,17,.85);color:#eaf2ff;font:500 11px Vazirmatn}',
      '.ctcu-area{min-height:64px;resize:vertical}',
      '.ctcu-in:focus,.ctcu-area:focus{border-color:rgba(37,213,237,.55);box-shadow:0 0 0 3px rgba(37,213,237,.1)}',
      '.ctcu-in.ltr{direction:ltr;text-align:left;font-family:monospace;letter-spacing:.06em}',
      '.ctcu-in.bad{border-color:rgba(255,102,122,.6)}',
      'select.ctcu-in option{background:#0b1119;color:#eaf2ff}',
      '.ctcu-drop{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:96px;',
      'padding:14px;border-radius:13px;cursor:pointer;text-align:center;border:1.5px dashed rgba(137,158,190,.3);background:rgba(255,255,255,.018)}',
      '.ctcu-drop:hover,.ctcu-drop.over{border-color:rgba(37,213,237,.6);background:rgba(37,213,237,.06)}',
      '.ctcu-drop input{position:absolute;inset:0;opacity:0;cursor:pointer}',
      '.ctcu-drop b{font:600 10.5px Vazirmatn;color:#cfe3f5}.ctcu-drop small{font:400 9px Vazirmatn;color:#6f8096}',
      '.ctcu-drop.has{border-style:solid;border-color:rgba(70,227,155,.45);background:rgba(70,227,155,.06)}',
      '.ctcu-drop img{max-height:132px;max-width:100%;border-radius:9px}',
      '.ctcu-note{margin:12px 0 0;padding:11px 12px;border-radius:11px;font:400 9.5px/1.9 Vazirmatn;color:#8fa3b8;',
      'border:1px solid rgba(137,158,190,.14);background:rgba(137,158,190,.05)}',
      '.ctcu-err{margin:12px 0 0;padding:10px 12px;border-radius:11px;font:600 10px/1.7 Vazirmatn;color:#ffb3bd;',
      'border:1px solid rgba(255,102,122,.34);background:rgba(255,102,122,.09)}',
      '.ctcu-actions{display:flex;gap:9px;margin-top:16px}',
      '.ctcu-btn{flex:1;min-height:40px;border-radius:12px;cursor:pointer;font:600 11px Vazirmatn;',
      'border:1px solid rgba(137,158,190,.22);background:rgba(255,255,255,.035);color:#c3d1e2}',
      '.ctcu-btn.primary{border-color:transparent;color:#04252b;font-weight:800;background:linear-gradient(135deg,#25d5ed,#46e39b)}',
      '.ctcu-btn[disabled]{opacity:.55;cursor:not-allowed}',
      '.ctcu-ok{padding:22px 10px;text-align:center}',
      '.ctcu-ok .tick{width:58px;height:58px;margin:0 auto 14px;border-radius:50%;display:grid;place-items:center;font-size:27px;',
      'background:rgba(70,227,155,.14);border:1px solid rgba(70,227,155,.4);color:#46e39b}',
      '.ctcu-ok b{display:block;font:700 14px Vazirmatn;color:#eaf7ff;margin-bottom:7px}',
      '.ctcu-ok p{margin:0 0 16px;font:400 10.5px/1.95 Vazirmatn;color:#8497aa}',
      '.ctcu-row{padding:12px 13px;margin-bottom:9px;border-radius:13px;border:1px solid rgba(137,158,190,.15);background:rgba(255,255,255,.022)}',
      '.ctcu-row-top{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}',
      '.ctcu-row-top b{font:600 10.5px Vazirmatn;color:#e8f1ff}',
      '.ctcu-row small{display:block;font:400 9px/1.9 Vazirmatn;color:#75879c}',
      '.ctcu-row .mono{font-family:monospace;direction:ltr;unicode-bidi:embed}',
      '.ctcu-badge{flex:none;padding:3.5px 9px;border-radius:20px;font:700 8.5px Vazirmatn;white-space:nowrap}',
      '.ctcu-badge.pending{background:rgba(245,190,80,.14);color:#f6c860;border:1px solid rgba(245,190,80,.32)}',
      '.ctcu-badge.approved{background:rgba(70,227,155,.14);color:#5eecac;border:1px solid rgba(70,227,155,.34)}',
      '.ctcu-badge.rejected{background:rgba(255,102,122,.13);color:#ff8f9f;border:1px solid rgba(255,102,122,.32)}',
      '.ctcu-rn{margin-top:7px;padding:8px 10px;border-radius:9px;font:500 9.5px/1.8 Vazirmatn;background:rgba(137,158,190,.07);color:#9fb1c6}',
      '.ctcu-ent{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding:12px 13px;border-radius:13px;',
      'border:1px solid rgba(70,227,155,.3);background:rgba(70,227,155,.07)}',
      '.ctcu-ent.off{border-color:rgba(255,102,122,.3);background:rgba(255,102,122,.07)}',
      '.ctcu-ent i{font-style:normal;font-size:19px}.ctcu-ent div{flex:1}',
      '.ctcu-ent b{display:block;font:700 11px Vazirmatn;color:#eaf7ff}',
      '.ctcu-ent small{font:400 9.5px Vazirmatn;color:#8fa8b8}',
      '.ctcu-empty{padding:30px 14px;text-align:center;font:400 10px/1.9 Vazirmatn;color:#6f8096}',
      '.ctcu-load{padding:34px;text-align:center;font:500 10.5px Vazirmatn;color:#7d8fa5}',
      '@media(max-width:480px){.ctcu-fab{gap:6px;padding:7px 10px;border-radius:12px}.ctcu-meta small{display:none}',
      '.ctcu-buy{min-height:27px;padding:0 10px}.ctcu-ov{padding:0;align-items:flex-end}',
      '.ctcu-box{max-height:94vh;border-radius:20px 20px 0 0}}',
      '@media(max-width:380px){.ctcu-fab .ctcu-dot{display:none}}',
      '@media(max-width:360px){.ctcu-fab .ctcu-meta{display:none}}',
      /* این استایل‌شیت بعد از شیت اصلی تزریق می‌شود، پس قانون چاپ باید همین‌جا
         باشد وگرنه نشان اشتراک روی هر صفحهٔ «چاپ گزارش» چاپ می‌شود. */
      '@media print{.ctcu-fab,.ctcu-ov,.ctcu-box{display:none !important}}',
      /* پوستهٔ روشن: رنگ‌های این ویجت همه برای زمینهٔ تیره انتخاب شده بودند و
         روی کاغذِ روشنِ برنامه، متن فیروزه‌ای کم‌رنگ روی زمینهٔ تقریباً سفید
         می‌افتاد (کنتراست ~۱.۵). این بلوک همان‌ها را تیره می‌کند. */
      'html.pa-light .ctcu-fab{border-color:#cfd8e3;background:#ffffff;',
      'box-shadow:0 10px 28px -14px rgba(15,23,42,.45);color:#0f172a}',
      'html.pa-light .ctcu-meta small{color:#5b6b80}',
      'html.pa-light .ctcu-meta b{color:#0f172a}',
      'html.pa-light .ctcu-buy{border-color:#0e7490;background:#0891b2;color:#ffffff}',
      'html.pa-light .ctcu-buy:hover{background:#0e7490}',
    ].join('');
    document.head.appendChild(style);
  }

  /* ---------------------------------------------------------- overlay -- */
  function open(tab) {
    state.tab = tab || 'pay';
    var old = document.getElementById('ctcu-ov');
    if (old) old.remove();
    var ov = document.createElement('div');
    ov.id = 'ctcu-ov';
    ov.className = 'ctcu-ov';
    ov.setAttribute('role', 'dialog');
    ov.setAttribute('aria-modal', 'true');
    ov.innerHTML = '<div class="ctcu-box"><div class="ctcu-head"><div>'
      + '<span class="ctcu-eyebrow">SMARTJOURNAL · CARD TO CARD</span>'
      + '<h3>خرید و تمدید اشتراک</h3></div>'
      + '<button type="button" class="ctcu-x" aria-label="بستن">×</button></div>'
      + '<div class="ctcu-body"><div class="ctcu-tabs">'
      + '<button type="button" class="ctcu-tab' + (state.tab === 'pay' ? ' on' : '') + '" data-ctcu-tab="pay">پرداخت کارت‌به‌کارت</button>'
      + '<button type="button" class="ctcu-tab' + (state.tab === 'hist' ? ' on' : '') + '" data-ctcu-tab="hist">وضعیت پرداخت‌های من</button>'
      + '</div><div id="ctcu-content"><div class="ctcu-load">در حال بارگذاری…</div></div></div></div>';
    document.body.appendChild(ov);
    ov.querySelector('.ctcu-x').addEventListener('click', close);
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    document.addEventListener('keydown', escClose);
    load();
  }
  function escClose(e) { if (e.key === 'Escape') close(); }
  function close() {
    var ov = document.getElementById('ctcu-ov');
    if (ov) ov.remove();
    document.removeEventListener('keydown', escClose);
    state.file = null;
  }
  function content(html) {
    var box = document.getElementById('ctcu-content');
    if (box) box.innerHTML = html;
  }

  function load() {
    Promise.all([
      json('/api/billing/bank-cards').catch(function () { return { rows: [] }; }),
      json('/api/public/plans').catch(function () { return { rows: [] }; }),
      json('/api/journal/entitlements').catch(function () { return null; }),
    ]).then(function (r) {
      state.cards = r[0].rows || [];
      state.plans = (r[1].rows || []).filter(function (p) { return Number(p.price_monthly) > 0; });
      state.entitlement = r[2];
      if (!state.selectedCard && state.cards.length) state.selectedCard = state.cards[0].id;
      if (state.tab === 'hist') renderHistory(); else renderPay();
    }).catch(function (e) {
      content('<div class="ctcu-err">' + esc(e.message) + '</div>');
    });
  }

  function renderPay() {
    if (!state.cards.length) {
      content('<div class="ctcu-ok"><b>فعلاً کارت بانکی ثبت نشده است</b>'
        + '<p>مدیریت هنوز شماره کارتی برای واریز تعریف نکرده است. کمی بعد دوباره تلاش کنید.</p>'
        + '<button class="ctcu-btn" data-ctcu-close>بستن</button></div>');
      return;
    }
    var cards = state.cards.map(function (c) {
      return '<div class="ctcu-card' + (state.selectedCard === c.id ? ' sel' : '') + '" data-ctcu-card="' + esc(c.id) + '">'
        + '<span class="ctcu-ic">' + esc(String(c.bank_name || '؟').slice(0, 1)) + '</span>'
        + '<div class="ctcu-cm"><b>' + esc(c.bank_name) + '</b>'
        + '<span>' + esc(groupCard(c.card_number)) + '</span>'
        + '<small>' + esc(c.holder || '') + (c.sheba ? ' · شبا IR' + esc(c.sheba) : '') + '</small></div>'
        + '<button type="button" class="ctcu-copy" data-ctcu-copy="' + esc(c.card_number) + '">کپی</button></div>';
    }).join('');

    var options = state.plans.map(function (p) {
      var off = p.discount && p.discount.active;
      var pay = off ? p.discount.final_price : p.price_monthly;
      return '<option value="' + esc(p.id) + '">' + esc(p.name_fa) + ' — '
        + fa(pay) + ' تومان'
        + (off ? ' (به‌جای ' + fa(p.price_monthly) + ' — ' + fa(p.discount.percent) + '٪ تخفیف)' : '')
        + ' / ' + fa(p.duration_days || 30) + ' روز</option>';
    }).join('');

    content('<p class="ctcu-step">مرحله ۱ از ۲ — واریز</p>'
      + '<h3 class="ctcu-title">مبلغ پلن را به یکی از کارت‌های زیر واریز کنید</h3>'
      + '<p class="ctcu-sub">روی کارت بزنید تا انتخاب شود. سپس کد پیگیری و تصویر فیش را ثبت کنید تا برای بررسی به مدیریت برسد.</p>'
      + cards
      + '<p class="ctcu-step" style="margin-top:16px">مرحله ۲ از ۲ — ثبت رسید</p>'
      + '<div class="ctcu-fields">'
      + '<label>پلن موردنظر<select class="ctcu-in" id="ctcuPlan">' + (options || '<option value="">پلنی موجود نیست</option>') + '</select></label>'
      + '<label>کد پیگیری / شماره مرجع واریز <span style="color:#ff8f9f">*</span>'
      + '<input class="ctcu-in ltr" id="ctcuTracking" maxlength="60" placeholder="مثلاً 254891736"></label>'
      + '<label>تصویر فیش واریز <span style="color:#ff8f9f">*</span>'
      + '<div class="ctcu-drop" id="ctcuDrop"><input type="file" id="ctcuFile" accept="image/png,image/jpeg,image/webp,application/pdf">'
      + '<b>فایل فیش را بکشید یا کلیک کنید</b><small>JPG / PNG / WebP / PDF — حداکثر ۸ مگابایت</small></div></label>'
      + '<label>توضیح (اختیاری)<textarea class="ctcu-area" id="ctcuNote" maxlength="400" placeholder="مثلاً: واریز از کارت همسرم انجام شد."></textarea></label>'
      + '</div>'
      + '<div class="ctcu-note">پس از تایید مدیریت، اشتراک شما به‌صورت خودکار فعال یا تمدید می‌شود و فاکتور رسمی صادر می‌گردد.</div>'
      + '<div id="ctcuErr"></div>'
      + '<div class="ctcu-actions"><button class="ctcu-btn" data-ctcu-close>بستن</button>'
      + '<button class="ctcu-btn primary" id="ctcuSubmit">ارسال فیش برای مدیریت</button></div>');
    wireDrop();
  }

  function wireDrop() {
    var drop = document.getElementById('ctcuDrop');
    var input = document.getElementById('ctcuFile');
    if (!drop || !input) return;
    function show(file) {
      if (!file) return;
      state.file = file;
      drop.classList.add('has');
      var size = (file.size / 1048576).toFixed(2);
      var tag = '<input type="file" id="ctcuFile" accept="image/png,image/jpeg,image/webp,application/pdf">';
      if (/^image\//.test(file.type)) {
        var reader = new FileReader();
        reader.onload = function () {
          drop.innerHTML = tag + '<img src="' + reader.result + '" alt="فیش">'
            + '<small>' + esc(file.name) + ' · ' + size + ' مگابایت — برای تغییر کلیک کنید</small>';
          wireDrop();
        };
        reader.readAsDataURL(file);
      } else {
        drop.innerHTML = tag + '<b>📄 ' + esc(file.name) + '</b>'
          + '<small>' + size + ' مگابایت — برای تغییر کلیک کنید</small>';
        wireDrop();
      }
    }
    input.addEventListener('change', function () { show(input.files && input.files[0]); });
    ['dragenter', 'dragover'].forEach(function (ev) {
      drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
      drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); });
    });
    drop.addEventListener('drop', function (e) {
      var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) show(file);
    });
    if (state.file) show(state.file);
  }

  function showErr(message) {
    var box = document.getElementById('ctcuErr');
    if (box) box.innerHTML = message ? '<div class="ctcu-err">' + esc(message) + '</div>' : '';
  }

  function submit() {
    if (state.busy) return;
    var planId = (document.getElementById('ctcuPlan') || {}).value || '';
    var trackingEl = document.getElementById('ctcuTracking');
    var tracking = (trackingEl.value || '').replace(/[۰-۹]/g, function (d) {
      return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d);
    }).trim();
    trackingEl.classList.remove('bad');

    if (!planId) { showErr('لطفاً پلن موردنظر را انتخاب کنید.'); return; }
    if (tracking.length < 4) { trackingEl.classList.add('bad'); trackingEl.focus(); showErr('کد پیگیری واریز را وارد کنید.'); return; }
    if (!state.file) { showErr('تصویر فیش واریز الزامی است.'); return; }
    if (state.file.size > 8 * 1048576) { showErr('حجم فیش نباید بیشتر از ۸ مگابایت باشد.'); return; }

    showErr('');
    var button = document.getElementById('ctcuSubmit');
    state.busy = true;
    button.disabled = true;
    button.textContent = 'در حال ارسال…';

    var reader = new FileReader();
    reader.onload = function () {
      json('/api/billing/receipts', {
        method: 'POST',
        body: {
          planId: planId,
          bankCardId: state.selectedCard,
          trackingCode: tracking,
          note: (document.getElementById('ctcuNote') || {}).value || '',
          receipt: String(reader.result),
        },
      }).then(function () {
        state.busy = false;
        state.file = null;
        content('<div class="ctcu-ok"><div class="tick">✓</div><b>فیش شما با موفقیت ارسال شد</b>'
          + '<p>رسید و کد پیگیری برای مدیریت ثبت شد. پس از تایید، اشتراک شما خودکار فعال می‌شود.</p>'
          + '<div class="ctcu-actions"><button class="ctcu-btn" data-ctcu-close>بستن</button>'
          + '<button class="ctcu-btn primary" data-ctcu-tab="hist">مشاهده وضعیت</button></div></div>');
      }).catch(function (e) {
        state.busy = false;
        button.disabled = false;
        button.textContent = 'ارسال فیش برای مدیریت';
        showErr(e.message);
      });
    };
    reader.onerror = function () {
      state.busy = false;
      button.disabled = false;
      button.textContent = 'ارسال فیش برای مدیریت';
      showErr('خواندن فایل فیش ممکن نشد.');
    };
    reader.readAsDataURL(state.file);
  }

  function badge(status) {
    var map = { pending: 'در انتظار بررسی', approved: 'تایید شد', rejected: 'رد شد' };
    return '<span class="ctcu-badge ' + esc(status) + '">' + (map[status] || map.pending) + '</span>';
  }

  function renderHistory() {
    content('<div class="ctcu-load">در حال دریافت…</div>');
    Promise.all([
      json('/api/billing/receipts'),
      json('/api/journal/entitlements').catch(function () { return null; }),
    ]).then(function (r) {
      var rows = r[0].rows || [];
      var ent = r[1] || {};
      var expires = ent.expiresAt || ent.expires_at;
      var active = expires ? new Date(expires) > new Date() : false;
      var head = active
        ? '<div class="ctcu-ent"><i>✅</i><div><b>اشتراک شما فعال است</b><small>'
          + esc((ent.plan && (ent.plan.name_fa || ent.plan.name)) || '') + ' · تا ' + esc(dateFa(expires)) + '</small></div></div>'
        : '<div class="ctcu-ent off"><i>⏳</i><div><b>اشتراک فعالی ندارید</b>'
          + '<small>پس از تایید فیش توسط مدیریت، اشتراک فعال می‌شود.</small></div></div>';
      var list = rows.length ? rows.map(function (row) {
        return '<div class="ctcu-row"><div class="ctcu-row-top"><b>' + esc(row.plan_title || '')
          + (row.amount ? ' · ' + fa(row.amount) + ' تومان' : '') + '</b>' + badge(row.status) + '</div>'
          + '<small>کد پیگیری: <span class="mono">' + esc(row.tracking_code || '—') + '</span></small>'
          + '<small>' + esc(dateFa(row.created_at)) + '</small>'
          + (row.status === 'approved' && row.granted_days
            ? '<small>اعتبار افزوده‌شده: ' + fa(row.granted_days) + ' روز</small>' : '')
          + (row.admin_note ? '<div class="ctcu-rn">پیام مدیریت: ' + esc(row.admin_note) + '</div>' : '')
          + '</div>';
      }).join('') : '<div class="ctcu-empty">هنوز فیشی ثبت نکرده‌اید.</div>';
      content(head + list
        + '<div class="ctcu-actions"><button class="ctcu-btn" data-ctcu-close>بستن</button>'
        + '<button class="ctcu-btn primary" data-ctcu-tab="pay">پرداخت جدید</button></div>');
    }).catch(function (e) { content('<div class="ctcu-err">' + esc(e.message) + '</div>'); });
  }

  /* ------------------------------------------------------------- fab --- */
  var fab = null;
  function syncFab() {
    if (!state.auth) { if (fab) { fab.remove(); fab = null; } return; }
    var ent = state.entitlement || {};
    var expires = ent.expiresAt || ent.expires_at;
    var active = expires ? new Date(expires) > new Date() : false;
    var label = active
      ? Math.max(0, Math.ceil((new Date(expires) - Date.now()) / 86400000)) + ' روز مانده'
      : 'اشتراک فعال نیست';
    if (!fab) {
      fab = document.createElement('div');
      /* pa-sub-top = نشانِ نسخهٔ جدید: این حباب بالای صفحه (کنار هدر) می‌نشیند */
      fab.className = 'ctcu-fab pa-sub-top';
      fab.innerHTML = '<span class="ctcu-dot"></span><div class="ctcu-meta"><small>اشتراک</small><b></b></div>'
        + '<button type="button" class="ctcu-buy">خرید / تمدید</button>';
      fab.querySelector('.ctcu-buy').addEventListener('click', function () { open('pay'); });
      document.body.appendChild(fab);
    }
    fab.classList.toggle('off', !active);
    fab.querySelector('.ctcu-meta b').textContent = label;
  }

  function refresh() {
    return loadAuth().then(function (auth) {
      if (!auth) { syncFab(); return null; }
      return json('/api/journal/entitlements')
        .then(function (e) { state.entitlement = e; syncFab(); return e; })
        .catch(function () { syncFab(); return null; });
    });
  }

  /* ---------------------------------------------------------- events -- */
  document.addEventListener('click', function (e) {
    if (!e.target || typeof e.target.closest !== 'function') return;

    var copy = e.target.closest('[data-ctcu-copy]');
    if (copy) {
      var value = copy.getAttribute('data-ctcu-copy');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(value).catch(function () {});
      }
      copy.textContent = 'کپی شد ✓';
      copy.classList.add('done');
      setTimeout(function () { copy.textContent = 'کپی'; copy.classList.remove('done'); }, 1400);
      return;
    }
    var card = e.target.closest('[data-ctcu-card]');
    if (card) {
      state.selectedCard = card.getAttribute('data-ctcu-card');
      Array.prototype.forEach.call(document.querySelectorAll('[data-ctcu-card]'), function (el) {
        el.classList.toggle('sel', el === card);
      });
      return;
    }
    var tab = e.target.closest('[data-ctcu-tab]');
    if (tab) {
      state.tab = tab.getAttribute('data-ctcu-tab');
      Array.prototype.forEach.call(document.querySelectorAll('.ctcu-tab'), function (el) {
        el.classList.toggle('on', el.getAttribute('data-ctcu-tab') === state.tab);
      });
      if (state.tab === 'hist') renderHistory(); else renderPay();
      return;
    }
    if (e.target.closest('#ctcuSubmit')) { submit(); return; }
    if (e.target.closest('[data-ctcu-close]')) { close(); return; }
    if (e.target.closest('[data-pa-buy], [data-public-plan]')) {
      e.preventDefault();
      open('pay');
    }
  }, true);

  window.addEventListener('hashchange', function () {
    if (/#buy|#upgrade/.test(location.hash)) open('pay');
  });

  window.PACardPayment = { open: open, refresh: refresh };

  function boot() {
    refresh();
    setInterval(refresh, 120000);
    if (/#buy|#upgrade/.test(location.hash)) setTimeout(function () { open('pay'); }, 600);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
