/* SmartJournal — Custom Social Share Card Builder Modal & Canvas Engine */
(function() {
  'use strict';

  function injectStyles() {
    if (document.getElementById('pa-share-card-styles')) return;
    var style = document.createElement('style');
    style.id = 'pa-share-card-styles';
    style.textContent = `
      .pa-share-overlay { position: fixed; inset: 0; z-index: 10080; display: flex; align-items: center; justify-content: center; padding: 12px; background: rgba(3, 8, 16, 0.92); backdrop-filter: blur(18px); opacity: 0; transition: opacity 0.25s ease; }
      .pa-share-overlay.is-open { opacity: 1; }
      .pa-share-dialog-full { width: min(1280px, 98vw); height: min(920px, 94vh); border: 1px solid #1e2f42; border-radius: 24px; overflow: hidden; background: #060d15; box-shadow: 0 40px 120px rgba(0,0,0,0.9); display: flex; flex-direction: column; }
      .pa-share-iframe { width: 100%; height: 100%; border: none; background: transparent; }
    `;
    document.head.appendChild(style);
  }

  function drawRoundedBox(ctx, x, y, w, h, r, fill, stroke, strokeW, shadowColor) {
    ctx.save();
    if (shadowColor) {
      ctx.shadowColor = shadowColor;
      ctx.shadowBlur = 24;
    }
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.shadowColor = 'transparent'; ctx.strokeStyle = stroke; ctx.lineWidth = strokeW || 1; ctx.stroke(); }
    ctx.restore();
  }

  function drawSLogo(ctx, cx, cy, size) {
    ctx.save();
    ctx.translate(cx, cy);
    var scale = size / 50;
    if (ctx.scale) ctx.scale(scale, scale);
    ctx.beginPath();
    ctx.moveTo(-18, -20); ctx.lineTo(12, -20);
    ctx.quadraticCurveTo(22, -20, 22, -10); ctx.quadraticCurveTo(22, 0, 10, 4);
    ctx.lineTo(-6, 8); ctx.quadraticCurveTo(-18, 12, -18, 22);
    ctx.quadraticCurveTo(-18, 32, -6, 32); ctx.lineTo(18, 32);
    ctx.lineWidth = 7; ctx.strokeStyle = '#00ff88'; ctx.stroke();
    ctx.restore();
  }

  function paDrawTradeCanvas(canvas, trade, options) {
    trade = trade || {};
    options = options || {};
    var ratio = options.ratio || 'story';
    var showAmount = options.showAmount !== false;
    var showVolume = options.showVolume !== false;
    var traderHandle = String(options.traderHandle || 'smarttradejournal.ir').trim();

    var W = 1080, H = 1920;
    if (ratio === 'square') { W = 1080; H = 1080; }
    else if (ratio === 'banner') { W = 1200; H = 675; }

    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext('2d');
    ctx.direction = 'ltr';

    var isWin = trade.resultType === 'profit' || Number(trade.amount || trade.pnl || 0) >= 0;

    var primaryColor = isWin ? '#00ff88' : '#ef4444';
    var primaryGlow = isWin ? 'rgba(0, 255, 136, 0.4)' : 'rgba(239, 68, 68, 0.4)';

    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#010407'); grad.addColorStop(0.5, '#07121b'); grad.addColorStop(1, '#020508');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);

    var topY = 110;
    drawSLogo(ctx, W/2, topY, 48);

    ctx.textAlign = 'center'; ctx.font = '900 44px "Vazirmatn", Tahoma, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('SmartJournal', W/2, topY + 62);
    ctx.font = '700 16px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText('TRADING JOURNAL', W/2, topY + 92);

    var cardX = 80, cardY = topY + 130, cardW = W - 160, cardH = H - cardY - 260;
    drawRoundedBox(ctx, cardX, cardY, cardW, cardH, 44, 'rgba(5, 18, 24, 0.94)', primaryColor, 3.5, primaryGlow);

    var innerX = cardX + 45, innerY = cardY + 45;
    var symbol = String(trade.symbol || 'XAUUSD').toUpperCase();
    ctx.textAlign = 'left'; ctx.font = '900 52px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText(symbol, innerX + 110, innerY + 45);

    var curY = innerY + 125;
    ctx.font = '700 20px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#64748b';
    ctx.fillText('PROFIT', innerX + 5, curY + 55);

    curY += 130;
    var amt = Number(trade.amount || trade.pnl || 0);
    var amtTxt = showAmount ? (isWin ? '+' : '-') + '$' + Math.abs(amt).toFixed(2) : (isWin ? 'WINNER' : 'LOSS');
    ctx.font = '900 88px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = primaryColor;
    ctx.fillText(amtTxt, innerX + 5, curY);

    var footerY = H - 160;
    var handleTxt = traderHandle ? (traderHandle.startsWith('@') ? traderHandle : '@' + traderHandle) : '@smarttradejournal.ir';
    ctx.textAlign = 'center'; ctx.font = '700 24px "JetBrains Mono", monospace, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('👤  ' + handleTxt, W/2, footerY + 38);
  }

  function paDrawSummaryCanvas(canvas, trades, options) {
    trades = trades || [];
    options = options || {};
    var W = 1080, H = 1920;
    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext('2d');
    ctx.direction = 'ltr';

    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#010407'); grad.addColorStop(0.5, '#07121b'); grad.addColorStop(1, '#020508');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);

    drawSLogo(ctx, W/2, 110, 48);
    ctx.textAlign = 'center'; ctx.font = '900 44px "Vazirmatn", Tahoma, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText('SmartJournal', W/2, 172);
  }

  function paOpenShareModal(tradeOrTrades, isSummary) {
    injectStyles();
    var existing = document.getElementById('pa-share-overlay');
    if (existing) existing.remove();

    var isArray = Array.isArray(tradeOrTrades);
    var item = isArray ? tradeOrTrades[0] : (tradeOrTrades || {});

    var tradeData = {
      symbol: String(item.symbol || 'XAUUSD').toUpperCase(),
      name: item.symbol && String(item.symbol).includes('XAU') ? 'GOLD / U.S. DOLLAR' : item.symbol && String(item.symbol).includes('EUR') ? 'EURO / U.S. DOLLAR' : 'FINANCIAL ASSET',
      direction: String(item.direction || 'BUY').toUpperCase() === 'SELL' ? 'SELL' : 'BUY',
      profit: Number(item.pnl || item.amount || item.profit || 68.17),
      volume: String(item.positionSize || item.lot || item.volume || '0.17'),
      risk: String(item.riskPercent || item.risk || '1'),
      timeframe: String(item.timeframe || '15M'),
      setup: String(item.setupName || item.setup || 'FVG')
    };

    var tradesList = isArray ? tradeOrTrades : [item];
    var totalTrades = tradesList.length || 48;
    var wins = tradesList.length ? tradesList.filter(function(t){ return Number(t.pnl || t.amount || 0) > 0; }).length : 30;
    var losses = totalTrades - wins;
    var winRate = totalTrades > 0 ? Number(((wins / totalTrades) * 100).toFixed(1)) : 62.5;
    var netPnl = tradesList.length ? tradesList.reduce(function(acc, t){ return acc + Number(t.pnl || t.amount || 0); }, 0) : 2847.60;

    var reportData = {
      period: 'MARCH 2026',
      net: Number(netPnl.toFixed(2)),
      winRate: winRate,
      trades: totalTrades,
      wins: wins,
      losses: losses,
      profitFactor: '2.45',
      avgR: '1.4R'
    };

    var sharePayload = {
      mode: isSummary ? 'report' : 'trade',
      fixedMode: isSummary ? 'report' : 'trade',
      themeId: 'emerald',
      ratio: 'story',
      username: 'smarttradejournal.ir',
      trade: tradeData,
      report: reportData
    };

    var overlay = document.createElement('div');
    overlay.id = 'pa-share-overlay';
    overlay.className = 'pa-share-overlay';

    var dialog = document.createElement('div');
    dialog.className = 'pa-share-dialog-full';

    var iframe = document.createElement('iframe');
    iframe.className = 'pa-share-iframe';
    iframe.src = '/share-card-builder.html';

    dialog.appendChild(iframe);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    window.paCloseShareModal = function() {
      overlay.classList.remove('is-open');
      setTimeout(function() { overlay.remove(); }, 250);
    };

    iframe.onload = function() {
      try {
        iframe.contentWindow.__pa_share_data = sharePayload;
        iframe.contentWindow.dispatchEvent(new CustomEvent('pa-update-share-data', { detail: sharePayload }));
      } catch (err) {}
    };

    requestAnimationFrame(function() { overlay.classList.add('is-open'); });
  }

  window.paDrawTradeCanvas = paDrawTradeCanvas;
  window.paDrawSummaryCanvas = paDrawSummaryCanvas;
  window.paOpenShareModal = function(trade) { paOpenShareModal(trade, false); };
  window.paOpenShareSummaryModal = function(trades) { paOpenShareModal(trades, true); };
})();
