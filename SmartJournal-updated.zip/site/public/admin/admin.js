'use strict';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const state = {
  admin: null,
  csrf: '',
  view: 'dashboard',
  users: { page: 1, search: '', status: '', plan: '' },
  contacts: { page: 1, search: '', source: '', consent: '' },
  support: { search: '', status: '', priority: '' },
  subscriptions: { page: 1, search: '', status: '', plan: '' },
  subscriptionTab: 'subscriptions',
  payments: { page: 1, search: '', status: '' },
  usageTab: 'sms',
  logsTab: 'errors',
  errors: { status: '', severity: '' },
  cms: { selectedPageId: null },
  cache: {},
  requestId: 0
};

const icons = {
  dashboard: '<path d="M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  card: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20M6 15h4"/>',
  plus: '<path d="M12 5v14M5 12h14" stroke-linecap="round"/>',
  usage: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  logs: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="M9 12h6M12 9v6"/>',
  phone: '<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 5h4M11 18h2"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>',
  logout: '<path d="M10 17l5-5-5-5M15 12H3M14 3h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
  server: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
  arrow: '<path d="m15 18-6-6 6-6"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.34-5.66L20 8"/><path d="M20 3v5h-5"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  trend: '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  userPlus: '<path d="M15 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8" cy="7" r="4"/><path d="M19 8v6M16 11h6"/>',
  revenue: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  message: '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z"/><path d="M8 9h8M8 13h5"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v6c0 1.7 4 3 9 3s9-1.3 9-3V5M3 11v6c0 1.7 4 3 9 3s9-1.3 9-3v-6"/>',
  alert: '<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17h.01"/>',
  activity: '<path d="M3 12h4l2-7 4 14 2-7h6"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4L16.5 3.5Z"/>',
  crown: '<path d="m3 6 4 5 5-7 5 7 4-5-2 13H5L3 6Z"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Z"/><path d="M14 2v6h6"/>',
  sms: '<path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4 20-7Z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.09A1.7 1.7 0 0 0 8.97 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.56-1.03H3v-4h.09A1.7 1.7 0 0 0 4.6 8.94a1.7 1.7 0 0 0-.34-1.88L4.2 7l2.83-2.83.06.06a1.7 1.7 0 0 0 1.88.34H9A1.7 1.7 0 0 0 10 3.09V3h4v.09a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.88-.34l.06-.06L19.8 7l-.06.06a1.7 1.7 0 0 0-.34 1.88v.03A1.7 1.7 0 0 0 20.91 10H21v4h-.09A1.7 1.7 0 0 0 19.4 15Z"/>'
};

function icon(name, size = 17) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.info}</svg>`;
}
function hydrateIcons(root = document) {
  $$('[data-icon]', root).forEach(element => {
    const name = element.dataset.icon;
    element.innerHTML = icon(name, Number(element.dataset.size || 17));
  });
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}
const fa = new Intl.NumberFormat('fa-IR');
const money = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 0 });
function n(value) { return fa.format(Number(value || 0)); }
function toman(value) { return `${money.format(Number(value || 0))} تومان`; }
function bytes(value) {
  const number = Number(value || 0);
  if (number < 1024) return `${n(number)} بایت`;
  const units = ['KB', 'MB', 'GB', 'TB']; let size = number / 1024, index = 0;
  while (size >= 1024 && index < units.length - 1) { size /= 1024; index += 1; }
  return `${size.toLocaleString('fa-IR', { maximumFractionDigits: size >= 10 ? 1 : 2 })} ${units[index]}`;
}
function uptime(value) {
  const seconds = Math.max(0, Number(value || 0));
  const days = Math.floor(seconds / 86400), hours = Math.floor(seconds % 86400 / 3600), minutes = Math.floor(seconds % 3600 / 60);
  return days ? `${n(days)} روز و ${n(hours)} ساعت` : hours ? `${n(hours)} ساعت و ${n(minutes)} دقیقه` : `${n(minutes)} دقیقه`;
}
function dateFa(value, withTime = false) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('fa-IR', withTime ? { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' } : { year: 'numeric', month: 'short', day: 'numeric' });
}
function relativeTime(value) {
  if (!value) return 'بدون فعالیت';
  const seconds = Math.max(0, (Date.now() - new Date(value).getTime()) / 1000);
  if (seconds < 90) return 'لحظاتی پیش';
  if (seconds < 3600) return `${n(Math.floor(seconds / 60))} دقیقه پیش`;
  if (seconds < 86400) return `${n(Math.floor(seconds / 3600))} ساعت پیش`;
  if (seconds < 7 * 86400) return `${n(Math.floor(seconds / 86400))} روز پیش`;
  return dateFa(value);
}
function initials(name) {
  const parts = String(name || 'مدیر').trim().split(/\s+/);
  return `${parts[0]?.[0] || 'م'}${parts[1]?.[0] || ''}`;
}
function statusLabel(status) {
  return ({ active: 'فعال', suspended: 'مسدود', pending: 'در انتظار', limited: 'محدود', expired: 'منقضی', cancelled: 'لغوشده', trial: 'آزمایشی', delivered: 'تحویل‌شده', sent: 'ارسال‌شده', paid: 'پرداخت‌شده', refunded: 'بازپرداخت‌شده', partially_refunded: 'بازپرداخت جزئی', failed: 'ناموفق', open: 'باز', resolved: 'حل‌شده', ignored: 'نادیده گرفته‌شده', in_progress: 'در حال رسیدگی', closed: 'بسته', spam: 'هرزنامه' })[status] || status || '—';
}
function roleLabel(role) { return ({ owner: 'مالک سیستم', admin: 'مدیر عمومی', support: 'پشتیبانی', finance: 'امور مالی', security: 'امنیت', content_manager: 'مدیر محتوا' })[role] || role; }
function actionLabel(action) {
  return ({ LOGIN_SUCCESS: 'ورود موفق مدیر', LOGIN_FAILED: 'تلاش ورود ناموفق', LOGIN_BLOCKED: 'ورود مسدودشده', ADMIN_API_REQUEST: 'درخواست مدیریتی ثبت‌شده', LOGOUT: 'خروج از پنل', USER_STATUS_UPDATED: 'تغییر وضعیت کاربر', USER_FORCE_LOGOUT: 'خروج اجباری کاربر', USER_RECOVERY_STARTED: 'شروع بازیابی امن', USER_ACCOUNT_DELETED: 'حذف حساب کاربر', SUBSCRIPTION_UPDATED: 'ویرایش اشتراک', SUBSCRIPTION_MANUALLY_ACTIVATED: 'فعال‌سازی دستی اشتراک', SUBSCRIPTION_CANCELLED: 'لغو اشتراک', PLAN_LIMITS_UPDATED: 'تغییر محدودیت پلن', PLAN_CREATED: 'ساخت پلن جدید', PLAN_UPDATED: 'ویرایش پلن و قابلیت‌ها', PLAN_DELETED: 'حذف پلن', MARKETING_FAQ_CREATED: 'افزودن سؤال بازاریابی', MARKETING_FAQ_UPDATED: 'ویرایش یا انتشار سؤال', MARKETING_FAQ_DELETED: 'حذف سؤال بازاریابی', COUPON_CREATED: 'ساخت کد تخفیف', COUPON_STATUS_UPDATED: 'تغییر وضعیت کد تخفیف', PAYMENT_REFUNDED: 'بازپرداخت وجه', SMS_SETTINGS_UPDATED: 'تنظیمات پیامک و OTP', SMS_PROVIDER_SWITCHED: 'تعویض ارائه‌دهنده پیامک', SMS_PROVIDER_STATUS_UPDATED: 'تغییر وضعیت ارائه‌دهنده پیامک', FILE_SETTINGS_UPDATED: 'تغییر سیاست فایل و تصویر', ORPHAN_FILES_CLEANED: 'پاک‌سازی فایل‌های رهاشده', ORPHAN_FILES_AUTO_CLEANED: 'پاک‌سازی خودکار فایل‌های رهاشده', FILE_REVIEWED: 'بررسی امنیتی فایل', FILE_DELETED: 'حذف فایل', SECURITY_BLOCK_CREATED: 'ایجاد محدودیت امنیتی', SECURITY_BLOCK_REVOKED: 'لغو محدودیت امنیتی', SECURITY_ALERT_UPDATED: 'رسیدگی به هشدار امنیتی', SYSTEM_SETTINGS_UPDATED: 'تغییر تنظیمات سیستم', SYSTEM_CONTENT_UPDATED: 'ویرایش قوانین و راهنما', ADMIN_CREATED: 'ایجاد حساب مدیر', ADMIN_ACCESS_UPDATED: 'تغییر دسترسی مدیر', ADMIN_PROFILE_UPDATED: 'تغییر اطلاعات حساب مدیر', ROLE_PERMISSIONS_UPDATED: 'تغییر ماتریس دسترسی نقش', CMS_PAGE_CREATED: 'ساخت صفحه محتوایی', CMS_PAGE_UPDATED: 'ویرایش صفحه محتوایی', CMS_SECTION_CREATED: 'ساخت سکشن محتوا', CMS_SECTION_UPDATED: 'ویرایش سکشن محتوا', CMS_SECTION_ARCHIVED: 'بایگانی سکشن محتوا', CMS_PAGE_DUPLICATED: 'تکثیر صفحه محتوا', CMS_SECTION_DUPLICATED: 'تکثیر سکشن محتوا', CMS_REVISION_RESTORED: 'بازگردانی نسخه محتوا', CMS_MENU_CREATED: 'ساخت آیتم منو', CMS_MENU_UPDATED: 'ویرایش آیتم منو', CMS_MENU_ARCHIVED: 'بایگانی آیتم منو', USER_CONTACT_CREATED: 'ذخیره شماره کاربر', USER_CONTACT_UPDATED: 'ویرایش شماره کاربر', USER_CONTACT_DELETED: 'حذف شماره ذخیره‌شده', USER_CONTACTS_SYNCED: 'همگام‌سازی شماره کاربران', USER_CONTACTS_IMPORTED: 'ورود شماره‌ها از CSV', ANNOUNCEMENT_CREATED: 'ساخت اعلان عمومی', ANNOUNCEMENT_UPDATED: 'ویرایش اعلان عمومی', ANNOUNCEMENT_ARCHIVED: 'بایگانی اعلان عمومی', SUPPORT_REQUEST_UPDATED: 'رسیدگی به درخواست پشتیبانی', ERROR_RESOLVED: 'حل خطای سیستم', ERROR_STATUS_UPDATED: 'تغییر وضعیت خطا' })[action] || action;
}
function monthFa(month) {
  const [year, mon] = month.split('-').map(Number);
  return new Date(Date.UTC(year, mon - 1, 15)).toLocaleDateString('fa-IR', { month: 'short' });
}
function debounce(fn, wait = 350) { let timer; return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); }; }

async function api(url, options = {}) {
  const headers = { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) };
  if (state.csrf && options.method && !['GET', 'HEAD'].includes(options.method)) headers['X-CSRF-Token'] = state.csrf;
  const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
  let data = {};
  try { data = await response.json(); } catch {}
  if (response.status === 401 && !url.endsWith('/login')) { showLogin(); throw new Error(data.error || 'نشست منقضی شده است.'); }
  if (!response.ok) {
    const requestError = new Error(data.error || 'انجام درخواست ممکن نشد.');
    requestError.status = response.status;
    requestError.body = data;
    throw requestError;
  }
  return data;
}

function toast(message, type = 'success') {
  const item = document.createElement('div');
  item.className = `toast ${type}`;
  item.setAttribute('role',type === 'error' ? 'alert' : 'status');
  item.innerHTML = `<i aria-hidden="true">${icon(type === 'error' ? 'alert' : 'check', 15)}</i><span>${escapeHtml(message)}</span>`;
  $('#toastStack').appendChild(item);
  setTimeout(() => item.remove(), 4200);
}
function loadingView() {
  return `<div class="loading-grid" role="status" aria-label="در حال بارگذاری">${Array.from({ length: 8 }, () => '<div class="skeleton" aria-hidden="true"></div>').join('')}</div>`;
}
function prepareViewAccessibility(){
  const content=$('#pageContent');content.setAttribute('aria-busy','false');
  $$('.table-scroll',content).forEach((table,index)=>{table.tabIndex=0;table.setAttribute('role','region');table.setAttribute('aria-label',`جدول اطلاعات ${index+1}`)});
  $$('.billing-tabs,.resource-tabs,.security-tabs',content).forEach(group=>{group.setAttribute('role','tablist');$$('button',group).forEach(button=>{button.setAttribute('role','tab');button.setAttribute('aria-selected',String(button.classList.contains('active')))})});
  $$('button:not([type])',content).forEach(button=>button.type='button');
}
function setBusy(button, busy) {
  if (!button) return;
  button.disabled = busy;
  button.classList.toggle('loading', busy);
}

function showLogin() {
  state.admin = null; state.csrf = '';
  $('#boot').hidden = true; $('#adminApp').hidden = true; $('#loginScreen').hidden = false;
  setTimeout(() => $('#loginMobile').focus(), 50);
}
const roleLabels={owner:'مالک سیستم',admin:'مدیر عمومی',support:'پشتیبانی',finance:'امور مالی',security:'امنیت',content_manager:'مدیر محتوا'};
const permissionLabels={dashboard:'داشبورد','users.view':'مشاهده کاربران','users.manage':'مدیریت کاربران','users.security':'امنیت و بازیابی کاربران','users.delete':'حذف حساب کاربر','billing.view':'مشاهده اشتراک و پرداخت','billing.manage':'مدیریت پلن و اشتراک','billing.refund':'بازپرداخت وجه','resources.view':'مشاهده پیامک و فایل','resources.manage':'تنظیمات پیامک و فایل','resources.security':'بررسی امنیتی فایل','security.view':'مشاهده امنیت و Audit','security.manage':'رسیدگی به رخدادهای امنیتی','settings.view':'مشاهده تنظیمات عملیاتی','settings.manage':'ویرایش تنظیمات عملیاتی','content.view':'مشاهده محتوای عمومی','content.manage':'ویرایش قوانین و اعلان‌ها','cms.manage':'مدیریت صفحات و سکشن‌های سایت'};
const permissionGroups={dashboard:['dashboard'],users:['users.view','users.manage','users.security','users.delete'],billing:['billing.view','billing.manage','billing.refund'],resources:['resources.view','resources.manage','resources.security'],security:['security.view','security.manage'],settings:['settings.view','settings.manage'],content:['content.view','content.manage','cms.manage']};
const permissionGroupLabels={dashboard:'داشبورد',users:'کاربران',billing:'مالی و اشتراک',resources:'پیامک و فایل',security:'امنیت',settings:'تنظیمات سیستم',content:'محتوا و CMS'};
const viewScopes={dashboard:['dashboard'],users:['users.view','users.security'],journals:['users.view','users.security','users.manage'],contacts:['users.view','users.security'],support:['users.view','users.security'],subscriptions:['billing.view'],banking:['billing.view','billing.manage'],sitecontent:['content.view','content.manage','cms.manage'],usage:['resources.view','resources.security'],logs:['security.view'],settings:['settings.view','content.view'],cms:['cms.manage','content.manage'],legal:['content.view','users.security']};
function hasPermission(scope){const permissions=state.admin?.permissions||[];return permissions.includes('*')||permissions.includes(scope)}
function canView(view){return (viewScopes[view]||[]).some(hasPermission)}
function showApp(admin) {
  state.admin = admin;
  $('#boot').hidden = true; $('#loginScreen').hidden = true; $('#adminApp').hidden = false;
  $('#adminName').textContent = admin.name;
  $('#dropdownName').textContent = admin.name;
  $('#dropdownMobile').textContent = `${admin.username?'@'+admin.username+' · ':''}${admin.mobile}`;
  $('#adminRole').textContent = roleLabels[admin.role]||admin.role;
  $('#adminAvatar').textContent = initials(admin.name);
  $$('.nav-item[data-view]').forEach(button=>button.hidden=!canView(button.dataset.view));
  $('#today').textContent = new Date().toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' });
  if(admin.mfaRequired&&!admin.mfa?.enabled){$('#pageEyebrow').textContent='MANDATORY MFA ENROLLMENT';$('#pageTitle').textContent='تکمیل امنیت حساب Owner';$('#pageContent').innerHTML=`<div class="secure-empty">${icon('shield',20)} برای دسترسی به داده‌های پنل ابتدا TOTP یا Passkey را فعال کن.</div>`;return}
  renderView(canView('dashboard')?'dashboard':Object.keys(viewScopes).find(canView)||'dashboard');
}

async function bootstrap() {
  hydrateIcons();
  $('#demoCredential').hidden = !window.PA_STANDALONE_MOCK && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1' && !location.hostname.includes('e2b.app');
  try {
    const data = await api('/api/admin/me');
    state.csrf = data.csrfToken;
    showApp(data.admin);
    if(data.mfaSetupRequired)setTimeout(()=>openAdminMfaCenter(true),80);
  } catch { showLogin(); }
}

const viewMeta = {
  dashboard: ['OVERVIEW', 'داشبورد مدیریت'], users: ['USER MANAGEMENT', 'مدیریت کاربران'], journals: ['JOURNAL & TRADE MANAGEMENT', 'مدیریت ژورنال‌ها و معاملات'], contacts: ['USER MOBILE DIRECTORY', 'شماره‌های ذخیره‌شده کاربران'], support: ['JOURNAL SUPPORT TICKETS', 'تیکت‌های پشتیبانی کاربران ژورنال'],
  subscriptions: ['BILLING & PLANS', 'مدیریت اشتراک‌ها'],
  banking: ['CARD-TO-CARD PAYMENTS', 'کارت بانکی و فیش‌های واریز'],
  sitecontent: ['SITE CONTENT & SOCIAL PROOF', 'محتوای سایت و نظرات'], usage: ['SMS, FILES & STORAGE', 'مدیریت پیامک و فایل‌ها'],
  logs: ['SECURITY OPERATIONS & AUDIT', 'گزارش خطا و امنیت'], cms: ['SITE CONTENT MANAGEMENT', 'مدیریت محتوای سایت'], legal: ['LEGAL & PRIVACY OPERATIONS', 'حقوقی و حریم خصوصی'], settings: ['SYSTEM CONFIGURATION', 'تنظیمات سیستم']
};
async function renderView(view = state.view) {
  if (!canView(view)) view = Object.keys(viewScopes).find(canView)||'dashboard';
  state.view = view;
  const requestId = ++state.requestId;
  $$('.nav-item').forEach(button => { const active=button.dataset.view === view; button.classList.toggle('active',active); if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current'); });
  $('#pageEyebrow').textContent = viewMeta[view][0];
  $('#pageTitle').textContent = viewMeta[view][1];
  $('#pageContent').setAttribute('aria-busy','true');
  $('#pageContent').innerHTML = loadingView();
  closeSidebar();
  try {
    let html = '';
    if (view === 'dashboard') html = await renderDashboard();
    else if (view === 'users') html = await renderUsers();
    else if (view === 'journals') html = await renderJournals();
    else if (view === 'contacts') html = await renderContacts();
    else if (view === 'support') html = await renderSupport();
    else if (view === 'subscriptions') html = await renderSubscriptions();
    else if (view === 'banking') html = await renderBanking();
    else if (view === 'sitecontent') html = await renderSiteContent();
    else if (view === 'usage') html = await renderUsage();
    else if (view === 'settings') html = await renderSettings();
    else if (view === 'cms') html = await renderCms();
    else if (view === 'legal') html = await renderLegalPrivacy();
    else html = await renderLogs();
    if (requestId !== state.requestId) return;
    $('#pageContent').innerHTML = `<div class="view-enter">${html}</div>`;
    prepareViewAccessibility();
  } catch (error) {
    if (requestId !== state.requestId) return;
    $('#pageContent').innerHTML = `<div class="card empty-table" role="alert">${icon('alert', 28)}<p>${escapeHtml(error.message)}</p><button class="ghost-btn" data-retry>تلاش دوباره</button></div>`;
    $('#pageContent').setAttribute('aria-busy','false');
    toast(error.message, 'error');
  }
}

function metric({ iconName, label, value, change, foot, tone = '#22d3ee', warn = false }) {
  return `<article class="card metric-card" style="--tone:${tone}"><div class="metric-top"><span class="metric-icon">${icon(iconName, 18)}</span><span class="metric-change ${warn ? 'warn' : ''}">${escapeHtml(change)}</span></div><span class="metric-label">${escapeHtml(label)}</span><b class="metric-value">${escapeHtml(value)}</b><span class="metric-foot">${escapeHtml(foot)}</span></article>`;
}
async function renderDashboard() {
  const data = await api('/api/admin/dashboard');
  const canSeeFinance=hasPermission('billing.view'),canSeeSecurity=hasPermission('security.view');
  state.cache.dashboard = data;
  $('#navUsersCount').textContent = n(data.metrics.usersTotal);
  $('#navErrorCount').textContent = n(data.metrics.openErrors);
  const maxGrowth = Math.max(1, ...data.growth.map(item => item.users));
  let cumulative = 0;
  const totalPlans = data.plans.reduce((sum, item) => sum + item.count, 0) || 1;
  const stops = data.plans.map(item => {
    const start = cumulative / totalPlans * 100; cumulative += item.count;
    const end = cumulative / totalPlans * 100;
    return `${item.color} ${start}% ${end}%`;
  }).join(',');
  const recentErrorRows = data.recentErrors.map(item => `<div class="list-row"><span class="list-icon" style="color:${item.severity === 'critical' ? '#f87171' : item.severity === 'warning' ? '#fbbf24' : '#8ddfea'}">${icon('alert',14)}</span><div class="list-body"><b>${escapeHtml(item.message)}</b><span>${escapeHtml(item.source)} · ${statusLabel(item.status)}</span></div><span class="list-time">${relativeTime(item.occurred_at)}</span></div>`).join('');
  const auditRows = data.recentAudit.map(item => `<div class="list-row"><span class="list-icon" style="color:#b9a5fb;background:rgba(167,139,250,.08)">${icon('history',14)}</span><div class="list-body"><b>${escapeHtml(actionLabel(item.action))}</b><span>${escapeHtml(item.admin_name || 'سیستم')} · ${typeof item.details === 'string' ? escapeHtml(item.details) : 'فعالیت مدیریتی'}</span></div><span class="list-time">${relativeTime(item.created_at)}</span></div>`).join('');
  return `
    <div class="section-head"><div><span class="eyebrow">LIVE BUSINESS SNAPSHOT</span><h2>نمای کلی مدیریتی</h2><p>آمار ضروری کاربران، معاملات، پیامک، خطاها و سلامت زیرساخت ژورنال.</p></div><span class="soft-chip">آخرین بروزرسانی: همین حالا</span></div>
    <div class="metrics-grid admin-essential-grid">
      ${metric({ iconName:'users',label:'تعداد کل کاربران',value:n(data.metrics.usersTotal),change:`+${n(data.metrics.usersThisMonth)}`,foot:'ثبت‌نام در ماه جاری',tone:'#22d3ee' })}
      ${metric({ iconName:'activity',label:'کاربران فعال',value:n(data.metrics.usersActive7),change:`${Math.round(data.metrics.usersActive7/Math.max(1,data.metrics.usersTotal)*100)}٪`,foot:'فعال در ۷ روز اخیر',tone:'#22c55e' })}
      ${metric({ iconName:'userPlus',label:'ثبت‌نام‌های امروز',value:n(data.metrics.usersToday),change:'امروز',foot:'کاربر جدید از ابتدای روز',tone:'#38bdf8' })}
      ${metric({ iconName:'calendar',label:'ثبت‌نام‌های این ماه',value:n(data.metrics.usersThisMonth),change:`۳۰ روز: ${n(data.metrics.usersNew30)}`,foot:'رشد کاربران در ماه جاری',tone:'#818cf8' })}
      ${metric({ iconName:'trend',label:'معاملات ثبت‌شده',value:n(data.metrics.tradesTotal),change:'کل سیستم',foot:'مجموع معاملات تمام کاربران',tone:'#34d399' })}
      ${metric({ iconName:'database',label:'حجم تصاویر ذخیره‌شده',value:bytes(data.metrics.storageBytes),change:'Object Storage',foot:'مصرف تجمعی تصاویر کاربران',tone:'#06b6d4' })}
      ${metric({ iconName:'message',label:'پیامک‌های OTP این ماه',value:n(data.metrics.otpMonth),change:canSeeFinance?toman(data.metrics.otpCostMonth):'ماه جاری',foot:'تعداد و هزینه کدهای ورود',tone:'#fbbf24' })}
      ${canSeeFinance?`${metric({ iconName:'revenue',label:'درآمد ماهانه',value:toman(data.metrics.mrr),change:n(data.metrics.subscriptionsActive),foot:'اشتراک فعال',tone:'#a78bfa' })}`:''}
      ${canSeeSecurity?`${metric({ iconName:'lock',label:'خطاهای ورود',value:n(data.metrics.loginErrors24h),change:'۲۴ ساعت اخیر',foot:'تلاش‌های ناموفق ورود مدیران',tone:'#fb923c',warn:!!data.metrics.loginErrors24h })}`:''}
      ${canSeeSecurity?`${metric({ iconName:'alert',label:'خطاهای عملکرد سیستم',value:n(data.metrics.performanceErrors),change:`${n(data.metrics.systemErrors24h)} رخداد امروز`,foot:`${n(data.metrics.openErrors)} خطای باز در مجموع`,tone:'#f87171',warn:!!data.metrics.performanceErrors })}`:''}
    </div>
    <section class="card system-health-card">
      <div class="card-head"><div class="card-title"><b>وضعیت سرور و دیتابیس</b><span>بررسی زنده سرویس مدیریت و پایگاه داده</span></div><span class="health-overall"><i></i> همه سرویس‌ها در دسترس‌اند</span></div>
      <div class="health-grid">
        <div class="health-item"><span class="health-icon">${icon('server',18)}</span><div><small>سرور برنامه</small><b>${data.health.serverStatus==='online'?'آنلاین و پایدار':'نیازمند بررسی'}</b><em>Uptime: ${uptime(data.health.uptimeSeconds)}</em></div><i class="health-state ${data.health.serverStatus==='online'?'ok':'bad'}"></i></div>
        <div class="health-item"><span class="health-icon">${icon('database',18)}</span><div><small>اتصال دیتابیس</small><b>${data.health.databaseStatus==='connected'?'متصل':'قطع ارتباط'}</b><em>Latency: ${n(data.health.databaseLatencyMs)} ms · ${escapeHtml(data.health.journalMode)}</em></div><i class="health-state ${data.health.databaseStatus==='connected'?'ok':'bad'}"></i></div>
        <div class="health-item"><span class="health-icon">${icon('file',18)}</span><div><small>حجم دیتابیس</small><b>${bytes(data.health.databaseBytes)}</b><em>فایل داده مدیریت</em></div><i class="health-state ok"></i></div>
        <div class="health-item"><span class="health-icon">${icon('activity',18)}</span><div><small>حافظه سرور</small><b>${bytes(data.health.memoryBytes)}</b><em>بررسی: ${dateFa(data.health.checkedAt,true)}</em></div><i class="health-state ok"></i></div>
      </div>
    </section>
    <div class="dashboard-grid">
      <section class="card chart-card"><div class="card-head"><div class="card-title"><b>رشد کاربران</b><span>ثبت‌نام ماهانه در شش ماه اخیر</span></div><span class="soft-chip">۶ ماه</span></div><div class="bar-chart">${data.growth.map(item => `<div class="bar-col"><span class="bar-value">${n(item.users)}</span><i class="bar" style="height:${Math.max(5,item.users/maxGrowth*88)}%"></i><span class="bar-label">${monthFa(item.month)}</span></div>`).join('')}</div></section>
      ${canSeeFinance?`<section class="card distribution-card"><div class="card-head"><div class="card-title"><b>توزیع پلن‌ها</b><span>اشتراک‌های فعال و آزمایشی</span></div></div><div class="donut-wrap"><div class="donut" style="background:conic-gradient(${stops})"><div class="donut-center"><b>${n(totalPlans)}</b><span>اشتراک</span></div></div><div class="legend">${data.plans.map(item => `<div class="legend-row"><i style="background:${item.color}"></i><span>${escapeHtml(item.name_fa)}</span><b>${n(item.count)}</b></div>`).join('')}</div></div></section>`:''}
    </div>
    ${canSeeSecurity?`<div class="two-col">
      <section class="card errors-card"><div class="card-head"><div class="card-title"><b>آخرین خطاهای سیستم</b><span>رخدادهای نیازمند توجه</span></div><button class="table-action" data-go="logs">${icon('arrow',14)}</button></div><div class="list">${recentErrorRows || '<div class="empty-table">خطایی ثبت نشده است.</div>'}</div></section>
      <section class="card activity-card"><div class="card-head"><div class="card-title"><b>فعالیت مدیران</b><span>آخرین تغییرات ثبت‌شده</span></div></div><div class="list">${auditRows || '<div class="empty-table">فعالیتی ثبت نشده است.</div>'}</div></section>
    </div>`:''}`;
}

function toolbar({ type, search, status, plan, total, statusOptions, showPlan = true }) {
  return `<div class="toolbar" data-toolbar="${type}"><div class="search-box"><span>${icon('search',15)}</span><input class="input" data-filter="search" value="${escapeHtml(search)}" placeholder="جستجو با نام یا شماره موبایل…"></div>${showPlan ? `<select class="select" data-filter="plan"><option value="">همه پلن‌ها</option><option value="free" ${plan==='free'?'selected':''}>رایگان</option><option value="pro" ${plan==='pro'?'selected':''}>حرفه‌ای</option><option value="organization" ${plan==='organization'?'selected':''}>سازمانی</option></select>` : ''}<select class="select" data-filter="status"><option value="">همه وضعیت‌ها</option>${statusOptions.map(([value,label]) => `<option value="${value}" ${status===value?'selected':''}>${label}</option>`).join('')}</select><span class="toolbar-count">${n(total)} نتیجه</span></div>`;
}
function pager(type, pagination) {
  const buttons = [];
  const start = Math.max(1, pagination.page - 2), end = Math.min(pagination.pages, pagination.page + 2);
  for (let page = start; page <= end; page++) buttons.push(`<button class="${page===pagination.page?'active':''}" data-page-type="${type}" data-page="${page}">${n(page)}</button>`);
  return `<div class="pagination"><span>نمایش صفحه ${n(pagination.page)} از ${n(pagination.pages)}</span><div class="pager"><button data-page-type="${type}" data-page="${Math.max(1,pagination.page-1)}" ${pagination.page<=1?'disabled':''}>قبلی</button>${buttons.join('')}<button data-page-type="${type}" data-page="${Math.min(pagination.pages,pagination.page+1)}" ${pagination.page>=pagination.pages?'disabled':''}>بعدی</button></div></div>`;
}
async function renderUsers() {
  const q = state.users;
  const params = new URLSearchParams({ page:q.page, limit:15, ...(q.search&&{search:q.search}), ...(q.status&&{status:q.status}), ...(q.plan&&{plan:q.plan}) });
  const data = await api(`/api/admin/users?${params}`);
  const rows = data.rows.map(user => {
    const maxStorage = user.plan === 'organization' ? 10*1024**3 : user.plan === 'pro' ? 2*1024**3 : 100*1024**2;
    const used = Math.min(100, user.storage_bytes / maxStorage * 100), displayStatus = user.effective_status || user.status;
    return `<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(user.name))}</span><div><b>${escapeHtml(user.name)}${user.deletion_requested_at?'<i class="delete-request-dot" title="درخواست حذف حساب"></i>':''}</b><span dir="ltr">${escapeHtml(user.mobile)}</span></div></div></td><td><span class="status ${displayStatus}">${statusLabel(displayStatus)}</span></td><td><span class="plan-badge" style="--plan-color:${user.plan_color||'#94a3b8'}">${escapeHtml(user.plan_fa||'بدون پلن')}</span></td><td>${dateFa(user.created_at)}</td><td>${n(user.trades_count)}</td><td><div class="progress-mini"><span><i style="width:${used}%"></i></span><b>${bytes(user.storage_bytes)}</b></div></td><td><div class="expiry"><b>${relativeTime(user.last_seen_at)}</b><span>${n(user.active_sessions||0)} نشست فعال</span></div></td><td><button class="table-action" data-user-id="${user.id}" title="جزئیات و مدیریت">${icon('more',15)}</button></td></tr>`;
  }).join('');
  return `<div class="section-head"><div><span class="eyebrow">USERS & ACCESS</span><h2>مدیریت کاربران</h2><p>جستجو با نام یا موبایل، کنترل دسترسی، نشست‌ها، مصرف فضا، بازیابی و حذف امن حساب.</p></div></div>${toolbar({type:'users',...q,total:data.pagination.total,statusOptions:[['active','فعال'],['limited','محدود'],['suspended','مسدود'],['pending','در انتظار']]})}<section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>وضعیت</th><th>پلن</th><th>تاریخ ثبت‌نام</th><th>معاملات</th><th>فضای مصرفی</th><th>آخرین فعالیت</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="8"><div class="empty-table">کاربری با این فیلتر پیدا نشد.</div></td></tr>'}</tbody></table></div>${pager('users',data.pagination)}</section>`;
}

async function renderContacts(){
  const q=state.contacts,params=new URLSearchParams({page:q.page,limit:20,...(q.search&&{search:q.search}),...(q.source&&{source:q.source}),...(q.consent!==''&&{consent:q.consent})}),data=await api(`/api/admin/contacts?${params}`),canManage=hasPermission('users.manage');state.cache.contacts=data.rows;
  const sourceLabel={registered:'ثبت‌نام سایت',manual:'ثبت دستی',import:'ورودی CSV'};
  const rows=data.rows.map(contact=>`<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(contact.name))}</span><div><b>${escapeHtml(contact.name)}</b><span dir="ltr">${escapeHtml(contact.mobile)}</span></div></div></td><td><span class="status ${contact.user_id?'active':'pending'}">${contact.user_id?'متصل به کاربر':'مخاطب مستقل'}</span></td><td>${escapeHtml(sourceLabel[contact.source]||contact.source)}</td><td><div class="contact-tags">${(contact.tags||[]).map(tag=>`<span>${escapeHtml(tag)}</span>`).join('')||'—'}</div></td><td><span class="status ${contact.sms_consent?'active':'limited'}">${contact.sms_consent?'رضایت دارد':'بدون رضایت'}</span></td><td><div class="contact-note" title="${escapeHtml(contact.note||'')}">${escapeHtml(contact.note||'—')}</div></td><td>${dateFa(contact.updated_at,true)}</td><td>${canManage?`<button class="table-action" data-contact-id="${contact.id}">${icon('edit',13)}</button>`:'—'}</td></tr>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">USER MOBILE DIRECTORY</span><h2>شماره‌های ذخیره‌شده کاربران</h2><p>همگام‌سازی ثبت‌نام‌ها، افزودن دستی، برچسب، یادداشت، رضایت پیامک و ورود/خروج CSV.</p></div><div class="inline-actions">${canManage?`<button class="ghost-btn" data-sync-contacts>${icon('refresh',13)} همگام‌سازی</button><button class="ghost-btn" data-import-contacts>${icon('file',13)} ورود CSV</button><button class="primary-btn" data-add-contact>${icon('userPlus',13)} ذخیره شماره</button>`:''}<button class="ghost-btn" data-export-contacts>${icon('file',13)} خروجی CSV</button></div></div><div class="contact-metrics"><article class="card"><small>کل شماره‌ها</small><b>${n(data.metrics.total)}</b></article><article class="card"><small>کاربران ثبت‌نام‌شده</small><b>${n(data.metrics.registered)}</b></article><article class="card"><small>دستی و واردشده</small><b>${n(Number(data.metrics.manual||0)+Number(data.metrics.imported||0))}</b></article><article class="card"><small>رضایت دریافت پیامک</small><b>${n(data.metrics.consented)}</b></article></div><div class="toolbar" data-toolbar="contacts"><div class="search-box"><span>${icon('search',15)}</span><input class="input" data-filter="search" value="${escapeHtml(q.search)}" placeholder="نام، شماره موبایل یا برچسب…"></div><select class="select" data-filter="source"><option value="">همه منابع</option><option value="registered" ${q.source==='registered'?'selected':''}>ثبت‌نام سایت</option><option value="manual" ${q.source==='manual'?'selected':''}>ثبت دستی</option><option value="import" ${q.source==='import'?'selected':''}>CSV</option></select><select class="select" data-filter="consent"><option value="">همه وضعیت رضایت</option><option value="1" ${q.consent==='1'?'selected':''}>رضایت دارد</option><option value="0" ${q.consent==='0'?'selected':''}>بدون رضایت</option></select><span class="toolbar-count">${n(data.pagination.total)} شماره</span></div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>نام و شماره</th><th>اتصال</th><th>منبع</th><th>برچسب‌ها</th><th>رضایت پیامک</th><th>یادداشت</th><th>آخرین تغییر</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="8"><div class="empty-table">شماره‌ای ذخیره نشده است.</div></td></tr>'}</tbody></table></div>${pager('contacts',data.pagination)}</section>`;
}
function openContactEditor(contactId=null){const item=(state.cache.contacts||[]).find(contact=>contact.id===contactId);openModal(`<header class="modal-head"><div><h3 id="modalTitle">${item?'ویرایش شماره ذخیره‌شده':'ذخیره شماره جدید'}</h3><span class="modal-subtitle">${item?.user_id?'این شماره به حساب کاربر متصل است و تغییر آن روی حساب نیز اعمال می‌شود.':'مخاطب مستقل دفترچه کاربران'}</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>نام<input class="input" id="contactName" maxlength="120" value="${escapeHtml(item?.name||'')}"></label><label>شماره موبایل<input class="input" id="contactMobile" dir="ltr" maxlength="11" value="${escapeHtml(item?.mobile||'')}"></label><label class="full-field">برچسب‌ها<input class="input" id="contactTags" maxlength="500" value="${escapeHtml((item?.tags||[]).join(', '))}" placeholder="VIP, پیگیری, حرفه‌ای"></label><label class="full-field">یادداشت<textarea class="input settings-textarea short" id="contactNote" maxlength="2000">${escapeHtml(item?.note||'')}</textarea></label><label class="consent-check full-field"><input id="contactConsent" type="checkbox" ${item?.sms_consent?'checked':''}><span></span> رضایت دریافت پیامک توسط کاربر ثبت شده است.</label></div><div class="modal-actions">${item&&!item.user_id?`<button class="danger-btn" id="deleteContact">حذف شماره</button>`:''}<button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveContact">ذخیره</button></div></div>`);$('#contactMobile').addEventListener('input',event=>event.target.value=normalizeMobile(event.target.value).slice(0,11));$('#saveContact').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(item?`/api/admin/contacts/${item.id}`:'/api/admin/contacts',{method:item?'PATCH':'POST',body:JSON.stringify({name:$('#contactName').value,mobile:$('#contactMobile').value,tags:$('#contactTags').value.split(',').map(tag=>tag.trim()).filter(Boolean),note:$('#contactNote').value,smsConsent:$('#contactConsent').checked})});closeModal();toast('شماره موبایل ذخیره شد.');renderView('contacts')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});$('#deleteContact')?.addEventListener('click',async event=>{if(!confirm('این شماره از دفترچه حذف شود؟'))return;setBusy(event.currentTarget,true);try{await api(`/api/admin/contacts/${item.id}`,{method:'DELETE'});closeModal();toast('شماره حذف شد.');renderView('contacts')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}
function parseContactCsv(text){const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean);if(lines.length<2)return[];const parse=line=>{const out=[];let value='',quoted=false;for(let i=0;i<line.length;i++){const char=line[i];if(char==='"'){if(quoted&&line[i+1]==='"'){value+='"';i++}else quoted=!quoted}else if(char===','&&!quoted){out.push(value);value=''}else value+=char}out.push(value);return out};const headers=parse(lines[0]).map(h=>h.trim().toLowerCase());return lines.slice(1).map(line=>{const cells=parse(line),get=(...keys)=>{const index=headers.findIndex(h=>keys.includes(h));return index>=0?cells[index]:''};return{name:get('name','نام'),mobile:get('mobile','phone','شماره','شماره موبایل'),tags:get('tags','برچسب'),note:get('note','یادداشت'),smsConsent:['1','true','yes','بله'].includes(String(get('sms_consent','consent','رضایت')).toLowerCase())}})}
function openContactImporter(){openModal(`<header class="modal-head"><div><h3 id="modalTitle">ورود شماره‌ها از CSV</h3><span class="modal-subtitle">ستون‌های پیشنهادی: name, mobile, tags, note, sms_consent</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="csv-drop"><input id="contactCsvFile" type="file" accept=".csv,text/csv"><span>${icon('file',22)}</span><b>فایل CSV را انتخاب کنید</b><small>حداکثر ۲۰۰۰ ردیف در هر بار ورود</small></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="importContacts" disabled>ورود شماره‌ها</button></div></div>`);let rows=[];$('#contactCsvFile').addEventListener('change',async event=>{rows=parseContactCsv(await event.target.files[0]?.text());$('#importContacts').disabled=!rows.length;toast(`${n(rows.length)} ردیف آماده ورود است.`)});$('#importContacts').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const result=await api('/api/admin/contacts/import',{method:'POST',body:JSON.stringify({rows})});closeModal();toast(`${n(result.created)} شماره جدید و ${n(result.updated)} شماره به‌روزرسانی شد.`);renderView('contacts')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}
async function syncContacts(){try{const result=await api('/api/admin/contacts/sync',{method:'POST',body:'{}'});toast(`${n(result.count)} شماره ثبت‌نامی همگام شد.`);renderView('contacts')}catch(error){toast(error.message,'error')}}
function exportContacts(){if(location.protocol!=='file:'&&!window.PA_STANDALONE_MOCK){location.href='/api/admin/contacts/export';return}const rows=state.cache.contacts||[],csv=['name,mobile,tags,note,sms_consent,source',...rows.map(row=>[row.name,row.mobile,(row.tags||[]).join('|'),row.note||'',row.sms_consent,row.source].map(value=>`"${String(value).replace(/"/g,'""')}"`).join(','))].join('\n'),blob=new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='pa-user-contacts.csv';a.click();URL.revokeObjectURL(url)}

async function renderSupport(){
  const q=state.support,params=new URLSearchParams({...q.search&&{search:q.search},...q.status&&{status:q.status},...q.priority&&{priority:q.priority}}),data=await api(`/api/admin/support/requests?${params}`),canManage=hasPermission('users.manage')||hasPermission('users.security');state.cache.support=data.rows||[];
  const categories={general:'پرسش عمومی',account:'حساب کاربری',technical:'مشکل فنی',billing:'اشتراک و پرداخت',privacy:'حریم خصوصی',security:'امنیت'},priorities={low:'کم',normal:'عادی',high:'بالا',urgent:'فوری'},tone=status=>status==='open'?'failed':status==='in_progress'?'pending':status==='resolved'?'active':'limited';
  $('#navSupportCount').textContent=n(data.metrics.unread||data.metrics.open||0);
  const rows=(data.rows||[]).map(item=>`<tr><td><code class="source-code">${escapeHtml(item.public_reference)}</code></td><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(item.name))}</span><div><b>${escapeHtml(item.name)}</b><span dir="ltr">${escapeHtml(item.mobile||item.email||'—')}</span></div></div></td><td><div class="expiry"><b>${escapeHtml(item.subject)}${Number(item.unread_count||0)?`<i class="support-unread">${n(item.unread_count)}</i>`:''}</b><span>${escapeHtml(categories[item.category]||item.category)} · ${n(item.message_count||1)} پیام</span></div></td><td><span class="status ${tone(item.status)}">${statusLabel(item.status)}</span></td><td><span class="status ${item.priority==='urgent'?'failed':item.priority==='high'?'pending':'limited'}">${escapeHtml(priorities[item.priority]||item.priority)}</span></td><td>${dateFa(item.created_at,true)}</td><td><button class="table-action" data-support-id="${item.id}" title="مشاهده و رسیدگی">${icon(canManage?'edit':'eye',14)}</button></td></tr>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">CUSTOMER SUPPORT INBOX</span><h2>تیکت‌های پشتیبانی کاربران ژورنال</h2><p>تیکت‌های ارسالی از دکمه «پشتیبانی» داخل ژورنال و فرم تماس عمومی؛ همراه گفتگوی کامل، پاسخ عمومی، یادداشت داخلی، وضعیت، اولویت و Audit.</p></div></div><div class="contact-metrics"><article class="card"><small>کل درخواست‌ها</small><b>${n(data.metrics.total)}</b></article><article class="card"><small>باز</small><b>${n(data.metrics.open)}</b></article><article class="card"><small>در حال رسیدگی</small><b>${n(data.metrics.in_progress)}</b></article><article class="card"><small>پیام خوانده‌نشده</small><b>${n(data.metrics.unread||0)}</b></article><article class="card"><small>اولویت بالا / فوری</small><b>${n(data.metrics.priority)}</b></article></div><div class="toolbar" data-toolbar="support"><div class="search-box"><span>${icon('search',15)}</span><input class="input" data-filter="search" value="${escapeHtml(q.search)}" placeholder="کد پیگیری، نام، راه تماس یا موضوع…"></div><select class="select" data-filter="status"><option value="">همه وضعیت‌ها</option><option value="open" ${q.status==='open'?'selected':''}>باز</option><option value="in_progress" ${q.status==='in_progress'?'selected':''}>در حال رسیدگی</option><option value="resolved" ${q.status==='resolved'?'selected':''}>حل‌شده</option><option value="closed" ${q.status==='closed'?'selected':''}>بسته</option><option value="spam" ${q.status==='spam'?'selected':''}>هرزنامه</option></select><select class="select" data-filter="priority"><option value="">همه اولویت‌ها</option><option value="urgent" ${q.priority==='urgent'?'selected':''}>فوری</option><option value="high" ${q.priority==='high'?'selected':''}>بالا</option><option value="normal" ${q.priority==='normal'?'selected':''}>عادی</option><option value="low" ${q.priority==='low'?'selected':''}>کم</option></select><span class="toolbar-count">${n((data.rows||[]).length)} درخواست</span></div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>کد پیگیری</th><th>درخواست‌کننده</th><th>موضوع</th><th>وضعیت</th><th>اولویت</th><th>زمان ثبت</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="7"><div class="empty-table">درخواستی با این فیلتر پیدا نشد.</div></td></tr>'}</tbody></table></div></section>`;
}
async function openSupportRequest(requestId){
  const summary=(state.cache.support||[]).find(row=>row.id===requestId);if(!summary)return toast('درخواست پشتیبانی پیدا نشد.','error');
  const canManage=hasPermission('users.manage')||hasPermission('users.security'),categories={general:'پرسش عمومی',account:'حساب کاربری',technical:'مشکل فنی',billing:'اشتراک و پرداخت',privacy:'حریم خصوصی',security:'امنیت'},priorities={low:'کم',normal:'عادی',high:'بالا',urgent:'فوری'};
  let data;try{data=await api(`/api/admin/support/requests/${requestId}`)}catch(error){return toast(error.message,'error')}
  const item=data.item||summary,messages=data.messages||[],thread=messages.map(message=>{const internal=!!message.is_internal,admin=message.author_type==='admin',name=admin?(message.admin_name||'مدیر پشتیبانی'):(message.user_name||item.name||'کاربر');return `<article class="support-message ${admin?'admin':''} ${internal?'internal':''}"><p>${escapeHtml(message.message)}</p><footer><span>${internal?'یادداشت داخلی · ':''}${escapeHtml(name)}</span><time>${dateFa(message.created_at,true)}</time></footer></article>`}).join('');
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">درخواست ${escapeHtml(item.public_reference)}</h3><span class="modal-subtitle">${escapeHtml(categories[item.category]||item.category)} · ${dateFa(item.created_at,true)}</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="modal-user"><span class="user-avatar">${escapeHtml(initials(item.name))}</span><div><b>${escapeHtml(item.name)}</b><span dir="ltr">${escapeHtml([item.mobile,item.email].filter(Boolean).join(' · ')||'بدون راه تماس')}</span></div><span class="status ${item.status==='open'?'failed':item.status==='resolved'?'active':'pending'}" style="margin-right:auto">${statusLabel(item.status)}</span></div><section class="card" style="margin-top:14px;padding:16px"><div class="support-conversation-summary"><b>${escapeHtml(item.subject)}</b><span>·</span><span>${n(messages.length)} پیام</span><span>·</span><span>${escapeHtml(priorities[item.priority]||item.priority)}</span></div><div class="support-thread">${thread||`<article class="support-message"><p>${escapeHtml(item.message)}</p><footer><span>${escapeHtml(item.name)}</span><time>${dateFa(item.created_at,true)}</time></footer></article>`}</div></section>${canManage?`<div class="form-grid billing-form" style="margin-top:14px"><label>وضعیت<select class="select" id="supportStatus"><option value="open" ${item.status==='open'?'selected':''}>باز</option><option value="in_progress" ${item.status==='in_progress'?'selected':''}>در حال رسیدگی</option><option value="resolved" ${item.status==='resolved'?'selected':''}>حل‌شده</option><option value="closed" ${item.status==='closed'?'selected':''}>بسته</option><option value="spam" ${item.status==='spam'?'selected':''}>هرزنامه</option></select></label><label>اولویت<select class="select" id="supportPriority"><option value="low" ${item.priority==='low'?'selected':''}>کم</option><option value="normal" ${item.priority==='normal'?'selected':''}>عادی</option><option value="high" ${item.priority==='high'?'selected':''}>بالا</option><option value="urgent" ${item.priority==='urgent'?'selected':''}>فوری</option></select></label><label class="full-field">خلاصه داخلی پرونده<textarea class="input settings-textarea" id="supportNote" maxlength="4000" placeholder="این متن هرگز برای کاربر نمایش داده نمی‌شود.">${escapeHtml(item.admin_note||'')}</textarea></label></div><div class="support-reply-box"><label for="supportReply">پیام جدید</label><textarea class="input settings-textarea" id="supportReply" maxlength="4000" placeholder="پاسخ قابل مشاهده برای کاربر یا یادداشت داخلی را بنویسید…"></textarea><div class="support-reply-options"><label><input type="checkbox" id="supportInternal"> فقط یادداشت داخلی؛ برای کاربر ارسال نشود</label><div class="support-reply-actions"><button class="ghost-btn" id="saveSupportMeta">ذخیره وضعیت</button><button class="primary-btn" id="sendSupportReply">ارسال پیام</button></div></div></div>`:''}<div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button></div></div>`);
  $('#saveSupportMeta')?.addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(`/api/admin/support/requests/${item.id}`,{method:'PATCH',body:JSON.stringify({status:$('#supportStatus').value,priority:$('#supportPriority').value,adminNote:$('#supportNote').value})});toast('وضعیت، اولویت و یادداشت داخلی در Audit ثبت شد.');await renderView('support');await openSupportRequest(item.id)}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
  $('#sendSupportReply')?.addEventListener('click',async event=>{const message=$('#supportReply').value.trim(),isInternal=$('#supportInternal').checked;if(message.length<2)return toast('متن پیام باید حداقل ۲ کاراکتر باشد.','error');setBusy(event.currentTarget,true);try{await api(`/api/admin/support/requests/${item.id}/messages`,{method:'POST',body:JSON.stringify({message,isInternal,status:$('#supportStatus').value})});await api(`/api/admin/support/requests/${item.id}`,{method:'PATCH',body:JSON.stringify({status:$('#supportStatus').value,priority:$('#supportPriority').value,adminNote:$('#supportNote').value})});toast(isInternal?'یادداشت داخلی ثبت و Audit شد.':'پاسخ برای کاربر ارسال و Audit شد.');await renderView('support');await openSupportRequest(item.id)}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})
}

async function renderSubscriptions() {
  const canManageBilling=hasPermission('billing.manage'),plans=await api('/api/admin/plans');
  state.cache.plans=plans.rows;
  const planCards=plans.rows.map(plan=>`<article class="card plan-card ${plan.is_active?'':'inactive-plan'}" style="--plan-color:${escapeHtml(plan.color)}"><div class="plan-card-head"><span class="plan-mark">${icon(plan.name==='organization'?'crown':plan.name==='pro'?'trend':'users',17)}</span><span class="plan-badge" style="--plan-color:${escapeHtml(plan.color)}">${escapeHtml(plan.name_fa)}</span><span class="status ${plan.is_active?'active':'limited'}">${plan.is_active?'فعال':'غیرفعال'}</span></div><div class="plan-price">${plan.discount&&plan.discount.active?`<s class="plan-price-was">${toman(plan.discount.price)}</s><b>${toman(plan.discount.final_price)}</b><span>/ ماهانه</span><i class="plan-off-chip">${n(plan.discount.percent)}٪ تخفیف</i>`:`<b>${plan.price_monthly?toman(plan.price_monthly):'رایگان'}</b>${plan.price_monthly?'<span>/ ماهانه</span>':''}`}</div><p class="admin-plan-tagline">${escapeHtml(plan.tagline||'بدون متن معرفی')}</p><div class="plan-meta"><div><small>مشترک فعال</small><b>${n(plan.active_subscribers)}</b></div><div><small>سقف معامله</small><b>${n(plan.max_trades)}</b></div><div><small>قابلیت فعال</small><b>${n((plan.features||[]).filter(item=>item.is_enabled).length)}</b></div><div><small>مدت دسترسی</small><b>${Number(plan.duration_days||0)?`${n(plan.duration_days)} روز`:'نامحدود'}</b></div></div>${plan.is_recommended?'<div class="plan-recommended-chip">پیشنهاد اصلی سایت</div>':''}${canManageBilling?`<button class="plan-edit-btn" data-plan-id="${plan.id}">${icon('edit',13)} مدیریت کامل پلن و امکانات</button>`:''}</article>`).join('');
  const tabs=`<div class="billing-tabs"><button class="${state.subscriptionTab==='subscriptions'?'active':''}" data-billing-tab="subscriptions">${icon('card',14)} اشتراک‌ها</button><button class="${state.subscriptionTab==='coupons'?'active':''}" data-billing-tab="coupons">${icon('file',14)} کدهای تخفیف</button><button class="${state.subscriptionTab==='payments'?'active':''}" data-billing-tab="payments">${icon('revenue',14)} پرداخت‌ها و فاکتورها</button></div>`;
  let content='';if(state.subscriptionTab==='coupons')content=await renderCouponsContent();else if(state.subscriptionTab==='payments')content=await renderPaymentsContent();else content=await renderSubscriptionList();
  return `<div class="section-head"><div><span class="eyebrow">SUBSCRIPTIONS & REVENUE</span><h2>مدیریت اشتراک‌ها و پلن‌ها</h2><p>نام، معرفی، قیمت، ظرفیت، وضعیت انتشار، ترتیب و قابلیت‌های مستقل هر پلن مستقیماً روی سایت عمومی اعمال می‌شوند.</p></div>${canManageBilling?`<button class="primary-btn" data-add-plan>${icon('userPlus',14)} پلن جدید</button>`:''}</div><div class="plans-grid">${planCards}</div>${tabs}${content}`;
}

async function renderSubscriptionList() {
  const canManageBilling=hasPermission('billing.manage');
  const q = state.subscriptions;
  const params = new URLSearchParams({ page:q.page,limit:15,...(q.search&&{search:q.search}),...(q.status&&{status:q.status}),...(q.plan&&{plan:q.plan}) });
  const data = await api(`/api/admin/subscriptions?${params}`);
  const rows = data.rows.map(sub => `<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(sub.user_name))}</span><div><b>${escapeHtml(sub.user_name)}</b><span dir="ltr">${escapeHtml(sub.mobile)}</span></div></div></td><td><span class="plan-badge" style="--plan-color:${sub.plan_color}">${escapeHtml(sub.plan_fa)}</span></td><td><span class="status ${sub.status}">${statusLabel(sub.status)}</span></td><td><div class="expiry"><b>${dateFa(sub.started_at)}</b><span>شروع اشتراک</span></div></td><td><div class="expiry"><b>${dateFa(sub.expires_at)}</b><span>${sub.auto_renew?'تمدید خودکار':'تمدید دستی'}</span></div></td><td>${sub.coupon_code?`<span class="coupon-chip">${escapeHtml(sub.coupon_code)}</span>`:'—'}</td><td>${sub.payment_status?`<span class="status ${sub.payment_status}">${statusLabel(sub.payment_status)}</span>`:'—'}</td><td>${canManageBilling?`<button class="table-action" data-subscription-id="${sub.id}">${icon('edit',14)}</button>`:'—'}</td></tr>`).join('');
  return `${toolbar({type:'subscriptions',...q,total:data.pagination.total,statusOptions:[['active','فعال'],['trial','آزمایشی'],['expired','منقضی'],['cancelled','لغوشده']]})}<section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>پلن</th><th>وضعیت</th><th>شروع</th><th>پایان</th><th>تخفیف</th><th>پرداخت</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="8"><div class="empty-table">اشتراکی پیدا نشد.</div></td></tr>'}</tbody></table></div>${pager('subscriptions',data.pagination)}</section>`;
}

async function renderCouponsContent() {
  const canManageBilling=hasPermission('billing.manage');
  const data = await api('/api/admin/coupons');
  const now = new Date();
  const rows = data.rows.map(coupon => { const available=coupon.is_active&&new Date(coupon.starts_at)<=now&&(!coupon.expires_at||new Date(coupon.expires_at)>now)&&(!coupon.max_uses||coupon.used_count<coupon.max_uses); return `<tr><td><span class="coupon-code">${escapeHtml(coupon.code)}</span></td><td>${coupon.discount_type==='percent'?n(coupon.value)+'٪':toman(coupon.value)}</td><td>${n(coupon.used_count)}${coupon.max_uses?' / '+n(coupon.max_uses):''}</td><td>${dateFa(coupon.starts_at)}</td><td>${dateFa(coupon.expires_at)}</td><td><span class="status ${available?'active':'expired'}">${available?'فعال':'غیرفعال'}</span></td><td>${canManageBilling?`<button class="table-action" data-coupon-toggle="${coupon.id}" data-coupon-active="${coupon.is_active?1:0}" title="تغییر وضعیت">${icon(coupon.is_active?'close':'check',14)}</button>`:'—'}</td></tr>`; }).join('');
  return `<div class="billing-toolbar"><div><b>کدهای تخفیف</b><span>ساخت و کنترل ظرفیت کدها</span></div>${canManageBilling?`<button class="primary-btn" data-add-coupon>${icon('file',14)} ساخت کد تخفیف</button>`:''}</div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>کد</th><th>مقدار تخفیف</th><th>مصرف</th><th>شروع</th><th>پایان</th><th>وضعیت</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="7"><div class="empty-table">کد تخفیفی ساخته نشده است.</div></td></tr>'}</tbody></table></div></section>`;
}

async function renderPaymentsContent() {
  const q = state.payments;
  const params = new URLSearchParams({page:q.page,limit:15,...(q.search&&{search:q.search}),...(q.status&&{status:q.status})});
  const data = await api(`/api/admin/payments?${params}`);
  const rows = data.rows.map(payment => `<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(payment.user_name))}</span><div><b>${escapeHtml(payment.user_name)}</b><span dir="ltr">${escapeHtml(payment.mobile)}</span></div></div></td><td><span class="invoice-code">${escapeHtml(payment.invoice_number)}</span></td><td>${escapeHtml(payment.plan_fa||'—')}</td><td><div class="expiry"><b>${toman(payment.amount)}</b><span>${payment.discount_amount?toman(payment.discount_amount)+' تخفیف':'بدون تخفیف'}</span></div></td><td><span class="status ${payment.status}">${statusLabel(payment.status)}</span></td><td>${escapeHtml(payment.provider||'—')}</td><td>${dateFa(payment.created_at,true)}</td><td><button class="table-action" data-payment-id="${payment.id}">${icon('file',14)}</button></td></tr>`).join('');
  return `<div class="toolbar" data-toolbar="payments"><div class="search-box"><span>${icon('search',15)}</span><input class="input" data-filter="search" value="${escapeHtml(q.search)}" placeholder="نام، موبایل یا شماره فاکتور…"></div><select class="select" data-filter="status"><option value="">همه پرداخت‌ها</option><option value="paid" ${q.status==='paid'?'selected':''}>پرداخت‌شده</option><option value="pending" ${q.status==='pending'?'selected':''}>در انتظار</option><option value="failed" ${q.status==='failed'?'selected':''}>ناموفق</option><option value="refunded" ${q.status==='refunded'?'selected':''}>بازپرداخت‌شده</option><option value="partially_refunded" ${q.status==='partially_refunded'?'selected':''}>بازپرداخت جزئی</option></select><span class="toolbar-count">${n(data.pagination.total)} پرداخت</span></div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>فاکتور</th><th>پلن</th><th>مبلغ</th><th>وضعیت</th><th>درگاه</th><th>تاریخ</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="8"><div class="empty-table">پرداختی پیدا نشد.</div></td></tr>'}</tbody></table></div>${pager('payments',data.pagination)}</section>`;
}

async function renderUsage() {
  const canManageResources=hasPermission('resources.manage');
  if (!hasPermission('resources.view') && hasPermission('resources.security')) state.usageTab='files';
  if (state.usageTab === 'files') return renderFileManagement();
  const [data, gateway] = await Promise.all([
    api('/api/admin/usage'),
    api('/api/admin/sms/status').catch(() => null),
  ]);
  state.cache.smsGateway = gateway;
  state.cache.smsProviders=data.providers;
  const successRate = data.sms.total ? Math.round(Number(data.sms.sent||0)/data.sms.total*100) : 100;
  const providerHealth = { healthy:['فعال','active'], degraded:['اختلال جزئی','pending'], down:['قطع','failed'] };
  const providerCards = data.providers.map(provider => { const health = !provider.configured ? ['بدون اتصال','pending'] : !provider.is_enabled ? ['غیرفعال','pending'] : (providerHealth[provider.status]||[provider.status,'pending']); return `<article class="sms-provider ${provider.is_primary?'primary':''} ${provider.is_enabled?'':'disabled'}"><div class="sms-provider-head"><div><span class="provider-radio">${provider.is_primary?icon('check',12):''}</span><div><b>${escapeHtml(provider.name)}</b><small>${provider.is_primary?'ارائه‌دهنده اصلی':'ارائه‌دهنده جایگزین'}</small></div></div><span class="status ${health[1]}">${health[0]}</span></div><div class="provider-balance"><small>موجودی پنل</small><b>${toman(provider.balance)}</b></div><div class="provider-stats"><span>${n(provider.month_total)} ارسال ماه</span><span>${n(provider.month_failed)} ناموفق</span><span>${toman(provider.unit_cost)} / پیامک</span></div><div class="provider-actions"><span class="provider-enabled">${provider.configured?(provider.is_enabled?'✅ فعال و آماده ارسال':'⏸ تنظیم‌شده ولی غیرفعال'):'⚠️ اطلاعات اتصال ندارد'}</span>${canManageResources?`<button class="ghost-btn" data-provider-config="${provider.id}">تنظیم اتصال</button>`:''}${canManageResources&&provider.configured?`<button class="ghost-btn" data-provider-${provider.is_enabled?'disable':'enable'}="${provider.id}">${provider.is_enabled?'غیرفعال کردن':'فعال کردن'}</button>`:''}${canManageResources&&!provider.is_primary&&provider.is_enabled&&provider.status!=='down'?`<button class="ghost-btn" data-provider-primary="${provider.id}">انتخاب به‌عنوان اصلی</button>`:''}${canManageResources?`<button class="ghost-btn" data-provider-diagnose="${provider.id}">عیب‌یابی</button>`:''}${canManageResources&&provider.configured?`<button class="ghost-btn" data-provider-clear="${provider.id}">پاک کردن کلید</button>`:''}${canManageResources?`<button class="ghost-btn danger-text" data-provider-delete="${provider.id}">حذف</button>`:''}</div></article>`; }).join('');
  const suspiciousRows = data.suspiciousRequests.map(item => `<tr><td><div class="user-cell"><span class="user-avatar suspicious-avatar">${icon('shield',14)}</span><div><b>${escapeHtml(item.user_name||'درخواست ناشناس')}</b><span dir="ltr">${escapeHtml(item.mobile)}</span></div></div></td><td><span class="source-code">${escapeHtml(item.request_ip||'—')}</span></td><td><div class="suspicious-reason">${escapeHtml(item.suspicious_reason||'الگوی ارسال غیرعادی')}</div></td><td><span class="status ${item.status==='failed'?'failed':'pending'}">${statusLabel(item.status)}</span></td><td>${dateFa(item.created_at,true)}</td></tr>`).join('');
  const failedRows = data.failedSms.map(log => `<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(log.user_name||'کاربر'))}</span><div><b>${escapeHtml(log.user_name||'کاربر حذف‌شده')}</b><span dir="ltr">${escapeHtml(log.mobile)}</span></div></div></td><td><span class="source-code">${escapeHtml(log.request_ip||'—')}</span></td><td>${escapeHtml(log.provider)}</td><td><span class="error-code">${escapeHtml(log.error_code||'DELIVERY_FAILED')}</span></td><td>${toman(log.cost)}</td><td>${dateFa(log.created_at,true)}</td></tr>`).join('');
  const recentRows = data.smsLogs.map(log => `<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(log.user_name||'کاربر'))}</span><div><b>${escapeHtml(log.user_name||'کاربر حذف‌شده')}</b><span dir="ltr">${escapeHtml(log.mobile)}</span></div></div></td><td>${escapeHtml(log.type==='otp'?'کد ورود':'امنیتی')}</td><td>${escapeHtml(log.provider)}</td><td><span class="status ${log.status}">${statusLabel(log.status)}</span></td><td>${toman(log.cost)}</td><td>${dateFa(log.created_at,true)}</td></tr>`).join('');
  const rateRows = [...data.rateUsage.mobiles.slice(0,5).map(item=>({key:item.mobile,count:item.request_count,limit:data.settings.mobile_limit_count,type:'شماره موبایل',failed:item.failed_count})),...data.rateUsage.ips.slice(0,5).map(item=>({key:item.request_ip,count:item.request_count,limit:data.settings.ip_limit_count,type:'آدرس IP',failed:item.failed_count}))].sort((a,b)=>b.count/b.limit-a.count/a.limit).slice(0,8).map(item=>{const percent=Math.min(100,item.count/Math.max(1,item.limit)*100);return `<div class="rate-row"><div><b dir="ltr">${escapeHtml(item.key||'—')}</b><span>${item.type} · ${n(item.failed)} ناموفق</span></div><div class="rate-progress"><i style="width:${percent}%;background:${percent>=100?'#f87171':percent>=70?'#fbbf24':'#22d3ee'}"></i></div><strong>${n(item.count)} / ${n(item.limit)}</strong></div>`}).join('');
  const storageRows = data.topStorage.map(user => { const percent=Math.min(100,user.storage_bytes/Math.max(1,user.max_storage_bytes)*100); return `<div class="storage-row"><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(user.name))}</span><div><b>${escapeHtml(user.name)}</b><span>${escapeHtml(user.plan_fa||'—')}</span></div></div><div class="storage-bar"><i style="width:${percent}%;background:${percent>85?'#f87171':percent>65?'#fbbf24':'linear-gradient(90deg,#0891b2,#22d3ee)'}"></i></div><span class="storage-value">${bytes(user.storage_bytes)} / ${bytes(user.max_storage_bytes)}</span></div>`; }).join('');
  const primary = data.providers.find(provider=>provider.is_primary);
  return `<div class="section-head"><div><span class="eyebrow">SMS SECURITY & DELIVERY</span><h2>مدیریت پیامک و فایل‌ها</h2><p>کنترل ارسال OTP، هزینه، امنیت فایل‌ها و فضای تصاویر کاربران.</p></div>${canManageResources?`<button class="ghost-btn emergency-switch" data-sms-failover>${icon('refresh',14)} تعویض اضطراری ارائه‌دهنده</button>`:''}</div><div class="resource-tabs"><button class="active" data-usage-tab="sms">${icon('sms',14)} مدیریت پیامک</button><button data-usage-tab="files">${icon('database',14)} فایل‌ها و تصاویر</button></div>${smsGatewayBanner(gateway, canManageResources)}<div class="sms-metrics"><article class="card sms-metric"><span>${icon('sms',18)}</span><div><small>کدهای ارسال‌شده این ماه</small><b>${n(data.sms.sent)}</b><em>${n(successRate)}٪ موفقیت</em></div></article><article class="card sms-metric"><span class="amber">${icon('revenue',18)}</span><div><small>هزینه ماه جاری</small><b>${toman(data.sms.cost)}</b><em>${n(data.sms.total)} درخواست</em></div></article><article class="card sms-metric"><span class="green">${icon('card',18)}</span><div><small>موجودی کل پنل‌ها</small><b>${toman(data.providerBalance)}</b><em>${escapeHtml(primary?.name||'بدون ارائه‌دهنده')}</em></div></article><article class="card sms-metric"><span class="red">${icon('alert',18)}</span><div><small>پیامک‌های ناموفق</small><b>${n(data.sms.failed)}</b><em>${n(data.sms.suspicious)} مشکوک</em></div></article></div><div class="sms-config-grid"><section class="card sms-panel"><div class="card-head"><div class="card-title"><b>ارائه‌دهندگان پیامک</b><span>سلامت، موجودی و مسیر اصلی ارسال</span></div><span class="soft-chip">${n(data.providers.filter(x=>x.is_enabled).length)} درگاه فعال</span></div><div class="sms-provider-list">${providerCards}</div></section><section class="card sms-panel"><div class="card-head"><div class="card-title"><b>محدودیت ارسال و OTP</b><span>سیاست ضد سوءاستفاده برای هر شماره و IP</span></div></div><div class="sms-settings-form"><div class="limit-inputs"><label>حد هر شماره<input class="input" id="smsMobileLimit" ${canManageResources?'':'disabled'} type="number" min="1" max="50" value="${data.settings.mobile_limit_count}"></label><label>حد هر IP<input class="input" id="smsIpLimit" ${canManageResources?'':'disabled'} type="number" min="1" max="200" value="${data.settings.ip_limit_count}"></label><label>بازه زمانی (دقیقه)<input class="input" id="smsRateWindow" ${canManageResources?'':'disabled'} type="number" min="1" max="1440" value="${data.settings.rate_window_minutes}"></label></div><label class="otp-template-label">متن پیامک OTP<textarea class="input sms-template" id="smsOtpTemplate" ${canManageResources?'':'disabled'} maxlength="500">${escapeHtml(data.settings.otp_template)}</textarea><small>متغیر <code>{code}</code> با کد ورود جایگزین می‌شود.</small></label><div class="auto-failover-row"><div><b>تعویض خودکار هنگام قطعی</b><span>در صورت قطع درگاه اصلی، مسیر سالم بعدی انتخاب شود.</span></div><button type="button" class="toggle ${data.settings.auto_failover?'on':''}" id="smsAutoFailover" ${canManageResources?'':'disabled'}><i></i></button></div>${canManageResources?`<button class="primary-btn save-sms-settings" data-save-sms-settings>ذخیره سیاست پیامک</button>`:''}</div></section></div><div class="two-col sms-monitor-grid"><section class="card sms-panel"><div class="card-head"><div class="card-title"><b>مصرف محدودیت در لحظه</b><span>بازه ${n(data.settings.rate_window_minutes)} دقیقه‌ای برای شماره و IP</span></div></div><div class="rate-list">${rateRows||'<div class="secure-empty">در بازه فعلی درخواست پرتکراری ثبت نشده است.</div>'}</div></section><section class="card sms-panel suspicious-summary"><div class="card-head"><div class="card-title"><b>تشخیص درخواست مشکوک</b><span>الگوهای پرتکرار، IP مشترک و خطای متوالی</span></div><span class="status ${data.suspiciousRequests.length?'pending':'active'}">${data.suspiciousRequests.length?n(data.suspiciousRequests.length)+' مورد':'بدون هشدار'}</span></div><div class="security-rules"><div>${icon('shield',15)} عبور از حد شماره یا IP</div><div>${icon('activity',15)} چند شماره از یک IP مشترک</div><div>${icon('alert',15)} خطاهای متوالی در تحویل OTP</div></div></section></div><section class="card table-card" style="margin-top:13px"><div class="card-head table-section-head"><div class="card-title"><b>درخواست‌های مشکوک</b><span>رخدادهایی که برای بررسی امنیتی علامت‌گذاری شده‌اند</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر / شماره</th><th>IP</th><th>دلیل تشخیص</th><th>نتیجه ارسال</th><th>زمان</th></tr></thead><tbody>${suspiciousRows||'<tr><td colspan="5"><div class="empty-table">درخواست مشکوکی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section><section class="card table-card" style="margin-top:13px"><div class="card-head table-section-head"><div class="card-title"><b>پیامک‌های ناموفق</b><span>آخرین خطاهای تحویل برای بررسی و تغییر درگاه</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر / شماره</th><th>IP</th><th>ارائه‌دهنده</th><th>کد خطا</th><th>هزینه</th><th>زمان</th></tr></thead><tbody>${failedRows||'<tr><td colspan="6"><div class="empty-table">پیامک ناموفقی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section><div class="resource-divider"><span>مصرف فضای ذخیره‌سازی</span></div><div class="usage-hero"><article class="card usage-card" style="--tone:#22d3ee"><div class="usage-card-top"><div><span class="eyebrow">OBJECT STORAGE</span><b>فضای تصاویر و فایل‌ها</b></div><span class="usage-card-icon">${icon('database',20)}</span></div><div class="usage-number">${bytes(data.storage.total)}</div><div class="usage-caption">مصرف کل کاربران</div><div class="usage-stats"><div><small>میانگین کاربر</small><b>${bytes(data.storage.average)}</b></div><div><small>بیشترین مصرف</small><b>${bytes(data.storage.largest)}</b></div><div><small>وضعیت</small><b style="color:#66da8c">پایدار</b></div></div></article><article class="card usage-card"><div class="card-head"><div class="card-title"><b>بیشترین مصرف فضا</b><span>۱۰ کاربر اول بر اساس حجم فایل</span></div></div><div class="storage-list">${storageRows}</div></article></div><section class="card table-card" style="margin-top:13px"><div class="card-head table-section-head"><div class="card-title"><b>آخرین پیامک‌ها</b><span>وضعیت تحویل و هزینه ارسال</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>نوع</th><th>ارائه‌دهنده</th><th>وضعیت</th><th>هزینه</th><th>زمان</th></tr></thead><tbody>${recentRows}</tbody></table></div></section>`;
}

async function renderFileManagement() {
  const data = await api('/api/admin/files/overview');
  const canManageResources=hasPermission('resources.manage'),canReviewFiles=canManageResources||hasPermission('resources.security');
  state.cache.fileOverview = data;
  const typeLabels = {'image/jpeg':'JPG / JPEG','image/png':'PNG','image/webp':'WebP','image/gif':'GIF','image/svg+xml':'SVG'};
  const formatOptions = ['image/jpeg','image/png','image/webp','image/gif'].map(type=>`<label class="format-check"><input type="checkbox" name="allowedMime" value="${type}" ${data.settings.allowed_mime_types.includes(type)?'checked':''}><span>${typeLabels[type]}</span></label>`).join('');
  const planCaps = data.plans.map(plan=>`<article class="file-plan-cap" style="--plan-color:${plan.color}"><div><span class="plan-badge" style="--plan-color:${plan.color}">${escapeHtml(plan.name_fa)}</span><small>سقف فعلی ${bytes(plan.max_storage_bytes)}</small></div><label>سقف فضا (MB)<input class="input" type="number" min="50" max="102400" value="${Math.round(plan.max_storage_bytes/1048576)}" data-plan-storage-input="${plan.id}"></label><button class="ghost-btn" data-save-plan-storage="${plan.id}">ذخیره سقف</button></article>`).join('');
  const orphanRows = data.orphanedFiles.map(file=>{const age=Math.floor((Date.now()-new Date(file.orphaned_at||file.uploaded_at))/86400000),eligible=age>=data.settings.orphan_retention_days;return `<tr><td><div class="file-cell"><span>${icon('file',15)}</span><div><b>${escapeHtml(file.original_name)}</b><small>${escapeHtml(file.mime_type)}</small></div></div></td><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(file.user_name||'—'))}</span><div><b>${escapeHtml(file.user_name||'کاربر حذف‌شده')}</b><span dir="ltr">${escapeHtml(file.mobile||'—')}</span></div></div></td><td>${bytes(file.size_bytes)}</td><td><div class="expiry"><b>${dateFa(file.orphaned_at||file.uploaded_at)}</b><span>${n(age)} روز رهاشده</span></div></td><td><span class="status ${eligible?'failed':'pending'}">${eligible?'آماده حذف':'در مهلت نگهداری'}</span></td><td>${canReviewFiles?`<button class="table-action danger-action" data-file-delete="${file.id}" title="حذف فایل">${icon('close',14)}</button>`:'—'}</td></tr>`}).join('');
  const suspiciousRows = data.suspiciousFiles.map(file=>`<tr><td><div class="file-cell"><span class="${file.status==='quarantined'?'quarantined':''}">${icon('shield',15)}</span><div><b>${escapeHtml(file.original_name)}</b><small dir="ltr">${escapeHtml(file.checksum_sha256?.slice(0,16)||'بدون هش')}</small></div></div></td><td>${escapeHtml(file.mime_type)}</td><td>${bytes(file.size_bytes)}</td><td><div class="suspicious-reason" title="${escapeHtml(file.scan_reason||'نیازمند بررسی')}">${escapeHtml(file.scan_reason||'نیازمند بررسی')}</div></td><td><span class="status ${file.status==='quarantined'?'failed':'pending'}">${file.status==='quarantined'?'قرنطینه':'مشکوک'}</span></td><td>${canReviewFiles?`<button class="table-action" data-file-review="${file.id}">${icon('more',15)}</button>`:'—'}</td></tr>`).join('');
  const formatRows = data.formatStats.map(item=>{const allowed=data.settings.allowed_mime_types.includes(item.mime_type);return `<div class="format-stat"><span class="file-type-icon ${allowed?'safe':'unsafe'}">${icon(allowed?'check':'alert',13)}</span><div><b>${escapeHtml(typeLabels[item.mime_type]||item.mime_type)}</b><small>${n(item.file_count)} فایل · ${bytes(item.total_bytes)}</small></div><span class="status ${allowed?'active':'failed'}">${allowed?'مجاز':'غیرمجاز'}</span></div>`}).join('');
  return `<div class="section-head"><div><span class="eyebrow">FILE SECURITY & STORAGE</span><h2>مدیریت پیامک و فایل‌ها</h2><p>شناسایی فایل رهاشده، کنترل فرمت و حجم، بررسی امنیتی و سقف فضای پلن‌ها.</p></div>${canManageResources?`<button class="danger-btn cleanup-btn" data-cleanup-orphans ${data.metrics.cleanup_eligible?'':'disabled'}>${icon('alert',14)} پاک‌سازی ${n(data.metrics.cleanup_eligible)} فایل قدیمی</button>`:''}</div><div class="resource-tabs">${canManageResources?`<button data-usage-tab="sms">${icon('sms',14)} مدیریت پیامک</button>`:''}<button class="active" data-usage-tab="files">${icon('database',14)} فایل‌ها و تصاویر</button></div><div class="file-metrics"><article class="card file-metric"><span>${icon('database',18)}</span><div><small>فضای مصرف‌شده کاربران</small><b>${bytes(data.metrics.reported_user_bytes)}</b><em>${n(data.metrics.total_files)} فایل ثبت‌شده</em></div></article><article class="card file-metric orphan"><span>${icon('file',18)}</span><div><small>فایل‌های بدون معامله</small><b>${n(data.metrics.orphan_files)}</b><em>${bytes(data.metrics.orphan_bytes)} قابل بررسی</em></div></article><article class="card file-metric suspicious"><span>${icon('shield',18)}</span><div><small>فایل‌های مشکوک</small><b>${n(data.metrics.suspicious_files)}</b><em>${n(data.metrics.quarantined_files)} قرنطینه‌شده</em></div></article><article class="card file-metric violation"><span>${icon('alert',18)}</span><div><small>تخطی از سیاست فایل</small><b>${n(Number(data.metrics.invalid_format_files)+Number(data.metrics.oversized_files))}</b><em>${n(data.metrics.oversized_files)} بیش‌ازحد حجیم</em></div></article></div>${canManageResources?`<div class="file-config-grid"><section class="card file-policy-card"><div class="card-head"><div class="card-title"><b>محدودیت فرمت و حجم</b><span>سیاست پذیرش و نگهداری تصاویر</span></div></div><div class="format-options">${formatOptions}</div><div class="file-policy-inputs"><label>حداکثر حجم هر فایل (MB)<input class="input" id="maxFileSize" type="number" min="0.5" max="100" step="0.5" value="${(data.settings.max_file_size_bytes/1048576).toFixed(1)}"></label><label>مهلت فایل رهاشده (روز)<input class="input" id="orphanRetention" type="number" min="1" max="365" value="${data.settings.orphan_retention_days}"></label></div><div class="auto-failover-row"><div><b>پاک‌سازی خودکار فایل‌های رهاشده</b><span>پس از پایان مهلت نگهداری، فایل بدون معامله حذف شود.</span></div><button type="button" class="toggle ${data.settings.auto_cleanup?'on':''}" id="fileAutoCleanup"><i></i></button></div><button class="primary-btn" data-save-file-settings>ذخیره سیاست فایل</button></section><section class="card file-policy-card"><div class="card-head"><div class="card-title"><b>فرمت‌های موجود</b><span>حجم و تعداد فایل‌ها بر اساس نوع</span></div></div><div class="format-stats">${formatRows}</div><div class="file-policy-note">${icon('info',14)} فایل SVG و فرمت‌های اجرایی به‌صورت پیش‌فرض مجاز نیستند.</div></section></div>`:''}${canManageResources?`<section class="card plan-storage-card"><div class="card-head"><div class="card-title"><b>سقف فضای هر پلن</b><span>فضای قابل استفاده برای تصاویر معاملات هر کاربر</span></div></div><div class="file-plan-grid">${planCaps}</div></section>`:''}<section class="card table-card" style="margin-top:13px"><div class="card-head table-section-head"><div class="card-title"><b>فایل‌های بدون معامله</b><span>فایل‌هایی که به هیچ معامله‌ای متصل نیستند</span></div><span class="soft-chip">${n(data.orphanedFiles.length)} مورد</span></div><div class="table-scroll"><table class="data-table"><thead><tr><th>فایل</th><th>کاربر</th><th>حجم</th><th>زمان رهاشدن</th><th>وضعیت پاک‌سازی</th><th></th></tr></thead><tbody>${orphanRows||'<tr><td colspan="6"><div class="empty-table">فایل رهاشده‌ای وجود ندارد.</div></td></tr>'}</tbody></table></div></section><section class="card table-card" style="margin-top:13px"><div class="card-head table-section-head"><div class="card-title"><b>بررسی فایل‌های مشکوک</b><span>فایل‌های ناسازگار، بیش‌ازحد حجیم یا دارای امضای غیرعادی</span></div><span class="status ${data.suspiciousFiles.length?'pending':'active'}">${n(data.suspiciousFiles.length)} مورد</span></div><div class="table-scroll"><table class="data-table"><thead><tr><th>فایل / هش</th><th>فرمت</th><th>حجم</th><th>دلیل تشخیص</th><th>وضعیت</th><th></th></tr></thead><tbody>${suspiciousRows||'<tr><td colspan="6"><div class="empty-table">فایل مشکوکی وجود ندارد.</div></td></tr>'}</tbody></table></div></section>`;
}

async function renderCms() {
  const canManageStructured=hasPermission('cms.manage'),[data,faqData]=await Promise.all([canManageStructured?api('/api/admin/cms/pages'):Promise.resolve({rows:[]}),api('/api/admin/marketing/faqs')]),pages=data.rows||[],faqs=faqData.rows||[];
  state.cache.marketingFaqs=faqs;
  if(!pages.some(page=>page.id===state.cms.selectedPageId))state.cms.selectedPageId=pages[0]?.id||null;
  const details=canManageStructured&&state.cms.selectedPageId?await api(`/api/admin/cms/pages/${state.cms.selectedPageId}/sections`):{page:null,sections:[]};
  state.cache.cmsPages=pages;state.cache.cmsPage=details.page;state.cache.cmsSections=details.sections;
  const statusText={published:'منتشرشده',draft:'پیش‌نویس',archived:'بایگانی'},typeText={hero:'Hero',content:'محتوا',feature:'قابلیت',cta:'دعوت به اقدام',footer:'فوتر',form:'فرم',custom:'سفارشی'};
  const pageCards=pages.map(page=>`<button class="cms-page-card ${page.id===state.cms.selectedPageId?'active':''}" data-cms-page="${page.id}"><span>${icon(page.status==='published'?'eye':'file',16)}</span><div><b>${escapeHtml(page.title)}</b><small dir="ltr">/${escapeHtml(page.slug)}</small></div><em>${n(page.section_count)} سکشن</em><i class="status ${page.status==='published'?'active':page.status==='draft'?'pending':'limited'}">${statusText[page.status]}</i></button>`).join('');
  const sectionCards=details.sections.map(section=>`<article class="card cms-section-card"><div class="cms-section-order">${n(section.sort_order)}</div><div class="cms-section-main"><div class="cms-section-head"><span class="soft-chip">${escapeHtml(typeText[section.section_type]||section.section_type)}</span><code>${escapeHtml(section.section_key)}</code><span class="status ${section.status==='published'?'active':'pending'}">${statusText[section.status]}</span></div>${section.image_url?`<div class="cms-image-chip">${icon('file',12)} تصویر · ${escapeHtml(section.image_alt||section.image_url)}</div>`:''}<h3>${escapeHtml(section.title||'بدون عنوان')}</h3><p>${escapeHtml(section.body||'بدون متن')}</p>${section.button_label?`<div class="cms-button-preview">${icon('arrow',12)} ${escapeHtml(section.button_label)} <small dir="ltr">${escapeHtml(section.button_url||'بدون لینک')}</small></div>`:''}</div><div class="cms-section-actions"><button class="table-action" data-cms-history="section:${section.id}" title="تاریخچه">${icon('history',14)}</button><button class="table-action" data-duplicate-cms-section="${section.id}" title="تکثیر">${icon('file',14)}</button><button class="table-action" data-edit-cms-section="${section.id}" title="ویرایش">${icon('edit',14)}</button><button class="table-action danger-action" data-archive-cms-section="${section.id}" title="بایگانی">${icon('close',14)}</button></div></article>`).join('');
  const faqCategory={why:'چرا سایت ما؟',product:'محصول',security:'امنیت',pricing:'قیمت',privacy:'حریم خصوصی',support:'پشتیبانی'},faqCards=faqs.map(item=>`<article class="marketing-faq-card ${item.status==='archived'?'archived':''}"><div class="faq-order">${n(item.sort_order)}</div><div class="faq-admin-main"><div><span class="soft-chip">${escapeHtml(faqCategory[item.category]||item.category)}</span>${item.is_featured?'<span class="soft-chip feature-chip">ویژه</span>':''}<span class="status ${item.status==='published'?'active':item.status==='draft'?'pending':'limited'}">${statusText[item.status]}</span></div><h3>${escapeHtml(item.question)}</h3><p>${escapeHtml(item.answer)}</p></div><div class="faq-admin-actions"><button class="table-action" data-faq-up="${item.id}" title="انتقال به بالا">↑</button><button class="table-action" data-faq-down="${item.id}" title="انتقال به پایین">↓</button><button class="table-action" data-edit-marketing-faq="${item.id}" title="ویرایش">${icon('edit',14)}</button><button class="table-action danger-action" data-delete-marketing-faq="${item.id}" title="حذف">${icon('close',14)}</button></div></article>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">STRUCTURED CONTENT MANAGEMENT</span><h2>مدیریت محتوای سایت</h2><p>صفحه، سؤال، سکشن، عنوان، متن، ترتیب نمایش، انتشار و پیش‌نمایش محتوای سایت.</p></div><div class="inline-actions"><button class="primary-btn" data-add-marketing-faq>${icon('userPlus',13)} سؤال جدید</button>${canManageStructured?`<button class="ghost-btn" data-manage-cms-menus>${icon('menu',13)} مدیریت منوها</button><button class="primary-btn" data-add-cms-page>${icon('file',14)} صفحه جدید</button>`:''}</div></div><section class="card marketing-faq-manager"><div class="card-head"><div class="card-title"><b>سؤال‌های صفحه اصلی و FAQ</b><span>سؤال‌های «چرا SmartJournal؟» و سایر پاسخ‌ها؛ قابل انتشار، ویرایش، حذف و مرتب‌سازی</span></div><span class="soft-chip">${n(faqs.filter(item=>item.status==='published').length)} منتشرشده</span></div><div class="marketing-faq-list">${faqCards||'<div class="empty-table">سؤالی ثبت نشده است.</div>'}</div></section>${canManageStructured?`<div class="cms-layout"><aside class="card cms-pages-panel"><div class="card-head"><div class="card-title"><b>صفحات سایت</b><span>${n(pages.length)} صفحه ساختاریافته</span></div></div><div class="cms-page-list">${pageCards||'<div class="empty-table">صفحه‌ای ساخته نشده است.</div>'}</div></aside><section class="cms-content-panel">${details.page?`<div class="card cms-page-header"><div><span class="eyebrow">/${escapeHtml(details.page.slug)}</span><h3>${escapeHtml(details.page.title)}</h3><p>${escapeHtml(details.page.meta_description||'بدون توضیحات متا')}</p></div><div><button class="ghost-btn" data-secure-cms-preview>${icon('eye',13)} پیش‌نمایش امن</button><button class="ghost-btn" data-cms-history="page:${details.page.id}">${icon('history',13)} نسخه‌ها</button><button class="ghost-btn" data-duplicate-cms-page="${details.page.id}">${icon('file',13)} تکثیر</button><button class="ghost-btn" data-edit-cms-page="${details.page.id}">${icon('edit',13)} SEO و تنظیمات</button><button class="primary-btn compact-btn" data-add-cms-section>${icon('userPlus',13)} سکشن جدید</button></div></div><div class="cms-section-list">${sectionCards||'<div class="card empty-table">این صفحه هنوز سکشن ندارد.</div>'}</div>`:'<div class="card empty-table">برای شروع یک صفحه جدید بسازید.</div>'}</section></div>`:''}`;
}
function openMarketingFaqEditor(faqId=null){
  const item=(state.cache.marketingFaqs||[]).find(row=>row.id===faqId),categories=[['why','چرا SmartJournal؟'],['product','محصول و امکانات'],['security','امنیت'],['pricing','قیمت و اشتراک'],['privacy','حریم خصوصی'],['support','پشتیبانی']];
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">${item?'ویرایش سؤال':'افزودن سؤال جدید'}</h3><span class="modal-subtitle">محتوای منتشرشده بدون نیاز به تغییر کد روی سایت نمایش داده می‌شود.</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>دسته‌بندی<select class="select" id="marketingFaqCategory">${categories.map(([value,label])=>`<option value="${value}" ${item?.category===value?'selected':''}>${label}</option>`).join('')}</select></label><label>وضعیت<select class="select" id="marketingFaqStatus"><option value="draft" ${item?.status==='draft'||!item?'selected':''}>پیش‌نویس</option><option value="published" ${item?.status==='published'?'selected':''}>منتشرشده</option><option value="archived" ${item?.status==='archived'?'selected':''}>بایگانی</option></select></label><label>ترتیب نمایش<input class="input" id="marketingFaqOrder" type="number" min="0" max="10000" value="${Number(item?.sort_order??((state.cache.marketingFaqs?.length||0)+1)*10)}"></label><label class="consent-check"><input id="marketingFaqFeatured" type="checkbox" ${item?.is_featured?'checked':''}><span></span> پاسخ ویژه صفحه اصلی</label><label class="full-field">متن سؤال<input class="input" id="marketingFaqQuestion" maxlength="240" value="${escapeHtml(item?.question||'')}"></label><label class="full-field">پاسخ کامل<textarea class="input settings-textarea" id="marketingFaqAnswer" rows="7" maxlength="3000">${escapeHtml(item?.answer||'')}</textarea></label></div><div class="limit-summary">${icon('info',15)} دسته «چرا SmartJournal؟» بلافاصله زیر کارت‌های پلن در صفحه اصلی نمایش داده می‌شود.</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveMarketingFaq">${item?'ذخیره سؤال':'افزودن سؤال'}</button></div></div>`);
  $('#saveMarketingFaq').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(item?`/api/admin/marketing/faqs/${item.id}`:'/api/admin/marketing/faqs',{method:item?'PATCH':'POST',body:JSON.stringify({category:$('#marketingFaqCategory').value,status:$('#marketingFaqStatus').value,sortOrder:Number($('#marketingFaqOrder').value),isFeatured:$('#marketingFaqFeatured').checked,question:$('#marketingFaqQuestion').value,answer:$('#marketingFaqAnswer').value})});closeModal();toast(item?'سؤال و وضعیت انتشار ذخیره شد.':'سؤال جدید اضافه شد.');renderView('cms')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
async function moveMarketingFaq(faqId,direction){const all=state.cache.marketingFaqs||[],item=all.find(row=>row.id===faqId);if(!item)return;const rows=all.filter(row=>row.category===item.category&&row.status!=='archived').sort((a,b)=>a.sort_order-b.sort_order),index=rows.findIndex(row=>row.id===faqId),other=rows[index+direction];if(!other)return toast('این سؤال در انتهای همین دسته قرار دارد.');try{await Promise.all([api(`/api/admin/marketing/faqs/${item.id}`,{method:'PATCH',body:JSON.stringify({sortOrder:Number(other.sort_order)})}),api(`/api/admin/marketing/faqs/${other.id}`,{method:'PATCH',body:JSON.stringify({sortOrder:Number(item.sort_order)})})]);toast('ترتیب سؤال‌ها تغییر کرد.');renderView('cms')}catch(error){toast(error.message,'error')}}
async function deleteMarketingFaq(faqId){const item=(state.cache.marketingFaqs||[]).find(row=>row.id===faqId);if(!item||!confirm(`سؤال «${item.question}» برای همیشه حذف شود؟`))return;try{await api(`/api/admin/marketing/faqs/${item.id}`,{method:'DELETE'});toast('سؤال حذف شد.');renderView('cms')}catch(error){toast(error.message,'error')}}
function openCmsPageEditor(pageId=null){
  const page=(state.cache.cmsPages||[]).find(item=>item.id===pageId);
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">${page?'ویرایش صفحه':'ساخت صفحه جدید'}</h3><span class="modal-subtitle">شناسه صفحه در API عمومی و اتصال به سایت استفاده می‌شود</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>عنوان صفحه<input class="input" id="cmsPageTitle" maxlength="160" value="${escapeHtml(page?.title||'')}"></label><label>شناسه انگلیسی<input class="input" id="cmsPageSlug" dir="ltr" maxlength="80" value="${escapeHtml(page?.slug||'')}" placeholder="about-us"></label><label class="full-field">توضیحات متا<textarea class="input settings-textarea short" id="cmsPageMeta" maxlength="500">${escapeHtml(page?.meta_description||'')}</textarea></label><label class="full-field">عنوان SEO<input class="input" id="cmsSeoTitle" maxlength="180" value="${escapeHtml(page?.seo_title||'')}"></label><label class="full-field">کلمات کلیدی SEO<input class="input" id="cmsSeoKeywords" maxlength="500" value="${escapeHtml(page?.seo_keywords||'')}" placeholder="ژورنال, معامله‌گری, مدیریت ریسک"></label><label>تصویر Open Graph<input class="input" id="cmsOgImage" dir="ltr" maxlength="500" value="${escapeHtml(page?.og_image||'')}"></label><label>Canonical URL<input class="input" id="cmsCanonicalUrl" dir="ltr" maxlength="500" value="${escapeHtml(page?.canonical_url||'')}"></label><label>شروع انتشار<input class="input" id="cmsPagePublishAt" type="datetime-local" value="${page?.publish_at?page.publish_at.slice(0,16):''}"></label><label>پایان انتشار<input class="input" id="cmsPageUnpublishAt" type="datetime-local" value="${page?.unpublish_at?page.unpublish_at.slice(0,16):''}"></label><label>وضعیت<select class="select" id="cmsPageStatus"><option value="draft" ${!page||page.status==='draft'?'selected':''}>پیش‌نویس</option><option value="published" ${page?.status==='published'?'selected':''}>منتشرشده</option><option value="archived" ${page?.status==='archived'?'selected':''}>بایگانی</option></select></label></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveCmsPage">${page?'ذخیره صفحه':'ساخت صفحه'}</button></div></div>`);
  $('#cmsPageSlug').addEventListener('input',event=>event.target.value=event.target.value.toLowerCase().replace(/[^a-z0-9-]/g,''));
  $('#saveCmsPage').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const result=await api(page?`/api/admin/cms/pages/${page.id}`:'/api/admin/cms/pages',{method:page?'PATCH':'POST',body:JSON.stringify({title:$('#cmsPageTitle').value,slug:$('#cmsPageSlug').value,metaDescription:$('#cmsPageMeta').value,seoTitle:$('#cmsSeoTitle').value,seoKeywords:$('#cmsSeoKeywords').value,ogImage:$('#cmsOgImage').value,canonicalUrl:$('#cmsCanonicalUrl').value,publishAt:$('#cmsPagePublishAt').value||null,unpublishAt:$('#cmsPageUnpublishAt').value||null,status:$('#cmsPageStatus').value})});if(!page)state.cms.selectedPageId=result.id;closeModal();toast(page?'صفحه به‌روزرسانی شد.':'صفحه جدید ساخته شد.');renderView('cms')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
function openCmsSectionEditor(sectionId=null){
  const item=(state.cache.cmsSections||[]).find(section=>section.id===sectionId),page=state.cache.cmsPage;if(!page)return;
  const types=[['hero','Hero / معرفی'],['content','محتوا'],['feature','قابلیت'],['cta','دعوت به اقدام'],['footer','فوتر'],['form','فرم'],['custom','سفارشی']];
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">${item?'ویرایش سکشن':'سکشن جدید'}</h3><span class="modal-subtitle">صفحه ${escapeHtml(page.title)} · ترتیب و وضعیت انتشار مستقل</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>کلید سکشن<input class="input" id="cmsSectionKey" dir="ltr" maxlength="80" value="${escapeHtml(item?.section_key||'')}" placeholder="hero"></label><label>نوع سکشن<select class="select" id="cmsSectionType">${types.map(([value,label])=>`<option value="${value}" ${item?.section_type===value?'selected':''}>${label}</option>`).join('')}</select></label><label class="full-field">عنوان<input class="input" id="cmsSectionTitle" maxlength="300" value="${escapeHtml(item?.title||'')}"></label><label class="full-field">متن<textarea class="input cms-body-editor" id="cmsSectionBody" maxlength="50000">${escapeHtml(item?.body||'')}</textarea></label><label>متن دکمه<input class="input" id="cmsButtonLabel" maxlength="120" value="${escapeHtml(item?.button_label||'')}"></label><label>لینک دکمه<input class="input" id="cmsButtonUrl" dir="ltr" maxlength="500" value="${escapeHtml(item?.button_url||'')}"></label><label>آدرس تصویر<input class="input" id="cmsImageUrl" dir="ltr" maxlength="500" value="${escapeHtml(item?.image_url||'')}"></label><label>متن جایگزین تصویر<input class="input" id="cmsImageAlt" maxlength="300" value="${escapeHtml(item?.image_alt||'')}"></label><label>شروع انتشار<input class="input" id="cmsSectionPublishAt" type="datetime-local" value="${item?.publish_at?item.publish_at.slice(0,16):''}"></label><label>پایان انتشار<input class="input" id="cmsSectionUnpublishAt" type="datetime-local" value="${item?.unpublish_at?item.unpublish_at.slice(0,16):''}"></label><label>ترتیب نمایش<input class="input" id="cmsSortOrder" type="number" min="-10000" max="10000" value="${item?.sort_order??((state.cache.cmsSections?.length||0)+1)*10}"></label><label>وضعیت<select class="select" id="cmsSectionStatus"><option value="published" ${!item||item.status==='published'?'selected':''}>منتشرشده</option><option value="draft" ${item?.status==='draft'?'selected':''}>پیش‌نویس</option><option value="archived" ${item?.status==='archived'?'selected':''}>بایگانی</option></select></label></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveCmsSection">${item?'ذخیره سکشن':'افزودن سکشن'}</button></div></div>`);
  $('#cmsSectionKey').addEventListener('input',event=>event.target.value=event.target.value.toLowerCase().replace(/[^a-z0-9_-]/g,''));
  $('#saveCmsSection').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(item?`/api/admin/cms/sections/${item.id}`:`/api/admin/cms/pages/${page.id}/sections`,{method:item?'PATCH':'POST',body:JSON.stringify({sectionKey:$('#cmsSectionKey').value,sectionType:$('#cmsSectionType').value,title:$('#cmsSectionTitle').value,body:$('#cmsSectionBody').value,buttonLabel:$('#cmsButtonLabel').value,buttonUrl:$('#cmsButtonUrl').value,imageUrl:$('#cmsImageUrl').value,imageAlt:$('#cmsImageAlt').value,publishAt:$('#cmsSectionPublishAt').value||null,unpublishAt:$('#cmsSectionUnpublishAt').value||null,sortOrder:Number($('#cmsSortOrder').value),status:$('#cmsSectionStatus').value})});closeModal();toast(item?'سکشن به‌روزرسانی شد.':'سکشن جدید اضافه شد.');renderView('cms')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
async function archiveCmsSection(sectionId){if(!confirm('این سکشن بایگانی و از نسخه عمومی خارج شود؟'))return;try{await api(`/api/admin/cms/sections/${sectionId}`,{method:'DELETE'});toast('سکشن بایگانی شد.');renderView('cms')}catch(error){toast(error.message,'error')}}
async function duplicateCmsPage(pageId){try{const result=await api(`/api/admin/cms/pages/${pageId}/duplicate`,{method:'POST',body:'{}'});state.cms.selectedPageId=result.id;toast('یک نسخه پیش‌نویس از صفحه و سکشن‌ها ساخته شد.');renderView('cms')}catch(error){toast(error.message,'error')}}
async function duplicateCmsSection(sectionId){try{await api(`/api/admin/cms/sections/${sectionId}/duplicate`,{method:'POST',body:'{}'});toast('نسخه پیش‌نویس سکشن ساخته شد.');renderView('cms')}catch(error){toast(error.message,'error')}}
async function openSecureCmsPreview(){try{const result=await api(`/api/admin/cms/pages/${state.cache.cmsPage.id}/preview-token`,{method:'POST',body:'{}'});if(location.protocol==='file:'||window.PA_STANDALONE_MOCK)return openCmsPreview();window.open(result.url,'_blank','noopener');toast('لینک پیش‌نمایش امن تا ۳۰ دقیقه معتبر است.')}catch(error){toast(error.message,'error')}}
async function openCmsHistory(entityType,entityId){try{const data=await api(`/api/admin/cms/revisions/${entityType}/${entityId}`),current=entityType==='page'?state.cache.cmsPage:(state.cache.cmsSections||[]).find(item=>item.id===entityId);const rows=data.rows.map(row=>{const snap=row.snapshot||{},changes=[];['title','status','slug','section_key','body','button_label','image_url','sort_order'].forEach(key=>{if(snap[key]!==undefined&&snap[key]!==current?.[key])changes.push(`${key}: ${String(snap[key]??'—').slice(0,70)}`)});return `<article class="revision-row"><div><b>نسخه ${n(row.version)}</b><span>${dateFa(row.created_at,true)} · ${escapeHtml(row.admin_name||'سیستم')}</span><small>${escapeHtml(changes.join(' · ')||'نسخه ثبت‌شده بدون تغییر قابل نمایش')}</small></div><button class="ghost-btn" data-restore-cms-revision="${row.id}">بازگردانی</button></article>`}).join('');openModal(`<header class="modal-head"><div><h3 id="modalTitle">تاریخچه و بازگردانی نسخه‌ها</h3><span class="modal-subtitle">قبل از هر ویرایش یک Snapshot امن ذخیره می‌شود</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="revision-list">${rows||'<div class="empty-table">نسخه‌ای ثبت نشده است.</div>'}</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button></div></div>`)}catch(error){toast(error.message,'error')}}
async function restoreCmsRevision(revisionId){if(!confirm('محتوای فعلی با این نسخه جایگزین شود؟ یک Snapshot از وضعیت فعلی باقی می‌ماند.'))return;try{await api(`/api/admin/cms/revisions/${revisionId}/restore`,{method:'POST',body:'{}'});closeModal();toast('نسخه انتخاب‌شده بازگردانی شد.');renderView('cms')}catch(error){toast(error.message,'error')}}
async function openCmsMenus(){try{const data=await api('/api/admin/cms/menus');state.cache.cmsMenus=data.rows;const rows=data.rows.map(item=>`<tr><td>${escapeHtml(item.menu_key)}</td><td>${escapeHtml(item.label)}</td><td dir="ltr">${escapeHtml(item.url)}</td><td>${n(item.sort_order)}</td><td><span class="status ${item.status==='published'?'active':'pending'}">${item.status==='published'?'منتشرشده':'پیش‌نویس'}</span></td><td><div class="inline-actions"><button class="table-action" data-edit-cms-menu="${item.id}">${icon('edit',13)}</button><button class="table-action danger-action" data-delete-cms-menu="${item.id}">${icon('close',13)}</button></div></td></tr>`).join('');openModal(`<header class="modal-head"><div><h3 id="modalTitle">مدیریت منوهای سایت</h3><span class="modal-subtitle">منوهای header، footer یا هر ناحیه سفارشی</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="modal-toolbar"><button class="primary-btn" data-add-cms-menu>${icon('userPlus',13)} آیتم جدید</button></div><div class="table-scroll"><table class="data-table"><thead><tr><th>ناحیه</th><th>عنوان</th><th>لینک</th><th>ترتیب</th><th>وضعیت</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button></div></div>`)}catch(error){toast(error.message,'error')}}
function openCmsMenuEditor(menuId=null){const item=(state.cache.cmsMenus||[]).find(row=>row.id===menuId);openModal(`<header class="modal-head"><div><h3 id="modalTitle">${item?'ویرایش آیتم منو':'آیتم جدید منو'}</h3><span class="modal-subtitle">لینک داخلی یا خارجی امن</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>ناحیه منو<input class="input" id="cmsMenuKey" dir="ltr" value="${escapeHtml(item?.menu_key||'header')}"></label><label>عنوان<input class="input" id="cmsMenuLabel" maxlength="120" value="${escapeHtml(item?.label||'')}"></label><label class="full-field">لینک<input class="input" id="cmsMenuUrl" dir="ltr" maxlength="500" value="${escapeHtml(item?.url||'/')}"></label><label>ترتیب<input class="input" id="cmsMenuOrder" type="number" value="${item?.sort_order??10}"></label><label>وضعیت<select class="select" id="cmsMenuStatus"><option value="published" ${!item||item.status==='published'?'selected':''}>منتشرشده</option><option value="draft" ${item?.status==='draft'?'selected':''}>پیش‌نویس</option></select></label></div><div class="modal-actions"><button class="ghost-btn" data-manage-cms-menus>بازگشت</button><button class="primary-btn" id="saveCmsMenu">ذخیره</button></div></div>`);$('#saveCmsMenu').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(item?`/api/admin/cms/menus/${item.id}`:'/api/admin/cms/menus',{method:item?'PATCH':'POST',body:JSON.stringify({menuKey:$('#cmsMenuKey').value,label:$('#cmsMenuLabel').value,url:$('#cmsMenuUrl').value,sortOrder:Number($('#cmsMenuOrder').value),status:$('#cmsMenuStatus').value})});toast('آیتم منو ذخیره شد.');openCmsMenus()}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}
async function deleteCmsMenu(menuId){if(!confirm('این آیتم منو بایگانی شود؟'))return;try{await api(`/api/admin/cms/menus/${menuId}`,{method:'DELETE'});toast('آیتم منو بایگانی شد.');openCmsMenus()}catch(error){toast(error.message,'error')}}
function openCmsPreview(){const page=state.cache.cmsPage,sections=state.cache.cmsSections||[];if(!page)return;openModal(`<header class="modal-head"><div><h3 id="modalTitle">پیش‌نمایش ${escapeHtml(page.title)}</h3><span class="modal-subtitle">پیش‌نمایش شامل سکشن‌های پیش‌نویس نیز هست</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="cms-preview"><header><span dir="ltr">/${escapeHtml(page.slug)}</span><h1>${escapeHtml(page.title)}</h1><p>${escapeHtml(page.meta_description||'')}</p></header>${sections.map(section=>`<section class="${section.section_type} ${section.status==='draft'?'draft':''}"><small>${escapeHtml(permissionLabels[section.section_type]||section.section_type)} · ${escapeHtml(section.section_key)} · ${section.status==='draft'?'پیش‌نویس':'منتشرشده'}</small><h2>${escapeHtml(section.title||'')}</h2><p>${escapeHtml(section.body||'')}</p>${section.button_label?`<button>${escapeHtml(section.button_label)}</button>`:''}</section>`).join('')}</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن پیش‌نمایش</button></div></div>`)}

async function renderLegalPrivacy() {
  const canReadLegal=hasPermission('content.view'),canManageLegal=hasPermission('content.manage'),canHandlePrivacy=hasPermission('users.security');
  const [legal,privacy]=await Promise.all([canReadLegal?api('/api/admin/legal/documents'):Promise.resolve(null),canHandlePrivacy?api('/api/admin/privacy/requests'):Promise.resolve(null)]);
  state.cache.legal=legal;state.cache.privacyRequests=privacy?.rows||[];
  const typeLabels={terms:'قوانین استفاده',privacy:'سیاست حریم خصوصی',retention:'سیاست نگهداری داده',cookies:'سیاست کوکی',dpa:'قرارداد پردازش اطلاعات',disclaimer:'سلب مسئولیت مالی'};
  const documentCards=legal?legal.types.map(item=>{const current=legal.current[item.type];return `<article class="card legal-document-card"><div class="legal-document-head"><span>${icon('file',18)}</span><div><b>${escapeHtml(item.title||typeLabels[item.type])}</b><small>${current?`نسخه ${escapeHtml(current.version)} · اجرای ${dateFa(current.effective_at,true)}`:'نسخه منتشرشده ندارد'}</small></div><span class="status ${current?'active':'pending'}">${current?'منتشرشده':'بدون نسخه'}</span></div><div class="legal-hash" dir="ltr">SHA-256: ${escapeHtml(current?.content_sha256||'—')}</div><div class="legal-card-actions"><a class="ghost-btn" href="/legal/${item.type}" target="_blank" rel="noopener">مشاهده عمومی</a>${canManageLegal?`<button class="primary-btn compact-btn" data-new-legal="${item.type}">${icon('edit',13)} نسخه جدید</button>`:''}</div></article>`}).join(''):'';
  const versionRows=legal?legal.versions.map(item=>`<tr><td>${escapeHtml(typeLabels[item.document_type]||item.document_type)}</td><td dir="ltr">${escapeHtml(item.version)}</td><td><span class="status ${item.status==='published'?'active':'pending'}">${item.status==='published'?'منتشرشده':'پیش‌نویس'}</span></td><td>${dateFa(item.effective_at,true)}</td><td>${escapeHtml(item.created_by_name||'سیستم')}</td><td><code class="legal-sha">${escapeHtml(String(item.content_sha256||'').slice(0,16))}…</code></td></tr>`).join(''):'';
  const privacyRows=(privacy?.rows||[]).map(item=>{const type=item.request_type==='deletion'?'حذف حساب و داده':'دریافت نسخه اطلاعات',status={pending:'در انتظار',in_progress:'در حال رسیدگی',completed:'تکمیل‌شده',rejected:'ردشده',cancelled:'لغوشده'}[item.status]||item.status,actions=['pending','in_progress'].includes(item.status)?`<div class="table-actions">${item.status==='pending'?`<button class="table-action" data-privacy-progress="${item.id}">شروع رسیدگی</button>`:''}${item.request_type==='deletion'?`<button class="table-action" data-privacy-user="${item.user_id}">پرونده کاربر</button>`:''}<button class="table-action danger" data-privacy-reject="${item.id}">رد با دلیل</button></div>`:'—';return `<tr><td><div class="user-cell"><span>${escapeHtml(initials(item.user_name||'حذف‌شده'))}</span><div><b>${escapeHtml(item.user_name||'کاربر ناشناس‌شده')}</b><small dir="ltr">${escapeHtml(item.user_mobile||'—')}</small></div></div></td><td>${escapeHtml(type)}</td><td><span class="status ${item.status==='completed'?'active':item.status==='rejected'?'failed':'pending'}">${escapeHtml(status)}</span></td><td>${dateFa(item.requested_at,true)}</td><td>${dateFa(item.due_at,true)}</td><td>${item.rejection_reason?escapeHtml(item.rejection_reason):actions}</td></tr>`}).join('');
  return `<div class="section-head"><div><span class="eyebrow">IMMUTABLE CONSENT & DATA RIGHTS</span><h2>عملیات حقوقی و حریم خصوصی</h2><p>نسخه‌های اسناد، شواهد رضایت و درخواست‌های حقوق داده با مسیر ممیزی مدیریت می‌شوند.</p></div><div class="legal-public-links"><a class="ghost-btn" href="/api/public/legal" target="_blank" rel="noopener">API عمومی اسناد</a></div></div>
    ${legal?`<section class="legal-identity-banner ${legal.identityComplete?'complete':'blocked'}">${icon(legal.identityComplete?'check':'alert',17)}<div><b>${legal.identityComplete?'هویت حقوقی اپراتور تکمیل است':'انتشار Production مسدود است'}</b><span>${legal.identityComplete?'نام، شناسه ثبت و نشانی اپراتور در محیط تنظیم شده‌اند.':'مقادیر LEGAL_OPERATOR_NAME، LEGAL_OPERATOR_REGISTRATION و LEGAL_OPERATOR_ADDRESS باید پیش از انتشار Production تکمیل شوند.'}</span></div></section><div class="legal-documents-grid">${documentCards}</div><section class="card table-card"><div class="card-head"><div class="card-title"><b>تاریخچه تغییرناپذیر نسخه‌ها</b><span>نسخه ثبت‌شده قابل ویرایش یا بازنویسی نیست؛ فقط نسخه جدید ساخته می‌شود.</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>سند</th><th>نسخه</th><th>وضعیت</th><th>اجرا</th><th>ثبت‌کننده</th><th>اثر محتوا</th></tr></thead><tbody>${versionRows}</tbody></table></div></section>`:''}
    ${privacy?`<section class="card table-card privacy-requests-card"><div class="card-head"><div class="card-title"><b>درخواست‌های حقوق داده کاربران</b><span>حذف عملیاتی حداکثر ۳۰ روز؛ backup حداکثر ۹۰ روز؛ لاگ امنیتی ۱۲ ماه.</span></div><span class="soft-chip">${n(privacy.rows.filter(item=>['pending','in_progress'].includes(item.status)).length)} درخواست فعال</span></div><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>نوع درخواست</th><th>وضعیت</th><th>زمان ثبت</th><th>مهلت</th><th>عملیات / نتیجه</th></tr></thead><tbody>${privacyRows||'<tr><td colspan="6"><div class="empty-table">درخواستی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section>`:''}`;
}

function nextLegalVersion(current){const parts=String(current?.version||'0.9.0').split('.').map(Number);return `${parts[0]||1}.${(parts[1]||0)+1}.0`}
function openLegalVersionEditor(type){
  const legal=state.cache.legal,current=legal?.current?.[type],title=(legal?.types||[]).find(item=>item.type===type)?.title||type;
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">نسخه جدید ${escapeHtml(title)}</h3><span class="modal-subtitle">نسخه‌های ثبت‌شده تغییرناپذیرند و ایجاد نسخه جدید در Audit ثبت می‌شود.</span></div><button class="modal-close" data-close-modal data-icon="close" aria-label="بستن"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>نسخه Semantic<input class="input" id="legalVersion" dir="ltr" value="${escapeHtml(nextLegalVersion(current))}" placeholder="1.1.0"></label><label>تاریخ و زمان اجرا<input class="input" id="legalEffective" type="datetime-local" value="${new Date(Date.now()+300000).toISOString().slice(0,16)}"></label><label class="span-2">عنوان سند<input class="input" id="legalTitle" maxlength="160" value="${escapeHtml(current?.title||title)}"></label><label class="span-2">متن کامل سند<textarea class="input legal-editor-text" id="legalContent" rows="18" minlength="500" maxlength="50000">${escapeHtml(current?.content||'')}</textarea></label><label class="span-2 legal-publish-choice"><input type="checkbox" id="legalPublish" checked> <span>هم‌زمان منتشر شود و نسخه فعال عمومی گردد</span></label></div><div class="limit-summary">${icon('shield',15)} اثر SHA-256 محتوا در سرور محاسبه می‌شود. انتشار Production بدون هویت حقوقی کامل رد خواهد شد.</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="createLegalVersion">ثبت نسخه تغییرناپذیر</button></div></div>`);
  $('#createLegalVersion').addEventListener('click',async event=>{const button=event.currentTarget;setBusy(button,true);try{await api(`/api/admin/legal/documents/${type}`,{method:'POST',body:JSON.stringify({version:$('#legalVersion').value,title:$('#legalTitle').value,content:$('#legalContent').value,effectiveAt:$('#legalEffective').value,publish:$('#legalPublish').checked})});closeModal();toast('نسخه حقوقی جدید ثبت شد.');renderView('legal')}catch(error){toast(error.message,'error');setBusy(button,false)}});
}
async function updatePrivacyRequest(requestId,status,reason='') {try{await api(`/api/admin/privacy/requests/${requestId}`,{method:'PATCH',body:JSON.stringify({status,reason})});toast(status==='in_progress'?'رسیدگی به درخواست آغاز شد.':'رد درخواست با دلیل ثبت شد.');renderView('legal')}catch(error){toast(error.message,'error')}}
function rejectPrivacyRequest(requestId){openModal(`<header class="modal-head"><div><h3 id="modalTitle">رد درخواست حریم خصوصی</h3><span class="modal-subtitle">رد فقط با مبنای قانونی روشن مجاز است و در Audit ثبت می‌شود.</span></div><button class="modal-close" data-close-modal data-icon="close" aria-label="بستن"></button></header><div class="modal-body"><label>دلیل قانونی رد<textarea class="input legal-editor-text" id="privacyRejectReason" rows="6" minlength="10" maxlength="1000" placeholder="مبنای قانونی و توضیح قابل ارائه به کاربر…"></textarea></label><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="danger-btn" id="confirmPrivacyReject">ثبت رد درخواست</button></div></div>`);$('#confirmPrivacyReject').addEventListener('click',async event=>{const reason=$('#privacyRejectReason').value.trim();if(reason.length<10)return toast('دلیل قانونی باید حداقل ۱۰ کاراکتر باشد.','error');setBusy(event.currentTarget,true);try{await api(`/api/admin/privacy/requests/${requestId}`,{method:'PATCH',body:JSON.stringify({status:'rejected',reason})});closeModal();toast('رد درخواست و دلیل آن ثبت شد.');renderView('legal')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}

async function renderSettings() {
  const data = await api('/api/admin/system/settings');
  const isOwner=state.admin.role==='owner',contentOnly=!hasPermission('settings.view'),canManageSettings=hasPermission('settings.manage'),canViewContent=hasPermission('content.view'),canManageContent=hasPermission('content.manage');
  const [adminData,rolePermissionData]=isOwner?await Promise.all([api('/api/admin/admins'),api('/api/admin/role-permissions')]):[{rows:[]},{matrix:{},permissions:[]}];
  state.cache.plans=data.plans;state.cache.announcements=data.announcements;state.cache.admins=adminData.rows;state.cache.rolePermissions=rolePermissionData;
  const published=data.announcements.filter(item=>item.status==='published').length;
  const planCards=data.plans.map(plan=>`<article class="settings-plan" style="--plan-color:${plan.color}"><div><span class="plan-badge" style="--plan-color:${plan.color}">${escapeHtml(plan.name_fa)}</span><b>${plan.price_monthly?toman(plan.price_monthly):'رایگان'}</b></div><div class="settings-plan-limits"><span>${n(plan.max_trades)} معامله</span><span>${bytes(plan.max_storage_bytes)} تصویر</span><span>${n(plan.max_sms_monthly)} پیامک</span></div>${canManageSettings?`<button class="ghost-btn" data-plan-id="${plan.id}">${icon('edit',13)} مدیریت پلن</button>`:''}</article>`).join('');
  const toneLabels={info:'اطلاعاتی',success:'موفقیت',warning:'هشدار',critical:'بحرانی'},audienceLabels={all:'همه کاربران',free:'پلن رایگان',pro:'پلن حرفه‌ای',organization:'پلن سازمانی'};
  const announcementRows=data.announcements.map(item=>`<tr><td><div class="announcement-title"><span class="announcement-dot ${item.tone}"></span><div><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.body)}</small></div></div></td><td>${escapeHtml(toneLabels[item.tone]||item.tone)}</td><td>${escapeHtml(audienceLabels[item.audience]||item.audience)}</td><td><span class="status ${item.status==='published'?'active':item.status==='draft'?'pending':'limited'}">${item.status==='published'?'منتشرشده':item.status==='draft'?'پیش‌نویس':'بایگانی'}</span></td><td><div class="expiry"><b>${dateFa(item.starts_at)}</b><span>تا ${dateFa(item.expires_at)}</span></div></td><td>${canManageContent?`<div class="inline-actions"><button class="table-action" data-edit-announcement="${item.id}" title="ویرایش">${icon('edit',13)}</button>${item.status!=='archived'?`<button class="table-action danger-action" data-archive-announcement="${item.id}" title="بایگانی">${icon('close',13)}</button>`:''}</div>`:'—'}</td></tr>`).join('');
  const roleDescriptions={owner:'دسترسی کامل به همه بخش‌ها و مدیران',admin:'مدیریت عمومی بدون کنترل حساب Owner',support:'پشتیبانی کاربران بدون اطلاعات مالی',finance:'اشتراک‌ها، پرداخت‌ها و بازپرداخت',security:'خطاها، امنیت و بررسی فایل مشکوک',content_manager:'قوانین، راهنما و اعلان‌های عمومی'};
  const roleCards=Object.keys(roleDescriptions).map(role=>{const enabled=role==='owner'?permissionLabels:Object.fromEntries(Object.entries(rolePermissionData.matrix?.[role]||{}).filter(([,value])=>value));return `<article class="role-card ${role}"><span>${icon(role==='finance'?'revenue':role==='security'?'shield':role==='content_manager'?'file':role==='support'?'users':role==='owner'?'crown':'settings',17)}</span><div><b>${roleLabels[role]}</b><small>${roleDescriptions[role]}</small><em>${role==='owner'?'دسترسی کامل':`${n(Object.keys(enabled).length)} مجوز فعال`}</em></div>${role!=='owner'?`<button class="table-action role-permission-edit" data-role-permissions="${role}" title="ویرایش مجوزهای نقش">${icon('settings',13)}</button>`:''}</article>`}).join('');
  const adminRows=adminData.rows.map(admin=>`<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(admin.name))}</span><div><b>${escapeHtml(admin.name)}</b><span dir="ltr">@${escapeHtml(admin.username||'—')} · ${escapeHtml(admin.mobile)}</span></div></div></td><td><span class="admin-role-badge ${admin.role}">${escapeHtml(roleLabels[admin.role]||admin.role)}</span></td><td><span class="status ${admin.status==='active'?'active':'suspended'}">${admin.status==='active'?'فعال':'غیرفعال'}</span></td><td>${n(admin.active_sessions)} نشست</td><td>${dateFa(admin.last_login_at,true)}</td><td>${admin.id!==state.admin.id?`<button class="table-action" data-admin-id="${admin.id}">${icon('edit',13)}</button>`:'<span class="soft-chip">حساب فعلی</span>'}</td></tr>`).join('');
  const operationalSettings=contentOnly?'':`<div class="settings-main-grid"><section class="card settings-card"><div class="card-head"><div class="card-title"><b>وضعیت و دسترسی سامانه</b><span>کنترل ثبت‌نام و حالت تعمیرات</span></div></div><div class="system-switch-row"><div><span class="settings-icon">${icon('userPlus',16)}</span><div><b>ثبت‌نام کاربران جدید</b><small>در صورت غیرفعال‌بودن، ایجاد حساب جدید متوقف می‌شود.</small></div></div><button type="button" class="toggle ${data.settings.signup_enabled?'on':''}" id="signupEnabled" ${canManageSettings?'':'disabled'}><i></i></button></div><div class="system-switch-row"><div><span class="settings-icon maintenance">${icon('settings',16)}</span><div><b>حالت تعمیرات</b><small>کاربران پیام تعمیرات دریافت می‌کنند؛ پنل مدیر فعال می‌ماند.</small></div></div><button type="button" class="toggle ${data.settings.maintenance_mode?'on':''}" id="maintenanceMode" ${canManageSettings?'':'disabled'}><i></i></button></div><label class="settings-label">پیام حالت تعمیرات<textarea class="input settings-textarea short" id="maintenanceMessage" ${canManageSettings?'':'disabled'} maxlength="500">${escapeHtml(data.settings.maintenance_message||'')}</textarea></label><label class="settings-label">نسخه فعلی برنامه<input class="input ltr-input" id="appVersion" ${canManageSettings?'':'disabled'} maxlength="32" value="${escapeHtml(data.settings.app_version)}" placeholder="1.0.0"></label></section><section class="card settings-card"><div class="card-head"><div class="card-title"><b>محدودیت‌های عمومی</b><span>سیاست OTP و حداکثر حجم تصویر</span></div></div><div class="settings-limit-grid"><label>OTP هر شماره<input class="input" id="settingsOtpMobile" ${canManageSettings?'':'disabled'} type="number" min="1" max="50" value="${data.smsSettings.mobile_limit_count}"><small>در بازه تعیین‌شده</small></label><label>OTP هر IP<input class="input" id="settingsOtpIp" ${canManageSettings?'':'disabled'} type="number" min="1" max="200" value="${data.smsSettings.ip_limit_count}"><small>مجموع تمام شماره‌ها</small></label><label>بازه OTP (دقیقه)<input class="input" id="settingsOtpWindow" ${canManageSettings?'':'disabled'} type="number" min="1" max="1440" value="${data.smsSettings.rate_window_minutes}"><small>پنجره محدودسازی</small></label><label>حداکثر حجم تصویر (MB)<input class="input" id="settingsImageSize" ${canManageSettings?'':'disabled'} type="number" min="0.5" max="100" step="0.5" value="${(data.fileSettings.max_file_size_bytes/1048576).toFixed(1)}"><small>برای هر فایل</small></label></div><div class="settings-summary"><div>${icon('sms',14)}<span>OTP: ${n(data.smsSettings.mobile_limit_count)} بار برای شماره و ${n(data.smsSettings.ip_limit_count)} بار برای IP</span></div><div>${icon('file',14)}<span>تصویر: حداکثر ${bytes(data.fileSettings.max_file_size_bytes)}</span></div></div></section></div>`;
  const plansSection=contentOnly?'':`<section class="card settings-plans-card"><div class="card-head"><div class="card-title"><b>مدیریت پلن‌ها</b><span>قیمت و سقف معامله، تصویر و پیامک هر پلن</span></div></div><div class="settings-plan-grid">${planCards}</div></section>`;
  const accessSection=isOwner?`<section class="card access-management-card"><div class="card-head"><div class="card-title"><b>سطح دسترسی مدیران</b><span>اصل حداقل دسترسی برای نقش‌های مدیریتی</span></div><button class="primary-btn compact-btn" data-add-admin>${icon('userPlus',13)} مدیر جدید</button></div><div class="role-grid">${roleCards}</div><div class="table-scroll admin-access-table"><table class="data-table"><thead><tr><th>مدیر</th><th>نقش</th><th>وضعیت</th><th>نشست فعال</th><th>آخرین ورود</th><th></th></tr></thead><tbody>${adminRows}</tbody></table></div></section>`:'';
  return `<div class="section-head"><div><span class="eyebrow">SYSTEM CONFIGURATION</span><h2>تنظیمات سیستم</h2><p>${contentOnly?'مدیریت قوانین، راهنمای کاربران و اعلان‌های عمومی.':'کنترل ثبت‌نام، تعمیرات، محدودیت‌ها، محتوا، پلن‌ها و دسترسی مدیران.'}</p></div>${canManageSettings?`<button class="primary-btn" data-save-system-settings>${icon('check',14)} ذخیره همه تنظیمات</button>`:canManageContent?`<button class="primary-btn" data-save-system-content>${icon('check',14)} ذخیره محتوای عمومی</button>`:''}</div>${contentOnly?'':`<div class="settings-status-grid"><article class="card settings-status ${data.settings.signup_enabled?'healthy':'off'}"><span>${icon('userPlus',18)}</span><div><small>ثبت‌نام کاربران</small><b>${data.settings.signup_enabled?'فعال':'غیرفعال'}</b><em>پذیرش حساب جدید</em></div></article><article class="card settings-status ${data.settings.maintenance_mode?'maintenance':'healthy'}"><span>${icon('settings',18)}</span><div><small>وضعیت سرویس</small><b>${data.settings.maintenance_mode?'حالت تعمیرات':'عملیاتی'}</b><em>${data.settings.maintenance_mode?'دسترسی عمومی محدود':'سرویس در دسترس'}</em></div></article><article class="card settings-status version"><span>${icon('info',18)}</span><div><small>نسخه فعلی برنامه</small><b dir="ltr">v${escapeHtml(data.settings.app_version)}</b><em>${relativeTime(data.settings.updated_at)} به‌روزرسانی</em></div></article><article class="card settings-status announcement"><span>${icon('message',18)}</span><div><small>اعلان‌های عمومی</small><b>${n(published)}</b><em>${n(data.announcements.length)} اعلان ثبت‌شده</em></div></article></div>`}${operationalSettings}${canViewContent?`<section class="card legal-settings-card"><div class="card-head"><div class="card-title"><b>قوانین، حریم خصوصی و راهنما</b><span>محتوای عمومی قابل مشاهده برای کاربران</span></div><span class="soft-chip">نسخه ${escapeHtml(data.settings.app_version)}</span></div><div class="legal-grid three"><label>متن قوانین استفاده<textarea class="input legal-textarea" id="termsText" maxlength="30000" ${canManageContent?'':'disabled'}>${escapeHtml(data.settings.terms_text)}</textarea><small>${n(data.settings.terms_text.length)} کاراکتر</small></label><label>متن حریم خصوصی<textarea class="input legal-textarea" id="privacyText" maxlength="30000" ${canManageContent?'':'disabled'}>${escapeHtml(data.settings.privacy_text)}</textarea><small>${n(data.settings.privacy_text.length)} کاراکتر</small></label><label>راهنمای استفاده<textarea class="input legal-textarea" id="guideText" maxlength="30000" ${canManageContent?'':'disabled'}>${escapeHtml(data.settings.guide_text)}</textarea><small>${n(data.settings.guide_text.length)} کاراکتر</small></label></div></section>`:''}${plansSection}${accessSection}${canViewContent?`<section class="card table-card announcements-card"><div class="card-head settings-table-head"><div class="card-title"><b>اعلان‌های عمومی</b><span>پیام‌های منتشرشده برای همه کاربران یا یک پلن مشخص</span></div>${canManageContent?`<button class="primary-btn compact-btn" data-add-announcement>${icon('message',13)} اعلان جدید</button>`:''}</div><div class="table-scroll"><table class="data-table"><thead><tr><th>عنوان و متن</th><th>نوع</th><th>مخاطب</th><th>وضعیت</th><th>بازه نمایش</th><th></th></tr></thead><tbody>${announcementRows||'<tr><td colspan="6"><div class="empty-table">اعلانی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section>`:''}`;
}

function securityTabs() {
  return `<div class="tabs security-tabs"><button class="tab-btn ${state.logsTab==='errors'?'active':''}" data-logs-tab="errors">${icon('alert',14)} خطاهای سیستم</button><button class="tab-btn ${state.logsTab==='security'?'active':''}" data-logs-tab="security">${icon('shield',14)} امنیت و هشدارها</button><button class="tab-btn ${state.logsTab==='audit'?'active':''}" data-logs-tab="audit">${icon('history',14)} Audit Log</button></div>`;
}
async function renderLogs() {
  const canManageSecurity=hasPermission('security.manage');
  if (state.logsTab === 'audit') return renderAudit();
  if (state.logsTab === 'security') return renderSecurity();
  const q = state.errors;
  const params = new URLSearchParams({ ...(q.status&&{status:q.status}),...(q.severity&&{severity:q.severity}) });
  const data = await api(`/api/admin/errors?${params}`);
  const rows = data.rows.map(item => `<tr><td><span class="severity ${item.severity}">${escapeHtml(({critical:'بحرانی',error:'خطا',warning:'هشدار',info:'اطلاعات'})[item.severity])}</span></td><td><span class="source-code">${escapeHtml(item.source)}</span></td><td><div class="error-message" title="${escapeHtml(item.message)}">${escapeHtml(item.message)}</div></td><td><span class="status ${item.status==='open'?'failed':item.status==='resolved'?'active':'pending'}">${statusLabel(item.status)}</span></td><td>${dateFa(item.occurred_at,true)}</td><td>${canManageSecurity?`<button class="table-action" data-error-id="${item.id}">${icon('more',15)}</button>`:'—'}</td></tr>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">SYSTEM HEALTH & AUDIT</span><h2>خطاها و گزارش فعالیت</h2><p>رخدادهای فنی و تاریخچه تغییرات مدیران.</p></div>${securityTabs()}</div><div class="toolbar"><select class="select" data-error-filter="severity"><option value="">همه سطح‌ها</option><option value="critical" ${q.severity==='critical'?'selected':''}>بحرانی</option><option value="error" ${q.severity==='error'?'selected':''}>خطا</option><option value="warning" ${q.severity==='warning'?'selected':''}>هشدار</option><option value="info" ${q.severity==='info'?'selected':''}>اطلاعات</option></select><select class="select" data-error-filter="status"><option value="">همه وضعیت‌ها</option><option value="open" ${q.status==='open'?'selected':''}>باز</option><option value="resolved" ${q.status==='resolved'?'selected':''}>حل‌شده</option><option value="ignored" ${q.status==='ignored'?'selected':''}>نادیده گرفته‌شده</option></select><span class="toolbar-count">${n(data.rows.length)} رخداد</span></div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>سطح</th><th>سرویس</th><th>پیام خطا</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="6"><div class="empty-table">خطایی با این فیلتر وجود ندارد.</div></td></tr>'}</tbody></table></div></section>`;
}
async function renderSecurity() {
  const canManageSecurity=hasPermission('security.manage');
  const data = await api('/api/admin/security/overview');
  state.cache.security = data;
  const categoryLabels={api:'API',database:'دیتابیس',authentication:'ورود و احراز هویت',rate_limit:'محدودسازی',attack:'حمله احتمالی',consumption:'افزایش مصرف',file:'امنیت فایل',sms:'امنیت پیامک'};
  const severityLabels={critical:'بحرانی',error:'خطا',warning:'هشدار',info:'اطلاعات'};
  const compactDetails=value=>typeof value==='string'?value:value?Object.entries(value).map(([key,val])=>`${key}: ${val}`).join(' · '):'—';
  const alertRows=data.alerts.map(alert=>`<tr><td><span class="severity ${alert.severity}">${severityLabels[alert.severity]}</span></td><td><div class="security-alert-title"><b>${escapeHtml(alert.title)}</b><span>${escapeHtml(categoryLabels[alert.category]||alert.category)}</span></div></td><td><div class="security-detail" title="${escapeHtml(compactDetails(alert.details))}">${escapeHtml(compactDetails(alert.details))}</div></td><td><span class="status ${alert.status==='open'?'failed':alert.status==='acknowledged'?'pending':'active'}">${alert.status==='open'?'باز':alert.status==='acknowledged'?'در حال پیگیری':'حل‌شده'}</span></td><td>${dateFa(alert.detected_at,true)}</td><td>${canManageSecurity?`<div class="inline-actions">${alert.status==='open'?`<button class="table-action" data-security-alert="${alert.id}" data-alert-status="acknowledged" title="در حال پیگیری">${icon('eye',13)}</button>`:''}${alert.status!=='resolved'?`<button class="table-action success-action" data-security-alert="${alert.id}" data-alert-status="resolved" title="حل‌شده">${icon('check',13)}</button>`:''}</div>`:'—'}</td></tr>`).join('');
  const failedRows=data.failedLogins.map(item=>{const details=item.details||{};return `<tr><td><span class="status failed">${item.action==='LOGIN_BLOCKED'?'مسدودشده':'ناموفق'}</span></td><td dir="ltr">${escapeHtml(details.mobile||'—')}</td><td><span class="source-code">${escapeHtml(item.ip||details.ip||'—')}</span></td><td>${escapeHtml(details.reason||'رمز عبور یا اطلاعات ورود نامعتبر')}</td><td>${dateFa(item.created_at,true)}</td></tr>`}).join('');
  const blockRows=data.blocks.map(block=>`<tr><td><span class="block-type ${block.block_type}">${block.block_type==='ip'?'IP':'موبایل'}</span></td><td><span class="source-code">${escapeHtml(block.block_value)}</span></td><td>${escapeHtml(block.reason)}</td><td>${block.source==='automatic'?'خودکار':'مدیر'}</td><td><span class="status ${block.status==='active'?'failed':block.status==='expired'?'pending':'limited'}">${block.status==='active'?'فعال':block.status==='expired'?'منقضی':'لغوشده'}</span></td><td>${dateFa(block.expires_at,true)}</td><td>${canManageSecurity?`${block.status==='active'?`<button class="table-action" data-revoke-block="${block.id}" title="لغو محدودیت">${icon('close',13)}</button>`:''}`:'—'}</td></tr>`).join('');
  const limitedRows=data.limitedUsers.map(user=>`<tr><td><div class="user-cell"><span class="user-avatar">${escapeHtml(initials(user.name))}</span><div><b>${escapeHtml(user.name)}</b><span dir="ltr">${escapeHtml(user.mobile)}</span></div></div></td><td><span class="status ${user.access_mode==='limited'?'limited':'suspended'}">${user.access_mode==='limited'?'محدود':'مسدود'}</span></td><td>${escapeHtml(user.restriction_reason||'محدودیت دسترسی حساب')}</td><td>${dateFa(user.limited_until,true)}</td></tr>`).join('');
  const activityRows=data.adminActivity.slice(0,20).map(item=>`<tr><td><div class="audit-action"><i>${icon('history',13)}</i><b>${escapeHtml(actionLabel(item.action))}</b></div></td><td>${escapeHtml(item.admin_name||'سیستم')}</td><td>${escapeHtml(item.entity_type||'—')}</td><td><div class="security-detail">${escapeHtml(compactDetails(item.details))}</div></td><td>${dateFa(item.created_at,true)}</td></tr>`).join('');
  const changeRows=data.changeReports.slice(0,20).map(item=>`<tr><td><b class="change-action">${escapeHtml(actionLabel(item.action))}</b></td><td>${escapeHtml(item.admin_name||'سیستم')}</td><td>${escapeHtml(item.entity_type||'—')} / ${escapeHtml(item.entity_id||'—')}</td><td><div class="security-detail">${escapeHtml(compactDetails(item.details))}</div></td><td><span class="source-code">${escapeHtml(item.ip||'—')}</span></td><td>${dateFa(item.created_at,true)}</td></tr>`).join('');
  const apiDbErrors=data.errors.filter(error=>error.source.includes('API')||error.source.includes('DB')||error.source.includes('SQLITE')).slice(0,12).map(error=>`<div class="security-error-row"><span class="severity ${error.severity}">${severityLabels[error.severity]}</span><div><b>${escapeHtml(error.message)}</b><small>${escapeHtml(error.source)} · ${relativeTime(error.occurred_at)}</small></div><span class="status ${error.status==='open'?'failed':'active'}">${statusLabel(error.status)}</span></div>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">SECURITY OPERATIONS CENTER</span><h2>گزارش خطا و امنیت</h2><p>خطاهای API و دیتابیس، ورودهای ناموفق، محدودیت‌ها، هشدارها و ردپای کامل مدیران.</p></div><div class="section-head-actions">${securityTabs()}${canManageSecurity||hasPermission('settings.manage')?`<button class="ghost-btn" data-auth-security-settings>${icon('settings',14)} سیاست احراز هویت</button>`:''}</div></div><div class="security-metrics"><article class="card security-metric"><span>${icon('alert',18)}</span><div><small>خطاهای API در ۲۴ ساعت</small><b>${n(data.metrics.api_errors)}</b><em>${n(data.metrics.database_errors)} خطای دیتابیس</em></div></article><article class="card security-metric critical"><span>${icon('lock',18)}</span><div><small>ورود ناموفق / مسدود</small><b>${n(data.metrics.failed_logins_24h)}</b><em>۲۴ ساعت گذشته</em></div></article><article class="card security-metric blocked"><span>${icon('shield',18)}</span><div><small>IP و شماره محدودشده</small><b>${n(data.metrics.active_blocks)}</b><em>${n(data.limitedUsers.length)} حساب محدود</em></div></article><article class="card security-metric warning"><span>${icon('activity',18)}</span><div><small>هشدارهای باز</small><b>${n(data.metrics.open_alerts)}</b><em>${n(data.metrics.critical_alerts)} هشدار بحرانی</em></div></article><article class="card security-metric audit"><span>${icon('history',18)}</span><div><small>فعالیت ثبت‌شده مدیران</small><b>${n(data.metrics.audited_requests_24h)}</b><em>پوشش کامل درخواست‌های مدیریتی</em></div></article></div><div class="attack-indicators"><div class="indicator ${data.indicators.failed_logins_24h?'danger':''}">${icon('lock',15)}<span>ورود ناموفق</span><b>${n(data.indicators.failed_logins_24h)}</b></div><div class="indicator ${data.indicators.suspicious_sms_24h?'warning':''}">${icon('sms',15)}<span>OTP مشکوک</span><b>${n(data.indicators.suspicious_sms_24h)}</b></div><div class="indicator ${data.indicators.suspicious_files?'warning':''}">${icon('file',15)}<span>فایل مشکوک</span><b>${n(data.indicators.suspicious_files)}</b></div><div class="indicator ${data.indicators.storage_pressure_users?'danger':''}">${icon('database',15)}<span>مصرف بالای ۸۵٪</span><b>${n(data.indicators.storage_pressure_users)}</b></div></div><section class="card table-card"><div class="card-head security-section-head"><div class="card-title"><b>هشدارهای امنیتی و مصرف</b><span>افزایش خطا، حمله احتمالی و رشد غیرعادی منابع</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>سطح</th><th>هشدار</th><th>جزئیات</th><th>وضعیت</th><th>تشخیص</th><th></th></tr></thead><tbody>${alertRows||'<tr><td colspan="6"><div class="empty-table">هشدار امنیتی وجود ندارد.</div></td></tr>'}</tbody></table></div></section><div class="security-two-col"><section class="card security-panel"><div class="card-head"><div class="card-title"><b>خطاهای API و دیتابیس</b><span>خطاهای فنی اخیر با اولویت بالا</span></div><button class="text-btn" data-logs-tab="errors">مشاهده همه</button></div><div class="security-error-list">${apiDbErrors||'<div class="secure-empty">خطای جدیدی ثبت نشده است.</div>'}</div></section><section class="card security-panel"><div class="card-head"><div class="card-title"><b>IP و شماره‌های محدودشده</b><span>محدودیت خودکار یا اعمال‌شده توسط مدیر</span></div>${canManageSecurity?`<button class="primary-btn compact-btn" data-add-security-block>${icon('lock',13)} محدودسازی جدید</button>`:''}</div><div class="table-scroll mini-security-table"><table class="data-table"><thead><tr><th>نوع</th><th>مقدار</th><th>دلیل</th><th>منبع</th><th>وضعیت</th><th>پایان</th><th></th></tr></thead><tbody>${blockRows}</tbody></table></div></section></div><section class="card table-card" style="margin-top:13px"><div class="card-head security-section-head"><div class="card-title"><b>تلاش‌های ناموفق ورود</b><span>شماره، IP و علت رد درخواست</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>نتیجه</th><th>شماره</th><th>IP</th><th>علت</th><th>زمان</th></tr></thead><tbody>${failedRows||'<tr><td colspan="5"><div class="empty-table">تلاش ناموفقی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section><section class="card table-card" style="margin-top:13px"><div class="card-head security-section-head"><div class="card-title"><b>حساب‌های محدود یا مسدود</b><span>کاربرانی که دسترسی آن‌ها در مدیریت کاربران محدود شده است</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>کاربر</th><th>وضعیت</th><th>دلیل</th><th>پایان محدودیت</th></tr></thead><tbody>${limitedRows||'<tr><td colspan="4"><div class="empty-table">حساب محدودی وجود ندارد.</div></td></tr>'}</tbody></table></div></section><section class="card table-card" style="margin-top:13px"><div class="card-head security-section-head"><div class="card-title"><b>فعالیت‌های مهم مدیران</b><span>عملیات حساس و تغییرات دسترسی، مالی و امنیتی</span></div><button class="text-btn" data-logs-tab="audit">Audit Log کامل</button></div><div class="table-scroll"><table class="data-table"><thead><tr><th>فعالیت</th><th>مدیر</th><th>منبع</th><th>جزئیات</th><th>زمان</th></tr></thead><tbody>${activityRows||'<tr><td colspan="5"><div class="empty-table">فعالیت مهمی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section><section class="card table-card" style="margin-top:13px"><div class="card-head security-section-head"><div class="card-title"><b>گزارش تغییر یا حذف اطلاعات</b><span>تاریخچه قابل رهگیری تغییر، حذف، لغو و بازپرداخت</span></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>عملیات</th><th>مدیر</th><th>رکورد</th><th>جزئیات تغییر</th><th>IP</th><th>زمان</th></tr></thead><tbody>${changeRows||'<tr><td colspan="6"><div class="empty-table">تغییر یا حذفی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section>`;
}

async function renderAudit() {
  const data = await api('/api/admin/audit');
  const rows = data.rows.map(item => `<tr><td><div class="audit-action"><i>${icon('history',13)}</i><b>${escapeHtml(actionLabel(item.action))}</b></div></td><td>${escapeHtml(item.admin_name||'سیستم')}</td><td>${escapeHtml(item.entity_type||'—')}</td><td><div class="error-message">${escapeHtml(typeof item.details==='string'?item.details:item.details?JSON.stringify(item.details):'—')}</div></td><td dir="ltr">${escapeHtml(item.ip||'—')}</td><td>${dateFa(item.created_at,true)}</td></tr>`).join('');
  return `<div class="section-head"><div><span class="eyebrow">SYSTEM HEALTH & AUDIT</span><h2>خطاها و گزارش فعالیت</h2><p>تمام عملیات حساس مدیران به‌صورت غیرقابل‌انکار ثبت می‌شود.</p></div>${securityTabs()}</div><section class="card table-card"><div class="table-scroll"><table class="data-table"><thead><tr><th>فعالیت</th><th>مدیر</th><th>منبع</th><th>جزئیات</th><th>IP</th><th>زمان</th></tr></thead><tbody>${rows||'<tr><td colspan="6"><div class="empty-table">فعالیتی ثبت نشده است.</div></td></tr>'}</tbody></table></div></section>`;
}

let modalReturnFocus=null;
function openModal(html) {
  modalReturnFocus=document.activeElement instanceof HTMLElement?document.activeElement:null;
  $('#modal').classList.remove('wide-modal');
  $('#modal').innerHTML = html;
  $('#modal').tabIndex=-1;
  $('#modalLayer').hidden = false;
  $('#adminApp').inert=true;
  /* صفحه ورود هم باید غیرفعال شود؛ وگرنه هنگام «تأیید دومرحله‌ای»
     کارت ورود روی مودال می‌افتد و کادر کد اصلاً دیده نمی‌شود. */
  const loginScreen=$('#loginScreen'); if(loginScreen&&!loginScreen.hidden) loginScreen.inert=true;
  document.body.style.overflow = 'hidden';
  hydrateIcons($('#modal'));
  $$('button:not([type])',$('#modal')).forEach(button=>button.type='button');
  setTimeout(() => ($('.modal-close', $('#modal'))||$('#modal')).focus(), 30);
}
function closeModal() { if($('#modalLayer').hidden)return;$('#modalLayer').hidden = true; $('#modal').innerHTML = ''; $('#adminApp').inert=false;const loginScreen=$('#loginScreen');if(loginScreen)loginScreen.inert=false;document.body.style.overflow = '';const target=modalReturnFocus;modalReturnFocus=null;if(target?.isConnected)setTimeout(()=>target.focus(),0); }
function trapModalFocus(event){if(event.key!=='Tab'||$('#modalLayer').hidden)return;const modal=$('#modal'),items=$$('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',modal).filter(item=>!item.hidden&&item.getClientRects().length);if(!items.length){event.preventDefault();modal.focus();return}const first=items[0],last=items[items.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}}
async function openUser(userId) {
  try {
    const { user, sessions = [], recovery = [], journal = {} } = await api(`/api/admin/users/${userId}`);
    const canChangeUser=hasPermission('users.manage'),canSecureUser=canChangeUser||hasPermission('users.security'),canDeleteUser=hasPermission('users.delete');
    const max = Number(user.max_storage_bytes || 1), percent = Math.min(100, user.storage_bytes/max*100), displayStatus = user.effective_status || user.status;
    const defaultLimit = user.limited_until ? user.limited_until.slice(0,10) : new Date(Date.now()+7*86400000).toISOString().slice(0,10);
    const sessionRows = sessions.length ? sessions.map(session => `<div class="session-row"><span>${icon('server',14)}</span><div><b>${escapeHtml(session.device||'دستگاه ناشناس')}</b><small>${escapeHtml(session.ip||'—')} · ${relativeTime(session.last_seen_at)}</small></div><em>${dateFa(session.expires_at)}</em></div>`).join('') : '<div class="secure-empty">هیچ نشست فعالی وجود ندارد.</div>';
    openModal(`<header class="modal-head"><h3 id="modalTitle">مدیریت و امنیت کاربر</h3><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="modal-user"><span class="user-avatar">${escapeHtml(initials(user.name))}</span><div><b>${escapeHtml(user.name)}</b><span dir="ltr">${escapeHtml(user.mobile)}</span></div><span class="status ${displayStatus}" style="margin-right:auto">${statusLabel(displayStatus)}</span></div>${user.deletion_requested_at?`<div class="deletion-request-alert">${icon('alert',15)}<div><b>درخواست حذف حساب ثبت شده است</b><span>تاریخ درخواست: ${dateFa(user.deletion_requested_at,true)}</span></div></div>`:''}<div class="detail-grid"><div class="detail-box"><small>تاریخ ثبت‌نام</small><b>${dateFa(user.created_at,true)}</b></div><div class="detail-box"><small>آخرین فعالیت</small><b>${relativeTime(user.last_seen_at)}</b></div><div class="detail-box"><small>فضای مصرفی</small><b>${bytes(user.storage_bytes)} (${n(Math.round(percent))}٪)</b></div><div class="detail-box"><small>معاملات همگام‌شده</small><b>${n(journal.trades??user.trades_count)}</b></div><div class="detail-box"><small>حساب‌های معاملاتی</small><b>${n(journal.accounts||0)}</b></div><div class="detail-box"><small>آخرین همگام‌سازی</small><b>${journal.lastSyncAt?relativeTime(journal.lastSyncAt):'بدون داده'}</b></div><div class="detail-box"><small>پلن فعلی</small><b>${escapeHtml(user.plan_fa||'بدون پلن')}</b></div><div class="detail-box"><small>نشست‌های فعال</small><b>${n(sessions.length)} دستگاه</b></div></div>${canChangeUser?`<div class="access-editor"><label>وضعیت دسترسی<select class="select" id="userStatus"><option value="active" ${displayStatus==='active'?'selected':''}>فعال</option><option value="limited" ${displayStatus==='limited'?'selected':''}>محدود موقت</option><option value="suspended" ${displayStatus==='suspended'?'selected':''}>مسدود</option><option value="pending" ${displayStatus==='pending'?'selected':''}>در انتظار بررسی</option></select></label><div class="limit-fields" id="limitFields" ${displayStatus==='limited'?'':'hidden'}><label>پایان محدودیت<input class="input" id="limitedUntil" type="date" value="${defaultLimit}"></label><label>دلیل محدودیت<input class="input" id="limitReason" maxlength="300" value="${escapeHtml(user.restriction_reason||'محدودیت موقت توسط مدیر')}" placeholder="دلیل محدودیت"></label></div><button class="primary-btn save-access-btn" id="saveUserStatus">ذخیره وضعیت دسترسی</button></div>`:''}<div class="secure-section"><div class="secure-section-head"><div><b>نشست‌های فعال</b><span>دستگاه‌هایی که اکنون به حساب دسترسی دارند</span></div><span class="soft-chip">${n(sessions.length)} نشست</span></div><div class="session-list">${sessionRows}</div></div>${canSecureUser?`<div class="user-auth-security"><div><b>حفاظت ورود حساب</b><span>${user.mobile_verified_at?'شماره موبایل تأیید شده':'شماره موبایل هنوز تأیید نشده'}</span></div><label><input type="checkbox" id="userSensitive" ${user.security_level==='sensitive'?'checked':''}> حساب حساس</label><label><input type="checkbox" id="userRequire2fa" ${user.require_2fa?'checked':''}> الزام OTP در هر ورود</label><button class="ghost-btn" id="saveUserAuthSecurity">ذخیره سیاست ورود</button></div>`:''}<div class="secure-actions">${canSecureUser?`<button class="secure-action" id="forceLogout"><span>${icon('logout',17)}</span><div><b>خروج اجباری</b><small>خروج از تمام دستگاه‌ها</small></div></button><button class="secure-action recovery" id="startRecovery"><span>${icon('shield',17)}</span><div><b>بازیابی امن دسترسی</b><small>ارسال لینک یک‌بارمصرف ۱۵ دقیقه‌ای</small></div></button>`:''}${canDeleteUser?`<button class="secure-action danger" id="deleteUser"><span>${icon('alert',17)}</span><div><b>حذف حساب</b><small>فقط پس از درخواست صریح کاربر</small></div></button>`:''}</div>${recovery[0]&&recovery[0].status==='pending'?`<div class="recovery-note">${icon('shield',14)} یک فرایند بازیابی تا ${dateFa(recovery[0].expires_at,true)} فعال است.</div>`:''}<div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button></div></div>`);
    $('#userStatus')?.addEventListener('change', event => { $('#limitFields').hidden = event.target.value !== 'limited'; });
    $('#saveUserStatus')?.addEventListener('click', async event => {
      setBusy(event.currentTarget, true);
      try {
        const status = $('#userStatus').value;
        await api(`/api/admin/users/${user.id}/status`, { method:'PATCH', body:JSON.stringify({ status, limitedUntil:status==='limited'?$('#limitedUntil').value:null, reason:status==='limited'?$('#limitReason').value:null }) });
        closeModal(); toast('وضعیت دسترسی کاربر با موفقیت ذخیره شد.'); renderView('users');
      } catch (error) { toast(error.message,'error'); setBusy(event.currentTarget,false); }
    });
    $('#saveUserAuthSecurity')?.addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const result=await api(`/api/admin/users/${user.id}/security`,{method:'PATCH',body:JSON.stringify({securityLevel:$('#userSensitive').checked?'sensitive':'normal',require2fa:$('#userRequire2fa').checked})});toast(result.require2fa?'OTP برای همه ورودهای این حساب الزامی شد.':'سیاست امنیت ورود کاربر ذخیره شد.');openUser(user.id)}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
    $('#forceLogout')?.addEventListener('click', async event => {
      if (!confirm(`تمام نشست‌های فعال «${user.name}» بسته شوند؟`)) return;
      setBusy(event.currentTarget,true);
      try { const result=await api(`/api/admin/users/${user.id}/force-logout`,{method:'POST',body:'{}'}); toast(`${n(result.revokedSessions)} نشست با موفقیت بسته شد.`); openUser(user.id); }
      catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}
    });
    $('#startRecovery')?.addEventListener('click', async event => {
      if (!confirm(`فرایند بازیابی امن برای ${user.mobile} آغاز شود؟`)) return;
      setBusy(event.currentTarget,true);
      try { const result=await api(`/api/admin/users/${user.id}/recovery`,{method:'POST',body:'{}'}); toast(`لینک بازیابی برای ${result.maskedMobile} در صف ارسال قرار گرفت.`); openUser(user.id); }
      catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}
    });
    $('#deleteUser')?.addEventListener('click',()=>openDeleteUser(user));
  } catch (error) { toast(error.message,'error'); }
}

function openDeleteUser(user) {
  openModal(`<header class="modal-head"><h3 id="modalTitle">حذف امن حساب کاربر</h3><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="danger-zone"><span>${icon('alert',22)}</span><div><b>این عملیات برگشت‌پذیر نیست</b><p>نشست‌ها بسته، اشتراک لغو و حساب کاربر از فهرست فعال حذف می‌شود. گزارش مدیریتی عملیات باقی می‌ماند.</p></div></div><label style="margin-top:14px">برای تأیید، شماره موبایل کاربر را وارد کن<input class="input" id="deleteConfirmMobile" type="tel" dir="ltr" placeholder="${escapeHtml(user.mobile)}"></label><label class="consent-check"><input id="deleteRequested" type="checkbox"><span></span> تأیید می‌کنم درخواست صریح حذف توسط کاربر ثبت شده است.</label><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="danger-btn" id="confirmDeleteUser" disabled>حذف قطعی حساب</button></div></div>`);
  const validate=()=>{$('#confirmDeleteUser').disabled=!($('#deleteRequested').checked&&normalizeMobile($('#deleteConfirmMobile').value)===user.mobile)};
  $('#deleteConfirmMobile').addEventListener('input',event=>{event.target.value=normalizeMobile(event.target.value).slice(0,11);validate()});
  $('#deleteRequested').addEventListener('change',validate);
  $('#confirmDeleteUser').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(`/api/admin/users/${user.id}`,{method:'DELETE',body:JSON.stringify({confirmMobile:$('#deleteConfirmMobile').value,userRequested:$('#deleteRequested').checked})});closeModal();toast('حساب کاربر طبق درخواست حذف شد.');renderView('users')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
async function openSubscription(subscriptionId) {
  try {
    const sub = (await api(`/api/admin/subscriptions/${subscriptionId}`)).row;
    if (!sub) return toast('اشتراک پیدا نشد.','error');
    const plans = state.cache.plans || (await api('/api/admin/plans')).rows;
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">ویرایش اشتراک</h3><span class="modal-subtitle">فعال‌سازی، تمدید، لغو و اعمال تخفیف</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="modal-user"><span class="user-avatar">${escapeHtml(initials(sub.user_name))}</span><div><b>${escapeHtml(sub.user_name)}</b><span dir="ltr">${escapeHtml(sub.mobile)}</span></div><span class="status ${sub.status}" style="margin-right:auto">${statusLabel(sub.status)}</span></div><div class="form-grid billing-form" style="margin-top:14px"><label>پلن<select class="select" id="subPlan">${plans.map(plan=>`<option value="${plan.id}" ${plan.id===sub.plan_id?'selected':''}>${escapeHtml(plan.name_fa)} — ${plan.price_monthly?toman(plan.price_monthly):'رایگان'}</option>`).join('')}</select></label><label>وضعیت<select class="select" id="subStatus"><option value="active" ${sub.status==='active'?'selected':''}>فعال / فعال‌سازی دستی</option><option value="trial" ${sub.status==='trial'?'selected':''}>آزمایشی</option><option value="expired" ${sub.status==='expired'?'selected':''}>منقضی</option><option value="cancelled" ${sub.status==='cancelled'?'selected':''}>لغوشده</option></select></label><label>تاریخ شروع<input class="input" id="subStarted" type="date" value="${sub.started_at?sub.started_at.slice(0,10):''}"></label><label>تاریخ پایان<input class="input" id="subExpiry" type="date" value="${sub.expires_at?sub.expires_at.slice(0,10):''}"></label><label>کد تخفیف<input class="input coupon-input" id="subCoupon" dir="ltr" maxlength="40" value="${escapeHtml(sub.coupon_code||'')}" placeholder="مثلاً PRO20"></label><label>تمدید خودکار<div class="toggle-row">در پایان دوره تمدید شود<button type="button" class="toggle ${sub.auto_renew?'on':''}" id="subAuto"><i></i></button></div></label></div><div class="quick-actions"><button class="ghost-btn" id="extendSubscription">${icon('calendar',14)} اعمال مدت استاندارد پلن</button><button class="ghost-btn danger-text" id="cancelSubscription">${icon('close',14)} لغو اشتراک</button></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveSubscription">ذخیره اشتراک</button></div></div>`);
    $('#subAuto').addEventListener('click', event => event.currentTarget.classList.toggle('on'));
    $('#extendSubscription').addEventListener('click',()=>{const plan=plans.find(item=>item.id===$('#subPlan').value),days=Number(plan?.duration_days||0),started=$('#subStarted').value?new Date($('#subStarted').value+'T12:00:00'):new Date();if(days>0){started.setDate(started.getDate()+days);$('#subExpiry').value=started.toISOString().slice(0,10);toast(`مدت استاندارد ${n(days)} روزه پلن اعمال شد؛ برای ثبت، ذخیره را بزنید.`)}else{$('#subExpiry').value='';toast('این پلن بدون تاریخ انقضا تنظیم شده است.')}$('#subStatus').value='active';});
    $('#cancelSubscription').addEventListener('click',()=>{$('#subStatus').value='cancelled';$('#subAuto').classList.remove('on');toast('وضعیت لغوشده انتخاب شد؛ برای ثبت، ذخیره را بزنید.');});
    $('#saveSubscription').addEventListener('click', async event => { setBusy(event.currentTarget,true); try { await api(`/api/admin/subscriptions/${sub.id}`,{method:'PATCH',body:JSON.stringify({planId:$('#subPlan').value,status:$('#subStatus').value,startedAt:$('#subStarted').value||null,expiresAt:$('#subExpiry').value||null,autoRenew:$('#subAuto').classList.contains('on'),couponCode:$('#subCoupon').value})}); closeModal();toast('اشتراک کاربر به‌روزرسانی شد.');renderView('subscriptions'); } catch(error){toast(error.message,'error');setBusy(event.currentTarget,false);} });
  } catch(error) { toast(error.message,'error'); }
}

let planFeatureCounter=0;
function addPlanFeatureRow(feature={}){
  const list=$('#planFeatures'),key=feature.feature_key||`feature-${Date.now().toString(36)}-${++planFeatureCounter}`;
  const row=document.createElement('div');row.className='plan-feature-row';row.innerHTML=`<span class="feature-drag" aria-hidden="true">⋮⋮</span><label>کلید<input class="input plan-feature-key" dir="ltr" maxlength="50" value="${escapeHtml(key)}"></label><label>عنوان قابلیت<input class="input plan-feature-label" maxlength="160" value="${escapeHtml(feature.label||'')}"></label><label class="feature-description">توضیح اختیاری<input class="input plan-feature-description" maxlength="500" value="${escapeHtml(feature.description||'')}"></label><label class="feature-enabled"><input type="checkbox" ${feature.is_enabled!==false?'checked':''}> فعال</label><div class="feature-move-actions"><button type="button" data-feature-up title="انتقال به بالا">↑</button><button type="button" data-feature-down title="انتقال به پایین">↓</button><button type="button" class="danger" data-feature-remove title="حذف قابلیت">×</button></div>`;list.append(row);
  $('[data-feature-remove]',row).addEventListener('click',()=>row.remove());$('[data-feature-up]',row).addEventListener('click',()=>{if(row.previousElementSibling)list.insertBefore(row,row.previousElementSibling)});$('[data-feature-down]',row).addEventListener('click',()=>{if(row.nextElementSibling)list.insertBefore(row.nextElementSibling,row)});
}
function collectPlanFeatures(){return $$('.plan-feature-row',$('#planFeatures')).map(row=>({featureKey:$('.plan-feature-key',row).value.trim(),label:$('.plan-feature-label',row).value.trim(),description:$('.plan-feature-description',row).value.trim(),isEnabled:$('.feature-enabled input',row).checked}))}
function openPlan(planId=null) {
  const plan=(state.cache.plans||[]).find(row=>row.id===planId),creating=!plan,journalDefinitions=[['dashboard','داشبورد'],['new','ثبت معامله جدید'],['history','تاریخچه معاملات'],['calendar','تقویم و Heatmap'],['prop','قوانین پراپ‌فرم'],['risk','ریسک و بینش هوشمند'],['checklist','چک‌لیست معاملاتی'],['documents','مستندات و گالری'],['import','ورود CSV / MetaTrader'],['settings','حساب‌ها و تنظیمات'],['pwa','اپ همراه']],sectionState=new Map((plan?.journal_sections||[]).map(item=>[item.section_key,!!item.is_enabled]));
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">${creating?'ساخت پلن جدید':`مدیریت پلن ${escapeHtml(plan.name_fa)}`}</h3><span class="modal-subtitle">هویت بازاریابی، قیمت، ظرفیت، انتشار و امکانات مستقل پلن</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body plan-editor-body"><section class="plan-editor-section"><div class="plan-editor-title"><b>معرفی و نمایش عمومی</b><span>این اطلاعات روی صفحه اصلی و قیمت‌گذاری دیده می‌شوند.</span></div><div class="form-grid billing-form"><label>نام فارسی<input class="input" id="planNameFa" maxlength="80" value="${escapeHtml(plan?.name_fa||'')}"></label><label>شناسه انگلیسی<input class="input" id="planName" dir="ltr" maxlength="40" value="${escapeHtml(plan?.name||'')}"></label><label class="full-field">متن معرفی کوتاه<input class="input" id="planTagline" maxlength="240" value="${escapeHtml(plan?.tagline||'')}"></label><label>نشان / Badge<input class="input" id="planBadge" maxlength="80" value="${escapeHtml(plan?.badge_label||'')}" placeholder="پیشنهاد معامله‌گران"></label><label>متن دکمه CTA<input class="input" id="planCta" maxlength="80" value="${escapeHtml(plan?.cta_label||'شروع رایگان')}"></label><label>رنگ پلن<input class="input plan-color-input" id="planColor" type="color" value="${escapeHtml(plan?.color||'#22d3ee')}"></label><label>ترتیب نمایش<input class="input" id="planOrder" type="number" min="0" max="10000" value="${Number(plan?.sort_order||((state.cache.plans?.length||0)+1)*10)}"></label></div><div class="plan-editor-title" style="margin-top:18px"><b>تخفیف و قیمت ویژه</b><span>قیمت اصلی روی سایت خط می‌خورد و قیمت جدید کنارش می‌نشیند. خالی گذاشتن هر دو فیلد یعنی بدون تخفیف.</span></div><div class="form-grid billing-form"><label>درصد تخفیف (۰ تا ۹۵)<input class="input" id="planDiscountPercent" type="number" min="0" max="95" step="1" value="${Number(plan?.discount_percent||0)}"></label><label>یا قیمت با تخفیف (تومان)<input class="input" id="planDiscountPrice" type="number" min="0" step="1000" placeholder="خالی = از درصد حساب شود" value="${plan?.discount_price===null||plan?.discount_price===undefined?'':Number(plan.discount_price)}"></label><label>متن کنار تخفیف<input class="input" id="planDiscountLabel" maxlength="60" placeholder="جشنواره پاییز" value="${escapeHtml(plan?.discount_label||'')}"></label><label>پایان خودکار تخفیف<input class="input" id="planDiscountUntil" type="date" value="${plan?.discount_until?String(plan.discount_until).slice(0,10):''}"></label></div><p class="plan-discount-hint" id="planDiscountHint"></p><div class="plan-switches"><label><input id="planActive" type="checkbox" ${plan?.is_active!==false?'checked':''}><span>پلن فعال و قابل نمایش عمومی باشد</span></label><label><input id="planRecommended" type="checkbox" ${plan?.is_recommended?'checked':''}><span>به‌عنوان پیشنهاد اصلی برجسته شود</span></label></div></section><section class="plan-editor-section"><div class="plan-editor-title"><b>قیمت و ظرفیت عملیاتی</b><span>مقادیر واقعی اعمال‌شده برای اشتراک کاربران</span></div><div class="form-grid billing-form"><label>قیمت ماهانه (تومان)<input class="input" id="planPrice" type="number" min="0" step="1000" value="${Number(plan?.price_monthly||0)}"></label><label>حداکثر معاملات<input class="input" id="planTrades" type="number" min="10" step="1" value="${Number(plan?.max_trades||100)}"></label><label>فضای تصاویر (مگابایت)<input class="input" id="planStorage" type="number" min="50" step="1" value="${Math.round(Number(plan?.max_storage_bytes||104857600)/1048576)}"></label><label>سهمیه پیامک ماهانه<input class="input" id="planSms" type="number" min="1" step="1" value="${Number(plan?.max_sms_monthly||5)}"></label><label>مدت استاندارد دسترسی (روز)<input class="input" id="planDuration" type="number" min="0" max="3650" step="1" value="${Number(plan?.duration_days??30)}"><small>صفر یعنی بدون تاریخ انقضا</small></label></div></section><section class="plan-editor-section"><div class="plan-editor-title"><b>دسترسی به بخش‌های ژورنال</b><span>بخش‌های خاموش در رابط کاربر مخفی و عملیات حساس آن‌ها در Backend مسدود می‌شوند.</span></div><div class="journal-access-grid">${journalDefinitions.map(([key,label])=>`<label><input type="checkbox" data-journal-section="${key}" ${(sectionState.has(key)?sectionState.get(key):['dashboard','new','history','settings'].includes(key))?'checked':''}><span>${escapeHtml(label)}</span><code>${key}</code></label>`).join('')}</div></section><section class="plan-editor-section"><div class="plan-editor-title feature-editor-head"><div><b>امکانات و قابلیت‌های مستقل</b><span>قابلیت‌ها را اضافه، حذف، فعال/غیرفعال یا با دکمه‌های بالا/پایین مرتب کنید.</span></div><button type="button" class="ghost-btn" id="addPlanFeature">${icon('userPlus',13)} افزودن قابلیت</button></div><div class="plan-feature-list" id="planFeatures"></div></section><div class="limit-summary">${icon('info',15)} ذخیره این فرم بلافاصله API عمومی پلن‌ها، کارت‌های صفحه اصلی و جدول مقایسه را به‌روزرسانی می‌کند.</div><div class="modal-actions">${plan&&plan.id!=='plan_free'?'<button class="danger-btn" id="deletePlan">حذف پلن</button>':''}<button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="savePlan">${creating?'ساخت و ذخیره پلن':'ذخیره همه تغییرات'}</button></div></div>`);
  $('#modal').classList.add('wide-modal');
  (plan?.features||[]).forEach(addPlanFeatureRow);if(!(plan?.features||[]).length)addPlanFeatureRow({label:'ثبت ساختاریافته معامله',is_enabled:true});
  $('#addPlanFeature').addEventListener('click',()=>addPlanFeatureRow());
  const discountHint=()=>{const base=Number($('#planPrice').value||0),percent=Number($('#planDiscountPercent').value||0),fixed=$('#planDiscountPrice').value===''?null:Number($('#planDiscountPrice').value),until=$('#planDiscountUntil').value;
    let final=base;if(base>0){if(fixed!==null&&fixed<base)final=fixed;else if(percent>0)final=Math.max(0,Math.round(base*(100-percent)/100))}
    const box=$('#planDiscountHint');if(!box)return;
    if(!base||final>=base){box.textContent='بدون تخفیف — فقط قیمت اصلی نمایش داده می‌شود.';box.classList.remove('is-on');return}
    const off=Math.round((1-final/base)*100);
    box.textContent=`روی سایت این‌طور دیده می‌شود: ${toman(base)} خط‌خورده ← ${toman(final)} تومان (${n(off)}٪ تخفیف)${until?` · تا ${dateFa(until)}`:''}. همین مبلغ در صفحه پرداخت هم از کاربر گرفته می‌شود.`;box.classList.add('is-on');};
  ['#planPrice','#planDiscountPercent','#planDiscountPrice','#planDiscountUntil'].forEach(sel=>$(sel)?.addEventListener('input',discountHint));
  discountHint();

  $('#savePlan').addEventListener('click',async event=>{const button=event.currentTarget,setPayload=()=>({name:$('#planName').value,nameFa:$('#planNameFa').value,tagline:$('#planTagline').value,badgeLabel:$('#planBadge').value,ctaLabel:$('#planCta').value,color:$('#planColor').value,sortOrder:Number($('#planOrder').value),isActive:$('#planActive').checked,isRecommended:$('#planRecommended').checked,priceMonthly:Number($('#planPrice').value),discountPercent:Number($('#planDiscountPercent').value||0),discountPrice:$('#planDiscountPrice').value===''?null:Number($('#planDiscountPrice').value),discountLabel:$('#planDiscountLabel').value,discountUntil:$('#planDiscountUntil').value||null,maxTrades:Number($('#planTrades').value),maxStorageBytes:Math.round(Number($('#planStorage').value)*1048576),maxSmsMonthly:Number($('#planSms').value),durationDays:Number($('#planDuration').value),journalSections:$$('[data-journal-section]',$('#modal')).map(input=>({sectionKey:input.dataset.journalSection,isEnabled:input.checked})),features:collectPlanFeatures()});setBusy(button,true);try{await api(creating?'/api/admin/plans':`/api/admin/plans/${plan.id}`,{method:creating?'POST':'PATCH',body:JSON.stringify(setPayload())});closeModal();toast(creating?'پلن جدید ساخته و منتشر شد.':'پلن و امکانات آن ذخیره شد.');renderView('subscriptions')}catch(error){toast(error.message,'error');setBusy(button,false)}});
  $('#deletePlan')?.addEventListener('click',async event=>{if(!confirm(`پلن «${plan.name_fa}» حذف شود؟ این عمل فقط برای پلن بدون سابقه اشتراک مجاز است.`))return;setBusy(event.currentTarget,true);try{await api(`/api/admin/plans/${plan.id}`,{method:'DELETE'});closeModal();toast('پلن حذف شد.');renderView('subscriptions')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}

function openCouponCreator() {
  const today=new Date().toISOString().slice(0,10), later=new Date(Date.now()+30*86400000).toISOString().slice(0,10);
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">ساخت کد تخفیف</h3><span class="modal-subtitle">تخفیف درصدی یا مبلغ ثابت با ظرفیت مصرف</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>کد تخفیف<input class="input coupon-input" id="couponCode" dir="ltr" maxlength="40" placeholder="SUMMER25"></label><label>نوع تخفیف<select class="select" id="couponType"><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option></select></label><label>مقدار<input class="input" id="couponValue" type="number" min="1" value="20"></label><label>حداکثر دفعات مصرف<input class="input" id="couponMaxUses" type="number" min="1" placeholder="بدون محدودیت"></label><label>تاریخ شروع<input class="input" id="couponStart" type="date" value="${today}"></label><label>تاریخ پایان<input class="input" id="couponExpiry" type="date" value="${later}"></label></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="createCoupon">ساخت کد تخفیف</button></div></div>`);
  $('#couponCode').addEventListener('input',event=>event.target.value=event.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g,''));
  $('#createCoupon').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api('/api/admin/coupons',{method:'POST',body:JSON.stringify({code:$('#couponCode').value,discountType:$('#couponType').value,value:Number($('#couponValue').value),maxUses:$('#couponMaxUses').value?Number($('#couponMaxUses').value):null,startsAt:$('#couponStart').value,expiresAt:$('#couponExpiry').value||null})});closeModal();toast('کد تخفیف ساخته شد.');renderView('subscriptions');}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}

async function toggleCoupon(couponId, isActive) {
  try { await api(`/api/admin/coupons/${couponId}`,{method:'PATCH',body:JSON.stringify({isActive:!isActive})});toast(isActive?'کد تخفیف غیرفعال شد.':'کد تخفیف فعال شد.');renderView('subscriptions'); } catch(error){toast(error.message,'error');}
}

async function openPayment(paymentId) {
  try {
    const { invoice:p } = await api(`/api/admin/payments/${paymentId}/invoice`);
    const refundable=Math.max(0,Number(p.amount)-Number(p.refunded_amount||0)),canRefund=hasPermission('billing.refund');
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">فاکتور ${escapeHtml(p.invoice_number)}</h3><span class="modal-subtitle">جزئیات پرداخت و بازپرداخت</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><section class="invoice-sheet" id="invoiceSheet"><div class="invoice-brand"><span class="brand-mark small">P</span><div><b>SmartJournal</b><span>فاکتور اشتراک</span></div><span class="status ${p.status}" style="margin-right:auto">${statusLabel(p.status)}</span></div><div class="invoice-parties"><div><small>صورتحساب برای</small><b>${escapeHtml(p.user_name)}</b><span dir="ltr">${escapeHtml(p.mobile)}</span></div><div><small>شماره فاکتور</small><b dir="ltr">${escapeHtml(p.invoice_number)}</b><span>${dateFa(p.created_at,true)}</span></div></div><div class="invoice-lines"><div><span>اشتراک پلن ${escapeHtml(p.plan_fa||'—')}</span><b>${toman(Number(p.amount)+Number(p.discount_amount||0))}</b></div><div><span>تخفیف ${p.coupon_code?'('+escapeHtml(p.coupon_code)+')':''}</span><b>− ${toman(p.discount_amount||0)}</b></div><div class="total"><span>مبلغ پرداختی</span><b>${toman(p.amount)}</b></div>${p.refunded_amount?`<div class="refund-line"><span>بازپرداخت‌شده</span><b>− ${toman(p.refunded_amount)}</b></div>`:''}</div><div class="invoice-meta"><span>درگاه: ${escapeHtml(p.provider||'—')}</span><span dir="ltr">${escapeHtml(p.tracking_code||'—')}</span></div></section>${canRefund&&refundable>0&&['paid','partially_refunded'].includes(p.status)?`<div class="refund-box"><div><b>بازپرداخت وجه</b><span>حداکثر قابل بازپرداخت: ${toman(refundable)}</span></div><label>مبلغ بازپرداخت (تومان)<input class="input" id="refundAmount" type="number" min="1" max="${refundable}" value="${refundable}"></label><div class="refund-actions"><button class="ghost-btn" id="partialRefund">بازپرداخت مبلغ واردشده</button><button class="danger-btn" id="fullRefund">بازپرداخت کامل باقیمانده</button></div></div>`:''}<div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button><button class="primary-btn" id="printInvoice">${icon('file',14)} چاپ / ذخیره فاکتور</button></div></div>`);
    $('#printInvoice').addEventListener('click',()=>window.print());
    const refund=async amount=>{if(!confirm(`مبلغ ${toman(amount)} بازپرداخت شود؟`))return;try{await api(`/api/admin/payments/${p.id}/refund`,{method:'POST',body:JSON.stringify({amount})});closeModal();toast('بازپرداخت با موفقیت ثبت شد.');renderView('subscriptions');}catch(error){toast(error.message,'error')}};
    $('#partialRefund')?.addEventListener('click',()=>refund(Number($('#refundAmount').value)));
    $('#fullRefund')?.addEventListener('click',()=>refund(refundable));
  } catch(error) { toast(error.message,'error'); }
}

async function openError(errorId) {
  const data = await api('/api/admin/errors'); const item = data.rows.find(row=>row.id===errorId);
  if (!item) return toast('جزئیات خطا پیدا نشد.','error');
  openModal(`<header class="modal-head"><h3 id="modalTitle">جزئیات خطای سیستم</h3><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div style="display:flex;align-items:center;gap:8px"><span class="severity ${item.severity}">${escapeHtml(item.severity)}</span><span class="source-code">${escapeHtml(item.source)}</span><span class="status ${item.status==='open'?'failed':item.status==='resolved'?'active':'pending'}" style="margin-right:auto">${statusLabel(item.status)}</span></div><h4 style="margin:16px 0 8px;font-size:12px">${escapeHtml(item.message)}</h4><pre style="margin:0;max-height:230px;overflow:auto;padding:12px;border:1px solid #223148;border-radius:10px;color:#8495aa;background:#080e17;font:8.5px/1.8 monospace;direction:ltr;text-align:left;white-space:pre-wrap">${escapeHtml(item.stack||'Stack trace ثبت نشده است.')}</pre><div class="detail-grid"><div class="detail-box"><small>زمان رخداد</small><b>${dateFa(item.occurred_at,true)}</b></div><div class="detail-box"><small>زمان حل</small><b>${dateFa(item.resolved_at,true)}</b></div></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button>${item.status!=='ignored'?'<button class="ghost-btn" id="ignoreError">نادیده گرفتن</button>':''}${item.status!=='resolved'?'<button class="primary-btn" id="resolveError">علامت‌گذاری به‌عنوان حل‌شده</button>':''}</div></div>`);
  const update = async status => { try{await api(`/api/admin/errors/${item.id}`,{method:'PATCH',body:JSON.stringify({status})});closeModal();toast('وضعیت خطا ثبت شد.');renderView('logs');}catch(error){toast(error.message,'error');} };
  $('#resolveError')?.addEventListener('click',()=>update('resolved')); $('#ignoreError')?.addEventListener('click',()=>update('ignored'));
}

async function saveSmsSettings(button) {
  setBusy(button,true);
  try {
    await api('/api/admin/sms/settings',{method:'PATCH',body:JSON.stringify({otpTemplate:$('#smsOtpTemplate').value,mobileLimit:Number($('#smsMobileLimit').value),ipLimit:Number($('#smsIpLimit').value),rateWindowMinutes:Number($('#smsRateWindow').value),autoFailover:$('#smsAutoFailover').classList.contains('on')})});
    toast('سیاست ارسال، متن OTP و تعویض خودکار ذخیره شد.');renderView('usage');
  } catch(error) { toast(error.message,'error');setBusy(button,false); }
}
async function openAuthSecuritySettings(){try{const {settings}=await api('/api/admin/auth-security/settings');openModal(`<header class="modal-head"><div><h3 id="modalTitle">سیاست ورود و دستگاه کاربران</h3><span class="modal-subtitle">OTP و CAPTCHA تنها طبق ریسک ورود فعال می‌شوند</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label>حداکثر دستگاه فعال<input class="input" id="authMaxDevices" type="number" min="1" max="20" value="${settings.maxDevices}"></label><label>اعتماد به دستگاه (روز)<input class="input" id="authTrustedDays" type="number" min="1" max="365" value="${settings.trustedDeviceDays}"></label><label>اعتبار OTP (ثانیه)<input class="input" id="authOtpTtl" type="number" min="60" max="600" value="${settings.otpTtlSeconds}"></label><label>حداکثر تلاش OTP<input class="input" id="authOtpAttempts" type="number" min="3" max="10" value="${settings.otpMaxAttempts}"></label><label>آستانه نمایش CAPTCHA<input class="input" id="authCaptchaThreshold" type="number" min="2" max="10" value="${settings.captchaFailureThreshold}"></label><label>Turnstile Site Key<input class="input" id="authTurnstileSiteKey" dir="ltr" value="${escapeHtml(settings.turnstileSiteKey)}"></label><label class="span-2">Turnstile Secret<input class="input" id="authTurnstileSecret" type="password" autocomplete="new-password" placeholder="${settings.turnstileConfigured?'تنظیم شده — برای عدم تغییر خالی بگذارید':'Secret Key'}"></label></div><div class="auth-policy-toggles"><label><input type="checkbox" id="authNewDeviceOtp" ${settings.newDeviceOtp?'checked':''}> <span>برای دستگاه یا IP جدید مشکوک OTP الزامی باشد</span></label><label><input type="checkbox" id="authNotifyLogin" ${settings.notifyNewLogin?'checked':''}> <span>اعلان امنیتی ورود جدید ارسال شود</span></label></div><div class="limit-summary">${icon('shield',15)} Secret در پایگاه داده رمزنگاری می‌شود، در frontend برگردانده نمی‌شود و در Audit فقط وضعیت تغییر ثبت می‌شود.</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveAuthSecurity">ذخیره سیاست امنیتی</button></div></div>`);$('#saveAuthSecurity').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api('/api/admin/auth-security/settings',{method:'PATCH',body:JSON.stringify({maxDevices:Number($('#authMaxDevices').value),trustedDeviceDays:Number($('#authTrustedDays').value),otpTtlSeconds:Number($('#authOtpTtl').value),otpMaxAttempts:Number($('#authOtpAttempts').value),captchaFailureThreshold:Number($('#authCaptchaThreshold').value),turnstileSiteKey:$('#authTurnstileSiteKey').value,turnstileSecret:$('#authTurnstileSecret').value,newDeviceOtp:$('#authNewDeviceOtp').checked,notifyNewLogin:$('#authNotifyLogin').checked})});closeModal();toast('سیاست احراز هویت کاربران ذخیره شد.')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}catch(error){toast(error.message,'error')}}

function openSmsProviderConfig(providerId){const provider=(state.cache.smsProviders||[]).find(item=>item.id===providerId);if(!provider)return toast('ارائه‌دهنده پیدا نشد.','error');const config=provider.config||{};openModal(`<header class="modal-head"><div><h3 id="modalTitle">تنظیم اتصال ${escapeHtml(provider.name)}</h3><span class="modal-subtitle">کلیدها رمزنگاری و هرگز در پاسخ API نمایش داده نمی‌شوند</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="security-block-note" id="smsProviderNote"></div><div class="form-grid billing-form"><label>نوع ارائه‌دهنده<select class="select" id="smsProviderType"><option value="kavenegar" ${provider.provider_type==='kavenegar'?'selected':''}>کاوه‌نگار</option><option value="melipayamak" ${provider.provider_type==='melipayamak'?'selected':''}>ملی‌پیامک</option><option value="generic_webhook" ${provider.provider_type==='generic_webhook'?'selected':''}>Webhook سفارشی</option></select></label><label>نام نمایشی<input class="input" id="smsProviderName" value="${escapeHtml(provider.name)}"></label><label>کلید داخلی<input class="input" id="smsProviderKey" dir="ltr" value="${escapeHtml(provider.provider_key)}"></label><label id="fldSender"><span class="fld-title">فرستنده / Sender</span><input class="input" id="smsProviderSender" dir="ltr" value="${escapeHtml(config.sender||'')}"></label><label id="fldTemplate"><span class="fld-title">Template کاوه‌نگار</span><input class="input" id="smsProviderTemplate" dir="ltr" value="${escapeHtml(config.template||'')}"></label><label id="fldUrl"><span class="fld-title">Webhook / API URL</span><input class="input" id="smsProviderUrl" dir="ltr" value="${escapeHtml(config.url||'')}"></label><label id="fldApiKey"><span class="fld-title">API Key</span><input class="input" id="smsProviderApiKey" type="password" autocomplete="new-password" placeholder="${provider.configured?'برای عدم تغییر خالی بگذارید':'API Key'}"></label><label id="fldUsername"><span class="fld-title">نام کاربری API</span><input class="input" id="smsProviderUsername" dir="ltr" autocomplete="off"></label><label id="fldPassword"><span class="fld-title">رمز API</span><input class="input" id="smsProviderPassword" type="password" autocomplete="new-password"></label><label id="fldBearer"><span class="fld-title">Bearer Token برای Webhook</span><input class="input" id="smsProviderBearer" type="password" autocomplete="new-password"></label><label>هزینه هر پیامک<input class="input" id="smsProviderCost" type="number" min="0" value="${Number(provider.unit_cost||0)}"></label><label>اولویت<input class="input" id="smsProviderPriority" type="number" min="1" max="100" value="${Number(provider.priority||10)}"></label></div><label class="consent-check"><input id="smsProviderEnabled" type="checkbox" ${provider.is_enabled?'checked':''}><span></span> ارائه‌دهنده فعال باشد</label><div class="provider-test-box"><input class="input" id="smsProviderTestMobile" dir="ltr" placeholder="شماره تست 0912..."><button class="ghost-btn" id="testSmsProvider">ارسال تست واقعی</button></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveSmsProvider">ذخیره اتصال رمزنگاری‌شده</button></div></div>`);
  /* هر ارائه‌دهنده فیلدهای خودش را می‌خواهد. بدون این، مدیر نمی‌داند
     «Template» برای کاوه‌نگار نام الگوست ولی برای ملی‌پیامک کد عددی متن. */
  const PROVIDER_FIELDS={
    kavenegar:{note:'کاوه‌نگار: فقط <b>API Key</b> و نام الگوی Lookup لازم است. الگو باید در پنل کاوه‌نگار تأیید شده باشد.',
      show:['fldSender','fldTemplate','fldApiKey'],
      labels:{fldTemplate:'نام الگوی Lookup (مثلاً verify)',fldApiKey:'API Key کاوه‌نگار',fldSender:'شماره فرستنده (اختیاری)'},
      hints:{fldTemplate:'verify'}},
    melipayamak:{note:'ملی‌پیامک: <b>نام کاربری و رمز پنل</b> را وارد کنید و حتماً <b>کد متن الگو (bodyId)</b> را از بخش «وب‌سرویس خدماتی» پنل بگذارید؛ بدون آن کد ورود به شماره‌های داخل لیست سیاه مخابرات نمی‌رسد.',
      show:['fldTemplate','fldUsername','fldPassword','fldSender'],
      labels:{fldTemplate:'کد متن الگو / bodyId (عدد)',fldUsername:'نام کاربری پنل ملی‌پیامک',fldPassword:'رمز پنل (یا API Key اگر پنل الزام کرده)',fldSender:'خط اختصاصی (اختیاری — فقط برای پیام‌های غیرکد)'},
      hints:{fldTemplate:'مثلاً 12345'}},
    generic_webhook:{note:'Webhook سفارشی: آدرس سرویس خودتان و توکن Bearer.',
      show:['fldUrl','fldBearer','fldSender'],
      labels:{fldUrl:'آدرس Webhook',fldBearer:'Bearer Token'},hints:{}},
  };
  function applyProviderFields(){
    const type=$('#smsProviderType').value,spec=PROVIDER_FIELDS[type]||PROVIDER_FIELDS.generic_webhook,
          all=['fldSender','fldTemplate','fldUrl','fldApiKey','fldUsername','fldPassword','fldBearer'],
          defaults={fldSender:'فرستنده / Sender',fldTemplate:'Template',fldUrl:'Webhook / API URL',fldApiKey:'API Key',fldUsername:'نام کاربری API',fldPassword:'رمز API',fldBearer:'Bearer Token برای Webhook'};
    $('#smsProviderNote').innerHTML=spec.note;
    for(const id of all){
      const field=$('#'+id); if(!field)continue;
      field.hidden=!spec.show.includes(id);
      const title=$('.fld-title',field); if(title)title.textContent=spec.labels?.[id]||defaults[id];
      const input=$('input',field); if(input&&spec.hints?.[id])input.placeholder=spec.hints[id];
    }
  }
  applyProviderFields();
  $('#smsProviderType').addEventListener('change',applyProviderFields);
  function body(){return {providerType:$('#smsProviderType').value,name:$('#smsProviderName').value,providerKey:$('#smsProviderKey').value,config:{sender:$('#smsProviderSender').value,template:$('#smsProviderTemplate').value,url:$('#smsProviderUrl').value},credentials:{apiKey:$('#smsProviderApiKey').value,username:$('#smsProviderUsername').value,password:$('#smsProviderPassword').value,bearerToken:$('#smsProviderBearer').value},unitCost:Number($('#smsProviderCost').value),priority:Number($('#smsProviderPriority').value),isEnabled:$('#smsProviderEnabled').checked}}
  $('#saveSmsProvider').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(`/api/admin/sms/providers/${provider.id}`,{method:'PATCH',body:JSON.stringify(body())});closeModal();toast('اتصال ارائه‌دهنده ذخیره شد.');renderView('usage')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
  $('#testSmsProvider').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(`/api/admin/sms/providers/${provider.id}`,{method:'PATCH',body:JSON.stringify(body())});await api(`/api/admin/sms/providers/${provider.id}/test`,{method:'POST',body:JSON.stringify({mobile:$('#smsProviderTestMobile').value})});toast('پیامک تست با موفقیت ارسال شد.')}catch(error){toast(error.message,'error')}finally{setBusy(event.currentTarget,false)}})
}


/* ===================== درگاه پیامک: وضعیت، افزودن، تست ===================== */
function smsGatewayBanner(gateway, canManage) {
  if (!gateway) return '';
  const critical = (gateway.problems || []).filter(p => p.level === 'critical');
  const warnings = (gateway.problems || []).filter(p => p.level === 'warning');
  const infos    = (gateway.problems || []).filter(p => p.level === 'info');
  const tone = critical.length ? 'failed' : warnings.length ? 'pending' : 'active';
  const headline = critical.length
    ? 'ارسال پیامک کار نمی‌کند — کاربران نمی‌توانند ثبت‌نام یا وارد شوند'
    : gateway.simulator
      ? 'حالت آزمایشی روشن است — پیامک واقعی ارسال نمی‌شود'
      : `ارسال پیامک فعال است — درگاه ${escapeHtml(gateway.activeProvider || '—')}`;

  const problemList = [...critical, ...warnings, ...infos].map(p =>
    `<li class="sms-problem ${p.level}">${escapeHtml(p.text)}</li>`).join('');

  const last = gateway.last24h || {};
  const lastFail = gateway.lastFailure
    ? `آخرین خطا: ${escapeHtml(gateway.lastFailure.provider || '—')} · ${escapeHtml(gateway.lastFailure.error_code || '—')} · ${dateFa(gateway.lastFailure.created_at, true)}`
    : 'خطای تحویل ثبت نشده است.';

  return `<section class="card sms-gateway-banner ${tone}" style="margin-bottom:13px">
    <div class="card-head">
      <div class="card-title">
        <b>${critical.length ? '🔴' : gateway.simulator ? '🟡' : '🟢'} ${headline}</b>
        <span>${n(last.sent || 0)} ارسال موفق و ${n(last.failed || 0)} ناموفق در ۲۴ ساعت گذشته · ${lastFail}</span>
      </div>
      <span class="status ${tone}">${gateway.counts.usable} درگاه آماده از ${gateway.counts.total}</span>
    </div>
    ${problemList ? `<ul class="sms-problems">${problemList}</ul>` : ''}
    ${canManage ? `<div class="sms-gateway-actions">
      <button class="primary-btn" data-add-sms-provider>${icon('plus', 14)} افزودن درگاه پیامک</button>
      <button class="ghost-btn" data-sms-test-open>${icon('sms', 14)} تست ارسال واقعی</button>
      ${gateway.production ? '' : `<button class="ghost-btn" data-sms-simulator="${gateway.simulator ? 'off' : 'on'}">
        ${gateway.simulator ? 'خاموش کردن حالت آزمایشی' : 'روشن کردن حالت آزمایشی'}</button>`}
      <a class="ghost-btn" href="https://panel.kavenegar.com" target="_blank" rel="noopener">پنل کاوه‌نگار ↗</a>
    </div>` : ''}
    <div class="sms-gateway-help">
      ${icon('info', 14)} برای ارسال واقعی: در سایت کاوه‌نگار یا ملی‌پیامک حساب بسازید، اعتبار بخرید،
      یک <b>قالب (template) کد تایید</b> ثبت و تایید بگیرید، سپس API Key را در «تنظیم اتصال» وارد کنید.
      راهنمای کامل در فایل <code>SMS.md</code>.
    </div>
  </section>`;
}

function openSmsProviderCreate() {
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">افزودن درگاه پیامک</h3>
    <span class="modal-subtitle">کلیدها رمزنگاری می‌شوند و هرگز در پاسخ API برنمی‌گردند</span></div>
    <button class="modal-close" data-close-modal data-icon="close"></button></header>
    <div class="modal-body">
      <div class="form-grid billing-form">
        <label>نوع درگاه<select class="select" id="newSmsType">
          <option value="kavenegar">کاوه‌نگار</option>
          <option value="melipayamak">ملی‌پیامک</option>
          <option value="generic_webhook">Webhook سفارشی</option>
        </select></label>
        <label>نام نمایشی<input class="input" id="newSmsName" value="کاوه‌نگار"></label>
        <label>کلید داخلی (انگلیسی)<input class="input" id="newSmsKey" dir="ltr" value="kavenegar-main"></label>
        <label>اولویت (کوچک‌تر = زودتر)<input class="input" id="newSmsPriority" type="number" min="1" max="99" value="1"></label>
        <label>API Key<input class="input" id="newSmsApiKey" type="password" autocomplete="new-password" placeholder="کاوه‌نگار: API Key"></label>
        <label>نام کاربری<input class="input" id="newSmsUsername" dir="ltr" autocomplete="off" placeholder="ملی‌پیامک"></label>
        <label>رمز عبور<input class="input" id="newSmsPassword" type="password" autocomplete="new-password" placeholder="ملی‌پیامک"></label>
        <label>شماره فرستنده<input class="input" id="newSmsSender" dir="ltr" placeholder="10008663"></label>
        <label>نام قالب OTP (template)<input class="input" id="newSmsTemplate" dir="ltr" placeholder="verify"></label>
        <label>URL (فقط Webhook)<input class="input" id="newSmsUrl" dir="ltr" placeholder="https://..."></label>
        <label>Bearer Token (فقط Webhook)<input class="input" id="newSmsBearer" type="password" autocomplete="new-password" placeholder="توکن احراز هویت Webhook"></label>
        <label>هزینه هر پیامک (تومان)<input class="input" id="newSmsCost" type="number" min="0" value="0"></label>
      </div>
      <div class="limit-summary">${icon('shield', 15)} برای کاوه‌نگار حتماً یک <b>template</b> تاییدشده وارد کنید؛
        ارسال کد تایید با خط عادی در ایران معمولاً فیلتر می‌شود.</div>
    </div>
    <footer class="modal-foot"><button class="ghost-btn" data-close-modal>انصراف</button>
      <button class="primary-btn" id="createSmsProvider">ذخیره درگاه</button></footer>`);

  const $ = sel => document.querySelector(sel);
  $('#newSmsType').addEventListener('change', event => {
    const preset = { kavenegar: ['کاوه‌نگار', 'kavenegar-main'], melipayamak: ['ملی‌پیامک', 'melipayamak-main'], generic_webhook: ['Webhook سفارشی', 'webhook-main'] }[event.target.value];
    $('#newSmsName').value = preset[0]; $('#newSmsKey').value = preset[1];
  });
  $('#createSmsProvider').addEventListener('click', async event => {
    setBusy(event.currentTarget, true);
    try {
      await api('/api/admin/sms/providers', { method: 'POST', body: JSON.stringify({
        providerType: $('#newSmsType').value,
        name: $('#newSmsName').value.trim(),
        providerKey: $('#newSmsKey').value.trim(),
        priority: Number($('#newSmsPriority').value) || 10,
        unitCost: Number($('#newSmsCost').value) || 0,
        isEnabled: true,
        config: { sender: $('#newSmsSender').value.trim(), template: $('#newSmsTemplate').value.trim(), url: $('#newSmsUrl').value.trim() },
        credentials: { apiKey: $('#newSmsApiKey').value, username: $('#newSmsUsername').value, password: $('#newSmsPassword').value, bearerToken: $('#newSmsBearer').value },
      })});
      closeModal(); toast('درگاه پیامک اضافه شد. حالا با «تست ارسال واقعی» امتحانش کنید.'); renderView('usage');
    } catch (error) { toast(error.message, 'error'); setBusy(event.currentTarget, false); }
  });
}

function openSmsGatewayTest() {
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">تست ارسال واقعی پیامک</h3>
    <span class="modal-subtitle">دقیقاً همان مسیری که کاربر موقع ثبت‌نام طی می‌کند</span></div>
    <button class="modal-close" data-close-modal data-icon="close"></button></header>
    <div class="modal-body">
      <label>شماره موبایل مقصد<input class="input" id="smsTestMobile" dir="ltr" inputmode="numeric" placeholder="09123456789"></label>
      <div class="limit-summary" style="margin-top:10px">${icon('info', 15)} یک کد شش‌رقمی با همان قالب واقعی ارسال می‌شود.
        نتیجه در «پیامک‌های ناموفق» و Audit Log هم ثبت می‌شود.</div>
      <div id="smsTestResult" style="margin-top:12px"></div>
    </div>
    <footer class="modal-foot"><button class="ghost-btn" data-close-modal>بستن</button>
      <button class="primary-btn" id="runSmsTest">ارسال پیامک تست</button></footer>`);

  document.querySelector('#runSmsTest').addEventListener('click', async event => {
    const box = document.querySelector('#smsTestResult');
    setBusy(event.currentTarget, true);
    box.innerHTML = '<div class="secure-empty">در حال ارسال…</div>';
    try {
      const result = await api('/api/admin/sms/test-otp', { method: 'POST',
        body: JSON.stringify({ mobile: document.querySelector('#smsTestMobile').value }) });
      const rows = (result.attempts || []).map(a => `<li class="sms-problem ${a.ok ? 'info' : 'warning'}">
        ${escapeHtml(a.provider)} — ${a.ok ? 'موفق' : 'ناموفق: ' + escapeHtml(a.error || '')} (${a.ms}ms)</li>`).join('');
      box.innerHTML = `<div class="sms-test-ok"><b>✅ ${escapeHtml(result.message || 'ارسال شد')}</b>
        ${result.code ? `<div style="margin-top:6px">کد تولیدشده: <code dir="ltr">${escapeHtml(result.code)}</code></div>` : ''}
        <ul class="sms-problems">${rows}</ul></div>`;
      toast('پیامک تست ارسال شد.');
    } catch (error) {
      const detail = (error.body && error.body.attempts || []).map(a =>
        `<li class="sms-problem warning">${escapeHtml(a.provider)} — ${escapeHtml(a.error || 'ناموفق')}</li>`).join('');
      box.innerHTML = `<div class="sms-test-fail"><b>❌ ${escapeHtml(error.message)}</b>
        <ul class="sms-problems">${detail}</ul>
        ${error.body && error.body.hint ? `<small>${escapeHtml(error.body.hint)}</small>` : ''}</div>`;
      toast(error.message, 'error');
    } finally { setBusy(event.currentTarget, false); }
  });
}



async function clearSmsCredentials(providerId) {
  if (!confirm('اطلاعات اتصال (API Key/رمز) این درگاه پاک شود؟\nدرگاه هم غیرفعال می‌شود تا کلید جدید وارد کنید.')) return;
  try {
    await api(`/api/admin/sms/providers/${providerId}/clear-credentials`, { method: 'POST', body: '{}' });
    toast('اطلاعات اتصال پاک شد. حالا کلید درست را وارد کنید.'); renderView('usage');
  } catch (error) { toast(error.message, 'error'); }
}

async function diagnoseSmsProvider(providerId) {
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">عیب‌یابی درگاه پیامک</h3>
    <span class="modal-subtitle">هر حلقه زنجیره جدا بررسی می‌شود تا معلوم شود دقیقاً کجا خراب است</span></div>
    <button class="modal-close" data-close-modal data-icon="close"></button></header>
    <div class="modal-body"><div id="diagBody"><div class="secure-empty">در حال بررسی… (تا ۳۰ ثانیه)</div></div></div>
    <footer class="modal-foot"><button class="ghost-btn" data-close-modal>بستن</button></footer>`);
  try {
    const result = await api(`/api/admin/sms/providers/${providerId}/diagnose`, { method: 'POST', body: '{}' });
    const rows = (result.steps || []).map((step, index) => `<div class="diag-step ${step.ok ? 'ok' : 'bad'}">
      <span class="diag-num">${step.ok ? '✓' : '✗'}</span>
      <div><b>${index + 1}. ${escapeHtml(step.label)}</b><small>${escapeHtml(step.detail || '')}</small></div>
      ${step.ms != null ? `<em>${step.ms}ms</em>` : ''}</div>`).join('');
    const firstBad = (result.steps || []).find(step => !step.ok);
    document.querySelector('#diagBody').innerHTML = `
      <div class="${result.ok ? 'sms-test-ok' : 'sms-test-fail'}" style="margin-bottom:11px">
        <b>${result.ok ? '✅ همه مراحل سالم است' : '❌ مشکل در مرحله: ' + escapeHtml(firstBad ? firstBad.label : '—')}</b>
      </div>${rows}`;
  } catch (error) {
    document.querySelector('#diagBody').innerHTML = `<div class="sms-test-fail"><b>${escapeHtml(error.message)}</b></div>`;
  }
}

async function toggleSmsProvider(providerId, action) {
  try {
    await api(`/api/admin/sms/providers/${providerId}/${action}`, { method: 'POST', body: '{}' });
    toast(action === 'enable' ? 'درگاه فعال شد.' : 'درگاه غیرفعال شد.'); renderView('usage');
  } catch (error) {
    if (error.body && error.body.needsForce) {
      if (!confirm(`${error.message}\n\nمطمئنی؟`)) return;
      try {
        await api(`/api/admin/sms/providers/${providerId}/${action}`, { method: 'POST', body: JSON.stringify({ force: true }) });
        toast('انجام شد.'); renderView('usage'); return;
      } catch (inner) { toast(inner.message, 'error'); return; }
    }
    toast(error.message, 'error');
  }
}

async function deleteSmsProvider(providerId) {
  if (!confirm('این درگاه پیامک حذف شود؟ اطلاعات اتصال آن هم پاک می‌شود.')) return;
  try {
    await api(`/api/admin/sms/providers/${providerId}`, { method: 'DELETE' });
    toast('درگاه حذف شد.'); renderView('usage');
  } catch (error) {
    if (error.body && error.body.needsForce) {
      if (!confirm(`${error.message}\n\nبا این حال حذف شود؟`)) return;
      try {
        await api(`/api/admin/sms/providers/${providerId}`, { method: 'DELETE', body: JSON.stringify({ force: true }) });
        toast('درگاه حذف شد.'); renderView('usage'); return;
      } catch (inner) { toast(inner.message, 'error'); return; }
    }
    toast(error.message, 'error');
  }
}

async function toggleSmsSimulator(mode) {
  try {
    await api('/api/admin/sms/simulator', { method: 'POST', body: JSON.stringify({ enabled: mode === 'on' }) });
    toast(mode === 'on' ? 'حالت آزمایشی روشن شد؛ کد در پاسخ API برمی‌گردد.' : 'حالت آزمایشی خاموش شد.');
    renderView('usage');
  } catch (error) { toast(error.message, 'error'); }
}

async function switchSmsProvider(providerId) {
  if(!confirm('این ارائه‌دهنده به‌عنوان مسیر اصلی ارسال پیامک انتخاب شود؟'))return;
  try{await api(`/api/admin/sms/providers/${providerId}`,{method:'PATCH',body:JSON.stringify({makePrimary:true})});toast('ارائه‌دهنده اصلی پیامک تغییر کرد.');renderView('usage');}catch(error){toast(error.message,'error')}
}
async function failoverSmsProvider() {
  if(!confirm('ارسال پیامک به بهترین ارائه‌دهنده جایگزین منتقل شود؟'))return;
  try{const result=await api('/api/admin/sms/providers/failover',{method:'POST',body:'{}'});toast(`مسیر ارسال به ${result.provider.name} منتقل شد.`);renderView('usage');}catch(error){toast(error.message,'error')}
}
async function saveFileSettings(button) {
  const allowedMimeTypes=$$('input[name="allowedMime"]:checked').map(input=>input.value);
  setBusy(button,true);
  try{await api('/api/admin/files/settings',{method:'PATCH',body:JSON.stringify({allowedMimeTypes,maxFileSizeBytes:Math.round(Number($('#maxFileSize').value)*1048576),orphanRetentionDays:Number($('#orphanRetention').value),autoCleanup:$('#fileAutoCleanup').classList.contains('on')})});toast('محدودیت فرمت، حجم و پاک‌سازی ذخیره شد.');renderView('usage');}catch(error){toast(error.message,'error');setBusy(button,false)}
}
async function savePlanStorage(planId,button) {
  const input=$(`[data-plan-storage-input="${planId}"]`),value=Math.round(Number(input.value)*1048576);
  setBusy(button,true);
  try{await api(`/api/admin/plans/${planId}`,{method:'PATCH',body:JSON.stringify({maxStorageBytes:value})});toast('سقف فضای پلن ذخیره شد.');renderView('usage');}catch(error){toast(error.message,'error');setBusy(button,false)}
}
async function cleanupOrphanFiles() {
  const overview=state.cache.fileOverview,days=overview?.settings?.orphan_retention_days||14;
  if(!confirm(`تمام فایل‌های بدون معامله قدیمی‌تر از ${n(days)} روز حذف شوند؟ این عملیات قابل بازگشت نیست.`))return;
  try{const result=await api('/api/admin/files/cleanup',{method:'POST',body:JSON.stringify({olderThanDays:days})});toast(`${n(result.deletedCount)} فایل رهاشده با حجم ${bytes(result.deletedBytes)} حذف شد.`);renderView('usage');}catch(error){toast(error.message,'error')}
}
async function reviewFile(fileId,action) {
  const labels={mark_safe:'ایمن‌سازی',quarantine:'قرنطینه',delete:'حذف'};
  if(action==='delete'&&!confirm('این فایل برای همیشه حذف شود؟'))return;
  try{await api(`/api/admin/files/${fileId}/review`,{method:'PATCH',body:JSON.stringify({action})});closeModal();toast(`عملیات ${labels[action]} فایل ثبت شد.`);renderView('usage');}catch(error){toast(error.message,'error')}
}
function openFileReview(fileId) {
  const overview=state.cache.fileOverview||{},all=[...(overview.suspiciousFiles||[]),...(overview.orphanedFiles||[]),...(overview.recentFiles||[])],file=all.find(item=>item.id===fileId);
  if(!file)return toast('اطلاعات فایل پیدا نشد.','error');
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">بررسی امنیتی فایل</h3><span class="modal-subtitle">تصمیم‌گیری درباره نگهداری یا قرنطینه</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="file-review-hero"><span>${icon('file',22)}</span><div><b>${escapeHtml(file.original_name)}</b><small>${escapeHtml(file.mime_type)} · ${bytes(file.size_bytes)}</small></div><span class="status ${file.status==='quarantined'?'failed':'pending'}">${file.status==='quarantined'?'قرنطینه':'مشکوک'}</span></div><div class="detail-grid"><div class="detail-box"><small>مالک فایل</small><b>${escapeHtml(file.user_name||'کاربر حذف‌شده')}</b></div><div class="detail-box"><small>اتصال به معامله</small><b>${escapeHtml(file.trade_ref||'بدون معامله')}</b></div><div class="detail-box"><small>تاریخ بارگذاری</small><b>${dateFa(file.uploaded_at,true)}</b></div><div class="detail-box"><small>کلید ذخیره‌سازی</small><b dir="ltr">${escapeHtml(file.storage_key)}</b></div></div><div class="scan-alert">${icon('alert',16)}<div><b>دلیل شناسایی</b><span>${escapeHtml(file.scan_reason||'فایل برای بررسی دستی علامت‌گذاری شده است.')}</span></div></div><div class="checksum-box"><small>SHA-256</small><code>${escapeHtml(file.checksum_sha256||'—')}</code></div><div class="file-review-actions"><button class="ghost-btn" id="markFileSafe">${icon('check',14)} تأیید به‌عنوان ایمن</button><button class="ghost-btn quarantine-btn" id="quarantineFile">${icon('shield',14)} قرنطینه</button><button class="danger-btn" id="deleteReviewedFile">${icon('close',14)} حذف فایل</button></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>بستن</button></div></div>`);
  $('#markFileSafe').addEventListener('click',()=>reviewFile(file.id,'mark_safe'));$('#quarantineFile').addEventListener('click',()=>reviewFile(file.id,'quarantine'));$('#deleteReviewedFile').addEventListener('click',()=>reviewFile(file.id,'delete'));
}

async function saveSystemSettings(button) {
  setBusy(button,true);
  try{await api('/api/admin/system/settings',{method:'PATCH',body:JSON.stringify({signupEnabled:$('#signupEnabled').classList.contains('on'),maintenanceMode:$('#maintenanceMode').classList.contains('on'),maintenanceMessage:$('#maintenanceMessage').value,appVersion:$('#appVersion').value,otpMobileLimit:Number($('#settingsOtpMobile').value),otpIpLimit:Number($('#settingsOtpIp').value),otpWindowMinutes:Number($('#settingsOtpWindow').value),maxImageSizeBytes:Math.round(Number($('#settingsImageSize').value)*1048576),termsText:$('#termsText')?.value,privacyText:$('#privacyText')?.value,guideText:$('#guideText')?.value})});toast('تنظیمات سیستم با موفقیت ذخیره شد.');renderView('settings')}catch(error){toast(error.message,'error');setBusy(button,false)}
}
async function saveSystemContent(button) {
  setBusy(button,true);
  try{await api('/api/admin/system/content',{method:'PATCH',body:JSON.stringify({termsText:$('#termsText').value,privacyText:$('#privacyText').value,guideText:$('#guideText').value})});toast('قوانین، حریم خصوصی و راهنما ذخیره شد.');renderView('settings')}catch(error){toast(error.message,'error');setBusy(button,false)}
}
function openAnnouncementEditor(announcementId=null) {
  const item=(state.cache.announcements||[]).find(row=>row.id===announcementId),today=new Date().toISOString().slice(0,10),later=new Date(Date.now()+30*86400000).toISOString().slice(0,10);
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">${item?'ویرایش اعلان عمومی':'ساخت اعلان عمومی'}</h3><span class="modal-subtitle">نمایش پیام برای همه کاربران یا یک پلن خاص</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="form-grid billing-form"><label class="full-field">عنوان اعلان<input class="input" id="announcementTitle" maxlength="120" value="${escapeHtml(item?.title||'')}" placeholder="عنوان کوتاه و واضح"></label><label class="full-field">متن اعلان<textarea class="input announcement-body" id="announcementBody" maxlength="2000" placeholder="متن پیام برای کاربران">${escapeHtml(item?.body||'')}</textarea></label><label>نوع<select class="select" id="announcementTone"><option value="info" ${item?.tone==='info'?'selected':''}>اطلاعاتی</option><option value="success" ${item?.tone==='success'?'selected':''}>موفقیت</option><option value="warning" ${item?.tone==='warning'?'selected':''}>هشدار</option><option value="critical" ${item?.tone==='critical'?'selected':''}>بحرانی</option></select></label><label>مخاطب<select class="select" id="announcementAudience"><option value="all" ${!item||item.audience==='all'?'selected':''}>همه کاربران</option><option value="free" ${item?.audience==='free'?'selected':''}>پلن رایگان</option><option value="pro" ${item?.audience==='pro'?'selected':''}>پلن حرفه‌ای</option><option value="organization" ${item?.audience==='organization'?'selected':''}>پلن سازمانی</option></select></label><label>وضعیت<select class="select" id="announcementStatus"><option value="draft" ${!item||item.status==='draft'?'selected':''}>پیش‌نویس</option><option value="published" ${item?.status==='published'?'selected':''}>انتشار فوری</option><option value="archived" ${item?.status==='archived'?'selected':''}>بایگانی</option></select></label><label>شروع نمایش<input class="input" id="announcementStart" type="date" value="${item?.starts_at?item.starts_at.slice(0,10):today}"></label><label>پایان نمایش<input class="input" id="announcementExpiry" type="date" value="${item?.expires_at?item.expires_at.slice(0,10):later}"></label></div><div class="announcement-preview"><span class="announcement-dot ${item?.tone||'info'}"></span><div><b>پیش‌نمایش اعلان</b><small>اعلان منتشرشده از API عمومی تنظیمات در اختیار برنامه قرار می‌گیرد.</small></div></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveAnnouncement">${item?'ذخیره تغییرات':'ساخت اعلان'}</button></div></div>`);
  $('#announcementTone').addEventListener('change',event=>{$('.announcement-preview .announcement-dot').className=`announcement-dot ${event.target.value}`});
  $('#saveAnnouncement').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const payload={title:$('#announcementTitle').value,body:$('#announcementBody').value,tone:$('#announcementTone').value,audience:$('#announcementAudience').value,status:$('#announcementStatus').value,startsAt:$('#announcementStart').value,expiresAt:$('#announcementExpiry').value||null};await api(item?`/api/admin/announcements/${item.id}`:'/api/admin/announcements',{method:item?'PATCH':'POST',body:JSON.stringify(payload)});closeModal();toast(item?'اعلان ویرایش شد.':'اعلان عمومی ساخته شد.');renderView('settings')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
async function archiveAnnouncement(announcementId) {
  if(!confirm('این اعلان بایگانی و از نمایش عمومی خارج شود؟'))return;
  try{await api(`/api/admin/announcements/${announcementId}`,{method:'DELETE'});toast('اعلان بایگانی شد.');renderView('settings')}catch(error){toast(error.message,'error')}
}
function adminRoleOptions(selected='admin'){return Object.entries(roleLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${label}</option>`).join('')}
function openAdminCreator() {
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">ایجاد مدیر جدید</h3><span class="modal-subtitle">اختصاص نقش بر اساس اصل حداقل دسترسی</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="security-block-note">${icon('shield',17)} مدیر جدید فقط به بخش‌های مجاز نقش انتخاب‌شده دسترسی خواهد داشت.</div><div class="form-grid billing-form"><label>نام مدیر<input class="input" id="newAdminName" maxlength="100"></label><label>نام کاربری ورود<input class="input" id="newAdminUsername" dir="ltr" maxlength="32" placeholder="manager.name"></label><label>شماره موبایل<input class="input" id="newAdminMobile" dir="ltr" maxlength="11" placeholder="09120000000"></label><label>نقش<select class="select" id="newAdminRole">${adminRoleOptions()}</select></label><label>رمز عبور موقت<input class="input" id="newAdminPassword" type="password" minlength="10" maxlength="128" placeholder="حداقل ۱۰ کاراکتر"></label></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="createAdminAccount">ساخت حساب مدیر</button></div></div>`);
  $('#newAdminUsername').addEventListener('input',event=>event.target.value=event.target.value.toLowerCase().replace(/[^a-z0-9._-]/g,''));
  $('#newAdminMobile').addEventListener('input',event=>event.target.value=normalizeMobile(event.target.value).slice(0,11));
  $('#createAdminAccount').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api('/api/admin/admins',{method:'POST',body:JSON.stringify({name:$('#newAdminName').value,username:$('#newAdminUsername').value,mobile:$('#newAdminMobile').value,role:$('#newAdminRole').value,password:$('#newAdminPassword').value})});closeModal();toast('حساب مدیر با نقش انتخاب‌شده ساخته شد.');renderView('settings')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
function openAdminEditor(adminId) {
  const admin=(state.cache.admins||[]).find(item=>item.id===adminId);if(!admin)return toast('مدیر پیدا نشد.','error');
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">ویرایش دسترسی مدیر</h3><span class="modal-subtitle">تغییر نقش، وضعیت و بستن نشست‌ها</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="modal-user"><span class="user-avatar">${escapeHtml(initials(admin.name))}</span><div><b>${escapeHtml(admin.name)}</b><span dir="ltr">${escapeHtml(admin.mobile)}</span></div><span class="status ${admin.status==='active'?'active':'suspended'}" style="margin-right:auto">${admin.status==='active'?'فعال':'غیرفعال'}</span></div><div class="form-grid billing-form" style="margin-top:11px"><label>نام مدیر<input class="input" id="editAdminName" maxlength="100" value="${escapeHtml(admin.name)}"></label><label>نام کاربری ورود<input class="input" id="editAdminUsername" dir="ltr" maxlength="32" value="${escapeHtml(admin.username||'')}"></label><label>شماره موبایل ورود<input class="input" id="editAdminMobile" dir="ltr" maxlength="11" value="${escapeHtml(admin.mobile)}"></label><label>نقش<select class="select" id="editAdminRole">${adminRoleOptions(admin.role)}</select></label><label>وضعیت<select class="select" id="editAdminStatus"><option value="active" ${admin.status==='active'?'selected':''}>فعال</option><option value="disabled" ${admin.status==='disabled'?'selected':''}>غیرفعال</option></select></label><label>رمز عبور جدید<input class="input" id="editAdminPassword" type="password" minlength="10" maxlength="128" placeholder="برای عدم تغییر خالی بگذارید"></label></div><div class="limit-summary">${icon('info',15)} با تغییر نقش یا وضعیت، تمام نشست‌های فعال این مدیر بسته می‌شوند.</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveAdminAccess">ذخیره دسترسی</button></div></div>`);
  $('#editAdminUsername').addEventListener('input',event=>event.target.value=event.target.value.toLowerCase().replace(/[^a-z0-9._-]/g,''));
  $('#editAdminMobile').addEventListener('input',event=>event.target.value=normalizeMobile(event.target.value).slice(0,11));
  $('#saveAdminAccess').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api(`/api/admin/admins/${admin.id}`,{method:'PATCH',body:JSON.stringify({name:$('#editAdminName').value,username:$('#editAdminUsername').value,mobile:$('#editAdminMobile').value,newPassword:$('#editAdminPassword').value,role:$('#editAdminRole').value,status:$('#editAdminStatus').value})});closeModal();toast('سطح دسترسی مدیر به‌روزرسانی شد.');renderView('settings')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}

function openRolePermissions(role) {
  const data=state.cache.rolePermissions||{},matrix=data.matrix?.[role];if(!matrix)return toast('اطلاعات مجوزهای نقش پیدا نشد.','error');
  const groups=Object.entries(permissionGroups).map(([group,permissions])=>`<section class="permission-group"><div><b>${permissionGroupLabels[group]}</b><small>${permissions.filter(permission=>matrix[permission]).length} از ${permissions.length} فعال</small></div><div>${permissions.map(permission=>`<label class="permission-check"><input type="checkbox" value="${permission}" ${matrix[permission]?'checked':''}><span>${escapeHtml(permissionLabels[permission]||permission)}</span></label>`).join('')}</div></section>`).join('');
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">مجوزهای نقش ${roleLabels[role]||role}</h3><span class="modal-subtitle">تغییر این ماتریس روی تمام مدیران دارای این نقش اعمال می‌شود</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="security-block-note">${icon('shield',17)} پس از ذخیره، نشست فعال همه مدیران این نقش بسته می‌شود تا مجوزهای جدید فوراً اعمال شوند.</div><div class="permission-groups">${groups}</div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveRolePermissions">ذخیره ماتریس دسترسی</button></div></div>`);
  $('#saveRolePermissions').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const permissions=$$('.permission-check input:checked',$('#modal')).map(input=>input.value);await api(`/api/admin/role-permissions/${role}`,{method:'PATCH',body:JSON.stringify({permissions})});closeModal();toast(`مجوزهای نقش ${roleLabels[role]} ذخیره و نشست‌های آن باطل شد.`);renderView('settings')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}

function b64urlToBytes(value){const base64=String(value).replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(value.length/4)*4,'='),binary=atob(base64);return Uint8Array.from(binary,char=>char.charCodeAt(0))}
function bytesToB64url(value){const bytes=new Uint8Array(value),binary=Array.from(bytes,byte=>String.fromCharCode(byte)).join('');return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
async function createPasskeyCredential(options){const publicKey={...options,challenge:b64urlToBytes(options.challenge),user:{...options.user,id:b64urlToBytes(options.user.id)},excludeCredentials:(options.excludeCredentials||[]).map(item=>({...item,id:b64urlToBytes(item.id)}))},credential=await navigator.credentials.create({publicKey});return {id:credential.id,rawId:bytesToB64url(credential.rawId),type:credential.type,clientExtensionResults:credential.getClientExtensionResults(),authenticatorAttachment:credential.authenticatorAttachment,response:{clientDataJSON:bytesToB64url(credential.response.clientDataJSON),attestationObject:bytesToB64url(credential.response.attestationObject),transports:credential.response.getTransports?credential.response.getTransports():[]}}
}
async function getPasskeyCredential(options){const publicKey={...options,challenge:b64urlToBytes(options.challenge),allowCredentials:(options.allowCredentials||[]).map(item=>({...item,id:b64urlToBytes(item.id)}))},credential=await navigator.credentials.get({publicKey});return {id:credential.id,rawId:bytesToB64url(credential.rawId),type:credential.type,clientExtensionResults:credential.getClientExtensionResults(),authenticatorAttachment:credential.authenticatorAttachment,response:{clientDataJSON:bytesToB64url(credential.response.clientDataJSON),authenticatorData:bytesToB64url(credential.response.authenticatorData),signature:bytesToB64url(credential.response.signature),userHandle:credential.response.userHandle?bytesToB64url(credential.response.userHandle):null}}
}
function showRecoveryCodes(codes,required=false){if(!codes?.length)return;openModal(`<header class="modal-head"><h3 id="modalTitle">کدهای بازیابی MFA</h3>${required?'':'<button class="modal-close" data-close-modal data-icon="close"></button>'}</header><div class="modal-body"><div class="security-block-note">${icon('alert',17)} هر کد فقط یک‌بار قابل استفاده است. همین حالا آن‌ها را در محل امن ذخیره کن.</div><div class="recovery-code-grid">${codes.map(code=>`<code>${escapeHtml(code)}</code>`).join('')}</div><div class="modal-actions"><button class="primary-btn" id="copyRecoveryCodes">کپی کدها</button><button class="ghost-btn" id="finishRecoveryCodes">ذخیره کردم${required?'؛ ورود به پنل':''}</button></div></div>`);$('#copyRecoveryCodes').addEventListener('click',async()=>{await navigator.clipboard.writeText(codes.join('\n'));toast('کدهای بازیابی کپی شدند.')});$('#finishRecoveryCodes').addEventListener('click',()=>{closeModal();if(required)renderView(canView('dashboard')?'dashboard':Object.keys(viewScopes).find(canView)||'dashboard')})}
async function openAdminMfaCenter(required=false){try{const data=await api('/api/admin/mfa/status'),status=data.status,passkeys=data.passkeys||[];openModal(`<header class="modal-head"><div><h3 id="modalTitle">امنیت دومرحله‌ای مدیریت</h3><span class="modal-subtitle">TOTP و Passkey مقاوم در برابر فیشینگ</span></div>${required?'':'<button class="modal-close" data-close-modal data-icon="close"></button>'}</header><div class="modal-body">${required?`<div class="security-block-note">${icon('shield',17)} Owner باید پیش از دسترسی به پنل، حداقل یک روش MFA را فعال کند.</div>`:''}<div class="mfa-method-grid"><article><b>TOTP / Authenticator</b><span>${status.totp?'فعال':'غیرفعال'}</span><p>سازگار با Google Authenticator و Microsoft Authenticator</p><button class="${status.totp?'ghost-btn':'primary-btn'}" id="setupTotp">${status.totp?'تنظیم مجدد':'فعال‌سازی TOTP'}</button></article><article><b>Passkey / WebAuthn</b><span>${n(status.passkeys)} کلید فعال</span><p>ورود با اثر انگشت، Face ID یا کلید امنیتی</p><button class="primary-btn" id="addPasskey">افزودن Passkey</button></article></div>${passkeys.length?`<div class="passkey-list">${passkeys.map(item=>`<div><span>${icon('lock',15)}</span><div><b>${escapeHtml(item.name)}</b><small>${dateFa(item.created_at,true)}${item.last_used_at?' · آخرین استفاده '+relativeTime(item.last_used_at):''}</small></div><button class="table-action" data-remove-passkey="${item.id}">${icon('trash',13)}</button></div>`).join('')}</div>`:''}<div class="recovery-note">${icon('shield',14)} ${n(status.recoveryCodes)} کد بازیابی استفاده‌نشده باقی مانده است.</div>${status.enabled?`<div class="modal-actions"><button class="ghost-btn" id="regenerateRecovery">ساخت دوباره کدهای بازیابی</button>${required?'<button class="primary-btn" id="finishMfaSetup">ورود به پنل</button>':'<button class="ghost-btn" data-close-modal>بستن</button>'}</div>`:''}</div>`);
    $('#setupTotp').addEventListener('click',async()=>{const currentPassword=status.totp?prompt('برای تنظیم مجدد TOTP رمز فعلی را وارد کن:'):'';if(status.totp&&!currentPassword)return;try{const setup=await api('/api/admin/mfa/totp/setup',{method:'POST',body:JSON.stringify({currentPassword})});openModal(`<header class="modal-head"><h3 id="modalTitle">اتصال Authenticator</h3></header><div class="modal-body"><div class="totp-setup"><img src="${setup.qrDataUrl}" alt="QR TOTP"><code>${escapeHtml(setup.secret)}</code><p>QR را اسکن کن و کد ۶رقمی برنامه را وارد کن.</p><input class="input" id="totpVerifyCode" inputmode="numeric" maxlength="6" placeholder="123456"></div><div class="modal-actions"><button class="primary-btn" id="verifyTotpSetup">تأیید و فعال‌سازی</button></div></div>`);$('#verifyTotpSetup').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const result=await api('/api/admin/mfa/totp/verify',{method:'POST',body:JSON.stringify({code:$('#totpVerifyCode').value})});state.admin.mfa={...state.admin.mfa,totp:true,enabled:true};result.recoveryCodes?showRecoveryCodes(result.recoveryCodes,required):(toast('TOTP فعال شد.'),openAdminMfaCenter(required))}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}})}catch(error){toast(error.message,'error')}});
    $('#addPasskey').addEventListener('click',async()=>{if(!window.PublicKeyCredential)return toast('این مرورگر از Passkey پشتیبانی نمی‌کند.','error');try{const options=await api('/api/admin/mfa/passkeys/register/options',{method:'POST',body:JSON.stringify({name:'Passkey '+new Date().toLocaleDateString('fa-IR')})}),registrationToken=options.registrationToken;delete options.registrationToken;const response=await createPasskeyCredential(options),result=await api('/api/admin/mfa/passkeys/register/verify',{method:'POST',body:JSON.stringify({registrationToken,response})});state.admin.mfa={...state.admin.mfa,passkeys:(state.admin.mfa?.passkeys||0)+1,enabled:true};result.recoveryCodes?showRecoveryCodes(result.recoveryCodes,required):(toast('Passkey ثبت شد.'),openAdminMfaCenter(required))}catch(error){toast(error.message||'ثبت Passkey لغو شد.','error')}});
    $$('[data-remove-passkey]',$('#modal')).forEach(button=>button.addEventListener('click',()=>{const password=prompt('برای حذف Passkey رمز فعلی را وارد کن:');if(!password)return;api(`/api/admin/mfa/passkeys/${button.dataset.removePasskey}`,{method:'DELETE',body:JSON.stringify({currentPassword:password})}).then(()=>{toast('Passkey حذف شد.');openAdminMfaCenter(false)}).catch(error=>toast(error.message,'error'))}));
    $('#regenerateRecovery')?.addEventListener('click',()=>{const password=prompt('رمز فعلی را برای ساخت کدهای جدید وارد کن:');if(!password)return;api('/api/admin/mfa/recovery-codes/regenerate',{method:'POST',body:JSON.stringify({currentPassword:password})}).then(result=>showRecoveryCodes(result.recoveryCodes)).catch(error=>toast(error.message,'error'))});
    $('#finishMfaSetup')?.addEventListener('click',()=>{closeModal();renderView(canView('dashboard')?'dashboard':Object.keys(viewScopes).find(canView)||'dashboard')});
  }catch(error){toast(error.message,'error')}}
function openAdminMfaLogin(data){openModal(`<header class="modal-head"><div><h3 id="modalTitle">تأیید دومرحله‌ای</h3><span class="modal-subtitle">${escapeHtml(data.admin?.name||'مدیر')}</span></div></header><div class="modal-body"><div class="security-block-note">${icon('shield',17)} رمز صحیح بود؛ اکنون روش دوم را تأیید کن.</div>${data.methods.includes('totp')||data.methods.includes('recovery')?`<label>کد Authenticator یا کد بازیابی<input class="input" id="adminMfaCode" autocomplete="one-time-code" maxlength="20" dir="ltr"></label><button class="primary-btn" id="verifyAdminTotp" style="margin-top:10px">تأیید کد</button>`:''}${data.methods.includes('passkey')?`<button class="ghost-btn" id="verifyAdminPasskey" style="width:100%;margin-top:10px">ورود با Passkey</button>`:''}<div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button></div></div>`);
  $('#verifyAdminTotp')?.addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{const result=await api('/api/admin/mfa/login/totp',{method:'POST',body:JSON.stringify({challengeToken:data.challengeToken,code:$('#adminMfaCode').value})});state.csrf=result.csrfToken;closeModal();showApp(result.admin)}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
  $('#verifyAdminPasskey')?.addEventListener('click',async()=>{try{const options=await api('/api/admin/mfa/login/passkey/options',{method:'POST',body:JSON.stringify({challengeToken:data.challengeToken})}),response=await getPasskeyCredential(options),result=await api('/api/admin/mfa/login/passkey/verify',{method:'POST',body:JSON.stringify({challengeToken:data.challengeToken,response})});state.csrf=result.csrfToken;closeModal();showApp(result.admin)}catch(error){toast(error.message||'تأیید Passkey لغو شد.','error')}})
  const mfaCodeField=$('#adminMfaCode');
  if(mfaCodeField){
    /* ارقام فارسی/عربی را به انگلیسی تبدیل می‌کنیم تا کد Authenticator رد نشود */
    mfaCodeField.addEventListener('input',()=>{const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';mfaCodeField.value=mfaCodeField.value.replace(/[۰-۹]/g,d=>String(fa.indexOf(d))).replace(/[٠-٩]/g,d=>String(ar.indexOf(d))).replace(/\s+/g,'')});
    /* زدن Enter داخل کادر کد باید مثل کلیک روی «تأیید کد» عمل کند */
    mfaCodeField.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();$('#verifyAdminTotp')?.click()}});
    setTimeout(()=>mfaCodeField.focus(),70);
  }
}

function openProfileEditor() {
  const admin=state.admin;
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">تنظیمات حساب مدیریت</h3><span class="modal-subtitle">تغییر نام، شماره ورود و رمز عبور خودتان</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="security-block-note">${icon('lock',17)} برای هر تغییر باید رمز عبور فعلی را وارد کنید. نشست‌های دیگر حساب بسته خواهند شد.</div><div class="form-grid billing-form"><label>نام نمایشی<input class="input" id="profileName" maxlength="100" value="${escapeHtml(admin.name)}"></label><label>نام کاربری ورود<input class="input" id="profileUsername" dir="ltr" maxlength="32" value="${escapeHtml(admin.username||'')}"></label><label>شماره موبایل ورود<input class="input" id="profileMobile" dir="ltr" maxlength="11" value="${escapeHtml(admin.mobile)}"></label><label class="full-field">رمز عبور فعلی<input class="input" id="profileCurrentPassword" type="password" maxlength="128" autocomplete="current-password"></label><label>رمز عبور جدید<input class="input" id="profileNewPassword" type="password" minlength="10" maxlength="128" autocomplete="new-password" placeholder="برای عدم تغییر خالی بگذارید"></label><label>تکرار رمز جدید<input class="input" id="profileConfirmPassword" type="password" minlength="10" maxlength="128" autocomplete="new-password"></label></div><div class="modal-actions"><button class="ghost-btn" id="manageAdminMfa">مدیریت TOTP و Passkey</button><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="saveAdminProfile">ذخیره اطلاعات حساب</button></div></div>`);
  $('#profileUsername').addEventListener('input',event=>event.target.value=event.target.value.toLowerCase().replace(/[^a-z0-9._-]/g,''));
  $('#profileMobile').addEventListener('input',event=>event.target.value=normalizeMobile(event.target.value).slice(0,11));
  $('#manageAdminMfa').addEventListener('click',()=>openAdminMfaCenter(false));
  $('#saveAdminProfile').addEventListener('click',async event=>{const next=$('#profileNewPassword').value;if(next!==$('#profileConfirmPassword').value)return toast('تکرار رمز عبور جدید مطابقت ندارد.','error');setBusy(event.currentTarget,true);try{const result=await api('/api/admin/profile',{method:'PATCH',body:JSON.stringify({name:$('#profileName').value,username:$('#profileUsername').value,mobile:$('#profileMobile').value,currentPassword:$('#profileCurrentPassword').value,newPassword:next})});state.admin=result.admin;$('#adminName').textContent=result.admin.name;$('#dropdownName').textContent=result.admin.name;$('#dropdownMobile').textContent=`@${result.admin.username} · ${result.admin.mobile}`;$('#adminAvatar').textContent=initials(result.admin.name);closeModal();toast('اطلاعات حساب مدیریت به‌روزرسانی شد.')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}

function openSecurityBlockCreator() {
  const expires=new Date(Date.now()+7*86400000).toISOString().slice(0,10);
  openModal(`<header class="modal-head"><div><h3 id="modalTitle">محدودسازی امنیتی جدید</h3><span class="modal-subtitle">مسدودکردن موقت یا دائمی شماره موبایل و IP</span></div><button class="modal-close" data-close-modal data-icon="close"></button></header><div class="modal-body"><div class="security-block-note">${icon('shield',17)} این محدودیت پیش از بررسی رمز عبور اعمال می‌شود و تمام تلاش‌ها در Audit Log ثبت خواهند شد.</div><div class="form-grid billing-form"><label>نوع محدودیت<select class="select" id="securityBlockType"><option value="ip">آدرس IP</option><option value="mobile">شماره موبایل</option></select></label><label>مقدار<input class="input" id="securityBlockValue" dir="ltr" placeholder="203.0.113.20"></label><label class="full-field">دلیل محدودسازی<input class="input" id="securityBlockReason" maxlength="300" placeholder="مثلاً تلاش ورود پرتکرار"></label><label>پایان محدودیت<input class="input" id="securityBlockExpiry" type="date" value="${expires}"></label></div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button><button class="primary-btn" id="createSecurityBlock">ثبت محدودیت</button></div></div>`);
  $('#securityBlockType').addEventListener('change',event=>{$('#securityBlockValue').placeholder=event.target.value==='mobile'?'09120000000':'203.0.113.20'});
  $('#createSecurityBlock').addEventListener('click',async event=>{setBusy(event.currentTarget,true);try{await api('/api/admin/security/blocks',{method:'POST',body:JSON.stringify({blockType:$('#securityBlockType').value,value:$('#securityBlockValue').value,reason:$('#securityBlockReason').value,expiresAt:$('#securityBlockExpiry').value||null})});closeModal();toast('محدودیت امنیتی ثبت و فعال شد.');renderView('logs')}catch(error){toast(error.message,'error');setBusy(event.currentTarget,false)}});
}
async function updateSecurityAlert(alertId,status) {
  try{await api(`/api/admin/security/alerts/${alertId}`,{method:'PATCH',body:JSON.stringify({status})});toast(status==='resolved'?'هشدار به‌عنوان حل‌شده ثبت شد.':'هشدار در وضعیت پیگیری قرار گرفت.');renderView('logs')}catch(error){toast(error.message,'error')}
}
async function revokeSecurityBlock(blockId) {
  if(!confirm('این محدودیت امنیتی لغو شود؟'))return;
  try{await api(`/api/admin/security/blocks/${blockId}`,{method:'PATCH',body:JSON.stringify({status:'revoked'})});toast('محدودیت امنیتی لغو شد.');renderView('logs')}catch(error){toast(error.message,'error')}
}

function openSidebar(){ $('#sidebar').classList.add('open'); $('#sidebarScrim').classList.add('open');$('#menuBtn').setAttribute('aria-expanded','true');setTimeout(()=>$('.nav-item:not([hidden])',$('#sidebar'))?.focus(),30) }
function closeSidebar(){ $('#sidebar').classList.remove('open'); $('#sidebarScrim').classList.remove('open');$('#menuBtn').setAttribute('aria-expanded','false') }

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault(); const button=$('#loginSubmit'), error=$('#loginError'); error.textContent='';
  const identifier=$('#loginMobile').value.trim(),normalized=normalizeMobile(identifier),validIdentifier=/^09\d{9}$/.test(normalized)||/^[A-Za-z][A-Za-z0-9._-]{2,31}$/.test(identifier),password=$('#loginPassword').value;
  if(!validIdentifier){error.textContent='شماره موبایل یا نام کاربری معتبر وارد کن.';return}
  if(password.length<8){error.textContent='رمز عبور باید حداقل ۸ کاراکتر باشد.';return}
  setBusy(button,true);
  try{const data=await api('/api/admin/login',{method:'POST',body:JSON.stringify({identifier,password})});$('#loginPassword').value='';if(data.mfaRequired){openAdminMfaLogin(data);return}state.csrf=data.csrfToken;showApp(data.admin);if(data.mfaSetupRequired)setTimeout(()=>openAdminMfaCenter(true),80);}
  catch(err){error.textContent=err.message;}finally{setBusy(button,false)}
});
function normalizeMobile(value){const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';let v=String(value||'').replace(/[۰-۹]/g,d=>String(fa.indexOf(d))).replace(/[٠-٩]/g,d=>String(ar.indexOf(d))).replace(/[^+\d]/g,'');if(v.startsWith('0098'))v='0'+v.slice(4);else if(v.startsWith('+98'))v='0'+v.slice(3);else if(v.startsWith('98')&&v.length===12)v='0'+v.slice(2);return v.replace(/\D/g,'')}
$('#loginMobile').addEventListener('input',event=>{if(/[\u0600-\u06ff]/.test(event.target.value))event.target.value=normalizeMobile(event.target.value).slice(0,11)});
$('#togglePassword').addEventListener('click',()=>{const input=$('#loginPassword');input.type=input.type==='password'?'text':'password';});
$$('.nav-item').forEach(button=>button.addEventListener('click',async()=>{await renderView(button.dataset.view);$('#pageContent').focus({preventScroll:true})}));
$('#refreshBtn').addEventListener('click',async event=>{event.currentTarget.classList.add('spinning');await renderView();setTimeout(()=>event.currentTarget.classList.remove('spinning'),500);});
$('#menuBtn').addEventListener('click',openSidebar);$('#sidebarScrim').addEventListener('click',closeSidebar);$('#backToJournal').addEventListener('click',()=>location.href='/');
$('#adminProfile').addEventListener('click',()=>{const dropdown=$('#adminDropdown'),open=dropdown.hidden;dropdown.hidden=!open;$('#adminProfile').setAttribute('aria-expanded',String(open));if(open)setTimeout(()=>$('button',dropdown)?.focus(),0)});
$('#profileSettingsBtn').addEventListener('click',()=>{$('#adminDropdown').hidden=true;$('#adminProfile').setAttribute('aria-expanded','false');openProfileEditor()});
document.addEventListener('click',event=>{if(!event.target.closest('.admin-menu-wrap')){$('#adminDropdown').hidden=true;$('#adminProfile').setAttribute('aria-expanded','false')}});
$('#logoutBtn').addEventListener('click',async()=>{try{await api('/api/admin/logout',{method:'POST'});}catch{}showLogin();});
$('#modalLayer').addEventListener('click',event=>{if(event.target.closest('[data-close-modal]'))closeModal();});
document.addEventListener('keydown',event=>{trapModalFocus(event);if(event.key==='Escape'){if(!(state.admin?.mfaRequired&&!state.admin?.mfa?.enabled))closeModal();closeSidebar();$('#adminDropdown').hidden=true;$('#adminProfile').setAttribute('aria-expanded','false');}});

const filterSearch = debounce((type,value)=>{state[type].search=value;state[type].page=1;renderView(type==='payments'?'subscriptions':type);},380);
$('#pageContent').addEventListener('keydown',event=>{const tab=event.target.closest?.('[role="tab"]');if(!tab||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;const group=tab.closest('[role="tablist"]'),tabs=$$('[role="tab"]',group).filter(item=>!item.disabled&&!item.hidden),index=tabs.indexOf(tab);if(!tabs.length)return;event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowLeft'?1:-1)+tabs.length)%tabs.length;tabs[next].focus();tabs[next].click()});
$('#pageContent').addEventListener('input',event=>{const toolbar=event.target.closest('[data-toolbar]');if(toolbar&&event.target.dataset.filter==='search')filterSearch(toolbar.dataset.toolbar,event.target.value);});
$('#pageContent').addEventListener('change',event=>{
  const toolbar=event.target.closest('[data-toolbar]');
  if(toolbar&&event.target.dataset.filter){const type=toolbar.dataset.toolbar;state[type][event.target.dataset.filter]=event.target.value;state[type].page=1;renderView(type==='payments'?'subscriptions':type);return}
  if(event.target.dataset.errorFilter){state.errors[event.target.dataset.errorFilter]=event.target.value;renderView('logs');}
});
$('#pageContent').addEventListener('click',event=>{
  const page=event.target.closest('[data-page]');if(page){const type=page.dataset.pageType;state[type].page=Number(page.dataset.page);renderView(type==='payments'?'subscriptions':type);return}
  const user=event.target.closest('[data-user-id]');if(user){openUser(user.dataset.userId);return}
  const contact=event.target.closest('[data-contact-id]');if(contact){openContactEditor(contact.dataset.contactId);return}
  if(event.target.closest('[data-add-contact]')){openContactEditor();return}
  if(event.target.closest('[data-import-contacts]')){openContactImporter();return}
  if(event.target.closest('[data-sync-contacts]')){syncContacts();return}
  if(event.target.closest('[data-export-contacts]')){exportContacts();return}
  const supportRequest=event.target.closest('[data-support-id]');if(supportRequest){openSupportRequest(supportRequest.dataset.supportId);return}
  const sub=event.target.closest('[data-subscription-id]');if(sub){openSubscription(sub.dataset.subscriptionId);return}
  if(event.target.closest('[data-add-plan]')){openPlan();return}
  const plan=event.target.closest('[data-plan-id]');if(plan){openPlan(plan.dataset.planId);return}
  const billingTab=event.target.closest('[data-billing-tab]');if(billingTab){state.subscriptionTab=billingTab.dataset.billingTab;renderView('subscriptions');return}
  if(event.target.closest('[data-add-coupon]')){openCouponCreator();return}
  const coupon=event.target.closest('[data-coupon-toggle]');if(coupon){toggleCoupon(coupon.dataset.couponToggle,coupon.dataset.couponActive==='1');return}
  const payment=event.target.closest('[data-payment-id]');if(payment){openPayment(payment.dataset.paymentId);return}
  const usageTab=event.target.closest('[data-usage-tab]');if(usageTab){state.usageTab=usageTab.dataset.usageTab;renderView('usage');return}
  if(event.target.closest('#smsAutoFailover')){event.target.closest('#smsAutoFailover').classList.toggle('on');return}
  const saveSms=event.target.closest('[data-save-sms-settings]');if(saveSms){saveSmsSettings(saveSms);return}
  const smsProviderConfig=event.target.closest('[data-provider-config]');if(smsProviderConfig){openSmsProviderConfig(smsProviderConfig.dataset.providerConfig);return}
  const smsProvider=event.target.closest('[data-provider-primary]');if(smsProvider){switchSmsProvider(smsProvider.dataset.providerPrimary);return}
  if(event.target.closest('[data-sms-failover]')){failoverSmsProvider();return}
  if(event.target.closest('[data-add-sms-provider]')){openSmsProviderCreate();return}
  if(event.target.closest('[data-sms-test-open]')){openSmsGatewayTest();return}
  const smsSim=event.target.closest('[data-sms-simulator]');if(smsSim){toggleSmsSimulator(smsSim.dataset.smsSimulator);return}
  const smsEnable=event.target.closest('[data-provider-enable]');if(smsEnable){toggleSmsProvider(smsEnable.dataset.providerEnable,'enable');return}
  const smsDisable=event.target.closest('[data-provider-disable]');if(smsDisable){toggleSmsProvider(smsDisable.dataset.providerDisable,'disable');return}
  const smsClear=event.target.closest('[data-provider-clear]');if(smsClear){clearSmsCredentials(smsClear.dataset.providerClear);return}
  const smsDiag=event.target.closest('[data-provider-diagnose]');if(smsDiag){diagnoseSmsProvider(smsDiag.dataset.providerDiagnose);return}
  const smsDelete=event.target.closest('[data-provider-delete]');if(smsDelete){deleteSmsProvider(smsDelete.dataset.providerDelete);return}
  if(event.target.closest('#fileAutoCleanup')){event.target.closest('#fileAutoCleanup').classList.toggle('on');return}
  const saveFiles=event.target.closest('[data-save-file-settings]');if(saveFiles){saveFileSettings(saveFiles);return}
  const saveCap=event.target.closest('[data-save-plan-storage]');if(saveCap){savePlanStorage(saveCap.dataset.savePlanStorage,saveCap);return}
  if(event.target.closest('[data-cleanup-orphans]')){cleanupOrphanFiles();return}
  const fileReview=event.target.closest('[data-file-review]');if(fileReview){openFileReview(fileReview.dataset.fileReview);return}
  const fileDelete=event.target.closest('[data-file-delete]');if(fileDelete){reviewFile(fileDelete.dataset.fileDelete,'delete');return}
  if(event.target.closest('#signupEnabled')){event.target.closest('#signupEnabled').classList.toggle('on');return}
  if(event.target.closest('#maintenanceMode')){event.target.closest('#maintenanceMode').classList.toggle('on');return}
  const saveSystem=event.target.closest('[data-save-system-settings]');if(saveSystem){saveSystemSettings(saveSystem);return}
  const saveContent=event.target.closest('[data-save-system-content]');if(saveContent){saveSystemContent(saveContent);return}
  if(event.target.closest('[data-add-admin]')){openAdminCreator();return}
  const adminAccess=event.target.closest('[data-admin-id]');if(adminAccess){openAdminEditor(adminAccess.dataset.adminId);return}
  const roleAccess=event.target.closest('[data-role-permissions]');if(roleAccess){openRolePermissions(roleAccess.dataset.rolePermissions);return}
  const newLegal=event.target.closest('[data-new-legal]');if(newLegal){openLegalVersionEditor(newLegal.dataset.newLegal);return}
  const privacyProgress=event.target.closest('[data-privacy-progress]');if(privacyProgress){updatePrivacyRequest(privacyProgress.dataset.privacyProgress,'in_progress');return}
  const privacyReject=event.target.closest('[data-privacy-reject]');if(privacyReject){rejectPrivacyRequest(privacyReject.dataset.privacyReject);return}
  const privacyUser=event.target.closest('[data-privacy-user]');if(privacyUser){openUser(privacyUser.dataset.privacyUser);return}
  if(event.target.closest('[data-add-marketing-faq]')){openMarketingFaqEditor();return}
  const editMarketingFaq=event.target.closest('[data-edit-marketing-faq]');if(editMarketingFaq){openMarketingFaqEditor(editMarketingFaq.dataset.editMarketingFaq);return}
  const deleteFaq=event.target.closest('[data-delete-marketing-faq]');if(deleteFaq){deleteMarketingFaq(deleteFaq.dataset.deleteMarketingFaq);return}
  const faqUp=event.target.closest('[data-faq-up]');if(faqUp){moveMarketingFaq(faqUp.dataset.faqUp,-1);return}
  const faqDown=event.target.closest('[data-faq-down]');if(faqDown){moveMarketingFaq(faqDown.dataset.faqDown,1);return}
  if(event.target.closest('[data-add-cms-page]')){openCmsPageEditor();return}
  const cmsPage=event.target.closest('[data-cms-page]');if(cmsPage){state.cms.selectedPageId=cmsPage.dataset.cmsPage;renderView('cms');return}
  const editCmsPage=event.target.closest('[data-edit-cms-page]');if(editCmsPage){openCmsPageEditor(editCmsPage.dataset.editCmsPage);return}
  if(event.target.closest('[data-add-cms-section]')){openCmsSectionEditor();return}
  const editCmsSection=event.target.closest('[data-edit-cms-section]');if(editCmsSection){openCmsSectionEditor(editCmsSection.dataset.editCmsSection);return}
  const archiveCms=event.target.closest('[data-archive-cms-section]');if(archiveCms){archiveCmsSection(archiveCms.dataset.archiveCmsSection);return}
  const duplicatePage=event.target.closest('[data-duplicate-cms-page]');if(duplicatePage){duplicateCmsPage(duplicatePage.dataset.duplicateCmsPage);return}
  const duplicateSection=event.target.closest('[data-duplicate-cms-section]');if(duplicateSection){duplicateCmsSection(duplicateSection.dataset.duplicateCmsSection);return}
  const cmsHistory=event.target.closest('[data-cms-history]');if(cmsHistory){const [type,id]=cmsHistory.dataset.cmsHistory.split(':');openCmsHistory(type,id);return}
  const restoreRevision=event.target.closest('[data-restore-cms-revision]');if(restoreRevision){restoreCmsRevision(restoreRevision.dataset.restoreCmsRevision);return}
  if(event.target.closest('[data-secure-cms-preview]')){openSecureCmsPreview();return}
  if(event.target.closest('[data-manage-cms-menus]')){openCmsMenus();return}
  if(event.target.closest('[data-add-cms-menu]')){openCmsMenuEditor();return}
  const editMenu=event.target.closest('[data-edit-cms-menu]');if(editMenu){openCmsMenuEditor(editMenu.dataset.editCmsMenu);return}
  const deleteMenu=event.target.closest('[data-delete-cms-menu]');if(deleteMenu){deleteCmsMenu(deleteMenu.dataset.deleteCmsMenu);return}
  if(event.target.closest('[data-preview-cms-page]')){openCmsPreview();return}
  if(event.target.closest('[data-add-announcement]')){openAnnouncementEditor();return}
  const editAnnouncement=event.target.closest('[data-edit-announcement]');if(editAnnouncement){openAnnouncementEditor(editAnnouncement.dataset.editAnnouncement);return}
  const archiveItem=event.target.closest('[data-archive-announcement]');if(archiveItem){archiveAnnouncement(archiveItem.dataset.archiveAnnouncement);return}
  if(event.target.closest('[data-auth-security-settings]')){openAuthSecuritySettings();return}
  if(event.target.closest('[data-add-security-block]')){openSecurityBlockCreator();return}
  const securityAlert=event.target.closest('[data-security-alert]');if(securityAlert){updateSecurityAlert(securityAlert.dataset.securityAlert,securityAlert.dataset.alertStatus);return}
  const revokeBlock=event.target.closest('[data-revoke-block]');if(revokeBlock){revokeSecurityBlock(revokeBlock.dataset.revokeBlock);return}
  const error=event.target.closest('[data-error-id]');if(error){openError(error.dataset.errorId);return}
  const tab=event.target.closest('[data-logs-tab]');if(tab){state.logsTab=tab.dataset.logsTab;renderView('logs');return}
  const go=event.target.closest('[data-go]');if(go){renderView(go.dataset.go);return}
  if(event.target.closest('[data-retry]'))renderView();
});

bootstrap();

/* ==========================================================================
   بانک و پرداخت کارت‌به‌کارت — نمای پنل مدیریت
   از همان api() پنل استفاده می‌کند، پس نشست، CSRF و permission همان‌های قبلی‌اند.
   ========================================================================== */
(function () {
  'use strict';

  const bankingState = { status: 'pending', q: '' };

  const RECEIPT_STATUS = {
    pending: ['در انتظار بررسی', '#f5be50'],
    approved: ['تایید شده', '#46e39b'],
    rejected: ['رد شده', '#ff667a'],
  };

  const groupCard = (v) => String(v || '').replace(/(.{4})(?=.)/g, '$1-');

  function receiptBadge(status) {
    const [label, color] = RECEIPT_STATUS[status] || RECEIPT_STATUS.pending;
    return `<span class="rcpt-badge" style="--c:${color}">${label}</span>`;
  }

  if (!document.getElementById('pa-ctc-styles')) {
    const style = document.createElement('style');
    style.id = 'pa-ctc-styles';
    style.textContent = `
.ctc-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:13px;align-items:start}
@media(max-width:1000px){.ctc-grid{grid-template-columns:1fr}}
.ctc-stat{display:grid;grid-template-columns:repeat(auto-fit,minmax(104px,1fr));gap:8px;margin-bottom:13px}
.ctc-stat div{padding:11px;border:1px solid #24344a;border-radius:12px;background:#0c1622;text-align:center}
.ctc-stat small{display:block;font-size:8px;color:#7d8fa5;margin-bottom:4px}
.ctc-stat b{font-size:15px;color:#eaf2ff}
.ctc-card{display:flex;align-items:center;gap:11px;padding:13px;border:1px solid #24344a;border-radius:13px;background:#0c1622;margin-bottom:9px}
.ctc-card-ic{display:grid;width:44px;height:44px;flex:none;place-items:center;border-radius:11px;color:#8ef4ff;background:rgba(34,211,238,.08);font-weight:700}
.ctc-card-body{flex:1;min-width:0}
.ctc-card-body b{display:block;font-size:10px;color:#eaf2ff;margin-bottom:3px}
.ctc-card-body span{display:block;font-family:'JetBrains Mono',monospace;font-size:13px;letter-spacing:.08em;color:#7ce7f8;direction:ltr;text-align:left}
.ctc-card-body small{font-size:7.5px;color:#5f7288}
.ctc-toolbar{display:flex;flex-wrap:wrap;gap:7px;align-items:center;margin-bottom:11px}
.ctc-tab{min-height:29px;padding:0 12px;border-radius:9px;border:1px solid #24344a;background:rgba(255,255,255,.03);color:#8fa0b6;font:600 9px inherit;cursor:pointer}
.ctc-tab:hover{background:rgba(255,255,255,.07)}
.ctc-tab.on{border-color:rgba(34,211,238,.55);background:rgba(34,211,238,.14);color:#9beefc}
.ctc-tab i{font-style:normal;display:inline-block;min-width:15px;height:15px;margin-inline-start:5px;padding:0 4px;border-radius:8px;background:#ff667a;color:#fff;font:700 8px/15px monospace}
.ctc-search{flex:1;min-width:160px;min-height:29px;padding:0 10px;border-radius:9px;border:1px solid #24344a;background:#0a1420;color:#e6eefc;font-size:9.5px;outline:none}
.rcpt{display:flex;gap:12px;padding:12px;margin-bottom:9px;border:1px solid #24344a;border-radius:13px;background:#0c1622}
.rcpt[data-status=pending]{border-inline-start:3px solid #f5be50}
.rcpt[data-status=approved]{border-inline-start:3px solid #46e39b}
.rcpt[data-status=rejected]{border-inline-start:3px solid #ff667a;opacity:.8}
.rcpt-thumb{flex:none;width:78px;height:78px;border-radius:10px;overflow:hidden;border:1px solid #24344a;background:#08111c;display:grid;place-items:center;cursor:zoom-in;color:#5f7288;font-size:8px;text-align:center}
.rcpt-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.rcpt-main{flex:1;min-width:0}
.rcpt-head{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-bottom:7px}
.rcpt-head b{font-size:10.5px;color:#eaf2ff}
.rcpt-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:4px 12px;margin-bottom:8px}
.rcpt-grid span{font-size:8.5px;line-height:1.8;color:#75879c}
.rcpt-grid span b{color:#c4d4e6}
.rcpt-grid .mono{font-family:'JetBrains Mono',monospace;direction:ltr;unicode-bidi:embed;display:inline-block}
.rcpt-badge{padding:3px 9px;border-radius:20px;font-size:8px;font-weight:700;white-space:nowrap;color:var(--c);border:1px solid color-mix(in srgb,var(--c) 40%,transparent);background:color-mix(in srgb,var(--c) 13%,transparent)}
.rcpt-note{margin-top:6px;padding:7px 10px;border-radius:8px;background:rgba(137,158,190,.08);font-size:8.5px;line-height:1.8;color:#9db0c5}
.rcpt-actions{display:flex;flex-wrap:wrap;gap:6px}
.rcpt-btn{min-height:28px;padding:0 11px;border-radius:8px;border:1px solid #24344a;background:rgba(255,255,255,.04);color:#c0cfe0;font:600 9px inherit;cursor:pointer}
.rcpt-btn:hover{background:rgba(255,255,255,.09)}
.rcpt-btn.ok{border-color:rgba(70,227,155,.45);background:rgba(70,227,155,.14);color:#7ff0bd}
.rcpt-btn.no{border-color:rgba(255,102,122,.42);background:rgba(255,102,122,.12);color:#ff9dab}
.ctc-light{position:fixed;inset:0;z-index:2147483646;display:grid;place-items:center;padding:24px;background:rgba(3,6,11,.92);cursor:zoom-out}
.ctc-light img{max-width:96%;max-height:92vh;border-radius:12px}
`;
    document.head.appendChild(style);
  }

  async function renderBanking() {
    const canManage = hasPermission('billing.manage');
    const [cards, receipts, summary] = await Promise.all([
      api('/api/admin/bank-cards'),
      api(`/api/admin/receipts?status=${encodeURIComponent(bankingState.status)}&q=${encodeURIComponent(bankingState.q)}`),
      api('/api/admin/receipts-summary'),
    ]);

    const cardRows = (cards.rows || []).map((c) => `
      <div class="ctc-card">
        <span class="ctc-card-ic">${escapeHtml((c.bank_name || '؟').slice(0, 1))}</span>
        <div class="ctc-card-body">
          <b>${escapeHtml(c.bank_name)} · ${escapeHtml(c.holder || '—')}</b>
          <span>${escapeHtml(groupCard(c.card_number))}</span>
          <small>${c.is_enabled ? 'فعال — روی صفحه پرداخت نمایش داده می‌شود' : 'غیرفعال'}${c.sheba ? ` · IR${escapeHtml(c.sheba)}` : ''}</small>
        </div>
        ${canManage ? `<div class="bank-card-actions">
          <button class="table-action" data-ctc-edit="${escapeHtml(c.id)}" title="ویرایش">${icon('edit', 13)}</button>
          <button class="table-action danger-action" data-ctc-del="${escapeHtml(c.id)}" title="حذف">${icon('close', 13)}</button>
        </div>` : ''}
      </div>`).join('');

    const rcptRows = (receipts.rows || []).map((r) => {
      const thumb = r.has_receipt
        ? (String(r.receipt_mime).startsWith('image/')
          ? `<div class="rcpt-thumb" data-ctc-view="${escapeHtml(r.id)}"><img loading="lazy" src="/api/admin/receipts/${encodeURIComponent(r.id)}/image" alt="فیش"></div>`
          : `<a class="rcpt-thumb" href="/api/admin/receipts/${encodeURIComponent(r.id)}/image" target="_blank" rel="noopener">مشاهده<br>PDF</a>`)
        : '<div class="rcpt-thumb">بدون فیش</div>';
      const actions = canManage ? `<div class="rcpt-actions">
        ${r.status !== 'approved' ? `<button class="rcpt-btn ok" data-ctc-approve="${escapeHtml(r.id)}">${icon('check', 12)} تایید و فعال‌سازی اشتراک</button>` : ''}
        ${r.status === 'pending' ? `<button class="rcpt-btn no" data-ctc-reject="${escapeHtml(r.id)}">رد کردن</button>` : ''}
      </div>` : '';
      return `<div class="rcpt" data-status="${escapeHtml(r.status)}">${thumb}
        <div class="rcpt-main">
          <div class="rcpt-head"><b>${escapeHtml(r.user_name || '—')}</b>${receiptBadge(r.status)}
            <small style="color:#5f7288;font-size:8px">${dateFa(r.created_at, true)}</small></div>
          <div class="rcpt-grid">
            <span>موبایل: <b class="mono">${escapeHtml(r.user_mobile || '—')}</b></span>
            <span>پلن: <b>${escapeHtml(r.plan_title || '—')}</b></span>
            <span>مبلغ: <b>${toman(r.amount)}</b></span>
            <span>کد پیگیری: <b class="mono">${escapeHtml(r.tracking_code || '—')}</b></span>
            <span>کارت مقصد: <b>${escapeHtml(r.bank_name || '—')}${r.card_number ? ` · ${escapeHtml(r.card_number)}` : ''}</b></span>
            ${r.granted_days ? `<span>اعتبار داده‌شده: <b>${n(r.granted_days)} روز</b></span>` : ''}
            ${r.reviewer_name ? `<span>بررسی توسط: <b>${escapeHtml(r.reviewer_name)}</b></span>` : ''}
          </div>
          ${r.note ? `<div class="rcpt-note">توضیح کاربر: ${escapeHtml(r.note)}</div>` : ''}
          ${r.admin_note ? `<div class="rcpt-note">یادداشت مدیر: ${escapeHtml(r.admin_note)}</div>` : ''}
          ${actions}
        </div></div>`;
    }).join('');

    const counts = receipts.counts || {};
    const tabs = [['pending', 'در انتظار'], ['approved', 'تاییدشده'], ['rejected', 'ردشده'], ['all', 'همه']]
      .map(([key, label]) => {
        const c = key === 'all'
          ? (counts.pending || 0) + (counts.approved || 0) + (counts.rejected || 0)
          : (counts[key] || 0);
        return `<button class="ctc-tab ${bankingState.status === key ? 'on' : ''}" data-ctc-status="${key}">${label}${key === 'pending' && c ? `<i>${n(c)}</i>` : ` (${n(c)})`}</button>`;
      }).join('');

    return `<div class="section-head"><div><span class="eyebrow">CARD-TO-CARD PAYMENTS</span>
        <h2>کارت بانکی و فیش‌های واریز</h2>
        <p>شماره کارت‌هایی که به کاربران نمایش داده می‌شود و فیش‌هایی که ثبت کرده‌اند. با تایید هر فیش، اشتراک کاربر واقعاً تمدید و یک پرداخت رسمی ثبت می‌شود.</p></div>
        ${canManage ? `<button class="primary-btn" data-ctc-add>${icon('userPlus', 14)} کارت بانکی جدید</button>` : ''}</div>

      <div class="ctc-stat">
        <div><small>در انتظار بررسی</small><b style="color:#f5be50">${n(summary.pending || 0)}</b></div>
        <div><small>تاییدشده</small><b style="color:#46e39b">${n(summary.approved || 0)}</b></div>
        <div><small>ردشده</small><b style="color:#ff667a">${n(summary.rejected || 0)}</b></div>
        <div><small>درآمد کارت‌به‌کارت</small><b style="font-size:11px">${toman(summary.revenue || 0)}</b></div>
      </div>

      <div class="ctc-grid">
        <section class="card settings-card"><div class="card-head"><div class="card-title">
          <b>فیش‌های واریز</b><span>برای فعال‌سازی اشتراک، «تایید» را بزنید</span></div></div>
          <div class="ctc-toolbar">${tabs}
            <input class="ctc-search" id="ctcSearch" placeholder="جستجو: نام، موبایل یا کد پیگیری…" value="${escapeHtml(bankingState.q)}"></div>
          ${rcptRows || '<div class="empty-note">فیشی در این وضعیت وجود ندارد.</div>'}
        </section>

        <section class="card settings-card"><div class="card-head"><div class="card-title">
          <b>کارت‌های بانکی</b><span>در صفحه پرداخت سایت نمایش داده می‌شود</span></div></div>
          ${cardRows || '<div class="empty-note">هنوز کارتی اضافه نشده است. روی «کارت بانکی جدید» بزنید.</div>'}
        </section>
      </div>`;
  }
  window.renderBanking = renderBanking;

  /* --------------------------------------------------------- editors ---- */
  function cardEditor(row) {
    const r = row || { bank_name: '', holder: '', card_number: '', sheba: '', is_enabled: 1 };
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">${r.id ? 'ویرایش کارت بانکی' : 'کارت بانکی جدید'}</h3>
      <span class="modal-subtitle">این کارت به کاربران برای واریز نمایش داده می‌شود</span></div>
      <button class="modal-close" data-close-modal data-icon="close"></button></header>
      <div class="modal-body"><div class="form-grid billing-form">
        <label>نام بانک<input class="input" id="ctcBank" maxlength="60" value="${escapeHtml(r.bank_name)}" placeholder="مثل: بانک ملت"></label>
        <label>نام صاحب کارت<input class="input" id="ctcHolder" maxlength="80" value="${escapeHtml(r.holder)}" placeholder="نام و نام خانوادگی"></label>
        <label class="full-field">شماره کارت (۱۶ رقم)<input class="input ltr-input" id="ctcNumber" dir="ltr" inputmode="numeric" maxlength="19" value="${escapeHtml(groupCard(r.card_number))}" placeholder="6104-3378-1234-5678"></label>
        <label class="full-field">شماره شبا بدون IR (اختیاری)<input class="input ltr-input" id="ctcSheba" dir="ltr" inputmode="numeric" maxlength="24" value="${escapeHtml(r.sheba || '')}" placeholder="۲۴ رقم"></label>
        <label class="full-field"><label class="system-switch-row" style="margin:0"><div><b>نمایش روی سایت</b></div>
          <button type="button" class="toggle ${r.is_enabled ? 'on' : ''}" id="ctcEnabled" data-toggle><i></i></button></label></label>
      </div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button>
        <button class="primary-btn" id="ctcSave">${r.id ? 'ذخیره' : 'افزودن'}</button></div></div>`);

    const toggle = $('#ctcEnabled');
    toggle.addEventListener('click', () => toggle.classList.toggle('on'));
    const numberInput = $('#ctcNumber');
    numberInput.addEventListener('input', () => {
      const tail = numberInput.value.length - numberInput.selectionStart;
      numberInput.value = groupCard(numberInput.value.replace(/\D/g, '').slice(0, 16));
      numberInput.selectionStart = numberInput.selectionEnd = Math.max(0, numberInput.value.length - tail);
    });

    $('#ctcSave').addEventListener('click', async (event) => {
      setBusy(event.currentTarget, true);
      const body = {
        bankName: $('#ctcBank').value,
        holder: $('#ctcHolder').value,
        cardNumber: numberInput.value.replace(/\D/g, ''),
        sheba: $('#ctcSheba').value.replace(/\D/g, ''),
        isEnabled: toggle.classList.contains('on'),
      };
      try {
        if (r.id) await api(`/api/admin/bank-cards/${r.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api('/api/admin/bank-cards', { method: 'POST', body: JSON.stringify(body) });
        closeModal(); toast(r.id ? 'کارت بانکی به‌روزرسانی شد.' : 'کارت بانکی اضافه شد.'); renderView('banking');
      } catch (error) { toast(error.message, 'error'); setBusy(event.currentTarget, false); }
    });
  }

  async function approveDialog(receiptId) {
    const data = await api('/api/admin/receipts?status=all');
    const r = (data.rows || []).find((x) => x.id === receiptId);
    if (!r) { toast('فیش پیدا نشد.', 'error'); return; }
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">تایید فیش واریز</h3>
      <span class="modal-subtitle">${escapeHtml(r.user_name || '')} · ${escapeHtml(r.user_mobile || '')} · ${escapeHtml(r.plan_title || '')} · ${toman(r.amount)}</span></div>
      <button class="modal-close" data-close-modal data-icon="close"></button></header>
      <div class="modal-body"><div class="form-grid billing-form">
        <label class="full-field">مدت اعتباری که فعال می‌شود (روز)
          <input class="input" id="ctcDays" type="number" min="1" max="3650" value="${Number(r.plan_duration) || 30}"></label>
        <label class="full-field">یادداشت برای کاربر (اختیاری)
          <input class="input" id="ctcNote" maxlength="200" placeholder="مثلاً: با تشکر، اشتراک شما فعال شد."></label>
      </div>
      <div class="empty-note" style="margin-top:4px">اگر کاربر اشتراک فعال داشته باشد، این مدت به انتهای آن اضافه می‌شود و یک پرداخت رسمی با کد پیگیری <b>${escapeHtml(r.tracking_code)}</b> ثبت خواهد شد.</div>
      <div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button>
        <button class="primary-btn" id="ctcDoApprove">تایید و فعال‌سازی</button></div></div>`);

    $('#ctcDoApprove').addEventListener('click', async (event) => {
      setBusy(event.currentTarget, true);
      try {
        const result = await api(`/api/admin/receipts/${receiptId}/approve`, {
          method: 'POST',
          body: JSON.stringify({ days: Number($('#ctcDays').value), note: $('#ctcNote').value }),
        });
        closeModal();
        toast(`اشتراک فعال شد تا ${dateFa(result.expiresAt)} · فاکتور ${result.invoice}`);
        renderView('banking');
      } catch (error) { toast(error.message, 'error'); setBusy(event.currentTarget, false); }
    });
  }

  function rejectDialog(receiptId) {
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">رد کردن فیش</h3>
      <span class="modal-subtitle">این دلیل برای کاربر نمایش داده می‌شود</span></div>
      <button class="modal-close" data-close-modal data-icon="close"></button></header>
      <div class="modal-body"><div class="form-grid billing-form">
        <label class="full-field">دلیل رد<input class="input" id="ctcReason" maxlength="200" value="کد پیگیری یا مبلغ فیش با واریزی مطابقت ندارد."></label>
      </div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button>
        <button class="primary-btn danger-action" id="ctcDoReject">رد کردن</button></div></div>`);
    $('#ctcDoReject').addEventListener('click', async (event) => {
      setBusy(event.currentTarget, true);
      try {
        await api(`/api/admin/receipts/${receiptId}/reject`, {
          method: 'POST', body: JSON.stringify({ note: $('#ctcReason').value }),
        });
        closeModal(); toast('فیش رد شد.'); renderView('banking');
      } catch (error) { toast(error.message, 'error'); setBusy(event.currentTarget, false); }
    });
  }

  /* ---------------------------------------------------------- events ---- */
  document.addEventListener('click', (event) => {
    if (!event.target || typeof event.target.closest !== 'function') return;

    if (event.target.closest('[data-ctc-add]')) { cardEditor(null); return; }

    const edit = event.target.closest('[data-ctc-edit]');
    if (edit) {
      api('/api/admin/bank-cards').then((d) => {
        const c = (d.rows || []).find((x) => x.id === edit.dataset.ctcEdit);
        if (c) cardEditor(c); else toast('کارت پیدا نشد.', 'error');
      }).catch((error) => toast(error.message, 'error'));
      return;
    }

    const del = event.target.closest('[data-ctc-del]');
    if (del) {
      if (!confirm('این کارت حذف شود؟ کاربران دیگر آن را نمی‌بینند.')) return;
      api(`/api/admin/bank-cards/${del.dataset.ctcDel}`, { method: 'DELETE' })
        .then(() => { toast('کارت حذف شد.'); renderView('banking'); })
        .catch((error) => toast(error.message, 'error'));
      return;
    }

    const approve = event.target.closest('[data-ctc-approve]');
    if (approve) { approveDialog(approve.dataset.ctcApprove).catch((e) => toast(e.message, 'error')); return; }

    const reject = event.target.closest('[data-ctc-reject]');
    if (reject) { rejectDialog(reject.dataset.ctcReject); return; }

    const status = event.target.closest('[data-ctc-status]');
    if (status) { bankingState.status = status.dataset.ctcStatus; renderView('banking'); return; }

    const view = event.target.closest('[data-ctc-view]');
    if (view) {
      const box = document.createElement('div');
      box.className = 'ctc-light';
      box.innerHTML = `<img src="/api/admin/receipts/${encodeURIComponent(view.dataset.ctcView)}/image" alt="فیش واریز">`;
      box.addEventListener('click', () => box.remove());
      document.body.appendChild(box);
    }
  });

  let searchTimer = null;
  document.addEventListener('input', (event) => {
    if (event.target.id !== 'ctcSearch') return;
    clearTimeout(searchTimer);
    const value = event.target.value;
    searchTimer = setTimeout(() => { bankingState.q = value; renderView('banking'); }, 420);
  });
})();

/* ==========================================================================
   محتوای سایت — ویرایش همه متن‌های صفحه اصلی + نظرات کاربران
   ========================================================================== */
(function () {
  'use strict';

  const contentState = { tab: 'texts', q: '', group: '' };

  if (!document.getElementById('pa-sitecontent-styles')) {
    const st = document.createElement('style');
    st.id = 'pa-sitecontent-styles';
    st.textContent = `
.sc-tabs{display:flex;gap:7px;margin-bottom:13px}
.sc-tab{min-height:31px;padding:0 14px;border-radius:9px;border:1px solid #24344a;background:rgba(255,255,255,.03);color:#8fa0b6;font:600 9.5px inherit;cursor:pointer}
.sc-tab.on{border-color:rgba(34,211,238,.55);background:rgba(34,211,238,.14);color:#9beefc}
.sc-toolbar{display:flex;flex-wrap:wrap;gap:7px;align-items:center;margin-bottom:12px}
.sc-search{flex:1;min-width:180px;min-height:30px;padding:0 11px;border-radius:9px;border:1px solid #24344a;background:#0a1420;color:#e6eefc;font-size:9.5px;outline:none}
.sc-chip{min-height:27px;padding:0 11px;border-radius:20px;border:1px solid #24344a;background:rgba(255,255,255,.03);color:#8fa0b6;font:600 8.5px inherit;cursor:pointer;white-space:nowrap}
.sc-chip.on{border-color:rgba(34,211,238,.5);background:rgba(34,211,238,.12);color:#9beefc}
.sc-group{margin-bottom:16px}
.sc-group>h4{margin:0 0 8px;font:700 10px inherit;color:#8ef4ff;display:flex;align-items:center;gap:7px}
.sc-group>h4 span{flex:none;padding:2px 8px;border-radius:20px;background:rgba(34,211,238,.1);color:#7fd9e8;font:600 8px inherit}
.sc-row{display:grid;grid-template-columns:1fr auto;gap:9px;align-items:start;padding:10px 12px;margin-bottom:7px;border:1px solid #24344a;border-radius:11px;background:#0c1622}
.sc-row.changed{border-color:rgba(245,190,80,.4);background:rgba(245,190,80,.045)}
.sc-row textarea{width:100%;min-height:34px;padding:7px 9px;border-radius:8px;border:1px solid #24344a;background:#0a1420;color:#e6eefc;font:400 10px/1.75 inherit;resize:vertical;outline:none;box-sizing:border-box}
.sc-row textarea:focus{border-color:rgba(34,211,238,.5)}
.sc-meta{display:flex;gap:8px;align-items:center;margin-top:5px;font-size:7.5px;color:#5f7288}
.sc-meta code{font-family:monospace;color:#6f8ba3}
.sc-actions{display:flex;flex-direction:column;gap:5px}
.sc-btn{min-height:27px;padding:0 10px;border-radius:8px;border:1px solid #24344a;background:rgba(255,255,255,.04);color:#c0cfe0;font:600 8.5px inherit;cursor:pointer;white-space:nowrap}
.sc-btn:hover{background:rgba(255,255,255,.09)}
.sc-btn.save{border-color:rgba(70,227,155,.45);background:rgba(70,227,155,.14);color:#7ff0bd}
.sc-btn[disabled]{opacity:.4;cursor:default}
.sc-t-card{display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:start;padding:13px;margin-bottom:9px;border:1px solid #24344a;border-radius:13px;background:#0c1622}
.sc-t-card.off{opacity:.55}
.sc-t-av{display:grid;place-items:center;width:40px;height:40px;border-radius:50%;font:700 14px inherit;color:#04252b;background:linear-gradient(135deg,#25d5ed,#46e39b)}
.sc-t-main b{display:block;font-size:10.5px;color:#eaf2ff}
.sc-t-main small{display:block;font-size:8.5px;color:#75879c;margin-bottom:5px}
.sc-t-main p{margin:0;font:400 9.5px/1.9 inherit;color:#c0cfe0}
.sc-stars{color:#f5be50;letter-spacing:2px;font-size:11px}
.sc-badges{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:9px;margin-bottom:14px}
.sc-badge{display:flex;gap:9px;align-items:center;padding:11px;border:1px solid #24344a;border-radius:11px;background:#0c1622}
.sc-badge input{min-width:0;padding:5px 7px;border-radius:7px;border:1px solid #24344a;background:#0a1420;color:#e6eefc;font-size:9px}
`;
    document.head.appendChild(st);
  }

  async function renderSiteContent() {
    const canEdit = hasPermission('content.manage') || hasPermission('cms.manage');
    const tabs = `<div class="sc-tabs">
      <button class="sc-tab ${contentState.tab === 'texts' ? 'on' : ''}" data-sc-tab="texts">متن‌های سایت</button>
      <button class="sc-tab ${contentState.tab === 'trust' ? 'on' : ''}" data-sc-tab="trust">نظرات و اعتمادسازی</button>
      <button class="sc-tab ${contentState.tab === 'social' ? 'on' : ''}" data-sc-tab="social">راه‌های ارتباطی</button>
    </div>`;

    if (contentState.tab === 'trust') return tabs + await renderTrustTab(canEdit);
    if (contentState.tab === 'social') return tabs + await renderSocialTab(canEdit);
    return tabs + await renderTextsTab(canEdit);
  }
  window.renderSiteContent = renderSiteContent;

  async function renderTextsTab(canEdit) {
    const data = await api(`/api/admin/site-texts?q=${encodeURIComponent(contentState.q)}`);
    const rows = contentState.group
      ? data.rows.filter((r) => r.group_label === contentState.group) : data.rows;

    const chips = ['', ...data.groups].map((g) => `<button class="sc-chip ${contentState.group === g ? 'on' : ''}"
      data-sc-group="${escapeHtml(g)}">${g ? escapeHtml(g) : 'همه'}</button>`).join('');

    const grouped = {};
    rows.forEach((r) => { (grouped[r.group_label] = grouped[r.group_label] || []).push(r); });

    const body = Object.keys(grouped).length ? Object.entries(grouped).map(([group, list]) => `
      <div class="sc-group"><h4>${escapeHtml(group)}<span>${n(list.length)}</span></h4>
      ${list.map((r) => {
        const changed = r.value !== r.default_value;
        return `<div class="sc-row ${changed ? 'changed' : ''}" data-sc-id="${escapeHtml(r.id)}">
          <div>
            <textarea data-sc-input ${canEdit ? '' : 'disabled'} rows="${r.value.length > 90 ? 3 : 1}"
              >${escapeHtml(r.value)}</textarea>
            <div class="sc-meta"><code>${escapeHtml(r.text_key)}</code>
              ${changed ? '<span style="color:#f5be50">تغییر داده شده</span>' : ''}</div>
          </div>
          <div class="sc-actions">
            ${canEdit ? `<button class="sc-btn save" data-sc-save>ذخیره</button>` : ''}
            ${canEdit && changed ? `<button class="sc-btn" data-sc-reset>بازگردانی</button>` : ''}
          </div>
        </div>`;
      }).join('')}</div>`).join('') : '<div class="empty-note">متنی با این فیلتر پیدا نشد.</div>';

    return `<div class="section-head"><div><span class="eyebrow">SITE COPY</span>
        <h2>متن‌های سایت</h2>
        <p>هر متنی که در صفحه اصلی دیده می‌شود اینجا قابل تغییر است. بعد از ذخیره، بلافاصله روی سایت اعمال می‌شود.</p></div>
        <div style="text-align:left"><b style="font-size:20px;color:#8ef4ff">${n(data.total)}</b>
        <div style="font-size:8px;color:#75869b">متن قابل ویرایش · ${n(data.changed)} تغییر یافته</div></div></div>
      <div class="sc-toolbar">
        <input class="sc-search" id="scSearch" placeholder="جستجو در متن‌ها…" value="${escapeHtml(contentState.q)}">
      </div>
      <div class="sc-toolbar">${chips}</div>
      ${body}`;
  }

  const SOCIAL_PRESETS = {
    telegram:{label:'تلگرام',hint:'@yourchannel یا https://t.me/yourchannel'},
    instagram:{label:'اینستاگرام',hint:'@yourpage یا https://instagram.com/yourpage'},
    whatsapp:{label:'واتس‌اپ',hint:'989121234567'},
    eitaa:{label:'ایتا',hint:'@yourchannel'},
    bale:{label:'بله',hint:'@yourchannel'},
    rubika:{label:'روبیکا',hint:'@yourchannel'},
    youtube:{label:'یوتیوب',hint:'@yourchannel'},
    aparat:{label:'آپارات',hint:'yourchannel'},
    x:{label:'ایکس (توییتر)',hint:'@youraccount'},
    linkedin:{label:'لینکدین',hint:'yourname'},
    email:{label:'ایمیل',hint:'info@smarttradejournal.ir'},
    phone:{label:'تلفن',hint:'02112345678'},
    website:{label:'وب‌سایت',hint:'https://example.ir'},
    custom:{label:'دلخواه',hint:'https://…'},
  };

  async function renderSocialTab(canEdit) {
    const data = await api('/api/admin/social-links');
    const rows = data.rows || [];
    const live = rows.filter((r) => r.is_published && r.url).length;

    const card = (r) => `<div class="sc-soc" data-soc="${escapeHtml(r.id)}">
      <div class="sc-soc-grid">
        <label>شبکه
          <select class="select" data-sk="platform" ${canEdit ? '' : 'disabled'}>
            ${Object.entries(SOCIAL_PRESETS).map(([key, meta]) =>
              `<option value="${key}" ${r.platform === key ? 'selected' : ''}>${escapeHtml(meta.label)}</option>`).join('')}
          </select></label>
        <label>عنوان روی سایت
          <input class="input" data-sk="label" maxlength="40" value="${escapeHtml(r.label)}" ${canEdit ? '' : 'disabled'}></label>
        <label class="full-field">آدرس یا نام کاربری
          <input class="input" dir="ltr" data-sk="url" maxlength="300"
            placeholder="${escapeHtml(SOCIAL_PRESETS[r.platform]?.hint || 'https://…')}"
            value="${escapeHtml(r.url)}" ${canEdit ? '' : 'disabled'}></label>
        <label class="full-field">توضیح کوتاه (اختیاری — زیر عنوان نشان داده می‌شود)
          <input class="input" dir="ltr" data-sk="handle" maxlength="60" value="${escapeHtml(r.handle)}" ${canEdit ? '' : 'disabled'}></label>
      </div>
      <div class="sc-soc-foot">
        <label class="sc-soc-check"><input type="checkbox" data-sk="isPublished" ${r.is_published ? 'checked' : ''} ${canEdit ? '' : 'disabled'}><span>روی سایت نمایش داده شود</span></label>
        <label class="sc-soc-check"><input type="checkbox" data-sk="showWidget" ${r.show_widget ? 'checked' : ''} ${canEdit ? '' : 'disabled'}><span>در دکمه شناور گوشه صفحه هم باشد</span></label>
        <span class="sc-soc-status ${r.is_published && r.url ? 'on' : ''}">${r.is_published && r.url ? 'منتشر شده' : 'خاموش'}</span>
        ${canEdit ? `<div class="sc-soc-btns">
          <button class="sc-btn" data-soc-up title="بالاتر">▲</button>
          <button class="sc-btn" data-soc-down title="پایین‌تر">▼</button>
          <button class="sc-btn save" data-soc-save>ذخیره</button>
          <button class="sc-btn danger" data-soc-del>حذف</button>
        </div>` : ''}
      </div>
    </div>`;

    return `<div class="section-head"><div><span class="eyebrow">CONTACT CHANNELS</span>
        <h2>راه‌های ارتباطی</h2>
        <p>تلگرام، اینستاگرام و هر راه ارتباطی دیگر. هرچه اینجا منتشر کنید،
           هم زیر کارت «تماس و پشتیبانی» صفحه اصلی می‌آید و هم داخل دکمه شناور گوشه صفحه.</p></div>
        <div style="text-align:left"><b style="font-size:20px;color:#8ef4ff">${n(live)}</b>
        <div style="font-size:8px;color:#75869b">لینک فعال از ${n(rows.length)}</div></div></div>
      ${canEdit ? '<div class="sc-toolbar"><button class="primary-btn" id="socAdd">افزودن راه ارتباطی</button></div>' : ''}
      ${rows.length ? rows.map(card).join('') : '<div class="empty-note">هنوز راه ارتباطی اضافه نشده است.</div>'}
      <div class="sc-soc-note">${icon('shield', 15)} آدرس‌ها قبل از ذخیره بررسی می‌شوند؛ فقط لینک‌های http/https پذیرفته می‌شود.
        می‌توانید فقط نام کاربری بنویسید (مثلاً <code dir="ltr">@smartjournal</code>) و سیستم خودش آدرس کامل را می‌سازد.</div>`;
  }

  async function renderTrustTab(canEdit) {
    const data = await api('/api/admin/testimonials');
    const badges = (data.badges || []).map((b) => `
      <div class="sc-badge" data-sc-badge="${escapeHtml(b.id)}">
        <input style="width:38px;text-align:center" data-bk="icon" value="${escapeHtml(b.icon)}" ${canEdit ? '' : 'disabled'}>
        <div style="flex:1;display:grid;gap:4px">
          <input data-bk="value" value="${escapeHtml(b.value)}" ${canEdit ? '' : 'disabled'}>
          <input data-bk="label" value="${escapeHtml(b.label)}" ${canEdit ? '' : 'disabled'}>
        </div>
        ${canEdit ? '<button class="sc-btn save" data-sc-badge-save>ذخیره</button>' : ''}
      </div>`).join('');

    const cards = (data.rows || []).map((t) => `
      <div class="sc-t-card ${t.is_published ? '' : 'off'}" data-sc-t="${escapeHtml(t.id)}">
        <span class="sc-t-av">${escapeHtml(String(t.name).trim().charAt(0))}</span>
        <div class="sc-t-main">
          <b>${escapeHtml(t.name)}</b><small>${escapeHtml(t.role || '—')}</small>
          <div class="sc-stars">${'★'.repeat(t.rating)}${'☆'.repeat(5 - t.rating)}</div>
          <p>${escapeHtml(t.body)}</p>
        </div>
        ${canEdit ? `<div class="sc-actions">
          <button class="sc-btn" data-sc-t-edit>ویرایش</button>
          <button class="sc-btn" data-sc-t-toggle>${t.is_published ? 'پنهان کن' : 'نمایش بده'}</button>
          <button class="sc-btn" data-sc-t-del>حذف</button>
        </div>` : ''}
      </div>`).join('');

    return `<div class="section-head"><div><span class="eyebrow">SOCIAL PROOF</span>
        <h2>نظرات و اعتمادسازی</h2>
        <p>این بخش زیر «قابلیت‌ها» در صفحه اصلی نمایش داده می‌شود تا بازدیدکننده به سایت اعتماد کند.</p></div>
        ${canEdit ? `<button class="primary-btn" data-sc-t-add>${icon('userPlus', 14)} نظر جدید</button>` : ''}</div>
      <section class="card settings-card"><div class="card-head"><div class="card-title">
        <b>آمار اعتماد</b><span>نوار بالای نظرات در صفحه اصلی</span></div></div>
        <div class="sc-badges">${badges}</div></section>
      <section class="card settings-card" style="margin-top:13px"><div class="card-head"><div class="card-title">
        <b>نظرات کاربران</b><span>${n((data.rows || []).length)} نظر · فقط موارد فعال روی سایت دیده می‌شوند</span>
        </div></div>
        ${cards || '<div class="empty-note">هنوز نظری ثبت نشده است.</div>'}</section>`;
  }

  function testimonialEditor(row) {
    const r = row || { name: '', role: '', body: '', rating: 5, is_published: 1 };
    openModal(`<header class="modal-head"><div><h3 id="modalTitle">${r.id ? 'ویرایش نظر' : 'نظر جدید'}</h3>
      <span class="modal-subtitle">در بخش اعتمادسازی صفحه اصلی نمایش داده می‌شود</span></div>
      <button class="modal-close" data-close-modal data-icon="close"></button></header>
      <div class="modal-body"><div class="form-grid billing-form">
        <label>نام<input class="input" id="scName" maxlength="60" value="${escapeHtml(r.name)}" placeholder="مثلاً سارا محمدی"></label>
        <label>عنوان / سابقه<input class="input" id="scRole" maxlength="90" value="${escapeHtml(r.role || '')}" placeholder="معامله‌گر فارکس · ۳ سال"></label>
        <label class="full-field">متن نظر<textarea class="input" id="scBody" rows="4" maxlength="600">${escapeHtml(r.body)}</textarea></label>
        <label>امتیاز<select class="input" id="scRating">${[5, 4, 3, 2, 1].map((v) =>
          `<option value="${v}" ${Number(r.rating) === v ? 'selected' : ''}>${'★'.repeat(v)} (${v})</option>`).join('')}</select></label>
        <label class="full-field"><label class="system-switch-row" style="margin:0"><div><b>نمایش روی سایت</b></div>
          <button type="button" class="toggle ${r.is_published ? 'on' : ''}" id="scPub" data-toggle><i></i></button></label></label>
      </div><div class="modal-actions"><button class="ghost-btn" data-close-modal>انصراف</button>
        <button class="primary-btn" id="scSave">${r.id ? 'ذخیره' : 'افزودن'}</button></div></div>`);

    const pub = $('#scPub');
    pub.addEventListener('click', () => pub.classList.toggle('on'));
    $('#scSave').addEventListener('click', async (event) => {
      setBusy(event.currentTarget, true);
      const body = {
        name: $('#scName').value, role: $('#scRole').value, body: $('#scBody').value,
        rating: Number($('#scRating').value), isPublished: pub.classList.contains('on'),
      };
      try {
        if (r.id) await api(`/api/admin/testimonials/${r.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api('/api/admin/testimonials', { method: 'POST', body: JSON.stringify(body) });
        closeModal(); toast(r.id ? 'نظر به‌روزرسانی شد.' : 'نظر اضافه شد.'); renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(event.currentTarget, false); }
    });
  }

  /* -------------------------------------------------------- events ---- */
  document.addEventListener('click', async (event) => {
    if (!event.target || typeof event.target.closest !== 'function') return;

    const tab = event.target.closest('[data-sc-tab]');
    if (tab) { contentState.tab = tab.dataset.scTab; renderView('sitecontent'); return; }

    const chip = event.target.closest('[data-sc-group]');
    if (chip) { contentState.group = chip.dataset.scGroup; renderView('sitecontent'); return; }

    const save = event.target.closest('[data-sc-save]');
    if (save) {
      const row = save.closest('[data-sc-id]');
      const value = row.querySelector('[data-sc-input]').value;
      setBusy(save, true);
      try {
        await api(`/api/admin/site-texts/${row.dataset.scId}`, { method: 'PATCH', body: JSON.stringify({ value }) });
        toast('متن ذخیره شد و روی سایت اعمال شد.'); renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(save, false); }
      return;
    }

    const reset = event.target.closest('[data-sc-reset]');
    if (reset) {
      const row = reset.closest('[data-sc-id]');
      try {
        await api(`/api/admin/site-texts/${row.dataset.scId}/reset`, { method: 'POST', body: '{}' });
        toast('به متن اولیه برگشت.'); renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); }
      return;
    }

    if (event.target.closest('[data-sc-t-add]')) { testimonialEditor(null); return; }

    const edit = event.target.closest('[data-sc-t-edit]');
    if (edit) {
      const id = edit.closest('[data-sc-t]').dataset.scT;
      const d = await api('/api/admin/testimonials');
      const row = (d.rows || []).find((x) => x.id === id);
      if (row) testimonialEditor(row); else toast('نظر پیدا نشد.', 'error');
      return;
    }

    const toggle = event.target.closest('[data-sc-t-toggle]');
    if (toggle) {
      const id = toggle.closest('[data-sc-t]').dataset.scT;
      const d = await api('/api/admin/testimonials');
      const row = (d.rows || []).find((x) => x.id === id);
      try {
        await api(`/api/admin/testimonials/${id}`, {
          method: 'PATCH', body: JSON.stringify({ isPublished: !row.is_published }),
        });
        toast(row.is_published ? 'از سایت پنهان شد.' : 'روی سایت نمایش داده می‌شود.');
        renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); }
      return;
    }

    const del = event.target.closest('[data-sc-t-del]');
    if (del) {
      if (!confirm('این نظر حذف شود؟')) return;
      const id = del.closest('[data-sc-t]').dataset.scT;
      try {
        await api(`/api/admin/testimonials/${id}`, { method: 'DELETE' });
        toast('نظر حذف شد.'); renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); }
      return;
    }

    const badgeSave = event.target.closest('[data-sc-badge-save]');
    if (badgeSave) {
      const box = badgeSave.closest('[data-sc-badge]');
      const body = {};
      box.querySelectorAll('[data-bk]').forEach((i) => { body[i.dataset.bk] = i.value; });
      setBusy(badgeSave, true);
      try {
        await api(`/api/admin/trust-badges/${box.dataset.scBadge}`, { method: 'PATCH', body: JSON.stringify(body) });
        toast('آمار به‌روزرسانی شد.'); setBusy(badgeSave, false);
      } catch (error) { toast(error.message, 'error'); setBusy(badgeSave, false); }
    }

    /* ------------------------------------------- راه‌های ارتباطی -------- */
    if (event.target.closest('#socAdd')) {
      const button = event.target.closest('#socAdd');
      setBusy(button, true);
      try {
        await api('/api/admin/social-links', { method: 'POST',
          body: JSON.stringify({ platform: 'telegram', label: 'تلگرام', url: '', isPublished: false }) });
        contentState.tab = 'social'; renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(button, false); }
      return;
    }

    const socSave = event.target.closest('[data-soc-save]');
    if (socSave) {
      const box = socSave.closest('[data-soc]');
      const get = (k) => box.querySelector(`[data-sk="${k}"]`);
      const body = {
        platform: get('platform').value,
        label: get('label').value,
        url: get('url').value,
        handle: get('handle').value,
        isPublished: get('isPublished').checked,
        showWidget: get('showWidget').checked,
      };
      if (body.isPublished && !body.url.trim()) {
        return toast('برای نمایش روی سایت، اول آدرس را وارد کنید.', 'error');
      }
      setBusy(socSave, true);
      try {
        await api(`/api/admin/social-links/${box.dataset.soc}`, { method: 'PATCH', body: JSON.stringify(body) });
        toast('ذخیره شد و بلافاصله روی سایت اعمال می‌شود.');
        renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(socSave, false); }
      return;
    }

    const socDel = event.target.closest('[data-soc-del]');
    if (socDel) {
      const box = socDel.closest('[data-soc]');
      const name = box.querySelector('[data-sk="label"]').value || 'این راه ارتباطی';
      if (!confirm(`«${name}» حذف شود؟`)) return;
      setBusy(socDel, true);
      try {
        await api(`/api/admin/social-links/${box.dataset.soc}`, { method: 'DELETE' });
        toast('حذف شد.'); renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(socDel, false); }
      return;
    }

    const socMove = event.target.closest('[data-soc-up],[data-soc-down]');
    if (socMove) {
      const box = socMove.closest('[data-soc]');
      const boxes = [...document.querySelectorAll('[data-soc]')];
      const index = boxes.indexOf(box);
      const target = socMove.hasAttribute('data-soc-up') ? index - 1 : index + 1;
      if (target < 0 || target >= boxes.length) return;
      setBusy(socMove, true);
      try {
        await api(`/api/admin/social-links/${box.dataset.soc}`, { method: 'PATCH',
          body: JSON.stringify({ sortOrder: (target + 1) * 10 }) });
        await api(`/api/admin/social-links/${boxes[target].dataset.soc}`, { method: 'PATCH',
          body: JSON.stringify({ sortOrder: (index + 1) * 10 }) });
        renderView('sitecontent');
      } catch (error) { toast(error.message, 'error'); setBusy(socMove, false); }
      return;
    }
  });

  /* وقتی شبکه عوض شد، عنوان و راهنمای فیلد آدرس هم خودکار عوض شود */
  document.addEventListener('change', (event) => {
    const select = event.target.closest('[data-sk="platform"]');
    if (!select) return;
    const box = select.closest('[data-soc]');
    const preset = SOCIAL_PRESETS[select.value];
    if (!preset || !box) return;
    const label = box.querySelector('[data-sk="label"]');
    const url = box.querySelector('[data-sk="url"]');
    const known = Object.values(SOCIAL_PRESETS).map((p) => p.label);
    if (!label.value.trim() || known.includes(label.value.trim())) label.value = preset.label;
    url.placeholder = preset.hint;
  });

  let scTimer = null;
  document.addEventListener('input', (event) => {
    if (event.target.id !== 'scSearch') return;
    clearTimeout(scTimer);
    const v = event.target.value;
    scTimer = setTimeout(() => { contentState.q = v; renderView('sitecontent'); }, 420);
  });
})();

/* ==================== JOURNAL & TRADE MANAGEMENT (ADMIN) ==================== */
async function renderJournals() {
  state.journalsTab = state.journalsTab || 'overview';
  const tab = state.journalsTab;

  const nav = `<div class="subnav">
    <button class="${tab==='overview'?'active':''}" data-jtab="overview">${icon('usage', 16)} آمار و نمادها</button>
    <button class="${tab==='accounts'?'active':''}" data-jtab="accounts">${icon('users', 16)} حساب‌های معاملاتی</button>
    <button class="${tab==='trades'?'active':''}" data-jtab="trades">${icon('file', 16)} کاوشگر معاملات</button>
    <button class="${tab==='inspect'?'active':''}" data-jtab="inspect">${icon('server', 16)} بازرسی ژورنال کاربر</button>
  </div>`;

  let content = '';
  if (tab === 'overview') content = await renderJournalsOverview();
  else if (tab === 'accounts') content = await renderJournalsAccounts();
  else if (tab === 'trades') content = await renderJournalsTrades();
  else if (tab === 'inspect') content = await renderJournalsInspect();

  setTimeout(() => {
    $$('[data-jtab]').forEach(btn => btn.addEventListener('click', () => {
      state.journalsTab = btn.dataset.jtab;
      renderView('journals');
    }));
  }, 20);

  return nav + content;
}

async function renderJournalsOverview() {
  const data = await api('/api/admin/journal/stats');

  const metricsHtml = `<div class="metrics-grid">
    ${metric({ iconName: 'usage', label: 'کل حساب‌های معاملاتی', value: n(data.totalAccounts), change: 'فعال', foot: 'تعداد حساب‌های متصل' })}
    ${metric({ iconName: 'file', label: 'کل معاملات ثبت‌شده', value: n(data.totalTrades), change: 'ثبت‌شده', foot: 'در تمام حساب‌ها' })}
    ${metric({ iconName: 'users', label: 'معامله‌گران فعال', value: n(data.activeTraders), change: 'کاربر', foot: 'دارای حداقل ۱ حساب' })}
    ${metric({ iconName: 'dashboard', label: 'وین‌ریت میانگین سیستم', value: `${data.winRate}%`, change: `${n(data.profitTrades)} سود / ${n(data.lossTrades)} زیان`, foot: 'نسبت معاملات سودده', tone: '#00ff88' })}
    ${metric({ iconName: 'revenue', label: 'سود/زیان خالص سیستم', value: `${data.totalPnl >= 0 ? '+' : ''}$${n(data.totalPnl)}`, change: 'مجموع دلار', foot: 'در کل معاملات فعال', tone: data.totalPnl >= 0 ? '#00ff88' : '#ef4444' })}
  </div>`;

  const symbolsRows = (data.topSymbols || []).map((s, idx) => `
    <tr>
      <td><b>#${idx + 1} ${escapeHtml(s.symbol)}</b></td>
      <td>${n(s.count)} معامله</td>
      <td><span class="badge ${s.winRate >= 50 ? 'success' : 'warn'}">${s.winRate}%</span> (${n(s.profitCount)} برد)</td>
      <td dir="ltr" style="font-family:var(--font-mono, monospace); font-weight:700; color:${s.totalAmount >= 0 ? '#00ff88' : '#ef4444'}">
        ${s.totalAmount >= 0 ? '+' : ''}$${n(s.totalAmount)}
      </td>
    </tr>
  `).join('') || '<tr><td colspan="4" class="empty-cell">هیچ معامله‌ای پیدا نشد.</td></tr>';

  const symbolsCard = `<div class="card" style="margin-top:18px">
    <div class="card-head">
      <div><h3>پر معامله‌ترین نمادهای سیستم</h3><span class="subtitle">۸ نماد با بیشترین حجم فعالیت معامله‌گران</span></div>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr><th>نماد (Symbol)</th><th>تعداد معاملات</th><th>وین‌ریت (Win Rate)</th><th>سود/زیان خالص</th></tr>
        </thead>
        <tbody>${symbolsRows}</tbody>
      </table>
    </div>
  </div>`;

  const recentRows = (data.recentTrades || []).map(t => {
    const isWin = t.result_type === 'profit' || Number(t.amount || 0) >= 0;
    return `
      <tr>
        <td>
          <b>${escapeHtml(t.symbol || '—')}</b>
          <small class="db-block" style="color:var(--txt-dim, #64748b)">${escapeHtml(t.account_name || 'حساب بدون نام')}</small>
        </td>
        <td>
          <span class="badge ${t.direction === 'buy' ? 'info' : 'warn'}">${(t.direction || 'BUY').toUpperCase()}</span>
        </td>
        <td>
          <b>${escapeHtml(t.user_name || 'کاربر')}</b>
          <small class="db-block" dir="ltr" style="color:var(--txt-dim, #64748b)">${escapeHtml(t.user_mobile || '')}</small>
        </td>
        <td>
          <span class="badge ${isWin ? 'success' : 'danger'}">${isWin ? 'سودده' : 'زیان‌ده'}</span>
        </td>
        <td dir="ltr" style="font-family:var(--font-mono, monospace); font-weight:700; color:${isWin ? '#00ff88' : '#ef4444'}">
          ${isWin ? '+' : ''}$${n(Number(t.amount || 0).toFixed(2))}
        </td>
        <td><small>${dateFa(t.created_at, true)}</small></td>
        <td>
          <button class="ghost-btn compact" data-inspect-trade="${t.id}">${icon('file', 14)} جزئیات</button>
        </td>
      </tr>
    `;
  }).join('') || '<tr><td colspan="7" class="empty-cell">معامله‌ای پیدا نشد.</td></tr>';

  const recentCard = `<div class="card" style="margin-top:18px">
    <div class="card-head">
      <div><h3>آخرین معاملات ثبت‌شده در سیستم</h3><span class="subtitle">۱۰ معامله اخیر ثبت‌شده توسط معامله‌گران</span></div>
    </div>
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr><th>نماد و حساب</th><th>جهت</th><th>معامله‌گر</th><th>نتیجه</th><th>سود/زیان</th><th>تاریخ ثبت</th><th>عملیات</th></tr>
        </thead>
        <tbody>${recentRows}</tbody>
      </table>
    </div>
  </div>`;

  setTimeout(() => {
    $$('[data-inspect-trade]').forEach(btn => btn.addEventListener('click', () => {
      openTradeDetailsModal(btn.dataset.inspectTrade);
    }));
  }, 20);

  return metricsHtml + symbolsCard + recentCard;
}

async function renderJournalsAccounts() {
  state.accPage = state.accPage || 1;
  state.accSearch = state.accSearch || '';

  const res = await api(`/api/admin/journal/accounts?page=${state.accPage}&limit=15&search=${encodeURIComponent(state.accSearch)}`);
  const rows = res.rows || [];
  const pag = res.pagination || {};

  const searchBar = `<div class="toolbar-row" style="margin-bottom:16px; display:flex; gap:12px; align-items:center">
    <div class="search-wrap" style="flex:1">
      <input class="input" id="accSearchInput" value="${escapeHtml(state.accSearch)}" placeholder="جستجوی نام حساب، نام کاربر یا شماره موبایل...">
    </div>
  </div>`;

  const tableRows = rows.map(a => `
    <tr>
      <td>
        <b>${escapeHtml(a.name || 'حساب معاملاتی')}</b>
        <small class="db-block" style="color:var(--txt-dim, #64748b)">آیدی: <code>${escapeHtml(a.id)}</code></small>
      </td>
      <td>
        <b>${escapeHtml(a.user_name || 'کاربر')}</b>
        <small class="db-block" dir="ltr" style="color:var(--txt-dim, #64748b)">${escapeHtml(a.user_mobile || '')}</small>
      </td>
      <td dir="ltr" style="font-family:var(--font-mono, monospace)">$${n(Number(a.starting_balance || 0).toFixed(2))}</td>
      <td dir="ltr" style="font-family:var(--font-mono, monospace); font-weight:700; color:${a.net_pnl >= 0 ? '#00ff88' : '#ef4444'}">
        ${a.net_pnl >= 0 ? '+' : ''}$${n(Number(a.net_pnl || 0).toFixed(2))}
      </td>
      <td><span class="badge info">${n(a.trades_count || 0)} معامله</span></td>
      <td><small>${dateFa(a.created_at, true)}</small></td>
      <td>
        <div class="table-actions">
          <button class="ghost-btn compact" data-filter-acc-trades="${a.id}">${icon('file', 14)} معاملات</button>
          <button class="ghost-btn compact danger" data-delete-acc="${a.id}" data-acc-name="${escapeHtml(a.name)}">${icon('trash', 14)} حذف</button>
        </div>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="7" class="empty-cell">هیچ حساب معاملاتی پیدا نشد.</td></tr>';

  const paginationHtml = `<div class="table-foot" style="margin-top:16px; display:flex; justify-content:space-between; align-items:center">
    <span>نمایش ${n(rows.length)} از ${n(pag.total || 0)} حساب</span>
    <div class="pagination">
      <button class="ghost-btn compact" id="prevAccPage" ${pag.page <= 1 ? 'disabled' : ''}>صفحه قبل</button>
      <span>صفحه ${n(pag.page)} از ${n(pag.pages || 1)}</span>
      <button class="ghost-btn compact" id="nextAccPage" ${pag.page >= pag.pages ? 'disabled' : ''}>صفحه بعد</button>
    </div>
  </div>`;

  const html = `<div class="card">
    <div class="card-head">
      <div><h3>مدیریت حساب‌های معاملاتی کاربران</h3><span class="subtitle">لیست کل حساب‌های فعال در ژورنال‌ها</span></div>
    </div>
    ${searchBar}
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr><th>نام حساب</th><th>مالک حساب</th><th>بالانس اولیه</th><th>سود/زیان کل</th><th>معاملات</th><th>تاریخ ساخت</th><th>عملیات</th></tr>
        </thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
    ${paginationHtml}
  </div>`;

  setTimeout(() => {
    let accTimer = null;
    const inp = $('#accSearchInput');
    if (inp) inp.addEventListener('input', () => {
      clearTimeout(accTimer);
      accTimer = setTimeout(() => {
        state.accSearch = inp.value;
        state.accPage = 1;
        renderView('journals');
      }, 400);
    });

    $('#prevAccPage')?.addEventListener('click', () => { state.accPage--; renderView('journals'); });
    $('#nextAccPage')?.addEventListener('click', () => { state.accPage++; renderView('journals'); });

    $$('[data-filter-acc-trades]').forEach(btn => btn.addEventListener('click', () => {
      state.journalsTab = 'trades';
      state.tradeAccId = btn.dataset.filterAccTrades;
      renderView('journals');
    }));

    $$('[data-delete-acc]').forEach(btn => btn.addEventListener('click', async () => {
      const accId = btn.dataset.deleteAcc;
      const accName = btn.dataset.accName;
      if (!confirm(`آیا از حذف حساب معاملاتی «${accName}» و تمام معاملات آن اطمینان داری؟`)) return;
      try {
        await api(`/api/admin/journal/accounts/${accId}`, { method: 'DELETE' });
        toast('حساب و معاملات مرتبط با موفقیت حذف شدند.');
        renderView('journals');
      } catch (err) { toast(err.message, 'error'); }
    }));
  }, 20);

  return html;
}

async function renderJournalsTrades() {
  state.tradePage = state.tradePage || 1;
  state.tradeSearch = state.tradeSearch || '';
  state.tradeResult = state.tradeResult || '';
  state.tradeDir = state.tradeDir || '';
  state.tradeAccId = state.tradeAccId || '';

  let url = `/api/admin/journal/trades?page=${state.tradePage}&limit=15&search=${encodeURIComponent(state.tradeSearch)}`;
  if (state.tradeResult) url += `&resultType=${state.tradeResult}`;
  if (state.tradeDir) url += `&direction=${state.tradeDir}`;
  if (state.tradeAccId) url += `&accountId=${encodeURIComponent(state.tradeAccId)}`;

  const res = await api(url);
  const rows = res.rows || [];
  const pag = res.pagination || {};

  const filterBar = `<div class="toolbar-row" style="margin-bottom:16px; display:flex; gap:12px; align-items:center; flex-wrap:wrap">
    <div class="search-wrap" style="flex:2; min-width:200px">
      <input class="input" id="tradeSearchInput" value="${escapeHtml(state.tradeSearch)}" placeholder="جستجوی نماد (XAUUSD...)، توضیحات یا نام کاربر...">
    </div>
    <select class="input" id="tradeResultSelect" style="flex:1; min-width:120px">
      <option value="">همه نتایج</option>
      <option value="profit" ${state.tradeResult === 'profit' ? 'selected' : ''}>سودده (Profit)</option>
      <option value="loss" ${state.tradeResult === 'loss' ? 'selected' : ''}>زیان‌ده (Loss)</option>
    </select>
    <select class="input" id="tradeDirSelect" style="flex:1; min-width:120px">
      <option value="">همه جهت‌ها</option>
      <option value="buy" ${state.tradeDir === 'buy' ? 'selected' : ''}>خرید (BUY)</option>
      <option value="sell" ${state.tradeDir === 'sell' ? 'selected' : ''}>فروش (SELL)</option>
    </select>
    ${state.tradeAccId ? `<button class="ghost-btn compact warn" id="clearAccFilter">حذف فیلتر حساب</button>` : ''}
  </div>`;

  const tableRows = rows.map(t => {
    const isWin = t.result_type === 'profit' || Number(t.amount || 0) >= 0;
    return `
      <tr>
        <td>
          <b>${escapeHtml(t.symbol || '—')}</b>
          <small class="db-block" style="color:var(--txt-dim, #64748b)">حساب: ${escapeHtml(t.account_name || '—')}</small>
        </td>
        <td>
          <span class="badge ${t.direction === 'buy' ? 'info' : 'warn'}">${(t.direction || 'BUY').toUpperCase()}</span>
        </td>
        <td>
          <b>${escapeHtml(t.user_name || 'کاربر')}</b>
          <small class="db-block" dir="ltr" style="color:var(--txt-dim, #64748b)">${escapeHtml(t.user_mobile || '')}</small>
        </td>
        <td>
          <span class="badge ${isWin ? 'success' : 'danger'}">${isWin ? 'سودده' : 'زیان‌ده'}</span>
        </td>
        <td dir="ltr" style="font-family:var(--font-mono, monospace); font-weight:700; color:${isWin ? '#00ff88' : '#ef4444'}">
          ${isWin ? '+' : ''}$${n(Number(t.amount || 0).toFixed(2))}
        </td>
        <td><small>${t.entry_at ? dateFa(t.entry_at, true) : '—'}</small></td>
        <td>
          <div class="table-actions">
            <button class="ghost-btn compact" data-inspect-trade="${t.id}">${icon('file', 14)} جزئیات</button>
            <button class="ghost-btn compact danger" data-delete-trade="${t.id}">${icon('trash', 14)} حذف</button>
          </div>
        </td>
      </tr>
    `;
  }).join('') || '<tr><td colspan="7" class="empty-cell">هیچ معامله‌ای با این مشخصات یافت نشد.</td></tr>';

  const paginationHtml = `<div class="table-foot" style="margin-top:16px; display:flex; justify-content:space-between; align-items:center">
    <span>نمایش ${n(rows.length)} از ${n(pag.total || 0)} معامله</span>
    <div class="pagination">
      <button class="ghost-btn compact" id="prevTradePage" ${pag.page <= 1 ? 'disabled' : ''}>صفحه قبل</button>
      <span>صفحه ${n(pag.page)} از ${n(pag.pages || 1)}</span>
      <button class="ghost-btn compact" id="nextTradePage" ${pag.page >= pag.pages ? 'disabled' : ''}>صفحه بعد</button>
    </div>
  </div>`;

  const html = `<div class="card">
    <div class="card-head">
      <div><h3>کاوشگر کامل معاملات ژورنال</h3><span class="subtitle">جستجو، بررسی و مدیریت معاملات تمام کاربران</span></div>
    </div>
    ${filterBar}
    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr><th>نماد و حساب</th><th>جهت</th><th>معامله‌گر</th><th>نتیجه</th><th>سود/زیان</th><th>تاریخ ورود</th><th>عملیات</th></tr>
        </thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
    ${paginationHtml}
  </div>`;

  setTimeout(() => {
    let tTimer = null;
    const inp = $('#tradeSearchInput');
    if (inp) inp.addEventListener('input', () => {
      clearTimeout(tTimer);
      tTimer = setTimeout(() => {
        state.tradeSearch = inp.value;
        state.tradePage = 1;
        renderView('journals');
      }, 400);
    });

    $('#tradeResultSelect')?.addEventListener('change', (e) => { state.tradeResult = e.target.value; state.tradePage = 1; renderView('journals'); });
    $('#tradeDirSelect')?.addEventListener('change', (e) => { state.tradeDir = e.target.value; state.tradePage = 1; renderView('journals'); });
    $('#clearAccFilter')?.addEventListener('click', () => { state.tradeAccId = ''; renderView('journals'); });

    $('#prevTradePage')?.addEventListener('click', () => { state.tradePage--; renderView('journals'); });
    $('#nextTradePage')?.addEventListener('click', () => { state.tradePage++; renderView('journals'); });

    $$('[data-inspect-trade]').forEach(btn => btn.addEventListener('click', () => {
      openTradeDetailsModal(btn.dataset.inspectTrade);
    }));

    $$('[data-delete-trade]').forEach(btn => btn.addEventListener('click', async () => {
      if (!confirm('آیا از حذف این معامله اطمینان داری؟')) return;
      try {
        await api(`/api/admin/journal/trades/${btn.dataset.deleteTrade}`, { method: 'DELETE' });
        toast('معامله حذف شد.');
        renderView('journals');
      } catch (err) { toast(err.message, 'error'); }
    }));
  }, 20);

  return html;
}

async function renderJournalsInspect() {
  const usersRes = await api('/api/admin/users?limit=50');
  const users = usersRes.rows || [];

  const userOptions = users.map(u => `<option value="${u.id}">${escapeHtml(u.name)} (${escapeHtml(u.mobile)}) — ${n(u.trades_count || 0)} معامله</option>`).join('');

  const html = `<div class="card">
    <div class="card-head">
      <div><h3>بازرسی و مدیریت زنده ژورنال کاربر</h3><span class="subtitle">انتخاب کاربر برای مشاهده و ورود به ژورنال وی</span></div>
    </div>
    <div style="display:flex; gap:16px; align-items:flex-end; margin-bottom:24px; flex-wrap:wrap">
      <div style="flex:2; min-width:240px">
        <label class="field-label">انتخاب کاربر:</label>
        <select class="input" id="inspectUserSelect">
          <option value="">انتخاب کن...</option>
          ${userOptions}
        </select>
      </div>
      <button class="primary-btn" id="loadUserJournalBtn" style="height:42px">${icon('server', 16)} بررسی ژورنال کاربر</button>
      <button class="ghost-btn" id="loginAsUserBtn" style="height:42px; color:#00ff88; border-color:rgba(0,255,136,0.3)" disabled>${icon('logout', 16)} ورود و مشاهده زنده ژورنال کاربر</button>
    </div>
    <div id="userJournalDetails">
      <div class="secure-empty">${icon('info', 20)} یک کاربر را انتخاب کن تا جزئیات ژورنال و حساب‌های وی بارگذاری شود.</div>
    </div>
  </div>`;

  setTimeout(() => {
    const sel = $('#inspectUserSelect');
    const loadBtn = $('#loadUserJournalBtn');
    const loginBtn = $('#loginAsUserBtn');
    const container = $('#userJournalDetails');

    sel?.addEventListener('change', () => {
      loginBtn.disabled = !sel.value;
    });

    loadBtn?.addEventListener('click', async () => {
      const uid = sel.value;
      if (!uid) return toast('لطفاً یک کاربر را انتخاب کن.', 'error');
      setBusy(loadBtn, true);
      try {
        const res = await api(`/api/admin/users/${uid}/journal`);
        const accounts = res.accounts || [];
        const trades = res.trades || [];
        const u = res.user;

        const accList = accounts.map(a => `
          <div style="padding:12px; background:rgba(255,255,255,0.02); border:1px solid #1e2f42; border-radius:12px; margin-bottom:8px">
            <b>${escapeHtml(a.name)}</b> — بالانس اولیه: $${n(a.starting_balance)}
          </div>
        `).join('') || '<p style="color:var(--txt-dim)">بدون حساب معاملاتی</p>';

        container.innerHTML = `
          <div style="padding:16px; background:#07121b; border-radius:16px; border:1px solid #1e2f42">
            <h4 style="margin:0 0 12px 0; color:#00ff88">خلاصه ژورنال کاربر ${escapeHtml(u.name)} (${escapeHtml(u.mobile)})</h4>
            <div class="metrics-grid" style="grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); margin-bottom:16px">
              <div><small>تعداد حساب‌ها</small><br><b>${n(accounts.length)}</b></div>
              <div><small>تعداد معاملات</small><br><b>${n(trades.length)}</b></div>
            </div>
            <h5>حساب‌های معاملاتی:</h5>
            ${accList}
          </div>
        `;
      } catch (err) { toast(err.message, 'error'); }
      finally { setBusy(loadBtn, false); }
    });

    loginBtn?.addEventListener('click', async () => {
      const uid = sel.value;
      if (!uid) return;
      setBusy(loginBtn, true);
      try {
        const res = await api(`/api/admin/users/${uid}/journal/login-as`, { method: 'POST' });
        toast(`نشست جدید برای کاربر ${res.user?.name} فعال شد.`);
        window.open(res.redirectUrl || '/index.html#journal', '_blank');
      } catch (err) { toast(err.message, 'error'); }
      finally { setBusy(loginBtn, false); }
    });
  }, 20);

  return html;
}

async function openTradeDetailsModal(tradeId) {
  try {
    const res = await api(`/api/admin/journal/trades/${tradeId}`);
    const t = res.trade || {};
    const media = res.media || [];
    const p = t.payload || {};
    const isWin = t.result_type === 'profit' || Number(t.amount || 0) >= 0;

    const mediaHtml = media.map(m => `
      <div style="margin-top:12px">
        <small>${escapeHtml(m.original_name)}</small><br>
        <img src="/api/media/${m.id}" alt="Trade media" style="max-width:100%; max-height:240px; border-radius:8px; border:1px solid #1e2f42; margin-top:4px">
      </div>
    `).join('') || '<p style="color:var(--txt-dim, #64748b)">تصویری ثبت نشده است.</p>';

    openModal(`
      <header class="modal-head">
        <div><h3>جزئیات کامل معامله ${escapeHtml(t.symbol || '')}</h3><span class="modal-subtitle">شناسه: <code>${escapeHtml(t.id)}</code></span></div>
        <button class="modal-close" data-close-modal data-icon="close"></button>
      </header>
      <div class="modal-body">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px">
          <div><small>معامله‌گر:</small><br><b>${escapeHtml(t.user_name || '—')}</b> (${escapeHtml(t.user_mobile || '')})</div>
          <div><small>حساب معاملاتی:</small><br><b>${escapeHtml(t.account_name || '—')}</b></div>
          <div><small>جهت / ستاپ:</small><br><b>${(t.direction || 'BUY').toUpperCase()}</b> — ${escapeHtml(p.setupName || p.setup || '—')}</div>
          <div><small>سود / زیان:</small><br><b style="color:${isWin ? '#00ff88' : '#ef4444'}">${isWin ? '+' : ''}$${n(Number(t.amount || 0).toFixed(2))}</b></div>
          <div><small>تایم‌فریم:</small><br><b>${escapeHtml(p.timeframe || '—')}</b></div>
          <div><small>حجم پوزیشن:</small><br><b>${escapeHtml(p.positionSize || p.lot || '—')}</b></div>
        </div>
        ${p.notes ? `<div style="margin-bottom:16px"><b>یادداشت معامله:</b><p style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; margin-top:4px">${escapeHtml(p.notes)}</p></div>` : ''}
        <div><b>تصاویر و مستندات:</b>${mediaHtml}</div>
      </div>
      <div class="modal-foot">
        <button class="ghost-btn" data-close-modal>بستن</button>
      </div>
    `);
  } catch (err) { toast(err.message, 'error'); }
}
