/* ==========================================================================
   SmartJournal — هدر شناورِ جذاب برای موبایل (صفحهٔ اصلی / لندینگ)
   --------------------------------------------------------------------------
   درخواست کاربر: «هدر سایت رو برای گوشی جذاب کن».
   قبل: روی موبایل فقط لوگو + دکمهٔ منو بود؛ دکمهٔ «ورود» کاملاً پنهان می‌شد.
   بعد: نوار شناور شیشه‌ای با لبهٔ گرد، هالهٔ نبض‌دار دور لوگو، نام برندِ
   گرادیانی، دکمهٔ ورودِ قرصی و دکمهٔ منوی دایره‌ای که موقع باز شدن به ×
   تبدیل می‌شود. فقط در عرض‌های ≤۹۲۰px اعمال می‌شود و به دسکتاپ دست نمی‌زند.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__PA_LANDING_HEADER_POLISH__) return;
  window.__PA_LANDING_HEADER_POLISH__ = true;

  var css = `
@media (max-width:920px){
  /* — نوار شناور شیشه‌ای با لبهٔ گرد — */
  .pa-l-nav{
    top:calc(10px + env(safe-area-inset-top,0px));
    border-radius:18px;
    border:1px solid rgba(255,255,255,.075)!important;
    background:linear-gradient(180deg, rgba(8,12,20,.88), rgba(8,12,20,.7))!important;
    -webkit-backdrop-filter:blur(22px) saturate(160%)!important;
    backdrop-filter:blur(22px) saturate(160%)!important;
    box-shadow:0 18px 44px -22px rgba(0,0,0,.9), 0 1px 0 rgba(255,255,255,.06) inset;
  }
  .pa-l-nav::after{
    content:"";position:absolute;left:16px;right:16px;bottom:0;height:1px;pointer-events:none;
    background:linear-gradient(90deg, transparent, rgba(37,213,237,.55) 30%, rgba(132,108,255,.5) 70%, transparent);
    opacity:.85;
  }
  .pa-l-nav-inner{min-height:62px;gap:10px;padding:0 14px;justify-content:space-between}
  #pa-landing.is-scrolled .pa-l-nav{
    background:linear-gradient(180deg, rgba(8,12,20,.96), rgba(8,12,20,.86))!important;
    box-shadow:0 22px 50px -24px rgba(0,0,0,.95), 0 1px 0 rgba(255,255,255,.07) inset;
  }
  #pa-landing.is-scrolled .pa-l-nav-inner{min-height:56px}

  /* — لوگو با هالهٔ نبض‌دار — */
  .pa-l-logo{width:38px;height:38px}
  .pa-l-logo::before{
    content:"";position:absolute;inset:-4px;border-radius:16px;
    border:1px solid rgba(37,213,237,.42);
    animation:paHeaderRing 2.8s ease-in-out infinite;
  }
  @keyframes paHeaderRing{
    0%,100%{transform:scale(1);opacity:.55}
    50%{transform:scale(1.07);opacity:.1}
  }

  /* — نام برندِ گرادیانی — */
  .pa-l-brand{gap:11px}
  .pa-l-brand-copy b{
    font-size:12.5px;letter-spacing:.1em;
    background:linear-gradient(92deg,#f2f8ff 0%,#cfeef7 45%,#7ee7f5 100%);
    -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;
    filter:drop-shadow(0 0 14px rgba(37,213,237,.28));
  }

  /* — دکمهٔ ورود: قرصِ گرادیانی (قبلاً روی موبایل کاملاً پنهان بود) — */
  .pa-l-nav-actions{gap:9px}
  .pa-l-nav-actions .pa-l-nav-btn{
    display:inline-flex!important;
    min-height:38px;padding:0 15px;gap:6px;
    border:1px solid rgba(37,213,237,.45);border-radius:999px;
    color:#c9fbff;font-size:11.5px;
    background:linear-gradient(135deg, rgba(37,213,237,.22), rgba(70,227,155,.13));
    box-shadow:0 10px 26px -12px rgba(37,213,237,.65);
  }
  .pa-l-nav-actions .pa-l-nav-btn span{display:inline!important}
  .pa-l-nav-actions .pa-l-nav-btn:hover{
    background:linear-gradient(135deg, rgba(37,213,237,.34), rgba(70,227,155,.22));
    border-color:rgba(37,213,237,.7);transform:translateY(-1px);
  }
  .pa-l-nav-actions .pa-l-nav-btn svg{width:14px;height:14px}

  /* — دکمهٔ منو: دایرهٔ شیشه‌ای که به × تبدیل می‌شود — */
  .pa-l-burger{
    width:40px;height:40px;border-radius:999px;gap:4px;
    border:1px solid rgba(37,213,237,.32);
    background:linear-gradient(140deg, rgba(37,213,237,.15), rgba(132,108,255,.12) 55%, rgba(255,255,255,.045));
    box-shadow:0 0 22px -8px rgba(37,213,237,.6), 0 10px 22px -14px #000;
    transition:transform .18s ease, border-color .18s ease;
  }
  .pa-l-burger span{width:17px;height:2px;background:linear-gradient(90deg,#bff4fd,#7ee7f5);border-radius:2px}
  .pa-l-burger:active{transform:scale(.92)}
  .pa-l-burger[aria-expanded="true"]{border-color:rgba(255,255,255,.22)}
  .pa-l-burger[aria-expanded="true"] span:nth-child(1){transform:translateY(6px) rotate(45deg)}
  .pa-l-burger[aria-expanded="true"] span:nth-child(2){opacity:0}
  .pa-l-burger[aria-expanded="true"] span:nth-child(3){transform:translateY(-6px) rotate(-45deg)}

  /* — منوی موبایل هم‌خانوادهٔ هدر — */
  .pa-l-mobile{
    padding-top:calc(96px + env(safe-area-inset-top,0px));
    background:
      radial-gradient(circle at 82% 0%, rgba(37,213,237,.09), transparent 42%),
      radial-gradient(circle at 10% 92%, rgba(132,108,255,.11), transparent 40%),
      rgba(4,7,12,.96);
  }

  /* — گوشی‌های خیلی باریک: دکمهٔ ورود فقط آیکن — */
  @media(max-width:380px){
    .pa-l-nav-actions .pa-l-nav-btn span{display:none!important}
    .pa-l-nav-actions .pa-l-nav-btn{width:40px;padding:0;justify-content:center}
    .pa-l-brand-copy b{font-size:11px}
    .pa-l-nav-inner{padding:0 10px;gap:8px}
  }
}
@media (prefers-reduced-motion: reduce){
  .pa-l-logo::before{animation:none}
}
`;
  var style = document.createElement('style');
  style.id = 'pa-landing-header-polish';
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);
})();
