/* ==========================================================================
   محتوای قابل‌ویرایش سایت + بخش اعتمادسازی
   - متن‌هایی که مدیر از پنل عوض کرده را روی صفحه اعمال می‌کند
   - نظرات کاربران و آمار اعتماد را زیر بخش قابلیت‌ها می‌سازد
   ========================================================================== */
(function () {
  'use strict';
  if (window.__PA_SITE_CONTENT__) return;
  window.__PA_SITE_CONTENT__ = true;
  if (location.protocol === 'file:') return;

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ------------------------------------------------ متن‌های سفارشی مدیر -- */
  var customTexts = [];

  function paint() {
    if (!customTexts.length) return;
    customTexts.forEach(function (row) {
      try {
        var el = document.querySelector(row.selector);
        if (el && el.textContent.trim() !== row.value) el.textContent = row.value;
      } catch (e) { /* سلکتور نامعتبر را بی‌سروصدا رد کن */ }
    });
  }

  function applyTexts() {
    fetch('/api/public/site-texts', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !Array.isArray(data.rows) || !data.rows.length) return;
        customTexts = data.rows;
        paint();

        /* چند اسکریپت دیگر (مثل برند و منوی CMS) بعد از ما بخش‌هایی از صفحه را
           دوباره می‌سازند، پس متن‌ها را دوباره اعمال می‌کنیم و تغییرات DOM را
           هم زیر نظر می‌گیریم. */
        [120, 400, 900, 2000, 4000].forEach(function (ms) { setTimeout(paint, ms); });

        var host = document.getElementById('pa-landing') || document.body;
        var queued = false;
        new MutationObserver(function () {
          if (queued) return;
          queued = true;
          requestAnimationFrame(function () { queued = false; paint(); });
        }).observe(host, { childList: true, subtree: true, characterData: true });
      })
      .catch(function () {});
  }

  /* ----------------------------------------------------- اعتمادسازی ----- */
  if (!document.getElementById('pa-trust-styles')) {
    var style = document.createElement('style');
    style.id = 'pa-trust-styles';
    style.textContent = [
      '#pa-l-trust{padding:0 0 20px}',
      '.pa-trust-badges{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:34px}',
      '.pa-trust-badge{display:flex;align-items:center;gap:12px;padding:16px 18px;border-radius:16px;',
      'border:1px solid rgba(137,158,190,.16);background:rgba(255,255,255,.022)}',
      '.pa-trust-badge i{font-style:normal;font-size:22px;line-height:1}',
      '.pa-trust-badge b{display:block;font:800 17px/1.2 Vazirmatn;color:#eaf7ff;margin-bottom:3px}',
      '.pa-trust-badge span{font:400 10px/1.5 Vazirmatn;color:#8497aa}',
      '.pa-trust-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:13px}',
      '.pa-trust-card{display:flex;flex-direction:column;gap:12px;padding:20px;border-radius:18px;',
      'border:1px solid rgba(137,158,190,.16);background:linear-gradient(160deg,rgba(255,255,255,.03),rgba(255,255,255,.01));',
      'transition:border-color .2s,transform .2s}',
      '.pa-trust-card:hover{border-color:rgba(37,213,237,.32);transform:translateY(-2px)}',
      '.pa-trust-stars{color:#f5be50;font-size:13px;letter-spacing:2px;line-height:1}',
      '.pa-trust-body{font:400 11.5px/2.1 Vazirmatn;color:#c3d2e2;margin:0}',
      '.pa-trust-person{display:flex;align-items:center;gap:11px;margin-top:auto;padding-top:6px}',
      '.pa-trust-avatar{flex:none;display:grid;place-items:center;width:40px;height:40px;border-radius:50%;',
      'font:700 14px Vazirmatn;color:#04252b;background:linear-gradient(135deg,#25d5ed,#46e39b)}',
      '.pa-trust-avatar img{width:100%;height:100%;border-radius:50%;object-fit:cover}',
      '.pa-trust-person b{display:block;font:600 11px Vazirmatn;color:#eaf2ff}',
      '.pa-trust-person small{font:400 9px Vazirmatn;color:#75879c}',
      '.pa-trust-note{margin-top:22px;padding:14px 16px;border-radius:14px;text-align:center;',
      'border:1px solid rgba(70,227,155,.24);background:rgba(70,227,155,.06);',
      'font:500 10.5px/1.9 Vazirmatn;color:#9fe9c6}',
      '@media(max-width:640px){.pa-trust-grid{grid-template-columns:1fr}}',
    ].join('');
    document.head.appendChild(style);
  }

  function stars(n) {
    var full = Math.max(1, Math.min(5, Number(n) || 5));
    return '★★★★★'.slice(0, full) + '☆☆☆☆☆'.slice(0, 5 - full);
  }

  function renderTrust(data) {
    var host = document.getElementById('pa-l-features');
    if (!host || document.getElementById('pa-l-trust')) return;
    var rows = data.rows || [];
    var badges = data.badges || [];
    if (!rows.length && !badges.length) return;

    var section = document.createElement('section');
    section.id = 'pa-l-trust';
    section.className = 'pa-l-shell pa-l-section';

    var badgeHtml = badges.length ? '<div class="pa-trust-badges">' + badges.map(function (b) {
      return '<div class="pa-trust-badge"><i>' + esc(b.icon) + '</i><div>'
        + '<b>' + esc(b.value) + '</b><span>' + esc(b.label) + '</span></div></div>';
    }).join('') + '</div>' : '';

    var cards = rows.map(function (t) {
      var initial = esc(String(t.name || '؟').trim().charAt(0));
      var avatar = t.avatar_url
        ? '<span class="pa-trust-avatar"><img src="' + esc(t.avatar_url) + '" alt="' + esc(t.name) + '"></span>'
        : '<span class="pa-trust-avatar">' + initial + '</span>';
      return '<article class="pa-trust-card">'
        + '<div class="pa-trust-stars" aria-label="' + esc(t.rating) + ' از ۵">' + stars(t.rating) + '</div>'
        + '<p class="pa-trust-body">' + esc(t.body) + '</p>'
        + '<div class="pa-trust-person">' + avatar
        + '<div><b>' + esc(t.name) + '</b><small>' + esc(t.role) + '</small></div></div>'
        + '</article>';
    }).join('');

    section.innerHTML =
      '<div class="pa-l-section-head">'
      + '<span class="pa-l-kicker">TRUSTED BY TRADERS</span>'
      + '<h2>معامله‌گرها چه می‌گویند</h2>'
      + '<p>تجربه‌ی کسانی که ژورنال‌نویسی را از اکسل و کاغذ به SmartJournal منتقل کردند.</p>'
      + '</div>'
      + badgeHtml
      + '<div class="pa-trust-grid">' + cards + '</div>'
      + '<div class="pa-trust-note">۷ روز دسترسی کامل و رایگان به همه امکانات — بدون نیاز به کارت بانکی. '
      + 'داده‌های شما رمزنگاری‌شده ذخیره می‌شود و هر زمان بخواهید کامل قابل خروج گرفتن است.</div>';

    host.insertAdjacentElement('afterend', section);
  }

  function loadTrust() {
    fetch('/api/public/testimonials', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) { if (d) renderTrust(d); })
      .catch(function () {});
  }

  function boot() {
    applyTexts();
    loadTrust();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
