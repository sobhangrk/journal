(function(){
  'use strict';
  if(window.__SMARTJOURNAL_BRAND__)return;window.__SMARTJOURNAL_BRAND__=true;
  var style=document.createElement('style');
  style.id='smartjournal-brand-styles';
  style.textContent=`
.smartjournal-logo-mark{overflow:hidden!important;color:transparent!important;text-shadow:none!important;background-color:#071321!important;background-image:url('/media/smartjournal-logo-192.webp')!important;background-position:center!important;background-repeat:no-repeat!important;background-size:cover!important;border-color:rgba(111,247,235,.4)!important;box-shadow:0 0 24px -10px rgba(79,245,229,.8)!important;font-size:0!important}
.smartjournal-logo-mark::before,.smartjournal-logo-mark::after{display:none!important}
.pa-l-logo.smartjournal-logo-mark,.pa-a-logo.smartjournal-logo-mark,.pa-brand-mark.smartjournal-logo-mark{border-radius:13px!important}
.brand-mark.smartjournal-logo-mark,.login-brand>span.smartjournal-logo-mark,.boot-logo.smartjournal-logo-mark{border-radius:12px!important}
`;
  document.head.appendChild(style);
  var selector='.pa-l-logo,.pa-a-logo,.pa-brand-mark,.brand-mark,.login-brand>span,.boot-logo';
  function apply(root){
    var nodes=[];if(root&&root.nodeType===1&&root.matches&&root.matches(selector))nodes.push(root);
    Array.prototype.push.apply(nodes,(root||document).querySelectorAll?Array.prototype.slice.call((root||document).querySelectorAll(selector)):[]);
    nodes.forEach(function(node){if(node.classList.contains('smartjournal-logo-mark'))return;node.classList.add('smartjournal-logo-mark');node.textContent='';node.setAttribute('role','img');node.setAttribute('aria-label','لوگوی SmartJournal');node.title='SmartJournal'});
    Array.prototype.forEach.call((root||document).querySelectorAll?((root||document).querySelectorAll('.pa-l-brand-copy b,.pa-a-brand-copy b,.brand>div>b,.login-brand>div>b')):[],function(node){if(node.textContent.trim()!=='SMARTJOURNAL')node.textContent='SMARTJOURNAL'});
  }
  var queued=false;new MutationObserver(function(records){if(queued)return;queued=true;requestAnimationFrame(function(){queued=false;records.forEach(function(record){Array.prototype.forEach.call(record.addedNodes,function(node){if(node.nodeType===1)apply(node)})});apply(document)})}).observe(document.documentElement,{subtree:true,childList:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){apply(document)});else apply(document);
})();
