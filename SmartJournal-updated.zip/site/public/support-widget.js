/* ==========================================================================
   پشتیبانی و شبکه‌های اجتماعی

   ۱) دکمه‌ی شناور گوشه‌ی صفحه که با اسکرول سر جایش می‌ماند و با کلیک،
      راه‌های ارتباطی (تلگرام، اینستاگرام و …) را باز می‌کند.
   ۲) همان لینک‌ها را زیر کارت «تماس و پشتیبانی» صفحه‌ی اصلی هم می‌گذارد.

   آدرس‌ها از پنل مدیریت می‌آیند (/api/public/social-links) و مدیر می‌تواند
   هر تعداد را اضافه/کم/خاموش کند. اگر هیچ لینک منتشرشده‌ای نباشد، هیچ چیزی
   نمایش داده نمی‌شود (نه دکمه‌ی خالی، نه جای خالی).
   ========================================================================== */
(function () {
  'use strict';
  if (window.__PA_SUPPORT_WIDGET__) return;
  window.__PA_SUPPORT_WIDGET__ = true;
  if (location.protocol === 'file:') return;
  /* داخل پنل مدیریت لازم نیست */
  if (location.pathname.indexOf('/admin') === 0) return;

  var esc = function (v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  /* ------------------------------------------------------------ آیکون‌ها -- */
  var ICONS = {
    telegram: '<path d="M21.5 4.3 2.9 11.5c-1.1.4-1.1 1.1-.2 1.4l4.7 1.5 1.8 5.5c.2.6.4.8.8.8.4 0 .6-.2.9-.5l2.3-2.2 4.8 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.9-1.3-1.6Z"/>',
    instagram: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor" stroke="none"/>',
    whatsapp: '<path d="M20.5 11.6a8.4 8.4 0 0 1-12.4 7.4L3.5 20.5l1.6-4.5A8.4 8.4 0 1 1 20.5 11.6Z"/><path d="M8.8 9.2c.2-.5.4-.5.7-.5h.5c.2 0 .4 0 .6.5l.7 1.6c.1.3 0 .5-.1.7l-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2 1.1 1 2 1.3 2.3 1.4.2.1.4 0 .6-.1l.6-.7c.2-.2.4-.2.6-.1l1.6.8c.3.1.4.3.4.5 0 .3-.2 1-.5 1.3-.3.3-1 .7-1.7.7-1.6 0-3.6-1-5.1-2.5-1.5-1.5-2.6-3.4-2.6-4.9 0-.7.3-1.3.6-1.7Z" fill="currentColor" stroke="none"/>',
    eitaa: '<circle cx="12" cy="12" r="9"/><path d="M8 13.5 12 8l4 5.5-4 2.5-4-2.5Z"/>',
    bale: '<circle cx="12" cy="12" r="9"/><path d="M8.5 12.5 11 15l4.5-5.5"/>',
    rubika: '<circle cx="12" cy="12" r="9"/><path d="M9 15V9l6 3-6 3Z"/>',
    youtube: '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10.5 9.5v5l4.5-2.5-4.5-2.5Z" fill="currentColor" stroke="none"/>',
    aparat: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.2"/>',
    x: '<path d="m4 4 16 16M20 4 4 20"/>',
    linkedin: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 10v7M8 7v.01M12 17v-4a2 2 0 0 1 4 0v4"/>',
    email: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
    phone: '<path d="M5 4h3l2 5-2 1a11 11 0 0 0 5 5l1-2 5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/>',
    website: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18"/>',
    custom: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8m-4-4h8"/>'
  };
  var BRAND = {
    telegram: '#29b6f6', instagram: '#e1447f', whatsapp: '#25d366', eitaa: '#f5a623',
    bale: '#4fc3f7', rubika: '#8b5cf6', youtube: '#f43f5e', aparat: '#f97316',
    x: '#cbd5e1', linkedin: '#38bdf8', email: '#67e8f9', phone: '#34d399',
    website: '#67e8f9', custom: '#67e8f9'
  };
  function icon(platform, size) {
    var d = ICONS[platform] || ICONS.custom;
    return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" '
      + 'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" '
      + 'aria-hidden="true">' + d + '</svg>';
  }

  /* -------------------------------------------------------------- استایل -- */
  function injectStyles() {
    if (document.getElementById('pa-support-styles')) return;
    var st = document.createElement('style');
    st.id = 'pa-support-styles';
    st.textContent = [
      '.pa-sup{position:fixed;left:18px;bottom:18px;z-index:2147483000;',
      '  display:flex;flex-direction:column-reverse;align-items:flex-start;gap:10px;',
      '  font-family:inherit;direction:rtl}',
      '.pa-sup[hidden]{display:none}',
      '.pa-sup-fab{display:grid;place-items:center;width:54px;height:54px;padding:0;',
      '  border:1px solid rgba(103,232,249,.42);border-radius:50%;cursor:pointer;',
      '  color:#04222b;background:linear-gradient(135deg,#7ae9f6,#22d3ee 58%,#0e94b5);',
      '  box-shadow:0 14px 34px -12px rgba(34,211,238,.75),0 3px 10px rgba(0,0,0,.5);',
      '  transition:transform .18s ease,box-shadow .18s ease}',
      '.pa-sup-fab:hover{transform:translateY(-2px) scale(1.04)}',
      '.pa-sup-fab:focus-visible{outline:3px solid #fbbf24;outline-offset:3px}',
      '.pa-sup-fab .close{display:none}',
      '.pa-sup.open .pa-sup-fab .open-i{display:none}',
      '.pa-sup.open .pa-sup-fab .close{display:block}',
      '.pa-sup-pulse{position:absolute;inset:0;border-radius:50%;pointer-events:none;',
      '  box-shadow:0 0 0 0 rgba(34,211,238,.55);animation:paSupPulse 2.8s ease-out infinite}',
      '@keyframes paSupPulse{70%{box-shadow:0 0 0 16px rgba(34,211,238,0)}100%{box-shadow:0 0 0 0 rgba(34,211,238,0)}}',
      '.pa-sup-panel{display:none;width:min(268px,calc(100vw - 36px));padding:13px;',
      '  border:1px solid rgba(120,150,185,.26);border-radius:17px;',
      '  background:linear-gradient(160deg,rgba(17,26,41,.98),rgba(8,13,22,.99));',
      '  box-shadow:0 26px 60px -26px #000;backdrop-filter:blur(16px)}',
      '.pa-sup.open .pa-sup-panel{display:block;animation:paSupIn .18s ease both}',
      '@keyframes paSupIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
      '.pa-sup-title{margin:0 0 3px;color:#eaf3fb;font-size:12.5px;font-weight:800}',
      '.pa-sup-sub{margin:0 0 11px;color:#8fa0b6;font-size:10px;line-height:1.9}',
      '.pa-sup-link{display:flex;align-items:center;gap:10px;margin-top:7px;padding:9px 11px;',
      '  border:1px solid #26364c;border-radius:12px;color:#dbe6f2;background:rgba(255,255,255,.025);',
      '  text-decoration:none;transition:.16s}',
      '.pa-sup-link:hover{border-color:rgba(103,232,249,.5);background:rgba(34,211,238,.08);transform:translateX(-2px)}',
      '.pa-sup-link i{display:grid;place-items:center;width:30px;height:30px;flex:none;border-radius:9px;',
      '  background:rgba(255,255,255,.06)}',
      '.pa-sup-link b{display:block;font-size:11px;font-weight:700}',
      '.pa-sup-link small{display:block;margin-top:2px;color:#7e90a6;font-size:9px;direction:ltr;text-align:right}',
      '@media (max-width:520px){.pa-sup{left:12px;bottom:12px}',
      '  .pa-sup-fab{width:48px;height:48px}}',
      '@media print{.pa-sup{display:none!important}}',
      /* لینک‌های داخل کارت تماس صفحه اصلی */
      '.pa-social-row{display:flex;flex-wrap:wrap;gap:9px;margin-top:13px}',
      '.pa-social-chip{display:inline-flex;align-items:center;gap:8px;padding:9px 13px;',
      '  border:1px solid #27384f;border-radius:999px;color:#d9e5f2;background:rgba(255,255,255,.03);',
      '  text-decoration:none;font-size:11.5px;transition:.16s}',
      '.pa-social-chip:hover{border-color:rgba(103,232,249,.55);background:rgba(34,211,238,.09);',
      '  transform:translateY(-1px)}',
      '.pa-social-chip svg{flex:none}'
    ].join('');
    document.head.appendChild(st);
  }

  /* ------------------------------------------------------------- ساخت UI -- */
  function buildWidget(rows) {
    var list = rows.filter(function (r) { return r.show_widget !== false; });
    if (!list.length) return;
    var old = document.getElementById('pa-support-widget');
    if (old) old.remove();

    var wrap = document.createElement('div');
    wrap.className = 'pa-sup';
    wrap.id = 'pa-support-widget';
    wrap.innerHTML =
      '<button class="pa-sup-fab" type="button" aria-expanded="false" aria-controls="pa-sup-panel"'
      + ' aria-label="راه‌های ارتباط با پشتیبانی"><span class="pa-sup-pulse"></span>'
      + '<span class="open-i">' + icon('phone', 23) + '</span>'
      + '<span class="close"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor"'
      + ' stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></span></button>'
      + '<div class="pa-sup-panel" id="pa-sup-panel" role="dialog" aria-label="ارتباط با پشتیبانی">'
      + '<p class="pa-sup-title">با ما در ارتباط باش</p>'
      + '<p class="pa-sup-sub">هر سؤالی داری همین‌جا بپرس؛ سریع جواب می‌دهیم.</p>'
      + list.map(function (r) {
        var color = BRAND[r.platform] || BRAND.custom;
        return '<a class="pa-sup-link" href="' + esc(r.url) + '" target="_blank" rel="noopener noreferrer">'
          + '<i style="color:' + color + '">' + icon(r.platform, 17) + '</i>'
          + '<span><b>' + esc(r.label) + '</b>'
          + (r.handle ? '<small>' + esc(r.handle) + '</small>' : '') + '</span></a>';
      }).join('')
      + '</div>';
    document.body.appendChild(wrap);

    /* وقتی کاربر داخل خودِ اپ ژورنال است، دکمه را پنهان می‌کنیم تا روی
       ابزارهای برنامه نیفتد؛ در لندینگ و صفحات عمومی نمایش داده می‌شود. */
    var vis = function (el) {
      if (!el) return false;
      var cs = getComputedStyle(el);
      return cs.display !== 'none' && cs.visibility !== 'hidden' && el.getClientRects().length > 0;
    };
    /* هشدار عملکردی: MutationObserver روی کل درخت + خواندن layout در هر
       تغییر، اپ ری‌اکت را قفل می‌کند (با تست واقعی دیده شد). به‌جایش یک
       بررسی سبک با فاصله‌ی زمانی و روی رویدادهای ناوبری انجام می‌دهیم. */
    var lastState = null;
    var syncVisibility = function () {
      var inApp = vis(document.querySelector('#root .pa-app'))
        || vis(document.querySelector('.pa-app-shell'));
      if (inApp === lastState) return;
      lastState = inApp;
      wrap.hidden = !!inApp;
    };
    syncVisibility();
    setInterval(syncVisibility, 1200);
    ['popstate', 'hashchange', 'pageshow'].forEach(function (ev) {
      window.addEventListener(ev, function () { setTimeout(syncVisibility, 120); });
    });
    document.addEventListener('click', function () { setTimeout(syncVisibility, 250); }, true);

    var fab = wrap.querySelector('.pa-sup-fab');
    var setOpen = function (on) {
      wrap.classList.toggle('open', on);
      fab.setAttribute('aria-expanded', String(on));
    };
    fab.addEventListener('click', function () { setOpen(!wrap.classList.contains('open')); });
    document.addEventListener('click', function (e) {
      if (!wrap.contains(e.target)) setOpen(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setOpen(false);
    });
  }

  /* لینک‌ها را زیر کارت «تماس و پشتیبانی» صفحه اصلی هم می‌گذاریم */
  function paintContactSection(rows) {
    if (!rows.length) return;
    var host = document.querySelector('.pa-l-more-links');
    if (!host) return;
    var old = document.getElementById('pa-social-row');
    if (old) old.remove();
    var row = document.createElement('div');
    row.className = 'pa-social-row';
    row.id = 'pa-social-row';
    row.innerHTML = rows.map(function (r) {
      var color = BRAND[r.platform] || BRAND.custom;
      return '<a class="pa-social-chip" href="' + esc(r.url) + '" target="_blank" rel="noopener noreferrer">'
        + '<span style="color:' + color + ';display:flex">' + icon(r.platform, 15) + '</span>'
        + esc(r.label) + '</a>';
    }).join('');
    host.appendChild(row);
  }

  function start() {
    fetch('/api/public/social-links', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        var rows = (data && Array.isArray(data.rows)) ? data.rows : [];
        if (!rows.length) return;              // مدیر هنوز آدرسی منتشر نکرده
        injectStyles();
        buildWidget(rows);
        paintContactSection(rows);
        /* لندینگ چند بار دوباره رندر می‌شود؛ چیپ‌ها را برمی‌گردانیم */
        [500, 1500, 3500].forEach(function (ms) {
          setTimeout(function () { paintContactSection(rows); }, ms);
        });
      })
      .catch(function () {});
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else start();
})();
