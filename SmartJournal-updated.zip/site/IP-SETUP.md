# راه‌اندازی بدون دامنه (فقط با IP)

بله، می‌شود. دامنه لازم نیست تا سایت را ببینید. کافی است در مرورگر بزنید:

```
http://<آی‌پی-سرور>
```

این حالت برای **تست و دیدن سایت** عالی است. برای معرفی به کاربران واقعی نه —
دلیلش پایین توضیح داده شده.

---

## گام‌به‌گام

### ۱) نصب پیش‌نیازها

```bash
ssh root@<IP>
bash server-setup.sh          # یا مراحل دستی DEPLOY.md
```

### ۲) آپلود کد

روی **کامپیوتر خودتان**:

```bash
scp SmartJournal-Platform.zip root@<IP>:/tmp/
```

روی **سرور**:

```bash
unzip /tmp/SmartJournal-Platform.zip -d /tmp/sj
cp -r /tmp/sj/platform/* /opt/smartjournal/
chown -R smartjournal:smartjournal /opt/smartjournal
cd /opt/smartjournal && sudo -u smartjournal npm ci --omit=dev
```

### ۳) تنظیم `.env` برای حالت IP

```bash
nano /opt/smartjournal/.env
```

این سه خط را مطابق IP خودتان بگذارید:

```ini
PUBLIC_BASE_URL=http://<IP>
WEBAUTHN_RP_ID=<IP>
WEBAUTHN_ORIGIN=http://<IP>

# 🔴 فقط تا وقتی دامنه و HTTPS ندارید:
COOKIE_SECURE=false
```

### ۴) اجرا

```bash
systemctl enable --now smartjournal
systemctl status smartjournal
```

### ۵) باز کردن در مرورگر

```
http://<IP>          صفحه اصلی
http://<IP>/journal  ژورنال
http://<IP>/admin    پنل مدیریت
```

---

## چرا `COOKIE_SECURE=false` لازم است؟

در حالت `production` کوکی نشست با پرچم **`Secure`** صادر می‌شود، یعنی مرورگر
آن را **فقط روی HTTPS** می‌فرستد. روی `http://IP` مرورگر کوکی را نگه نمی‌دارد و
نتیجه‌اش این است که:

* وارد پنل مدیریت می‌شوید ولی بلافاصله بیرون می‌افتید
* کاربر لاگین می‌کند ولی صفحه ژورنال دوباره فرم ورود را نشان می‌دهد

با `COOKIE_SECURE=false` این پرچم موقتاً برداشته می‌شود.

### تست‌شده

هر دو حالت روی PostgreSQL و `NODE_ENV=production` واقعی آزمایش شد:

| حالت | پرچم Secure | ورود روی HTTP |
|---|---|---|
| `COOKIE_SECURE=false` | خاموش | ✅ کار می‌کند (`/api/admin/me` → ۲۰۰) |
| پیش‌فرض production | روشن | ✅ درست — فقط HTTPS |

سرور هنگام بوت هم هشدار می‌دهد تا یادتان نرود:

```
WARN  insecure_cookies — COOKIE_SECURE=false — کوکی بدون HTTPS ارسال می‌شود.
      فقط برای تست موقت با IP؛ بعد از نصب دامنه و SSL حذفش کنید.
```

---

## ⚠️ محدودیت‌های حالت IP

| مورد | وضعیت |
|---|---|
| دیدن سایت و صفحات | ✅ کامل |
| پنل مدیریت | ✅ کامل |
| ثبت‌نام و ورود با پیامک | ✅ اگر درگاه پیامک تنظیم شده باشد |
| **رمزگذاری ترافیک** | ❌ همه‌چیز plain است — رمز عبور کاربران روی شبکه قابل شنود |
| ورود با اثر انگشت (WebAuthn) | ❌ مرورگر روی HTTP اجازه نمی‌دهد |
| نصب PWA روی موبایل | ❌ نیاز به HTTPS |
| نمایش «قفل» در مرورگر | ❌ «Not secure» نشان می‌دهد |

> 🔴 **کاربر واقعی را با IP دعوت نکنید.** این حالت فقط برای این است که خودتان
> ببینید همه‌چیز کار می‌کند. قبل از معرفی سایت، دامنه و HTTPS را راه بیندازید.

---

## بعد از گرفتن دامنه — ۳ کار

```bash
# ۱) گواهی رایگان
certbot --nginx -d yourdomain.ir -d www.yourdomain.ir

# ۲) اصلاح .env
nano /opt/smartjournal/.env
#    PUBLIC_BASE_URL=https://yourdomain.ir
#    WEBAUTHN_RP_ID=yourdomain.ir
#    WEBAUTHN_ORIGIN=https://yourdomain.ir
#    خط COOKIE_SECURE=false را کامل پاک کنید   ← مهم

# ۳) ری‌استارت
systemctl restart smartjournal
```

بررسی نهایی:

```bash
curl -sI https://yourdomain.ir | head -1        # باید 200 بدهد
cd /opt/smartjournal && npm run preflight:production
```

---

## عیب‌یابی سریع

| علامت | راه‌حل |
|---|---|
| مرورگر اصلاً وصل نمی‌شود | `ufw allow 80/tcp` · `systemctl status nginx` |
| صفحه ۵۰۲ Bad Gateway | برنامه بالا نیست: `journalctl -u smartjournal -n 50` |
| وارد پنل می‌شوم ولی بیرون می‌افتم | `COOKIE_SECURE=false` را نگذاشته‌اید |
| ثبت‌نام خطای ۵۰۳ | درگاه پیامک تنظیم نشده — `SMS.md` |
| صفحه سفید | `journalctl -u smartjournal -f` را ببینید |
