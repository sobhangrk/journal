<!-- PA_DOCS_INDEX -->
## 📁 راهنمای فایل‌های مستندات

| فایل | چه چیزی داخلش است |
|---|---|
| **`DEPLOY.md`** | نصب روی هاست واقعی — موانع، چک‌لیست، کانفیگ Nginx |
| **`HOSTING.md`** | مشخصات سرور موردنیاز بر اساس اندازه‌گیری واقعی |
| **`CARD-PAYMENTS.md`** | پرداخت کارت‌به‌کارت و تایید/رد فیش از پنل |
| **`WEBP.md`** | تبدیل خودکار تصاویر به WebP |
| **`FONTS.md`** | فونت محلی وزیرمتن (بدون وابستگی به گوگل) |
| **`SITE-CONTENT.md`** | ویرایش متن‌های سایت، نظرات کاربران و دوره آزمایشی |
| **`SPEED-NEXT.md`** | اندازه‌گیری سرعت، کارهای انجام‌شده و فهرست قدم‌های بعدی |
| **`PERFORMANCE-SPLIT.md`** | جداسازی باندل ژورنال از صفحهٔ اصلی — سرعت، کش و دستورها |
| **`BUGFIXES.md`** | فهرست باگ‌های پیداشده و رفع‌شده |
| **`.env.production.example`** | همه متغیرهای محیطی با توضیح |

### شروع سریع

```bash
npm install
npm start                      # http://localhost:3000
```

- سایت: `/` · ژورنال: `/journal` · پنل مدیریت: `/admin`
- حساب توسعه: `owner` / `09120000000` — رمز `Admin@12345`
- Owner در اولین ورود باید TOTP فعال کند (عمدی است)

### آزمون‌ها

```bash
npm run check           # بررسی نحوی همه ماژول‌ها
npm run smoke:admin     # ۳۹ آزمون پنل مدیریت
npm run smoke:auth      # ۲۶ آزمون امنیت احراز هویت
npm run smoke:journal   # ۲۶ آزمون Backend ژورنال
npm run smoke:cards     # ۳۰ آزمون کارت‌به‌کارت
npm run smoke:webp      # ۱۰ آزمون تبدیل WebP
npm run smoke:postgres  # اجرا روی PostgreSQL
npm run smoke:pg-cards  # ۱۲ آزمون کارت‌به‌کارت روی PostgreSQL
npm run capacity        # اندازه‌گیری مصرف حافظه و دیسک
npm run smoke:split     # ۳۳ آزمون جداسازی باندل صفحهٔ اصلی
npm run audit:speed     # اندازه‌گیری سرعت با مرورگر واقعی (موبایل کند)
npm run preflight:production   # دروازه آمادگی production
```

### بازسازی فایل‌های HTML

```bash
python3 scripts/build-index.py    # ساخت public/index.html از سه export
python3 scripts/rebuild-html.py   # ساخت public/admin/index.html بدون mock
npm run media:optimize            # تبدیل تصاویر جدید به WebP
```

---

# SmartJournal Platform 1.2 — ژورنال و پنل مدیریت Full‑Stack

نسخه Full‑Stack واقعی SmartJournal: ثبت‌نام و ورود کاربران، حساب‌ها، معاملات، تنظیمات، چک‌لیست‌ها، یادداشت‌ها و تصاویر ژورنال در Backend ذخیره و میان دستگاه‌ها همگام می‌شوند. پنل مدیریت مستقل `/admin` نیز RBAC، CMS، Audit و عملیات کامل مدیریتی را ارائه می‌دهد.

## قابلیت‌های اصلی

1. **ژورنال ابری کاربران:** ثبت‌نام و ورود سروری، نشست‌های چنددستگاهی، حساب‌های معاملاتی و معاملات نرمال‌شده، تنظیمات، چک‌لیست، بازبینی، مستندات و تصاویر محافظت‌شده.
2. **مهاجرت بدون حذف داده:** پس از اولین ورود/ثبت‌نام، داده موجود IndexedDB فقط در صورت خالی‌بودن حساب سروری به‌صورت خودکار منتقل می‌شود؛ فایل HTML در حالت `file:` همچنان fallback محلی دارد.
3. **همگام‌سازی مقاوم:** نسخه‌گذاری optimistic، جلوگیری از بازنویسی داده جدیدتر، cache محلی، صف تغییرات آفلاین و ارسال مجدد پس از اتصال.
4. **داشبورد:** کاربران، فعالیت، اشتراک و درآمد ماهانه، پیامک، خطاها، رشد و توزیع پلن‌ها.
5. **کاربران:** جست‌وجو، جزئیات، وضعیت حساب، خروج اجباری، بازیابی، مصرف فضا و حذف کنترل‌شده.
6. **دفترچه شماره کاربران:** همگام‌سازی خودکار کاربران ثبت‌نام‌شده، افزودن/ویرایش/حذف مخاطب مستقل، جست‌وجو و فیلتر، برچسب، یادداشت، رضایت پیامک و import/export استاندارد CSV.
7. **مالی:** پلن‌ها، اشتراک‌ها، پرداخت‌ها، فاکتور، کد تخفیف و بازپرداخت جزئی یا کامل.
8. **پیامک:** گزارش هزینه و خطا، OTP، محدودیت شماره/IP، تشخیص رفتار مشکوک و مدیریت ارائه‌دهنده.
9. **فایل و تصویر:** مصرف فضا، فایل یتیم، محدودیت فرمت/حجم، قرنطینه، بررسی و حذف امن.
10. **امنیت و Audit:** خطاها، تلاش‌های ورود، محدودیت‌ها، هشدارها و ثبت خودکار درخواست‌های احراز‌شده و عملیات حساس مدیران.
11. **تنظیمات:** ثبت‌نام، تعمیرات، OTP، فایل، قوانین، حریم خصوصی، راهنما، نسخه برنامه و اعلان‌ها.
12. **مدیران و RBAC پویا:** نقش‌های Owner، Admin، Support، Finance، Security و Content Manager؛ ماتریس ۱۸ مجوز؛ کنترل backend و مخفی‌سازی navigation/view/action در frontend؛ ابطال نشست‌های یک نقش پس از تغییر مجوز.
13. **حساب و credential مدیر:** تغییر نام، موبایل، username و رمز حساب جاری با رمز فعلی؛ مدیریت نام، موبایل، username، رمز، نقش و وضعیت سایر مدیران فقط توسط Owner.
14. **CMS نسخه‌دار:** صفحه و سکشن، تصویر و alt، SEO title/keywords، meta description، OG image، canonical URL، زمان انتشار/انقضا، ترتیب، draft/published/archive، تکثیر، تاریخچه و restore، منوهای سایت و پیش‌نمایش عمومی امن ۳۰دقیقه‌ای.
15. **خروجی عمومی امن CMS:** draft، محتوای آرشیوی و محتوای خارج از بازه زمان‌بندی از API عمومی و `/content/:slug` افشا نمی‌شود.
16. **احراز هویت حرفه‌ای کاربران:** ثبت‌نام با تأیید موبایل، ورود رمزی یا passwordless OTP، challenge دستگاه/IP جدید، حساب حساس با 2FA، بازیابی امن، اعلان ورود جدید، مدیریت دستگاه‌ها و نشست‌ها.
17. **CAPTCHA مشروط:** Cloudflare Turnstile فقط پس از رفتار مشکوک ظاهر می‌شود؛ Site Key و Secret از پنل قابل تنظیم‌اند و Secret رمزنگاری می‌شود.
18. **MFA اجباری Owner:** رمز عبور به‌تنهایی کافی نیست؛ Owner باید TOTP یا Passkey فعال کند و کدهای بازیابی یک‌بارمصرف دریافت می‌کند.
19. **تنظیم واقعی SMS:** کاوه‌نگار، ملی‌پیامک و Webhook سفارشی با failover، تست ارسال و credential رمزنگاری‌شده از پنل مدیریت.
20. **سایت بازاریابی و پشتیبانی:** landing سبک SSR، کارت و مقایسه پلن کاملاً دیتابیس‌محور، FAQ و بخش «چرا SmartJournal؟» قابل مدیریت، Footer چندستونه responsive، دموی تعاملی، تصاویر responsive واقعی محصول، درباره ما، تماس، شروع سریع و راهنماهای آموزشی.
21. **تجربه داخل ژورنال:** Onboarding چهارمرحله‌ای بعد از ثبت‌نام، تور قابل اجرای مجدد، Empty Stateهای راهنما، Skeleton Loading، پیام عملیات و خطای قابل‌فهم، وضعیت آفلاین، PWA shell محدود به `/journal` و احترام به reduced motion/دستگاه کم‌توان.
22. **دسترسی پلن به ژورنال:** مدیر با `billing.manage` مدت استاندارد صفر تا ۳۶۵۰ روز و وضعیت هر یک از ۱۱ بخش ژورنال را برای هر پلن تعیین می‌کند؛ انقضای اشتراک در entitlement مؤثر است، تب‌های غیرمجاز در frontend مخفی می‌شوند و عملیات نوشتن حساس در Backend مسدود می‌شوند.
23. **پشتیبانی تیکتی چندپیامی:** کاربر از داخل ژورنال تیکت می‌سازد، وضعیت و گفتگو را می‌بیند و پاسخ می‌دهد؛ مدیر مجاز پاسخ عمومی یا یادداشت داخلی جداگانه ثبت می‌کند، وضعیت و اولویت را تغییر می‌دهد و همه عملیات مدیریتی Audit می‌شوند.
24. **SEO و عملکرد:** URL تمیز، canonical، Open Graph، Schema.org محصول/FAQ، sitemap/robots، redirect استاندارد، 404 اختصاصی، AVIF/WebP، lazy loading و cache policy تفکیک‌شده برای HTML/API/media.

## فناوری و کنترل‌های امنیتی

- Node.js 20، Express 5 و PostgreSQL به‌عنوان runtime اصلی Production؛ SQLite فقط برای Development یا rollback کنترل‌شده
- bcrypt با ۱۲ دور برای hash رمز
- نشست تصادفی سمت سرور و Cookie از نوع `HttpOnly`، `SameSite=Strict` و `Secure` در Production
- CSRF token برای همه درخواست‌های تغییردهنده
- Rate limit ورود، Security Headers و CSP پنل
- Query پارامتری، escaping خروجی HTML و دیتابیس خارج از Public
- کنترل permission در تمام endpointهای مدیریت؛ Owner همیشه دسترسی کامل دارد
- جلوگیری از حذف آخرین Owner فعال و ابطال نشست پس از تغییر credential/نقش/وضعیت
- ثبت عملیات مدیران، CMS، منو، credential، permission و دفترچه کاربران در Audit Log
- نشست مستقل کاربران با Cookie امن `pa_user_session`، CSRF، rate limit و امکان ابطال یک یا همه دستگاه‌ها
- سیاست پیش‌فرض حداکثر ۵ دستگاه، اعتماد ۳۰روزه و OTP برای دستگاه یا ورود مشکوک جدید
- AES-256-GCM برای credential درگاه SMS، Secret ترنستایل و Secretهای TOTP در حالت at-rest
- WebAuthn/Passkey با user verification، TOTP با replay protection و recovery code هش‌شده برای مدیران
- قفل challenge مدیر پس از ۵ تلاش MFA ناموفق و چرخش دومرحله‌ای TOTP بدون غیرفعال‌کردن روش قبلی
- الزام رمز فعلی برای تنظیم مجدد/حذف TOTP، حذف Passkey و بازسازی recovery code
- محافظت SSRF برای Webhook پیامک با منع loopback، IP خصوصی و دامنه‌های resolve‌شونده به شبکه داخلی
- Owner در Backend بدون حداقل یک روش MFA فقط به endpointهای enrollment دسترسی دارد
- PostgreSQL schema مستقل `pa_journal`، advisory lock هنگام bootstrap، transaction واقعی و fail-closed بودن اجرای Production در صورت انتخاب SQLite
- bridge سازگاری SQL در Worker Thread برای حفظ API همگام دامنه فعلی؛ هر replica اتصال مستقل PostgreSQL دارد و state مشترک داخل دیتابیس/Redis نگهداری می‌شود
- جداول نرمال‌شده `journal_accounts` و `journal_trades` به‌همراه version registry برای کنترل تعارض
- تصاویر خارج از JSON و دیتابیس، داخل `UPLOAD_DIR`؛ تشخیص MIME از محتوای باینری، سهمیه پلن، checksum و مالکیت اجباری
- فایل‌های رسانه‌ای فقط از API احرازشده مالک قابل دریافت‌اند و پوشه Upload به‌صورت Static منتشر نمی‌شود
- محدودیت نوشتن اعمال‌شده توسط مدیر در Backend ژورنال enforce می‌شود
- entitlement مؤثر ژورنال از پلن فعال/آزمایشی و انقضای اشتراک محاسبه می‌شود؛ اشتراک منقضی به پلن رایگان fallback دارد
- دسترسی‌های پلن با کلیدهای `dashboard,new,history,calendar,prop,risk,checklist,documents,import,settings,pwa` در `plan_journal_sections` نگهداری می‌شوند
- پیام اولیه و ادامه گفتگوی تیکت در `support_messages` ذخیره می‌شوند؛ `is_internal` یادداشت مدیر را از پاسخ قابل مشاهده برای کاربر جدا می‌کند

## اجرا

```bash
npm install
npm start
```

بدون `DB_ENGINE`، اجرای Development برای سهولت از SQLite محلی استفاده می‌کند. در `NODE_ENV=production` برنامه به‌صورت fail-closed فقط با `DB_ENGINE=postgres` و `DATABASE_URL` یا مجموعه `PGHOST/PGDATABASE/PGUSER/PGPASSWORD` بالا می‌آید؛ `ALLOW_SQLITE_PRODUCTION=true` فقط برای rollback کوتاه و کنترل‌شده است.

آدرس‌ها:

- landing عمومی و indexable: `http://localhost:3000/`
- ژورنال کامل (عمداً `noindex`): `http://localhost:3000/journal`
- ورود/ثبت‌نام مستقیم: `/journal#login` و `/journal#signup`
- صفحات عمومی تمیز: `/pricing`، `/faq`، `/guides`، `/quick-start`، `/about` و `/contact`
- پنل مستقل: `http://localhost:3000/admin`
- Sitemap و robots: `/sitemap.xml` و `/robots.txt`
- Health Check: `http://localhost:3000/api/health`

### مسیر مخفی پنل

روی لوگوی **PA** در صفحه معرفی، ورود یا محیط ژورنال، در کمتر از ۴ ثانیه **۷ بار** کلیک/لمس کنید. این میان‌بر فقط `/admin` را باز می‌کند؛ احراز هویت همچنان الزامی است.

## حساب‌های توسعه

رمز همه حساب‌های seed: `Admin@12345`

| نقش | موبایل | username | دسترسی اصلی |
|---|---|---|---|
| Owner | `09120000000` | `owner` | دسترسی کامل و مدیریت مدیران/مجوزها |
| Admin | `09120000001` | `admin` | مدیریت عمومی مطابق ماتریس مجوز |
| Support | `09120000002` | `support` | کاربران و پشتیبانی؛ بدون endpoint یا داده مالی |
| Finance | `09120000003` | `finance` | پلن، اشتراک، پرداخت، فاکتور و بازپرداخت |
| Security | `09120000004` | `security` | خطا، Audit، محدودیت و فایل مشکوک |
| Content Manager | `09120000005` | `content` | CMS، قوانین، راهنما و اعلان؛ بدون تنظیمات عملیاتی |

در Development، Owner در اولین ورود مجبور به فعال‌سازی TOTP یا Passkey است. در Production فقط Owner اولیه از متغیرهای محیطی ساخته می‌شود و داده نمایشی باید غیرفعال باشد.

## endpointهای مهم

### احراز هویت کاربران

- `POST /api/auth/signup` سپس `POST /api/auth/signup/verify` — ساخت حساب پس از OTP و تأیید واقعی موبایل؛ payload ثبت‌نام باید `acceptTerms`، `acceptPrivacy` و `acceptDisclaimer` برابر `true` داشته باشد و `marketingConsent` مستقل و اختیاری است
- `POST /api/auth/login` سپس در صورت پاسخ `202`، مسیر `POST /api/auth/login/verify`
- `POST /api/auth/otp/request` و `POST /api/auth/otp/verify` — ورود passwordless
- `POST /api/auth/recovery/request|verify|reset` — بازیابی چندمرحله‌ای و ابطال همه نشست‌ها/دستگاه‌ها
- `GET /api/auth/security-config` — Site Key عمومی و policy بدون افشای Secret
- `GET /api/auth/me`، `POST /api/auth/logout` و `POST /api/auth/logout-all`
- `GET /api/auth/sessions` و `DELETE /api/auth/sessions/:id`
- `GET/PATCH/DELETE /api/auth/devices[/:id]` و `GET /api/auth/security-events`
- `PATCH /api/auth/profile` — تغییر نام و رمز با تأیید رمز فعلی و ابطال نشست‌های دیگر
- `POST /api/auth/mobile/request` و `POST /api/auth/mobile/verify` — تغییر موبایل با OTP شماره جدید

### Backend ژورنال

- `GET /api/journal/entitlements` — پلن مؤثر، اشتراک، تاریخ انقضا، روز باقی‌مانده، وضعیت همه ۱۱ بخش و `allowedSections`
- `GET /api/journal/summary` — شاخص‌ها، سهمیه و وضعیت داده سروری
- `GET/PUT/DELETE /api/journal/storage/:key` — لایه همگام‌سازی سازگار با اپ فعلی و Version Conflict
- `POST /api/journal/migrate` — مهاجرت امن داده قدیمی
- `GET/POST/PATCH/DELETE /api/journal/accounts[/:id]` — CRUD حساب‌های معاملاتی
- `GET/POST/PATCH/DELETE /api/journal/trades[/:id]` — CRUD معاملات و pagination
- `POST /api/journal/media` و `GET /api/journal/media/:id` — تصاویر خصوصی و احرازشده
- `GET/POST /api/journal/support/tickets` — فهرست و ساخت تیکت کاربر
- `GET /api/journal/support/tickets/:id` و `POST .../:id/messages` — مشاهده thread و ارسال پیام تکمیلی کاربر؛ یادداشت داخلی مدیر هرگز برگردانده نمی‌شود

داده‌های اصلی در `journal_accounts` و `journal_trades` نرمال می‌شوند. بخش‌های انعطاف‌پذیر مانند تنظیمات و چک‌لیست در `journal_preferences` قرار می‌گیرند. حذف تصویر یا معامله، reference فایل را orphan می‌کند تا سیاست cleanup تنظیم‌شده آن را پاک کند.

### مدیران و حساب

- `POST /api/admin/login` — فیلد `identifier` می‌تواند موبایل یا username باشد؛ در حساب MFA پاسخ اولیه `202` است
- `POST /api/admin/mfa/login/totp` و مسیرهای `.../passkey/options|verify` — تکمیل ورود دومرحله‌ای
- `GET /api/admin/mfa/status`، مسیرهای `mfa/totp/*`، `mfa/passkeys/*` و `mfa/recovery-codes/regenerate` — مدیریت MFA
- `GET/PATCH /api/admin/auth-security/settings` — سیاست دستگاه، OTP، CAPTCHA و اعلان ورود
- `PATCH /api/admin/profile` — نام، موبایل، username و رمز حساب جاری
- `GET/POST/PATCH /api/admin/sms/providers[/:id]` و `POST .../:id/test` — تنظیم و تست credential رمزنگاری‌شده SMS
- `GET/POST /api/admin/admins` و `PATCH /api/admin/admins/:id` — فقط Owner
- `GET /api/admin/role-permissions` و `PATCH /api/admin/role-permissions/:role` — فقط Owner

### دفترچه کاربران

- `GET/POST /api/admin/contacts`
- `PATCH/DELETE /api/admin/contacts/:id`
- `POST /api/admin/contacts/sync`
- `POST /api/admin/contacts/import`
- `GET /api/admin/contacts/export`

مخاطب متصل به کاربر ثبت‌نام‌شده حذف نمی‌شود؛ تغییر نام یا موبایل آن به رکورد کاربر نیز اعمال می‌شود.

### CMS

- صفحات: `GET/POST /api/admin/cms/pages` و `PATCH /api/admin/cms/pages/:id`
- سکشن‌ها: `/api/admin/cms/pages/:id/sections` و `/api/admin/cms/sections/:id`
- تکثیر: `POST .../pages/:id/duplicate` و `POST .../sections/:id/duplicate`
- نسخه‌ها: `GET /api/admin/cms/revisions/:entityType/:entityId` و `POST /api/admin/cms/revisions/:id/restore`
- منو: `GET/POST /api/admin/cms/menus` و `PATCH/DELETE /api/admin/cms/menus/:id`
- پیش‌نمایش: `POST /api/admin/cms/pages/:id/preview-token`
- عمومی: `GET /api/public/cms/:slug`، `GET /api/public/cms-menus/:key` و `GET /content/:slug`

### سایت عمومی، SEO و پشتیبانی

- `GET /` — landing سبک SSR؛ bundle کامل ژورنال را بارگذاری نمی‌کند
- `GET /journal` — برنامه کامل با `X-Robots-Tag: noindex, nofollow`، canonical ریشه و hash ورود/ثبت‌نام
- `GET /api/public/plans` — منبع runtime نام، معرفی، قیمت، ظرفیت، مدت استاندارد، دسترسی ۱۱ بخش ژورنال، نشان، CTA، ترتیب و قابلیت‌های مستقل پلن‌های فعال
- `GET /api/public/faqs` — سؤال‌های منتشرشده و مرتب‌شده صفحه اصلی و FAQ
- `GET/POST /api/admin/plans` و `PATCH/DELETE /api/admin/plans/:id` — CRUD پلن، مدت، دسترسی بخش‌های ژورنال و قابلیت‌ها با `billing.manage`
- `GET /api/admin/support/requests[/:id]`، `POST .../:id/messages` و `PATCH .../:id` — صف و thread تیکت، پاسخ عمومی/داخلی، وضعیت و اولویت با permission پشتیبانی و Audit
- `GET/POST /api/admin/marketing/faqs` و `PATCH/DELETE /api/admin/marketing/faqs/:id` — CRUD، انتشار و ترتیب سؤال‌ها با `content.manage`
- `POST /api/public/support` — ثبت درخواست عمومی با validation، honeypot، rate limit، reference پیگیری `PA-*` و نمایش permission-aware در صف پنل
- `POST /api/public/events` — فقط رخدادهای whitelist‌شده و بدون شناسه خام؛ landing هنگام DNT یا Global Privacy Control چیزی ارسال نمی‌کند
- `GET /sitemap.xml` و `GET /robots.txt` — با origin تنظیم‌شده در `PUBLIC_BASE_URL`

فایل‌های تصویر محصول در `public/media` دارای sourceهای AVIF/WebP، ابعاد صریح، `srcset` و lazy loading پایین صفحه‌اند. HTML عمومی cache کوتاه با stale-while-revalidate، API قیمت cache کوتاه و media دارای cache طولانی است؛ HTML ژورنال و endpointهای حساس cache عمومی نمی‌شوند. مسیرهای قدیمی `/content/{pricing,faq,about,contact,quick-start,guides}` به URL تمیز با `301` و slash انتهایی با `308` هدایت می‌شود.

برای اتصال ابزار وب‌مستر، token صادرشده را در `GOOGLE_SITE_VERIFICATION` یا `BING_SITE_VERIFICATION` قرار دهید، `PUBLIC_BASE_URL` را origin دقیق HTTPS تنظیم و deploy کنید؛ سپس مالکیت را در Google Search Console/Bing Webmaster تأیید و `${PUBLIC_BASE_URL}/sitemap.xml` را ثبت کنید. token خالی در preflight هشدار است، ولی origin غیر HTTPS و صندوق نامعتبر `SUPPORT_EMAIL` مانع استقرار می‌شوند.

## حقوقی، حریم خصوصی و دسترس‌پذیری

شش سند فارسی نسخه‌دار برای حوزه ایران شامل قوانین استفاده، حریم خصوصی، نگهداری داده، کوکی، قرارداد پردازش داده و سلب مسئولیت مالی در `legal-content.js` تعریف و با SHA-256 و نسخه immutable نگهداری می‌شوند.

- عمومی: `GET /api/public/legal`، `GET /api/public/legal/:type` و صفحه مستقل `/legal/:type`
- Privacy Center کاربر: `GET /api/auth/privacy-center`
- رضایت تبلیغاتی مستقل: `POST /api/auth/privacy/marketing-consent`
- دریافت نسخه داده: `POST /api/auth/privacy/export`
- درخواست/لغو حذف: `POST /api/auth/privacy/deletion-request` و `POST /api/auth/privacy/deletion-request/cancel`
- صف ادمین: `GET /api/admin/privacy/requests` و `PATCH /api/admin/privacy/requests/:id`
- مدیریت نسخه اسناد: `GET /api/admin/legal/documents` و `POST /api/admin/legal/documents/:type`

حذف ادمین فقط پس از درخواست صریح کاربر انجام می‌شود؛ داده عملیاتی و فایل‌ها حذف، اشتراک لغو و شناسه کاربر مستعار می‌شود، در حالی که سوابق مالی و evidence رضایت لازم برای تعهدات قانونی حفظ می‌شوند. مبنای retention: حذف عملیاتی حداکثر ۳۰ روز، backup حداکثر ۹۰ روز و لاگ امنیتی ۱۲ ماه است.

انتشار Production تا تنظیم `LEGAL_OPERATOR_NAME`، `LEGAL_OPERATOR_REGISTRATION`، `LEGAL_OPERATOR_ADDRESS` و `LEGAL_REVIEW_APPROVED=true` در preflight مسدود است.

سایت اصلی، `/journal` و `/admin` دارای skip link، focus-visible سراسری، label/نام دسترس‌پذیر کنترل‌ها، اعلان خطا برای screen reader، focus trap و بازگردانی focus در dialog، کنتراست تقویت‌شده، احترام به `prefers-reduced-motion` و هدف لمسی حداقل ۴۴ پیکسل در موبایل هستند. runtime مشترک دسترس‌پذیری در `public/site-accessibility.js` و runtime onboarding/tour/empty-state/feedback در `public/journal-ux-runtime.js` قرار دارد. کنترل runtime پلن، نشان روز باقی‌مانده و رابط تیکت در `public/journal-plan-support.js` قرار گرفته و در PWA shell نیز cache می‌شود؛ runtime دسترس‌پذیری و UX داخل standalone ژورنال نیز inline شده‌اند.

## بررسی و تست

```bash
npm run check
npm run smoke:auth
npm run smoke:journal
npm run smoke:admin
npm run smoke:legal
npm run smoke:marketing
npm run smoke:postgres
# نیازمند Redis واقعی
REDIS_URL=redis://127.0.0.1:6379/15 npm run smoke:infrastructure
node scripts/smoke-mock-v10.js
npm run preflight:production
```

`smoke-v10.js` پنل، RBAC، CMS و دفترچه را بررسی می‌کند. `smoke-journal-backend.js` جریان OTP ثبت‌نام/ورود و تمام Backend ژورنال را با fixtureهای پاک‌شونده تست می‌کند. `smoke-auth-security.js` نیز enrollment و login مدیر با TOTP، قفل تلاش MFA، چرخش امن TOTP، گزینه‌های Passkey، تأیید موبایل، دستگاه جدید، نشست‌ها، حساب حساس، CAPTCHA مشروط، بازیابی حساب، محافظت SSRF و عدم نشت Secretهای SMS/Turnstile را بررسی می‌کند. `smoke-legal-accessibility.js` شش سند عمومی، evidence رضایت، export، صف درخواست حذف، fulfillment/مستعارسازی، نسخه immutable و تحویل لایه‌های UI/WCAG را تست می‌کند. `smoke-marketing-seo.js` landing سبک، `/journal`، schema/canonical، صفحات تمیز، redirectها، sitemap/robots، cache تصویر، قیمت runtime، فرم پشتیبانی، رخداد مجاز، 404 و ثبت DB را با fixture موقت مستقل بررسی می‌کند. `smoke-postgres-runtime.js` با PostgreSQL سازگار درون‌حافظه‌ای، bootstrap schema، bridge باینری/پارامترها، احراز هویت، نشست، transactionهای ژورنال، Version Conflict، پشتیبانی و SEO را بدون دست‌زدن به دیتابیس واقعی بررسی می‌کند. Smokeهای OTP باید با `NODE_ENV=development` اجرا شوند تا `devCode` فقط در محیط تست بازگردد.

## نسخه مستقل بررسی پنل

فایل `/home/user/admin-panel-standalone-preview.html` یک snapshot تک‌فایلی از پنل با mock API داخلی است و برای بررسی UI بدون سرور استفاده می‌شود. منبع اصلی Production همچنان پروژه و API واقعی همین پوشه است.

## زیرساخت، پایداری و استقرار Production

اجزای اضافه‌شده:

- Redis برای rate limit توزیع‌شده، session mirror/cache و BullMQ
- Queue جدا برای پیامک رمزنگاری‌شده، verify/mirror تصویر و maintenance زمان‌بندی‌شده
- S3-compatible private storage با checksum، versioning و fallback staging محلی
- Pino JSON log، Sentry، Prometheus، Grafana، exporterهای PostgreSQL/Redis/host/container و alert rules
- `pg_dump` روزانه رمزنگاری‌شده با AES-256-GCM، retention، restore verification و drill هفتگی روی دیتابیس موقت
- CI برای audit/regression/container و CD کنترل‌شده با approval، backup و health rollback
- runtime اصلی PostgreSQL، bootstrap نسخه‌دار، migration تراکنشی SQLite→PostgreSQL در schema جدا، advisory lock، empty-target guard و count verification

راه‌اندازی پیشنهادی:

1. secretهای Docker را بسازید: `npm run infra:secrets`.
2. `.env.example` و یکی از نمونه‌های `deploy/environments` را برای محیط هدف تکمیل کنید؛ secret محیط‌ها باید مستقل باشند.
3. گیرنده و SMTP واقعی را در `deploy/alertmanager.yml` جایگزین کنید.
4. `PUBLIC_BASE_URL` را origin عمومی HTTPS، `SUPPORT_EMAIL` را صندوق عملیاتی و `WEBAUTHN_RP_ID`/`WEBAUTHN_ORIGIN`، Owner، Turnstile، Sentry و SMS را با مقادیر واقعی تنظیم کنید.
5. token ابزار وب‌مستر را در `GOOGLE_SITE_VERIFICATION` یا `BING_SITE_VERIFICATION` قرار دهید؛ پس از انتشار مالکیت را تأیید و `/sitemap.xml` را submit کنید.
6. تمام smokeها، به‌ویژه `npm run smoke:postgres` و `npm run smoke:marketing` را اجرا کنید.
7. برای نصب تازه، app در اولین اجرا schema نسخه‌دار PostgreSQL را با advisory lock می‌سازد. برای انتقال داده SQLite موجود، ابتدا backup بگیرید، فقط PostgreSQL را بالا بیاورید و migration را قبل از app اجرا کنید:
   ```bash
   docker compose -f compose.infrastructure.yml up -d postgres
   docker compose -f compose.infrastructure.yml --profile tools run --rm postgres-migrate
   ```
8. `npm run backup:encrypted` و `npm run restore:drill` را موفق اجرا و سپس `POSTGRES_BACKUP_CONFIRMED=true` و در cutover قدیمی `PREFLIGHT_BACKUP_CONFIRMED=true` را تنظیم کنید.
9. `npm run preflight:production` را بدون failure اجرا و کل زیرساخت را بالا بیاورید:
   ```bash
   docker compose -f compose.infrastructure.yml up -d --build
   docker compose -f compose.infrastructure.yml --profile monitoring up -d
   ```
10. gateway را فقط پشت TLS/load balancer یا CDN منتشر کنید. CDN فقط static pathها را cache کند؛ API، HTML شخصی و media private نباید public cache شوند.
11. uptime check را روی provider و region دیگری برای `/api/health/live` و `/api/health/ready` فعال کنید.

Endpointهای عملیاتی:

- liveness: `/api/health/live`
- readiness dependency-aware: `/api/health/ready`
- metrics: `/internal/metrics` با Bearer token و فقط network داخلی
- worker callbacks: `/internal/jobs/*` با token مستقل و فقط network داخلی

> **وضعیت PostgreSQL:** در Production، PostgreSQL منبع حقیقت و انتخاب اجباری runtime است. schema در Worker دیتابیس مستقل اجرا می‌شود، bootstrap با advisory lock و transaction محافظت شده و اجرای Production با SQLite به‌صورت پیش‌فرض متوقف می‌شود. SQLite فقط برای Development و rollback کوتاه با opt-in صریح باقی مانده است. bridge فعلی درخواست‌های هر replica را سری می‌کند؛ برای ظرفیت بیشتر می‌توان app را افقی scale کرد و تبدیل کامل لایه دامنه به async را به‌عنوان بهینه‌سازی عملکرد آینده انجام داد، نه شرط cutover داده.

Runbookها:

- `docs/MONITORING_RUNBOOK.md`
- `docs/DISASTER_RECOVERY.md`
- `docs/INFRASTRUCTURE_ROLLOUT.md`

- [`SMS.md`](SMS.md) — راه‌اندازی و مدیریت درگاه پیامک (کاوه‌نگار / ملی‌پیامک / Webhook)
- [`START.md`](START.md) — اجرای سایت روی ویندوز و لینوکس
- [`IP-SETUP.md`](IP-SETUP.md) — راه‌اندازی و دیدن سایت بدون دامنه (فقط با IP)
