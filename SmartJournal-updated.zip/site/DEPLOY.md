# نصب روی هاست واقعی — چه چیزی لازم است

این فایل نتیجه‌ی **اجرای واقعی** پروژه در حالت production روی PostgreSQL 17
است، نه فهرست تئوری. چیزی که تست شد:

```
✓ سرور در NODE_ENV=production روی PostgreSQL واقعی بالا آمد
✓ / و /journal و /admin و /pricing و /faq و sitemap و robots همه 200
✓ جدول‌های bank_cards و payment_receipts روی PostgreSQL ساخته شدند
✓ پلن‌ها seed شدند
✓ HSTS و CSP و frame-ancestors 'none' فعال
✗ ثبت‌نام کاربر: خطای 503 — «هیچ ارائه‌دهنده پیامک فعالی وجود ندارد»
```

---


## ⚡ نصب خودکار با Startup Script (پیشنهادی)

اگر سرور را تازه از پارس‌پک/ابر آروان می‌گیرید، به‌جای اجرای دستی همه مراحل،
محتوای `scripts/server-setup.sh` را در مرحله **«افزودن استارت‌آپ اسکریپت»**
کپی کنید. به‌محض اولین بوت، اینها را نصب و آماده می‌کند:

* Node.js 20 LTS
* PostgreSQL + ساخت دیتابیس و کاربر با رمز تصادفی
* Redis
* Nginx به‌عنوان reverse proxy روی پورت ۳۰۰۰
* Certbot برای HTTPS رایگان
* فایروال UFW (فقط SSH، ۸۰ و ۴۴۳)
* کاربر سیستمی `smartjournal` و سرویس systemd
* فایل `.env` با کلیدهای رمزنگاری تصادفی
* **تست خودکار دسترسی به API کاوه‌نگار**

بعد از بوت، خلاصه و رمزها اینجاست:

```bash
cat /root/smartjournal-info.txt      # رمز دیتابیس، رمز مدیر، وضعیت پیامک
cat /var/log/smartjournal-setup.log  # گزارش کامل نصب
```

> اگر سرور را بدون استارت‌آپ اسکریپت گرفتید، همین فایل را دستی اجرا کنید:
> `bash server-setup.sh`

**آنچه تست شده:** بلوک PostgreSQL (ساخت کاربر/دیتابیس + اتصال واقعی + اجرای
دوباره بدون خطا)، کانفیگ Nginx (`nginx -t` و سرو واقعی سایت از پشت پروکسی با
brotli سالم)، و صحت نام همه بسته‌های apt.

---

## 🔴 موانع قطعی (بدون این‌ها سایت کار نمی‌کند)

### ۱. سرویس پیامک — مهم‌ترین مورد

بدون آن **هیچ‌کس نمی‌تواند ثبت‌نام یا وارد شود.** تست واقعی:

```
POST /api/auth/signup → 503
{"error":"ارسال پیامک ناموفق بود: هیچ ارائه‌دهنده پیامک تنظیم‌شده و فعالی وجود ندارد."}
```

در حالت توسعه کد تأیید در پاسخ برمی‌گردد (`devCode`)، ولی در production این
کار به‌درستی انجام نمی‌شود. باید از پنل مدیریت → پیامک، اعتبارنامه‌ی
**کاوه‌نگار** یا **ملی‌پیامک** را وارد و تست کنید. هر دو از قبل seed شده‌اند
ولی credential ندارند.

### ۲. PostgreSQL

در production برنامه عمداً fail-closed است و با SQLite بالا نمی‌آید:

```bash
DB_ENGINE=postgres
DATABASE_URL=postgres://user:pass@host:5432/dbname
```

### ۳. دامنه و HTTPS

کوکی‌های نشست در production با `secure: true` ست می‌شوند؛ **روی HTTP ورود
کار نمی‌کند**. سرور `trust proxy` دارد پس پشت Nginx درست عمل می‌کند، ولی
Nginx باید `X-Forwarded-Proto` را بفرستد.

### ۴. متغیرهای محیطی اجباری

از `.env.production.example` استفاده کنید. کلیدها را با
`openssl rand -hex 32` بسازید. `npm run preflight:production` باید سبز شود.

---

## 🟠 مهم برای کاربر ایرانی

### فونت از سرور گوگل

`fonts.googleapis.com` و `fonts.gstatic.com` هنوز در صفحه لود می‌شوند و در
ایران کند یا بلاک‌اند. نتیجه: صفحه با تاهوما رندر می‌شود و چیدمان می‌پرد.
**راه‌حل:** فایل woff2 وزیرمتن را در `public/fonts/` بگذارید و با
`@font-face` محلی صدا بزنید.

### کپچای Cloudflare

`challenges.cloudflare.com` فقط بعد از رفتار مشکوک لود می‌شود و Site Key از
پنل قابل تنظیم است. اگر تنظیمش نکنید کپچا غیرفعال می‌ماند — ولی اگر تنظیم
کنید و در ایران لود نشود، ورود قفل می‌شود. آگاهانه تصمیم بگیرید.

---

## 🟡 بسته به معماری هاست

| مورد | با یک VPS ساده | چند اینستنس / کانتینر |
|---|---|---|
| `STORAGE_BACKEND=local` | کافی است | ✗ فایل‌ها گم می‌شوند → S3 لازم است |
| `REDIS_ENABLED=false` | کافی است | ✗ rate limit هر پروسه جداست → Redis لازم |
| `QUEUE_ENABLED=false` | پیامک همزمان ارسال می‌شود | ✗ صف لازم است |
| `UPLOAD_DIR` | باید روی دیسک ماندگار باشد | باید volume مشترک یا S3 باشد |

`preflight:production` برای هر سه مورد بالا FAIL می‌دهد چون سخت‌گیرانه برای
معماری چنداینستنسی نوشته شده. برنامه **بدون** آن‌ها هم اجرا می‌شود (تست شد)،
ولی اگر بعداً اینستنس دوم اضافه کنید باید فعالشان کنید.

---

## 🟢 بکاپ — قبل از اولین کاربر واقعی

```bash
npm run backup            # بکاپ رمزنگاری‌شده
npm run restore:drill     # تمرین بازیابی
```

بعد از یک بازیابی موفق `POSTGRES_BACKUP_CONFIRMED=true` را ست کنید.
بدون این، اگر دیتابیس از دست برود همه‌چیز رفته است.

---

## دستور نصب روی VPS

```bash
# ۱) وابستگی‌ها
sudo apt install -y nodejs npm postgresql nginx
sudo -u postgres psql -c "CREATE ROLE sj LOGIN PASSWORD 'یک-رمز-قوی';"
sudo -u postgres psql -c "CREATE DATABASE smartjournal OWNER sj;"

# ۲) پروژه
cd /var/www/smartjournal
npm ci --omit=dev
cp .env.production.example .env      # و پرش کنید
npm run preflight:production         # باید سبز شود

# ۳) اجرای دائمی
npm i -g pm2
pm2 start server.js --name smartjournal
pm2 save && pm2 startup
```

### Nginx

```nginx
server {
    listen 443 ssl http2;
    server_name smartjournal.ir;

    ssl_certificate     /etc/letsencrypt/live/smartjournal.ir/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/smartjournal.ir/privkey.pem;

    client_max_body_size 12M;          # آپلود فیش و تصویر معامله

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;   # ← بدون این کوکی امن نمی‌شود
    }
}
server {
    listen 80;
    server_name smartjournal.ir;
    return 301 https://$host$request_uri;
}
```

---

## بعد از بالا آمدن، این‌ها را تست کنید

1. ثبت‌نام با شماره واقعی — پیامک باید برسد
2. ورود به `/admin` با `ADMIN_USERNAME` و فعال‌سازی TOTP
3. افزودن شماره کارت در «کارت بانکی و فیش‌های واریز»
4. ثبت یک فیش آزمایشی از حساب کاربری و تاییدش از پنل
5. `curl -I https://دامنه/` — باید `Strict-Transport-Security` داشته باشد

---

## آزمون‌ها

```bash
npm run smoke:postgres        # runtime روی PostgreSQL
npm run smoke:pg-cards        # کارت‌به‌کارت و WebP روی PostgreSQL
npm run smoke:admin           # ۳۹
npm run smoke:auth            # ۲۶
npm run smoke:journal         # ۲۶
npm run smoke:cards           # ۳۰
npm run smoke:webp            # ۱۰
```
