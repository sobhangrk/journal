'use strict';
/* ==========================================================================
   تبدیل خودکار تصاویر به WebP
   هر تصویری که کاربر آپلود می‌کند — با هر فرمتی — قبل از رسیدن به
   منطق برنامه به WebP تبدیل می‌شود تا حجم پایین و سرعت سایت بالا برود.

   به‌صورت middleware کار می‌کند، پس هیچ‌کدام از توابع همگامِ موجود
   (storeJournalImage، normalizeJournalMedia و …) لازم نیست async شوند.
   ========================================================================== */

const sharp = require('sharp');

const ENABLED = process.env.WEBP_CONVERT !== 'false';
const QUALITY = Math.min(100, Math.max(40, Number(process.env.WEBP_QUALITY) || 82));
// 0 = ابعاد اصلی حفظ شود (پیش‌فرض؛ نمودار معاملات نباید کوچک شود)
const MAX_DIM = Math.max(0, Number(process.env.WEBP_MAX_DIMENSION) || 0);
const MAX_INPUT_BYTES = Number(process.env.WEBP_MAX_INPUT_BYTES) || 24 * 1024 * 1024;

// فرمت‌هایی که به WebP تبدیل می‌شوند. SVG عمداً نیست: می‌تواند اسکریپت داشته باشد
// و جای دیگری از برنامه هم آن را نمی‌پذیرد.
const CONVERTIBLE = new Set([
  'image/jpeg', 'image/jpg', 'image/png', 'image/gif',
  'image/tiff', 'image/bmp', 'image/avif', 'image/heic', 'image/heif',
]);

const DATA_URL_RE = /^data:([a-z0-9.+/-]+);base64,([A-Za-z0-9+/=\s]+)$/i;

const stats = { converted: 0, skipped: 0, failed: 0, bytesBefore: 0, bytesAfter: 0 };

/** نوع واقعی فایل را از روی بایت‌ها تشخیص می‌دهد، نه از روی ادعای کاربر. */
function sniff(buffer) {
  if (buffer.length < 12) return null;
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'image/jpeg';
  if (buffer.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buffer.slice(0, 6).toString('latin1') === 'GIF87a' || buffer.slice(0, 6).toString('latin1') === 'GIF89a') return 'image/gif';
  if (buffer.slice(0, 4).toString('latin1') === 'RIFF' && buffer.slice(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buffer.slice(4, 8).toString('latin1') === 'ftyp') {
    const brand = buffer.slice(8, 12).toString('latin1');
    if (brand.startsWith('avif') || brand.startsWith('avis')) return 'image/avif';
    if (brand.startsWith('heic') || brand.startsWith('heix') || brand.startsWith('mif1')) return 'image/heic';
  }
  if (buffer.slice(0, 2).toString('latin1') === 'BM') return 'image/bmp';
  if (buffer.slice(0, 4).equals(Buffer.from([0x49, 0x49, 0x2a, 0x00]))
   || buffer.slice(0, 4).equals(Buffer.from([0x4d, 0x4d, 0x00, 0x2a]))) return 'image/tiff';
  return null;
}

/** یک بافر تصویر را به WebP تبدیل می‌کند. اگر نشد یا سود نداشت، اصل را برمی‌گرداند. */
async function bufferToWebp(buffer, sniffed) {
  if (!ENABLED) return { buffer, mime: sniffed, converted: false };
  if (buffer.length > MAX_INPUT_BYTES) return { buffer, mime: sniffed, converted: false };
  if (sniffed === 'image/webp' || !CONVERTIBLE.has(sniffed)) {
    stats.skipped += 1;
    return { buffer, mime: sniffed, converted: false };
  }
  try {
    const animated = sniffed === 'image/gif' || sniffed === 'image/webp';
    let pipeline = sharp(buffer, { animated, failOn: 'none' });
    if (MAX_DIM > 0) {
      pipeline = pipeline.resize({
        width: MAX_DIM, height: MAX_DIM, fit: 'inside', withoutEnlargement: true,
      });
    }
    const out = await pipeline.webp({ quality: QUALITY, effort: 4 }).toBuffer();
    // اگر WebP بزرگ‌تر درآمد (گاهی برای PNGهای خیلی ساده) اصل را نگه می‌داریم
    if (out.length >= buffer.length) {
      stats.skipped += 1;
      return { buffer, mime: sniffed, converted: false };
    }
    stats.converted += 1;
    stats.bytesBefore += buffer.length;
    stats.bytesAfter += out.length;
    return { buffer: out, mime: 'image/webp', converted: true };
  } catch (error) {
    stats.failed += 1;
    return { buffer, mime: sniffed, converted: false, error };
  }
}

/** یک data-URL را می‌گیرد و data-URL وبپی برمی‌گرداند. */
async function convertDataUrl(value) {
  const match = DATA_URL_RE.exec(value);
  if (!match) return null;
  const claimed = match[1].toLowerCase();
  if (claimed === 'application/pdf') return null;      // فیش PDF دست‌نخورده می‌ماند
  let buffer;
  try { buffer = Buffer.from(match[2].replace(/\s+/g, ''), 'base64'); } catch { return null; }
  const sniffed = sniff(buffer);
  if (!sniffed) return null;
  const result = await bufferToWebp(buffer, sniffed);
  if (!result.converted) return null;
  return `data:${result.mime};base64,${result.buffer.toString('base64')}`;
}

/** درخت بدنه‌ی درخواست را می‌گردد و هر data-URL تصویری را به WebP تبدیل می‌کند. */
async function convertInPlace(node, depth = 0) {
  if (depth > 8 || node === null || typeof node !== 'object') return;
  const entries = Array.isArray(node) ? node.map((v, i) => [i, v]) : Object.entries(node);
  for (const [key, value] of entries) {
    if (typeof value === 'string') {
      if (value.length > 64 && value.startsWith('data:image/')) {
        const converted = await convertDataUrl(value);
        if (converted) node[key] = converted;
      }
    } else if (value && typeof value === 'object') {
      await convertInPlace(value, depth + 1);
    }
  }
}

/** Middleware: قبل از هر handler، تصاویر بدنه را به WebP تبدیل می‌کند. */
function webpRequestBody() {
  return function webpBodyMiddleware(req, res, next) {
    if (!ENABLED || !req.body || typeof req.body !== 'object') return next();
    if (!['POST', 'PUT', 'PATCH'].includes(req.method)) return next();
    convertInPlace(req.body).then(() => next()).catch(() => next());
  };
}

module.exports = {
  webpRequestBody, convertDataUrl, bufferToWebp, sniff, stats,
  config: { ENABLED, QUALITY, MAX_DIM },
};
