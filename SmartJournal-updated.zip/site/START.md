# چطور سایت را اجرا کنم؟ (ویندوز)

> این سایت یک **برنامه سرور** است، نه یک فایل HTML.
> تا وقتی سرور را اجرا نکنید، مرورگر می‌گوید **«This site can't be reached»**.
> این طبیعی است — یعنی هنوز چیزی پشت آدرس `localhost:3000` وجود ندارد.

---

## ⚠️ سه اشتباه رایج

| ❌ کار اشتباه | چه می‌بینید |
|---|---|
| دوبار کلیک روی `public/index.html` | ظاهر بدون عملکرد، آدرس `file:///…` |
| باز کردن `localhost:3000` بدون اجرای سرور | **This site can't be reached** |
| بستن پنجره ترمینال بعد از اجرا | سایت قطع می‌شود |

آدرس درست همیشه `http://localhost:3000` است و **پنجره سرور باید باز بماند**.

---

## گام‌به‌گام (ویندوز)

### گام ۱ — Node.js را نصب کنید (فقط یک‌بار در عمر سیستم)

1. به [nodejs.org](https://nodejs.org) بروید
2. دکمه بزرگ **LTS** را دانلود کنید (`.msi`)
3. نصب کنید — همه‌جا Next / Next / Install
4. **کامپیوتر را ری‌استارت نکنید، ولی حتماً پنجره‌های ترمینال باز را ببندید**

برای اطمینان، `cmd` را باز کنید و بزنید:

```
node -v
```

باید چیزی مثل `v20.11.0` چاپ شود. اگر گفت `'node' is not recognized`
یعنی نصب کامل نشده یا ترمینال را نبسته‌اید.

### گام ۲ — فایل zip را از حالت فشرده خارج کنید

روی `SmartJournal-Platform.zip` راست‌کلیک → **Extract All**.

⚠️ **مستقیم از داخل zip اجرا نکنید.** ویندوز فایل‌ها را در یک پوشه موقت باز
می‌کند و `npm install` شکست می‌خورد.

بعد از خارج کردن، باید پوشه‌ای به این شکل داشته باشید:

```
platform\
   ├── start.bat        ← این
   ├── server.js
   ├── package.json
   └── public\
```

### گام ۳ — روی `start.bat` دوبار کلیک کنید

یک پنجره مشکی باز می‌شود و مرحله‌به‌مرحله می‌گوید چه می‌کند:

```
[OK] Node v20.11.0
Installing dependencies - first run only, may take 1-3 minutes.
[OK] dependencies ready
Starting server...
Waiting for http://localhost:3000 ...
[OK] server is UP

   Site        http://localhost:3000
   Journal     http://localhost:3000/journal
   Admin       http://localhost:3000/admin
```

بار اول ۱ تا ۳ دقیقه طول می‌کشد (نصب وابستگی‌ها). **صبر کنید** — پنجره را نبندید.

بعد از `server is UP` مرورگر خودکار باز می‌شود.

> اگر ویندوز پیام «Windows protected your PC» داد:
> **More info** → **Run anyway**.

### گام ۴ — دو پنجره باز می‌ماند

| پنجره | کارش |
|---|---|
| `SmartJournal server - do not close` | خودِ سایت. **باز بماند.** |
| پنجره اول | فقط راهنما؛ می‌توانید ببندید. |

**برای خاموش کردن سایت:** پنجره `SmartJournal server` را ببندید.

---

## اگر باز هم «This site can't be reached» دیدید

پنجره `SmartJournal server` را نگاه کنید. متن خطا همان‌جاست.

### حالت ۱ — پنجره بسته شده / اصلاً باز نشد

یعنی Node نصب نیست یا `start.bat` را از داخل zip اجرا کرده‌اید.
گام ۱ و ۲ را دوباره انجام دهید.

### حالت ۲ — `Error: listen EADDRINUSE ... :3000`

پورت اشغال است (یک نسخه قبلی هنوز اجراست). در `cmd` بزنید:

```
netstat -ano | findstr :3000
taskkill /PID <عددی که آخر خط دیدید> /F
```

یا با پورت دیگر اجرا کنید — در `cmd` داخل همان پوشه:

```
set PORT=3001
start.bat
```

### حالت ۳ — `Cannot find module 'express'`

`npm install` کامل نشده. در `cmd` داخل پوشه `platform`:

```
npm install
npm start
```

### حالت ۴ — `npm install` خطای شبکه / timeout می‌دهد (رایج در ایران)

```
npm config set registry https://registry.npmmirror.com
npm install
```

اگر باز هم نشد، فیلترشکن را روشن کنید و دوباره `npm install` بزنید.
(این فقط برای دانلود کتابخانه‌هاست؛ بعدش دیگر لازم نیست.)

### حالت ۵ — سرور بالاست ولی مرورگر باز نمی‌کند

آدرس را **دستی** در مرورگر تایپ کنید:

```
http://localhost:3000
```

نه `https`، نه `www`، نه `file://`.

---

## راه دستی (اگر `start.bat` را دوست ندارید)

`cmd` را باز کنید، بروید داخل پوشه، سه دستور:

```
cd C:\مسیر\به\platform
npm install
npm start
```

وقتی این خط را دیدید یعنی آماده است:

```json
{"event":"server_started","port":3000,"databaseEngine":"sqlite", ...}
```

حالا `http://localhost:3000` را باز کنید. **پنجره cmd را نبندید.**
برای توقف: `Ctrl + C`.

---

## ورود آزمایشی

| کجا | دسترسی |
|---|---|
| پنل مدیریت `‎/admin` | نام کاربری `owner` یا موبایل `09120000000` — رمز `Admin@12345` (بار اول باید TOTP فعال کنید) |
| کاربر عادی | با هر شماره‌ای ثبت‌نام کنید؛ چون درگاه پیامک تنظیم نشده، در حالت توسعه کد تأیید در پاسخ API و لاگ ترمینال چاپ می‌شود |

---

## اگر نسخه قدیمی سایت را دیدید

سرویس‌ورکر مرورگر نسخه کهنه را نگه داشته. یک‌بار این آدرس را باز کنید:

```
http://localhost:3000/?fresh=1
```

برای اطمینان از نسخه، در کنسول مرورگر (کلید `F12`):

```js
document.querySelector('meta[name=pa-build]').content
```

---

## لینوکس / مک

```bash
cd platform
bash start.sh
```

یا دستی:

```bash
npm install
npm start
```

---

## اجرا روی سرور واقعی (هاست ایران)

این راهنما فقط برای اجرای محلی روی کامپیوتر خودتان است.
برای production — PostgreSQL، Nginx، HTTPS، systemd، بک‌آپ — به
**`DEPLOY.md`** و **`HOSTING.md`** مراجعه کنید.

```bash
npm ci --omit=dev
cp .env.production.example .env      # مقادیرش را پر کنید
npm run preflight:production         # چک‌لیست آمادگی
NODE_ENV=production npm start
```

> 🔴 قبل از راه‌اندازی واقعی حتماً **درگاه پیامک** را تنظیم کنید
> (پنل → پیامک → Kavenegar یا ملی‌پیامک). بدون آن هیچ کاربری نمی‌تواند
> ثبت‌نام یا ورود کند و `POST /api/auth/signup` خطای ۵۰۳ می‌دهد.

---

## دستورهای مفید

```bash
npm start                   # اجرای سایت
npm run dev                 # اجرا با ری‌استارت خودکار هنگام تغییر کد
npm run check               # بررسی نحوی همه فایل‌ها
npm run build:index         # ساخت دوباره public/index.html
npm run smoke:journal-open  # تست باز شدن ژورنال با مرورگر واقعی
npm run preflight:production
```
