'use strict';
/**
 * plan-pricing.js — منطق واحد «قیمت قبل / قیمت با تخفیف» برای همهٔ لایه‌ها.
 *
 * چهار ستون جدول plans این را می‌سازند:
 *   discount_percent  درصد تخفیف (۱ تا ۹۵)
 *   discount_price    قیمت نهایی دستی (اگر پر باشد بر درصد اولویت دارد)
 *   discount_label    متن دلخواه کنار برچسب، مثل «جشنوارهٔ پاییز»
 *   discount_until    تاریخ انقضا (ISO)؛ بعد از آن تخفیف خودکار خاموش می‌شود
 *
 * خروجی یکسان در SSR، API عمومی، پنل ادمین و صفحهٔ پرداخت استفاده می‌شود تا
 * قیمتِ نمایش‌داده‌شده و قیمتی که کاربر واقعاً می‌پردازد هیچ‌وقت واگرا نشوند.
 */
function num(value) { const n = Number(value); return Number.isFinite(n) ? n : 0 }

function planPricing(plan, nowMs) {
  const now = Number.isFinite(nowMs) ? nowMs : Date.now();
  const source = plan || {};
  const price = Math.max(0, Math.round(num(source.price_monthly !== undefined ? source.price_monthly : source.priceMonthly)));
  const percent = Math.max(0, Math.min(95, Math.round(num(source.discount_percent !== undefined ? source.discount_percent : source.discountPercent))));
  const fixedRaw = source.discount_price !== undefined ? source.discount_price : source.discountPrice;
  const fixed = fixedRaw === null || fixedRaw === undefined || fixedRaw === '' ? null : Math.max(0, Math.round(num(fixedRaw)));
  const untilRaw = source.discount_until !== undefined ? source.discount_until : source.discountUntil;
  const untilMs = untilRaw ? Date.parse(untilRaw) : NaN;
  const expired = Number.isFinite(untilMs) && untilMs <= now;

  let finalPrice = price;
  if (price > 0 && !expired) {
    if (fixed !== null && fixed < price) finalPrice = fixed;
    else if (percent > 0) finalPrice = Math.max(0, Math.round(price * (100 - percent) / 100));
  }
  const active = price > 0 && finalPrice < price;
  const label = String(source.discount_label !== undefined ? source.discount_label || '' : source.discountLabel || '').trim();
  return {
    price,
    final_price: active ? finalPrice : price,
    active,
    percent: active ? Math.round((1 - finalPrice / price) * 100) : 0,
    label: active && label ? label : null,
    until: active && Number.isFinite(untilMs) ? new Date(untilMs).toISOString() : null,
    expired: expired && (percent > 0 || (fixed !== null && fixed < price)),
  };
}

/** مبلغی که واقعاً باید پرداخت شود. */
function payablePrice(plan, nowMs) { return planPricing(plan, nowMs).final_price }

/** ستون‌های تخفیف را روی رکورد پلن می‌نشاند (برای پاسخ‌های API). */
function withPricing(plan, nowMs) {
  const pricing = planPricing(plan, nowMs);
  return { ...plan, discount: pricing, effective_price: pricing.final_price };
}

module.exports = { planPricing, payablePrice, withPricing };
