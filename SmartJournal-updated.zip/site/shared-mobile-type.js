'use strict';
/* ==========================================================================
   کف اندازهٔ متن روی موبایل — مشترک همهٔ صفحات

   کاربر گفت: «سایت رو برای موبایل حرفه‌ای درست کن، اندازهٔ ایکون‌ها هم درست
   باشد.» اندازه‌گیری با مرورگر واقعی روی ۳۹۰ و ۷۶۸ پیکسل نشان داد صفحهٔ
   اصلی ۵۲ متن زیر ۱۱ پیکسل دارد — بعضی تا ۷ پیکسل. روی گوشی این‌ها عملاً
   خوانا نیستند و ظاهر آماتوری می‌سازند. ابزار audit:mobile هم همین را
   گزارش می‌کرد («۱۷ متن زیر ۱۱px»).

   اینجا برای هر گروه، اندازهٔ حداقلی و متناسب گذاشته می‌شود — نه یک
   !important کور روی همه‌چیز، چون بعضی از این‌ها برچسب‌های تزئینیِ داخل
   نمودار ماکت‌اند و بزرگ‌کردنشان چیدمان را می‌شکند؛ آن‌ها فقط تا حد خوانا
   بزرگ می‌شوند.

   مرجع: ۱۱ پیکسل کف پذیرفته‌شدهٔ متن روی موبایل است (WCAG برای اندازهٔ
   مطلق الزام ندارد، ولی ابزارهای سنجش موبایل همین آستانه را می‌گیرند).
   ========================================================================== */

const MOBILE_TYPE_CSS = `
@media (max-width: 820px){
  /* برچسب‌های بالای بخش‌ها */
  .pa-l-eyebrow{font-size:11px!important;letter-spacing:.09em!important}
  .pa-l-feature-index{font-size:11px!important;letter-spacing:.06em!important}
  .pa-faq-number{font-size:11px!important}
  .pa-l-brand-copy span{font-size:11px!important}

  /* متن‌های توضیحی و لینک‌های محتوایی */
  .pa-trust-note{font-size:12px!important;line-height:1.9!important}
  .pa-l-inline-link{font-size:12px!important}
  .pa-faq-link-copy b{font-size:12px!important}
  .pa-faq-signal-row span{font-size:11px!important}
  .pa-trust-badge div span{font-size:11px!important}

  /* کارت‌های قیمت */
  .pa-l-price-card span{font-size:11px!important}
  .pa-l-plan-capacity span b{font-size:11px!important}

  /* لینک‌های پاورقی — این‌ها ناوبری واقعی‌اند و باید کاملاً خوانا باشند */
  .pa-l-footer-mainlinks a{font-size:12px!important;line-height:2.1!important}
  .pa-l-legal-links a{font-size:11.5px!important;line-height:2.1!important}
  .pa-l-footer-mainlinks a,
  .pa-l-legal-links a{display:inline-block;padding-block:3px}

  /* صفحهٔ ورود و ثبت‌نام */
  .pa-a-brand-copy span{font-size:11px!important}
  .pa-a-kicker{font-size:11px!important;letter-spacing:.08em!important}
  .pa-a-visual-copy p{font-size:12px!important;line-height:1.95!important}
  .pa-a-float-lock span{font-size:11px!important}
  .pa-a-form-head p{font-size:12px!important;line-height:1.95!important}
  .pa-a-success-inner p{font-size:12px!important}
  /* نسخهٔ اسناد حقوقی — متن حقوقی هرگز نباید ۷ پیکسل باشد */
  .pa-legal-versions{font-size:11px!important;line-height:1.9!important}
  /* فرم ورود/ثبت‌نام — اولین صفحه‌ای که هر کاربر می‌بیند؛ برچسب‌ها ۹ و
     دکمه‌های کمکی ۸ پیکسل بودند (اندازه‌گیری روی ۳۹۰ پیکسل). */
  .pa-a-card-top span{font-size:11px!important}
  .pa-a-status{font-size:11px!important}
  .pa-a-field label{font-size:11.5px!important}
  .pa-a-check{font-size:11.5px!important}
  .pa-a-reset{font-size:11.5px!important;min-height:32px}
  .pa-cloud-quick button{font-size:11.5px!important;min-height:36px}

  /* نوارها و برچسب‌های نمایشی صفحهٔ اصلی */
  .pa-l-cinematic-copy{font-size:11px!important}
  .pa-l-hud-rail{font-size:11px!important}
  .pa-l-live{font-size:11px!important}
  .pa-l-trust span{font-size:11px!important}
  .pa-l-ticker-track span{font-size:11px!important}

  /* برچسب‌های تزئینیِ داخل نمودار ماکت — فقط تا حد خوانا
     (این‌ها محتوای واقعی نیستند؛ بزرگ‌کردن کاملشان نمودار را می‌شکند) */
  .pa-l-timeframes span{font-size:10px!important}
  .pa-l-price-axis span{font-size:10px!important}
  .pa-l-terminal-meta b{font-size:11px!important}
}

/* هدف لمسی لینک‌های پاورقی روی موبایل */
@media (max-width: 560px){
  .pa-l-footer-mainlinks a,
  .pa-l-legal-links a{min-height:32px;display:inline-flex;align-items:center}
}
`;

function styleTag() {
  return `<style id="pa-mobile-typography">${MOBILE_TYPE_CSS}</style>`;
}

module.exports = { MOBILE_TYPE_CSS, styleTag };
