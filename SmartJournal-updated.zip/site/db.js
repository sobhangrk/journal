'use strict';

const Database = require('better-sqlite3');
const {PostgresSyncDatabase}=require('./postgres-sync-db');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const APP_VERSION = require('./package.json').version;
const {TYPES:LEGAL_TYPES,TITLES:LEGAL_TITLES,buildLegalDocuments}=require('./legal-content');
const {FAQS}=require('./marketing-content');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DATABASE_ENGINE=String(process.env.DB_ENGINE||(process.env.DATABASE_URL?'postgres':'sqlite')).toLowerCase();
if(!['sqlite','postgres'].includes(DATABASE_ENGINE))throw new Error('DB_ENGINE must be sqlite or postgres.');
if(process.env.NODE_ENV==='production'&&DATABASE_ENGINE!=='postgres'&&process.env.ALLOW_SQLITE_PRODUCTION!=='true')throw new Error('Production requires DB_ENGINE=postgres. Set ALLOW_SQLITE_PRODUCTION=true only for a controlled rollback window.');
if(process.env.NODE_ENV==='production'&&process.env.POSTGRES_EMBEDDED_TEST==='true')throw new Error('POSTGRES_EMBEDDED_TEST is forbidden in production.');
const DB_PATH = DATABASE_ENGINE==='sqlite'?(process.env.DATABASE_PATH || path.join(DATA_DIR, 'admin.db')):null;
const db = DATABASE_ENGINE==='postgres'?new PostgresSyncDatabase():new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

function iso(date = new Date()) { return date.toISOString(); }
function daysAgo(days, hours = 0) {
  return iso(new Date(Date.now() - (days * 24 + hours) * 60 * 60 * 1000));
}
function daysFromNow(days) {
  return iso(new Date(Date.now() + days * 24 * 60 * 60 * 1000));
}
function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }

const PERMISSION_KEYS = [
  'dashboard','users.view','users.manage','users.security','users.delete',
  'billing.view','billing.manage','billing.refund',
  'resources.view','resources.manage','resources.security',
  'security.view','security.manage','settings.view','settings.manage',
  'content.view','content.manage','cms.manage'
];
const DEFAULT_ROLE_PERMISSIONS = {
  admin: ['dashboard','users.view','users.manage','users.security','users.delete','billing.view','billing.manage','resources.view','resources.manage','resources.security','security.view','security.manage','settings.view','settings.manage','content.view','content.manage','cms.manage'],
  support: ['dashboard','users.view','users.manage','users.security'],
  finance: ['dashboard','billing.view','billing.manage','billing.refund'],
  security: ['dashboard','users.view','users.security','resources.view','resources.security','security.view','security.manage'],
  content_manager: ['dashboard','content.view','content.manage','cms.manage']
};

function migrateAdminRoleConstraint() {
  const row = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='admins'").get();
  if (!row || String(row.sql).includes('content_manager')) return;
  db.pragma('foreign_keys = OFF');
  try {
    db.exec(`
      BEGIN;
      CREATE TABLE admins_new (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        username TEXT UNIQUE,
        mobile TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin' CHECK(role IN ('owner','admin','support','finance','security','content_manager')),
        status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')),
        created_at TEXT NOT NULL,
        last_login_at TEXT,
        mfa_required INTEGER NOT NULL DEFAULT 0,
        mfa_enforced_at TEXT
      );
      INSERT INTO admins_new (id,name,mobile,password_hash,role,status,created_at,last_login_at)
        SELECT id,name,mobile,password_hash,role,status,created_at,last_login_at FROM admins;
      DROP TABLE admins;
      ALTER TABLE admins_new RENAME TO admins;
      COMMIT;
    `);
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch {}
    throw error;
  } finally {
    db.pragma('foreign_keys = ON');
  }
}

function initializeSchemaAndSeeds() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      source_checksum TEXT NOT NULL,
      started_at TIMESTAMPTZ NOT NULL,
      completed_at TIMESTAMPTZ,
      details JSONB NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admins (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      username TEXT UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin' CHECK(role IN ('owner','admin','support','finance','security','content_manager')),
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')),
      created_at TEXT NOT NULL,
      last_login_at TEXT,
      mfa_required INTEGER NOT NULL DEFAULT 0,
      mfa_enforced_at TEXT
    );

    CREATE TABLE IF NOT EXISTS admin_sessions (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      csrf_token TEXT NOT NULL,
      mfa_verified INTEGER NOT NULL DEFAULT 0,
      auth_method TEXT NOT NULL DEFAULT 'password',
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      ip TEXT,
      user_agent TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token_hash);
    CREATE INDEX IF NOT EXISTS idx_admin_sessions_expiry ON admin_sessions(expires_at);

    CREATE TABLE IF NOT EXISTS admin_totp (
      admin_id TEXT PRIMARY KEY REFERENCES admins(id) ON DELETE CASCADE,
      secret_encrypted TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      verified_at TEXT,
      last_used_step INTEGER,
      pending_secret_encrypted TEXT,
      pending_created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS admin_passkeys (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
      credential_id TEXT NOT NULL UNIQUE,
      public_key BLOB NOT NULL,
      counter INTEGER NOT NULL DEFAULT 0,
      transports TEXT,
      device_type TEXT,
      backed_up INTEGER NOT NULL DEFAULT 0,
      name TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_used_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_admin_passkeys_admin ON admin_passkeys(admin_id);

    CREATE TABLE IF NOT EXISTS admin_recovery_codes (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
      code_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      used_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_admin_recovery_codes_admin ON admin_recovery_codes(admin_id,used_at);

    CREATE TABLE IF NOT EXISTS admin_auth_challenges (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
      challenge_hash TEXT NOT NULL UNIQUE,
      challenge TEXT,
      purpose TEXT NOT NULL CHECK(purpose IN ('login','passkey_login','passkey_register','totp_setup')),
      payload TEXT,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      consumed_at TEXT,
      attempts INTEGER NOT NULL DEFAULT 0,
      max_attempts INTEGER NOT NULL DEFAULT 5,
      ip TEXT,
      user_agent TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_admin_auth_challenges_expiry ON admin_auth_challenges(expires_at,consumed_at);

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','suspended','pending')),
      created_at TEXT NOT NULL,
      updated_at TEXT,
      last_seen_at TEXT,
      mobile_verified_at TEXT,
      require_2fa INTEGER NOT NULL DEFAULT 0,
      security_level TEXT NOT NULL DEFAULT 'normal' CHECK(security_level IN ('normal','sensitive')),
      failed_login_count INTEGER NOT NULL DEFAULT 0,
      last_login_ip TEXT,
      last_login_at TEXT,
      storage_bytes INTEGER NOT NULL DEFAULT 0,
      trades_count INTEGER NOT NULL DEFAULT 0,
      sms_count INTEGER NOT NULL DEFAULT 0,
      access_mode TEXT NOT NULL DEFAULT 'normal' CHECK(access_mode IN ('normal','limited')),
      limited_until TEXT,
      restriction_reason TEXT,
      deletion_requested_at TEXT,
      deleted_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
    CREATE INDEX IF NOT EXISTS idx_users_created ON users(created_at);

    CREATE TABLE IF NOT EXISTS user_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT UNIQUE,
      csrf_token TEXT,
      device TEXT,
      ip TEXT,
      user_agent TEXT,
      device_id TEXT,
      auth_method TEXT NOT NULL DEFAULT 'password',
      mfa_verified INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      last_seen_at TEXT,
      expires_at TEXT NOT NULL,
      revoked_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_user_sessions_user ON user_sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_user_sessions_active ON user_sessions(user_id,revoked_at,expires_at);

    CREATE TABLE IF NOT EXISTS account_recovery_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','expired','cancelled')),
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      completed_at TEXT,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_recovery_user ON account_recovery_requests(user_id,status);

    CREATE TABLE IF NOT EXISTS user_trusted_devices (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      device_hash TEXT NOT NULL,
      label TEXT NOT NULL,
      user_agent TEXT,
      first_ip TEXT,
      last_ip TEXT,
      trusted_at TEXT NOT NULL,
      trusted_until TEXT NOT NULL,
      last_seen_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','revoked')),
      revoked_at TEXT,
      UNIQUE(user_id,device_hash)
    );
    CREATE INDEX IF NOT EXISTS idx_user_devices_active ON user_trusted_devices(user_id,status,trusted_until);

    CREATE TABLE IF NOT EXISTS user_otp_challenges (
      id TEXT PRIMARY KEY,
      challenge_hash TEXT NOT NULL UNIQUE,
      user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      mobile TEXT NOT NULL,
      purpose TEXT NOT NULL CHECK(purpose IN ('signup','login','passwordless','recovery','verify_mobile','security')),
      code_hash TEXT NOT NULL,
      payload TEXT,
      attempts INTEGER NOT NULL DEFAULT 0,
      max_attempts INTEGER NOT NULL DEFAULT 5,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      consumed_at TEXT,
      ip TEXT,
      device_hash TEXT,
      remember INTEGER NOT NULL DEFAULT 1,
      captcha_verified INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_user_otp_mobile ON user_otp_challenges(mobile,purpose,created_at);
    CREATE INDEX IF NOT EXISTS idx_user_otp_expiry ON user_otp_challenges(expires_at,consumed_at);

    CREATE TABLE IF NOT EXISTS user_security_events (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      event_type TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'info' CHECK(severity IN ('info','warning','critical')),
      title TEXT NOT NULL,
      details TEXT,
      ip TEXT,
      device_id TEXT,
      created_at TEXT NOT NULL,
      notified_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_user_security_events ON user_security_events(user_id,created_at);

    CREATE TABLE IF NOT EXISTS auth_security_settings (
      id TEXT PRIMARY KEY CHECK(id='default'),
      max_devices INTEGER NOT NULL DEFAULT 5,
      trusted_device_days INTEGER NOT NULL DEFAULT 30,
      otp_ttl_seconds INTEGER NOT NULL DEFAULT 120,
      otp_max_attempts INTEGER NOT NULL DEFAULT 5,
      captcha_failure_threshold INTEGER NOT NULL DEFAULT 3,
      turnstile_site_key TEXT,
      turnstile_secret_encrypted TEXT,
      new_device_otp INTEGER NOT NULL DEFAULT 0,   -- ورود با رمزِ درست نباید پیامک بخواهد
      notify_new_login INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS plans (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      name_fa TEXT NOT NULL,
      price_monthly INTEGER NOT NULL DEFAULT 0,
      currency TEXT NOT NULL DEFAULT 'TOMAN',
      max_trades INTEGER NOT NULL DEFAULT 100,
      max_storage_bytes INTEGER NOT NULL DEFAULT 104857600,
      max_sms_monthly INTEGER NOT NULL DEFAULT 10,
      color TEXT NOT NULL DEFAULT '#22d3ee',
      tagline TEXT,
      badge_label TEXT,
      cta_label TEXT,
      is_recommended INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      duration_days INTEGER NOT NULL DEFAULT 30,
      discount_percent INTEGER NOT NULL DEFAULT 0,
      discount_price INTEGER,
      discount_label TEXT,
      discount_until TEXT,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS plan_features (
      id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
      feature_key TEXT NOT NULL,
      label TEXT NOT NULL,
      description TEXT,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(plan_id,feature_key)
    );
    CREATE INDEX IF NOT EXISTS idx_plan_features_plan ON plan_features(plan_id,is_enabled,sort_order);

    CREATE TABLE IF NOT EXISTS plan_journal_sections (
      id TEXT PRIMARY KEY,
      plan_id TEXT NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
      section_key TEXT NOT NULL,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(plan_id,section_key)
    );
    CREATE INDEX IF NOT EXISTS idx_plan_journal_sections_plan ON plan_journal_sections(plan_id,is_enabled,sort_order);

    CREATE TABLE IF NOT EXISTS marketing_faqs (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL DEFAULT 'product' CHECK(category IN ('why','product','security','pricing','privacy','support')),
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('draft','published','archived')),
      is_featured INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_marketing_faqs_public ON marketing_faqs(status,is_featured,sort_order);

    CREATE TABLE IF NOT EXISTS subscriptions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      plan_id TEXT NOT NULL REFERENCES plans(id),
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','expired','cancelled','trial')),
      started_at TEXT NOT NULL,
      expires_at TEXT,
      auto_renew INTEGER NOT NULL DEFAULT 0,
      coupon_id TEXT,
      discount_amount INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
    CREATE INDEX IF NOT EXISTS idx_subscriptions_plan ON subscriptions(plan_id);

    CREATE TABLE IF NOT EXISTS coupons (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      discount_type TEXT NOT NULL CHECK(discount_type IN ('percent','fixed')),
      value INTEGER NOT NULL,
      max_uses INTEGER,
      used_count INTEGER NOT NULL DEFAULT 0,
      starts_at TEXT NOT NULL,
      expires_at TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_coupons_code ON coupons(code);

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
      subscription_id TEXT REFERENCES subscriptions(id) ON DELETE SET NULL,
      amount INTEGER NOT NULL,
      discount_amount INTEGER NOT NULL DEFAULT 0,
      refunded_amount INTEGER NOT NULL DEFAULT 0,
      currency TEXT NOT NULL DEFAULT 'TOMAN',
      status TEXT NOT NULL CHECK(status IN ('paid','pending','failed','refunded','partially_refunded')),
      provider TEXT,
      tracking_code TEXT,
      invoice_number TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL,
      paid_at TEXT,
      refunded_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);
    CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
    CREATE INDEX IF NOT EXISTS idx_payments_created ON payments(created_at);

    CREATE TABLE IF NOT EXISTS sms_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      mobile TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'otp',
      status TEXT NOT NULL CHECK(status IN ('sent','delivered','failed')),
      provider TEXT NOT NULL,
      cost INTEGER NOT NULL DEFAULT 0,
      error_code TEXT,
      request_ip TEXT,
      is_suspicious INTEGER NOT NULL DEFAULT 0,
      suspicious_reason TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sms_created ON sms_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_sms_status ON sms_logs(status);

    CREATE TABLE IF NOT EXISTS queue_deliveries (
      job_id TEXT PRIMARY KEY,
      queue_name TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('processing','completed','failed')),
      result_json TEXT,
      attempts INTEGER NOT NULL DEFAULT 1,
      started_at TEXT NOT NULL,
      completed_at TEXT,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_queue_deliveries_updated ON queue_deliveries(updated_at);

    CREATE TABLE IF NOT EXISTS sms_settings (
      id TEXT PRIMARY KEY CHECK(id='default'),
      otp_template TEXT NOT NULL,
      mobile_limit_count INTEGER NOT NULL DEFAULT 5,
      ip_limit_count INTEGER NOT NULL DEFAULT 12,
      rate_window_minutes INTEGER NOT NULL DEFAULT 10,
      auto_failover INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sms_providers (
      id TEXT PRIMARY KEY,
      provider_key TEXT NOT NULL UNIQUE,
      provider_type TEXT NOT NULL DEFAULT 'generic_webhook' CHECK(provider_type IN ('kavenegar','melipayamak','generic_webhook','development')),
      name TEXT NOT NULL UNIQUE,
      config_json TEXT,
      credentials_encrypted TEXT,
      balance INTEGER NOT NULL DEFAULT 0,
      unit_cost INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'healthy' CHECK(status IN ('healthy','degraded','down')),
      is_enabled INTEGER NOT NULL DEFAULT 1,
      is_primary INTEGER NOT NULL DEFAULT 0,
      priority INTEGER NOT NULL DEFAULT 10,
      last_error_at TEXT,
      last_checked_at TEXT,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sms_providers_primary ON sms_providers(is_primary,is_enabled);

    CREATE TABLE IF NOT EXISTS file_settings (
      id TEXT PRIMARY KEY CHECK(id='default'),
      allowed_mime_types TEXT NOT NULL,
      max_file_size_bytes INTEGER NOT NULL DEFAULT 10485760,
      orphan_retention_days INTEGER NOT NULL DEFAULT 7,
      auto_cleanup INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS media_files (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      trade_ref TEXT,
      original_name TEXT NOT NULL,
      storage_key TEXT NOT NULL UNIQUE,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      checksum_sha256 TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','quarantined','deleted')),
      scan_status TEXT NOT NULL DEFAULT 'pending' CHECK(scan_status IN ('pending','safe','suspicious')),
      scan_reason TEXT,
      uploaded_at TEXT NOT NULL,
      orphaned_at TEXT,
      reviewed_at TEXT,
      reviewed_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      deleted_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_media_files_user ON media_files(user_id,status);
    CREATE INDEX IF NOT EXISTS idx_media_files_orphan ON media_files(trade_ref,orphaned_at,status);
    CREATE INDEX IF NOT EXISTS idx_media_files_scan ON media_files(scan_status,status);
    CREATE INDEX IF NOT EXISTS idx_media_files_uploaded ON media_files(uploaded_at);

    CREATE TABLE IF NOT EXISTS system_errors (
      id TEXT PRIMARY KEY,
      severity TEXT NOT NULL CHECK(severity IN ('critical','error','warning','info')),
      source TEXT NOT NULL,
      message TEXT NOT NULL,
      stack TEXT,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved','ignored')),
      occurred_at TEXT NOT NULL,
      resolved_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_errors_status ON system_errors(status);
    CREATE INDEX IF NOT EXISTS idx_errors_occurred ON system_errors(occurred_at);

    CREATE TABLE IF NOT EXISTS security_blocks (
      id TEXT PRIMARY KEY,
      block_type TEXT NOT NULL CHECK(block_type IN ('ip','mobile')),
      block_value TEXT NOT NULL,
      reason TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT 'manual' CHECK(source IN ('manual','automatic')),
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','expired','revoked')),
      expires_at TEXT,
      created_at TEXT NOT NULL,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      revoked_at TEXT,
      revoked_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_security_blocks_lookup ON security_blocks(block_type,block_value,status,expires_at);
    CREATE INDEX IF NOT EXISTS idx_security_blocks_created ON security_blocks(created_at);

    CREATE TABLE IF NOT EXISTS security_alerts (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL CHECK(category IN ('api','database','authentication','rate_limit','attack','consumption','file','sms')),
      severity TEXT NOT NULL CHECK(severity IN ('critical','error','warning','info')),
      title TEXT NOT NULL,
      details TEXT,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','acknowledged','resolved')),
      detected_at TEXT NOT NULL,
      acknowledged_at TEXT,
      resolved_at TEXT,
      resolved_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_security_alerts_status ON security_alerts(status,severity,detected_at);
    CREATE INDEX IF NOT EXISTS idx_security_alerts_category ON security_alerts(category,detected_at);

    CREATE TABLE IF NOT EXISTS system_settings (
      id TEXT PRIMARY KEY CHECK(id='default'),
      signup_enabled INTEGER NOT NULL DEFAULT 1,
      maintenance_mode INTEGER NOT NULL DEFAULT 0,
      maintenance_message TEXT,
      terms_text TEXT NOT NULL,
      privacy_text TEXT NOT NULL,
      guide_text TEXT NOT NULL,
      app_version TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS legal_documents (
      id TEXT PRIMARY KEY,
      document_type TEXT NOT NULL CHECK(document_type IN ('terms','privacy','retention','cookies','dpa','disclaimer')),
      version TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      content_sha256 TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','archived')),
      effective_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      published_at TEXT,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      UNIQUE(document_type,version)
    );
    CREATE INDEX IF NOT EXISTS idx_legal_documents_current ON legal_documents(document_type,status,effective_at,published_at);

    CREATE TABLE IF NOT EXISTS user_legal_acceptances (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      document_type TEXT NOT NULL,
      document_version TEXT NOT NULL,
      document_sha256 TEXT NOT NULL,
      accepted_at TEXT NOT NULL,
      acceptance_method TEXT NOT NULL CHECK(acceptance_method IN ('signup_checkbox','reauth_checkbox','admin_attested')),
      ip TEXT,
      user_agent TEXT,
      withdrawn_at TEXT,
      UNIQUE(user_id,document_type,document_version)
    );
    CREATE INDEX IF NOT EXISTS idx_legal_acceptances_user ON user_legal_acceptances(user_id,document_type,accepted_at);

    CREATE TABLE IF NOT EXISTS privacy_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      request_type TEXT NOT NULL CHECK(request_type IN ('access_export','deletion','correction','restriction')),
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','in_progress','completed','rejected','cancelled')),
      requested_at TEXT NOT NULL,
      due_at TEXT NOT NULL,
      completed_at TEXT,
      cancelled_at TEXT,
      rejection_reason TEXT,
      result_summary TEXT,
      request_ip TEXT,
      handled_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_privacy_requests_user ON privacy_requests(user_id,status,requested_at);
    CREATE INDEX IF NOT EXISTS idx_privacy_requests_due ON privacy_requests(status,due_at);

    CREATE TABLE IF NOT EXISTS support_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      mobile TEXT,
      email TEXT,
      category TEXT NOT NULL DEFAULT 'general' CHECK(category IN ('general','account','technical','billing','privacy','security')),
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','resolved','closed','spam')),
      priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN ('low','normal','high','urgent')),
      public_reference TEXT NOT NULL UNIQUE,
      request_ip_hash TEXT,
      user_agent TEXT,
      assigned_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      handled_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      admin_note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      resolved_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_support_requests_status ON support_requests(status,priority,created_at);
    CREATE INDEX IF NOT EXISTS idx_support_requests_user ON support_requests(user_id,created_at);

    CREATE TABLE IF NOT EXISTS support_messages (
      id TEXT PRIMARY KEY,
      request_id TEXT NOT NULL REFERENCES support_requests(id) ON DELETE CASCADE,
      author_type TEXT NOT NULL CHECK(author_type IN ('user','admin','system')),
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      message TEXT NOT NULL,
      is_internal INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      read_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_support_messages_request ON support_messages(request_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_support_messages_unread ON support_messages(author_type,read_at,created_at);

    CREATE TABLE IF NOT EXISTS marketing_events (
      id TEXT PRIMARY KEY,
      event_name TEXT NOT NULL,
      page_path TEXT NOT NULL,
      session_hash TEXT,
      metadata TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_marketing_events_name ON marketing_events(event_name,created_at);

    CREATE TABLE IF NOT EXISTS data_deletion_tombstones (
      subject_hash TEXT PRIMARY KEY,
      original_user_id TEXT NOT NULL,
      requested_at TEXT NOT NULL,
      fulfilled_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      reason TEXT NOT NULL DEFAULT 'user_request'
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      tone TEXT NOT NULL DEFAULT 'info' CHECK(tone IN ('info','success','warning','critical')),
      audience TEXT NOT NULL DEFAULT 'all' CHECK(audience IN ('all','free','pro','organization')),
      status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','archived')),
      starts_at TEXT NOT NULL,
      expires_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_announcements_status ON announcements(status,starts_at,expires_at);
    CREATE INDEX IF NOT EXISTS idx_announcements_updated ON announcements(updated_at);

    CREATE TABLE IF NOT EXISTS role_permissions (
      role TEXT NOT NULL CHECK(role IN ('admin','support','finance','security','content_manager')),
      permission TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      PRIMARY KEY(role,permission)
    );
    CREATE INDEX IF NOT EXISTS idx_role_permissions_role ON role_permissions(role,enabled);

    CREATE TABLE IF NOT EXISTS cms_pages (
      id TEXT PRIMARY KEY,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      meta_description TEXT,
      seo_title TEXT,
      seo_keywords TEXT,
      og_image TEXT,
      canonical_url TEXT,
      publish_at TEXT,
      unpublish_at TEXT,
      status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','archived')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_cms_pages_status ON cms_pages(status,updated_at);

    CREATE TABLE IF NOT EXISTS cms_sections (
      id TEXT PRIMARY KEY,
      page_id TEXT NOT NULL REFERENCES cms_pages(id) ON DELETE CASCADE,
      section_key TEXT NOT NULL,
      section_type TEXT NOT NULL DEFAULT 'content' CHECK(section_type IN ('hero','content','feature','cta','footer','form','custom')),
      title TEXT,
      body TEXT,
      button_label TEXT,
      button_url TEXT,
      image_url TEXT,
      image_alt TEXT,
      publish_at TEXT,
      unpublish_at TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('draft','published','archived')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      UNIQUE(page_id,section_key)
    );
    CREATE INDEX IF NOT EXISTS idx_cms_sections_page ON cms_sections(page_id,status,sort_order);

    CREATE TABLE IF NOT EXISTS cms_revisions (
      id TEXT PRIMARY KEY,
      entity_type TEXT NOT NULL CHECK(entity_type IN ('page','section')),
      entity_id TEXT NOT NULL,
      version INTEGER NOT NULL,
      snapshot TEXT NOT NULL,
      created_at TEXT NOT NULL,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      UNIQUE(entity_type,entity_id,version)
    );
    CREATE INDEX IF NOT EXISTS idx_cms_revisions_entity ON cms_revisions(entity_type,entity_id,version DESC);

    CREATE TABLE IF NOT EXISTS cms_menu_items (
      id TEXT PRIMARY KEY,
      menu_key TEXT NOT NULL DEFAULT 'header',
      label TEXT NOT NULL,
      url TEXT NOT NULL,
      parent_id TEXT REFERENCES cms_menu_items(id) ON DELETE CASCADE,
      sort_order INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('draft','published','archived')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_cms_menu ON cms_menu_items(menu_key,status,sort_order);

    CREATE TABLE IF NOT EXISTS cms_preview_tokens (
      token_hash TEXT PRIMARY KEY,
      page_id TEXT NOT NULL REFERENCES cms_pages(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      created_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS user_contacts (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      mobile TEXT NOT NULL UNIQUE,
      tags TEXT,
      note TEXT,
      sms_consent INTEGER NOT NULL DEFAULT 0,
      sms_consent_at TEXT,
      sms_consent_version TEXT,
      sms_consent_source TEXT,
      sms_consent_revoked_at TEXT,
      source TEXT NOT NULL DEFAULT 'manual' CHECK(source IN ('registered','manual','import')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_user_contacts_mobile ON user_contacts(mobile);
    CREATE INDEX IF NOT EXISTS idx_user_contacts_source ON user_contacts(source,updated_at);

    CREATE TABLE IF NOT EXISTS marketing_consent_events (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      contact_id TEXT REFERENCES user_contacts(id) ON DELETE SET NULL,
      mobile_hash TEXT NOT NULL,
      channel TEXT NOT NULL DEFAULT 'sms' CHECK(channel IN ('sms')),
      purpose TEXT NOT NULL DEFAULT 'marketing' CHECK(purpose IN ('marketing')),
      granted INTEGER NOT NULL,
      policy_version TEXT NOT NULL,
      source TEXT NOT NULL CHECK(source IN ('signup_checkbox','privacy_center','admin_attested','import_attested','deletion_request')),
      occurred_at TEXT NOT NULL,
      ip TEXT,
      user_agent TEXT,
      actor_admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_marketing_consent_user ON marketing_consent_events(user_id,occurred_at);
    CREATE INDEX IF NOT EXISTS idx_marketing_consent_contact ON marketing_consent_events(contact_id,occurred_at);

    CREATE TABLE IF NOT EXISTS journal_accounts (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      id TEXT NOT NULL,
      name TEXT NOT NULL,
      starting_balance REAL NOT NULL DEFAULT 0,
      payload TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      deleted_at TEXT,
      PRIMARY KEY(user_id,id)
    );
    CREATE INDEX IF NOT EXISTS idx_journal_accounts_user ON journal_accounts(user_id,deleted_at,updated_at);

    CREATE TABLE IF NOT EXISTS journal_trades (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      id TEXT NOT NULL,
      account_id TEXT NOT NULL,
      entry_at TEXT,
      symbol TEXT,
      direction TEXT,
      result_type TEXT,
      amount REAL NOT NULL DEFAULT 0,
      payload TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      deleted_at TEXT,
      PRIMARY KEY(user_id,id),
      FOREIGN KEY(user_id,account_id) REFERENCES journal_accounts(user_id,id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_journal_trades_user ON journal_trades(user_id,deleted_at,entry_at);
    CREATE INDEX IF NOT EXISTS idx_journal_trades_account ON journal_trades(user_id,account_id,deleted_at,entry_at);

    CREATE TABLE IF NOT EXISTS journal_preferences (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      value TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(user_id,key)
    );

    CREATE TABLE IF NOT EXISTS journal_sync_versions (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(user_id,key)
    );

    CREATE TABLE IF NOT EXISTS journal_media_refs (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      storage_key TEXT NOT NULL,
      ref_path TEXT NOT NULL,
      file_id TEXT NOT NULL REFERENCES media_files(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      PRIMARY KEY(user_id,storage_key,ref_path)
    );
    CREATE INDEX IF NOT EXISTS idx_journal_media_refs_file ON journal_media_refs(file_id);

    CREATE TABLE IF NOT EXISTS user_activity_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      action TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      ip TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_user_activity_user ON user_activity_logs(user_id,created_at);
    CREATE INDEX IF NOT EXISTS idx_user_activity_action ON user_activity_logs(action,created_at);

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      admin_id TEXT REFERENCES admins(id) ON DELETE SET NULL,
      action TEXT NOT NULL,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      ip TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_audit_admin ON audit_logs(admin_id);
    CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action,created_at);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type,entity_id,created_at);
  `);

  migrateAdminRoleConstraint();
  const adminColumns = new Set(db.prepare('PRAGMA table_info(admins)').all().map(column => column.name));
  if (!adminColumns.has('username')) db.exec('ALTER TABLE admins ADD COLUMN username TEXT');
  if (!adminColumns.has('mfa_required')) db.exec('ALTER TABLE admins ADD COLUMN mfa_required INTEGER NOT NULL DEFAULT 0');
  if (!adminColumns.has('mfa_enforced_at')) db.exec('ALTER TABLE admins ADD COLUMN mfa_enforced_at TEXT');
  db.prepare("UPDATE admins SET mfa_required=1 WHERE role='owner'").run();
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_admins_username ON admins(username) WHERE username IS NOT NULL');
  const adminTotpColumns = new Set(db.prepare('PRAGMA table_info(admin_totp)').all().map(column => column.name));
  if (!adminTotpColumns.has('pending_secret_encrypted')) db.exec('ALTER TABLE admin_totp ADD COLUMN pending_secret_encrypted TEXT');
  if (!adminTotpColumns.has('pending_created_at')) db.exec('ALTER TABLE admin_totp ADD COLUMN pending_created_at TEXT');
  const adminChallengeColumns = new Set(db.prepare('PRAGMA table_info(admin_auth_challenges)').all().map(column => column.name));
  if (!adminChallengeColumns.has('attempts')) db.exec('ALTER TABLE admin_auth_challenges ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0');
  if (!adminChallengeColumns.has('max_attempts')) db.exec('ALTER TABLE admin_auth_challenges ADD COLUMN max_attempts INTEGER NOT NULL DEFAULT 5');
  const cmsPageColumns = new Set(db.prepare('PRAGMA table_info(cms_pages)').all().map(column => column.name));
  [['seo_title','TEXT'],['seo_keywords','TEXT'],['og_image','TEXT'],['canonical_url','TEXT'],['publish_at','TEXT'],['unpublish_at','TEXT']].forEach(([column,type])=>{if(!cmsPageColumns.has(column))db.exec(`ALTER TABLE cms_pages ADD COLUMN ${column} ${type}`)});
  const cmsSectionColumns = new Set(db.prepare('PRAGMA table_info(cms_sections)').all().map(column => column.name));
  [['image_url','TEXT'],['image_alt','TEXT'],['publish_at','TEXT'],['unpublish_at','TEXT']].forEach(([column,type])=>{if(!cmsSectionColumns.has(column))db.exec(`ALTER TABLE cms_sections ADD COLUMN ${column} ${type}`)});
  const userColumns = new Set(db.prepare('PRAGMA table_info(users)').all().map(column => column.name));
  const userMigrations = [
    ['password_hash', 'ALTER TABLE users ADD COLUMN password_hash TEXT'],
    ['updated_at', 'ALTER TABLE users ADD COLUMN updated_at TEXT'],
    ['mobile_verified_at', 'ALTER TABLE users ADD COLUMN mobile_verified_at TEXT'],
    ['require_2fa', 'ALTER TABLE users ADD COLUMN require_2fa INTEGER NOT NULL DEFAULT 0'],
    ['security_level', "ALTER TABLE users ADD COLUMN security_level TEXT NOT NULL DEFAULT 'normal' CHECK(security_level IN ('normal','sensitive'))"],
    ['failed_login_count', 'ALTER TABLE users ADD COLUMN failed_login_count INTEGER NOT NULL DEFAULT 0'],
    ['last_login_ip', 'ALTER TABLE users ADD COLUMN last_login_ip TEXT'],
    ['last_login_at', 'ALTER TABLE users ADD COLUMN last_login_at TEXT'],
    ['access_mode', "ALTER TABLE users ADD COLUMN access_mode TEXT NOT NULL DEFAULT 'normal' CHECK(access_mode IN ('normal','limited'))"],
    ['limited_until', 'ALTER TABLE users ADD COLUMN limited_until TEXT'],
    ['restriction_reason', 'ALTER TABLE users ADD COLUMN restriction_reason TEXT'],
    ['deletion_requested_at', 'ALTER TABLE users ADD COLUMN deletion_requested_at TEXT'],
    ['deleted_at', 'ALTER TABLE users ADD COLUMN deleted_at TEXT']
  ];
  userMigrations.forEach(([column, sql]) => { if (!userColumns.has(column)) db.exec(sql); });
  db.prepare('UPDATE users SET updated_at=COALESCE(updated_at,created_at)').run();
  const userSessionColumns = new Set(db.prepare('PRAGMA table_info(user_sessions)').all().map(column => column.name));
  [['token_hash','TEXT'],['csrf_token','TEXT'],['user_agent','TEXT'],['device_id','TEXT'],['auth_method',"TEXT NOT NULL DEFAULT 'password'"],['mfa_verified','INTEGER NOT NULL DEFAULT 0']].forEach(([column,type])=>{if(!userSessionColumns.has(column))db.exec(`ALTER TABLE user_sessions ADD COLUMN ${column} ${type}`)});
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token_hash) WHERE token_hash IS NOT NULL');
  const adminSessionColumns = new Set(db.prepare('PRAGMA table_info(admin_sessions)').all().map(column=>column.name));
  if(!adminSessionColumns.has('mfa_verified'))db.exec('ALTER TABLE admin_sessions ADD COLUMN mfa_verified INTEGER NOT NULL DEFAULT 0');
  if(!adminSessionColumns.has('auth_method'))db.exec("ALTER TABLE admin_sessions ADD COLUMN auth_method TEXT NOT NULL DEFAULT 'password'");
  const smsProviderColumns = new Set(db.prepare('PRAGMA table_info(sms_providers)').all().map(column=>column.name));
  if(!smsProviderColumns.has('provider_type'))db.exec("ALTER TABLE sms_providers ADD COLUMN provider_type TEXT NOT NULL DEFAULT 'generic_webhook'");
  if(!smsProviderColumns.has('config_json'))db.exec('ALTER TABLE sms_providers ADD COLUMN config_json TEXT');
  if(!smsProviderColumns.has('credentials_encrypted'))db.exec('ALTER TABLE sms_providers ADD COLUMN credentials_encrypted TEXT');
  db.prepare("UPDATE sms_providers SET provider_type=CASE WHEN provider_key='kavenegar' THEN 'kavenegar' WHEN provider_key='melipayamak' THEN 'melipayamak' ELSE provider_type END").run();
  db.prepare(`INSERT OR IGNORE INTO auth_security_settings (id,max_devices,trusted_device_days,otp_ttl_seconds,otp_max_attempts,captcha_failure_threshold,new_device_otp,notify_new_login,updated_at) VALUES ('default',5,30,120,5,3,0,1,?)`).run(iso());
  const planColumns=new Set(db.prepare('PRAGMA table_info(plans)').all().map(column=>column.name));
  [['tagline','TEXT'],['badge_label','TEXT'],['cta_label','TEXT'],['is_recommended','INTEGER NOT NULL DEFAULT 0'],['sort_order','INTEGER NOT NULL DEFAULT 0'],['duration_days','INTEGER NOT NULL DEFAULT 30'],['discount_percent','INTEGER NOT NULL DEFAULT 0'],['discount_price','INTEGER'],['discount_label','TEXT'],['discount_until','TEXT']].forEach(([column,type])=>{if(!planColumns.has(column))db.exec(`ALTER TABLE plans ADD COLUMN ${column} ${type}`)});
  const subscriptionColumns = new Set(db.prepare('PRAGMA table_info(subscriptions)').all().map(column => column.name));
  if (!subscriptionColumns.has('coupon_id')) db.exec('ALTER TABLE subscriptions ADD COLUMN coupon_id TEXT');
  if (!subscriptionColumns.has('discount_amount')) db.exec('ALTER TABLE subscriptions ADD COLUMN discount_amount INTEGER NOT NULL DEFAULT 0');
  const smsColumns = new Set(db.prepare('PRAGMA table_info(sms_logs)').all().map(column => column.name));
  if (!smsColumns.has('request_ip')) db.exec('ALTER TABLE sms_logs ADD COLUMN request_ip TEXT');
  if (!smsColumns.has('is_suspicious')) db.exec('ALTER TABLE sms_logs ADD COLUMN is_suspicious INTEGER NOT NULL DEFAULT 0');
  if (!smsColumns.has('suspicious_reason')) db.exec('ALTER TABLE sms_logs ADD COLUMN suspicious_reason TEXT');
  db.exec('CREATE INDEX IF NOT EXISTS idx_sms_mobile_created ON sms_logs(mobile,created_at)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_sms_ip_created ON sms_logs(request_ip,created_at)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_sms_suspicious ON sms_logs(is_suspicious,created_at)');
  const systemSettingColumns = new Set(db.prepare('PRAGMA table_info(system_settings)').all().map(column => column.name));
  if (!systemSettingColumns.has('guide_text')) db.exec("ALTER TABLE system_settings ADD COLUMN guide_text TEXT NOT NULL DEFAULT 'راهنمای استفاده از SmartJournal به‌زودی تکمیل خواهد شد.'");
  const contactColumns=new Set(db.prepare('PRAGMA table_info(user_contacts)').all().map(column=>column.name));
  [['sms_consent_at','TEXT'],['sms_consent_version','TEXT'],['sms_consent_source','TEXT'],['sms_consent_revoked_at','TEXT']].forEach(([column,type])=>{if(!contactColumns.has(column))db.exec(`ALTER TABLE user_contacts ADD COLUMN ${column} ${type}`)});

  seedPlans();
  seedAdmin();
  seedDemoAdmins();
  seedAdminUsernames();
  seedRolePermissions();
  seedSystemSettings();
  seedLegalDocuments();
  seedCmsContent();
  db.prepare("UPDATE cms_sections SET body=?,updated_at=? WHERE id='cms_login_form' AND body LIKE '%حساب محلی%'").run('با شماره موبایل و رمز وارد فضای امن و همگام‌شده ژورنال شو.',iso());
  db.prepare("UPDATE cms_sections SET body=?,updated_at=? WHERE id='cms_login_security' AND body LIKE '%همین مرورگر%'").run('داده‌های ژورنال با نشست امن و رمزنگاری انتقال روی حساب سروری شما همگام می‌شوند.',iso());
  seedCmsMenus();
  seedSmsManagementData();
  seedFileSettings();
  if (process.env.NODE_ENV !== 'production' && process.env.SEED_DEMO_DATA !== 'false') seedDemoData();
  syncUserContacts();
  seedUserSessions();
  seedBillingData();
  seedFileManagementData();
  seedSecurityData();
  db.prepare(`INSERT OR IGNORE INTO schema_migrations (version,source_checksum,started_at,completed_at,details) VALUES ('runtime-schema-1','native',?,?,?)`).run(iso(),iso(),JSON.stringify({engine:DATABASE_ENGINE,appVersion:APP_VERSION}));
  db.prepare(`INSERT OR IGNORE INTO schema_migrations (version,source_checksum,started_at,completed_at,details) VALUES ('runtime-schema-2-marketing-content','plans-features-faqs',?,?,?)`).run(iso(),iso(),JSON.stringify({engine:DATABASE_ENGINE,appVersion:APP_VERSION,tables:['plan_features','marketing_faqs'],planColumns:['tagline','badge_label','cta_label','is_recommended','sort_order']}));
  const brandColumns={marketing_faqs:['question','answer'],cms_pages:['title','meta_description','seo_title','seo_keywords'],cms_sections:['title','body','button_label'],sms_settings:['otp_template'],system_settings:['maintenance_message','terms_text','privacy_text','guide_text'],announcements:['title','body']};Object.entries(brandColumns).forEach(([table,columns])=>columns.forEach(column=>db.prepare(`UPDATE ${table} SET ${column}=replace(replace(${column},'PA Journal','SmartJournal'),'PA JOURNAL','SMARTJOURNAL') WHERE ${column} LIKE '%PA Journal%' OR ${column} LIKE '%PA JOURNAL%'`).run()));
  const updateSupportReference=db.prepare('UPDATE support_requests SET public_reference=? WHERE id=?');db.prepare("SELECT id,public_reference FROM support_requests WHERE public_reference LIKE 'PA-%'").all().forEach(row=>updateSupportReference.run('SJ-'+String(row.public_reference).slice(3),row.id));
  const legacySupportRequests=db.prepare(`SELECT id,user_id,message,created_at FROM support_requests WHERE id NOT IN (SELECT request_id FROM support_messages)`).all(),insertLegacySupportMessage=db.prepare(`INSERT OR IGNORE INTO support_messages (id,request_id,author_type,user_id,admin_id,message,is_internal,created_at,read_at) VALUES (?,?,'user',?,NULL,?,0,?,NULL)`);legacySupportRequests.forEach(item=>insertLegacySupportMessage.run(`support_message_legacy_${item.id}`,item.id,item.user_id||null,item.message,item.created_at));
  db.prepare(`INSERT OR IGNORE INTO schema_migrations (version,source_checksum,started_at,completed_at,details) VALUES ('runtime-schema-3-plan-access-support','journal-entitlements-support-thread',?,?,?)`).run(iso(),iso(),JSON.stringify({engine:DATABASE_ENGINE,appVersion:APP_VERSION,tables:['plan_journal_sections','support_messages'],planColumns:['duration_days']}));
  db.prepare(`INSERT OR IGNORE INTO schema_migrations (version,source_checksum,started_at,completed_at,details) VALUES ('runtime-schema-4-smartjournal-brand','smartjournal-brand-and-logo',?,?,?)`).run(iso(),iso(),JSON.stringify({engine:DATABASE_ENGINE,appVersion:APP_VERSION,brand:'SmartJournal'}));
  cleanupExpiredSessions();
}

function initDb(){
  if(DATABASE_ENGINE!=='postgres')return initializeSchemaAndSeeds();
  return db.transaction(()=>{db.prepare('SELECT pg_advisory_xact_lock(hashtext(?)) AS locked').get(`pa-journal-runtime-init:${db.schema||'pa_journal'}`);return initializeSchemaAndSeeds()})();
}

function seedPlans() {
  const plans = [
    ['plan_free', 'free', 'رایگان', 0, 100, 100 * 1024 * 1024, 5, '#94a3b8', 0],
    ['plan_pro', 'pro', 'حرفه‌ای', 390000, 2500, 2 * 1024 * 1024 * 1024, 30, '#22d3ee', 30],
    ['plan_elite', 'organization', 'سازمانی', 790000, 10000, 10 * 1024 * 1024 * 1024, 100, '#a78bfa', 30]
  ];
  const stmt = db.prepare(`INSERT OR IGNORE INTO plans
    (id,name,name_fa,price_monthly,max_trades,max_storage_bytes,max_sms_monthly,color,duration_days)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => plans.forEach(plan => stmt.run(...plan)));
  tx();
  db.prepare("UPDATE plans SET name='organization',name_fa='سازمانی' WHERE id='plan_elite'").run();
  db.prepare("UPDATE plans SET tagline=COALESCE(tagline,'شروع ساده و رایگان برای ساخت عادت ژورنال‌نویسی'),cta_label=COALESCE(cta_label,'شروع رایگان'),sort_order=CASE WHEN sort_order=0 THEN 10 ELSE sort_order END WHERE id='plan_free'").run();
  db.prepare("UPDATE plans SET tagline=COALESCE(tagline,'تحلیل عمیق‌تر برای معامله‌گرانی که پیوسته رشد می‌کنند'),badge_label=COALESCE(badge_label,'پیشنهاد معامله‌گران'),cta_label=COALESCE(cta_label,'انتخاب حرفه‌ای'),is_recommended=CASE WHEN NOT EXISTS(SELECT 1 FROM plans WHERE is_recommended=1) THEN 1 ELSE is_recommended END,sort_order=CASE WHEN sort_order=0 THEN 20 ELSE sort_order END WHERE id='plan_pro'").run();
  db.prepare("UPDATE plans SET tagline=COALESCE(tagline,'ظرفیت بیشتر، گزارش کامل‌تر و پشتیبانی اولویت‌دار'),cta_label=COALESCE(cta_label,'انتخاب سازمانی'),sort_order=CASE WHEN sort_order=0 THEN 30 ELSE sort_order END WHERE id='plan_elite'").run();
  if(!db.prepare("SELECT 1 FROM schema_migrations WHERE version='runtime-schema-3-plan-access-support'").get()){
    db.prepare("UPDATE plans SET duration_days=0 WHERE id='plan_free'").run();
    db.prepare("UPDATE plans SET duration_days=30 WHERE id IN ('plan_pro','plan_elite')").run();
  }
  const featureDefinitions={
    plan_free:[['trade_log','ثبت و مرور تا ۱۰۰ معامله'],['analytics','داشبورد عملکرد و سود و زیان'],['images','۱۰۰ مگابایت فضای تصاویر'],['sms','۵ پیامک اطلاع‌رسانی در ماه']],
    plan_pro:[['trade_log','ثبت تا ۲٬۵۰۰ معامله'],['analytics','تحلیل پیشرفته عملکرد و ریسک'],['images','۲ گیگابایت فضای تصاویر'],['sms','۳۰ پیامک اطلاع‌رسانی در ماه'],['exports','خروجی CSV و گزارش‌های تکمیلی'],['patterns','برچسب‌گذاری و کشف الگوهای معاملاتی']],
    plan_elite:[['trade_log','ثبت تا ۱۰٬۰۰۰ معامله'],['analytics','تحلیل پیشرفته عملکرد و ریسک'],['images','۱۰ گیگابایت فضای تصاویر'],['sms','۱۰۰ پیامک اطلاع‌رسانی در ماه'],['exports','خروجی CSV و گزارش‌های تکمیلی'],['patterns','برچسب‌گذاری و کشف الگوهای معاملاتی'],['priority_support','پشتیبانی اولویت‌دار'],['extended_archive','آرشیو گسترده داده و تصاویر']]
  };
  const featureInsert=db.prepare(`INSERT OR IGNORE INTO plan_features (id,plan_id,feature_key,label,description,is_enabled,sort_order,created_at,updated_at) VALUES (?,?,?,?,NULL,1,?,?,?)`),now=iso();
  db.transaction(()=>Object.entries(featureDefinitions).forEach(([planId,features])=>features.forEach(([key,label],index)=>featureInsert.run(`feature_${planId}_${key}`,planId,key,label,(index+1)*10,now,now))))();
  const journalSectionKeys=['dashboard','new','history','calendar','prop','risk','checklist','documents','import','settings','pwa'],journalAccess={
    plan_free:new Set(['dashboard','new','history','calendar','checklist','documents','settings','pwa']),
    plan_pro:new Set(['dashboard','new','history','calendar','risk','checklist','documents','import','settings','pwa']),
    plan_elite:new Set(journalSectionKeys)
  },sectionInsert=db.prepare(`INSERT OR IGNORE INTO plan_journal_sections (id,plan_id,section_key,is_enabled,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`);
  db.transaction(()=>Object.entries(journalAccess).forEach(([planId,enabled])=>journalSectionKeys.forEach((sectionKey,index)=>sectionInsert.run(`journal_section_${planId}_${sectionKey}`,planId,sectionKey,enabled.has(sectionKey)?1:0,(index+1)*10,now,now))))();

  const faqRows=[
    ['faq_why_1','why','چرا به‌جای فایل اکسل از SmartJournal استفاده کنم؟','چون ثبت معامله، تصویر، برچسب و تحلیل عملکرد در یک جریان امن و منظم کنار هم قرار می‌گیرند؛ بدون فرمول‌های شکننده و نسخه‌های پراکنده فایل.',1,10],
    ['faq_why_2','why','چرا مرور منظم ژورنال برای معامله‌گر مهم است؟','مرور منظم کمک می‌کند الگوهای تکرارشونده، خطاهای رفتاری و کیفیت اجرای پلن معاملاتی را با شواهد واقعی ببینید و تصمیم بعدی را آگاهانه‌تر بگیرید.',1,20],
    ['faq_why_3','why','چه چیزی SmartJournal را برای استفاده روزانه مناسب می‌کند؟','رابط سریع، ثبت ساختاریافته، گزارش‌های قابل فهم، پشتیبانی موبایل و کنترل‌های امنیتی باعث می‌شوند ژورنال‌نویسی بخشی ساده از فرایند روزانه باشد.',1,30],
    ...FAQS.map((item,index)=>[`faq_product_${index+1}`,'product',item.question,item.answer,0,(index+1)*10])
  ];
  const faqInsert=db.prepare(`INSERT OR IGNORE INTO marketing_faqs (id,category,question,answer,status,is_featured,sort_order,created_at,updated_at) VALUES (?,?,?,?,'published',?,?,?,?)`);
  db.transaction(()=>faqRows.forEach(row=>faqInsert.run(...row,now,now)))();
}

function normalizeMobile(value) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  let v = String(value || '')
    .replace(/[۰-۹]/g, d => String(fa.indexOf(d)))
    .replace(/[٠-٩]/g, d => String(ar.indexOf(d)))
    .replace(/[^+\d]/g, '');
  if (v.startsWith('0098')) v = `0${v.slice(4)}`;
  else if (v.startsWith('+98')) v = `0${v.slice(3)}`;
  else if (v.startsWith('98') && v.length === 12) v = `0${v.slice(2)}`;
  return v.replace(/\D/g, '');
}

function seedSystemSettings() {
  const owner = db.prepare("SELECT id FROM admins WHERE role='owner' LIMIT 1").get();
  db.prepare(`INSERT OR IGNORE INTO system_settings
    (id,signup_enabled,maintenance_mode,maintenance_message,terms_text,privacy_text,guide_text,app_version,updated_at,updated_by_admin_id)
    VALUES ('default',1,0,?,?,?,?,?,?,?)`)
    .run('سامانه در حال به‌روزرسانی است؛ لطفاً چند دقیقه دیگر دوباره تلاش کنید.',
      'با ایجاد حساب در SmartJournal، کاربر می‌پذیرد که مسئولیت ثبت و تحلیل معاملات، حفاظت از اطلاعات ورود و استفاده قانونی از سامانه بر عهده او است. استفاده از خدمات برای فعالیت‌های غیرقانونی، آسیب‌زدن به زیرساخت یا نقض حقوق دیگران مجاز نیست.',
      'SmartJournal فقط داده‌های لازم برای ارائه خدمات، امنیت حساب و بهبود عملکرد را پردازش می‌کند. اطلاعات شخصی بدون مبنای قانونی در اختیار اشخاص ثالث قرار نمی‌گیرد و کاربر می‌تواند درخواست مشاهده، اصلاح یا حذف داده‌های خود را ثبت کند.',
      'برای شروع، معامله جدید را ثبت کنید، نتیجه و تصاویر مرتبط را اضافه کنید و سپس از داشبورد برای مرور عملکرد، مدیریت ریسک و تحلیل الگوهای معاملاتی استفاده کنید.',
      APP_VERSION, iso(), owner && owner.id);
  if (process.env.NODE_ENV === 'production' || process.env.SEED_DEMO_DATA === 'false') return;
  if (!db.prepare('SELECT COUNT(*) AS count FROM announcements').get().count) {
    const stmt = db.prepare(`INSERT INTO announcements
      (id,title,body,tone,audience,status,starts_at,expires_at,created_at,updated_at,created_by_admin_id,updated_by_admin_id)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
    stmt.run('announcement_release','نسخه جدید ژورنال منتشر شد','نسخه جدید با بهبود مدیریت تصاویر، امنیت و گزارش‌های مدیریتی در دسترس است.','success','all','published',daysAgo(2),daysFromNow(20),daysAgo(2),daysAgo(2),owner && owner.id,owner && owner.id);
    stmt.run('announcement_maintenance','به‌روزرسانی برنامه‌ریزی‌شده','جمعه از ساعت ۲ تا ۳ بامداد ممکن است سرویس برای مدت کوتاهی در دسترس نباشد.','warning','all','draft',daysFromNow(2),daysFromNow(4),daysAgo(1),daysAgo(1),owner && owner.id,owner && owner.id);
    stmt.run('announcement_pro','راهنمای امکانات پلن حرفه‌ای','کاربران حرفه‌ای می‌توانند از فضای بیشتر تصاویر و گزارش‌های پیشرفته استفاده کنند.','info','pro','published',daysAgo(5),daysFromNow(30),daysAgo(5),daysAgo(3),owner && owner.id,owner && owner.id);
  }
}

function seedLegalDocuments(){const operatorName=String(process.env.LEGAL_OPERATOR_NAME||''),operatorRegistration=String(process.env.LEGAL_OPERATOR_REGISTRATION||''),operatorAddress=String(process.env.LEGAL_OPERATOR_ADDRESS||''),identityComplete=!!operatorName&&!!operatorRegistration&&!!operatorAddress,documents=buildLegalDocuments({operatorName,operatorRegistration,operatorAddress,effectiveDate:process.env.LEGAL_EFFECTIVE_DATE||new Date().toISOString().slice(0,10)}),owner=db.prepare("SELECT id FROM admins WHERE role='owner' LIMIT 1").get(),now=iso(),status=identityComplete||process.env.NODE_ENV!=='production'?'published':'draft',insert=db.prepare(`INSERT OR IGNORE INTO legal_documents (id,document_type,version,title,content,content_sha256,status,effective_at,created_at,published_at,created_by_admin_id) VALUES (?,?,?,?,?,?,?, ?,?,?,?)`);for(const type of LEGAL_TYPES){const content=documents[type],hash=crypto.createHash('sha256').update(content).digest('hex');insert.run(`legal_${type}_1_0_0`,type,'1.0.0',LEGAL_TITLES[type],content,hash,status,now,now,status==='published'?now:null,owner?.id||null)}const terms=documents.terms,privacy=documents.privacy;db.prepare("UPDATE system_settings SET terms_text=?,privacy_text=? WHERE id='default' AND length(terms_text)<1000").run(terms,privacy)}

function seedSmsManagementData() {
  const demo = process.env.NODE_ENV !== 'production' && process.env.SEED_DEMO_DATA !== 'false';
  db.prepare(`INSERT OR IGNORE INTO sms_settings
    (id,otp_template,mobile_limit_count,ip_limit_count,rate_window_minutes,auto_failover,updated_at)
    VALUES ('default',?,?,?,?,?,?)`)
    .run('کد ورود شما به SmartJournal: {code}\nاین کد تا ۲ دقیقه معتبر است.', 5, 12, 10, 1, iso());
  const providers = demo ? [
    ['sms_kavenegar','kavenegar','kavenegar','کاوه‌نگار',8450000,420,'healthy',1,1,1,null],
    ['sms_melipayamak','melipayamak','melipayamak','ملی‌پیامک',5160000,390,'degraded',1,0,2,daysAgo(1)],
    ['sms_faraz','farazsms','generic_webhook','فراز اس‌ام‌اس',2800000,360,'down',0,0,3,daysAgo(0,3)]
  ] : [
    ['sms_kavenegar','kavenegar','kavenegar','کاوه‌نگار',0,0,'healthy',1,1,1,null],
    ['sms_melipayamak','melipayamak','melipayamak','ملی‌پیامک',0,0,'healthy',1,0,2,null]
  ];
  const stmt = db.prepare(`INSERT OR IGNORE INTO sms_providers
    (id,provider_key,provider_type,name,balance,unit_cost,status,is_enabled,is_primary,priority,last_error_at,last_checked_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => providers.forEach(provider => stmt.run(...provider, iso(), iso())));
  tx();
  db.prepare("UPDATE sms_providers SET provider_type=CASE WHEN provider_key='kavenegar' THEN 'kavenegar' WHEN provider_key='melipayamak' THEN 'melipayamak' ELSE provider_type END").run();
  if (!db.prepare('SELECT 1 FROM sms_providers WHERE is_primary=1 AND is_enabled=1 LIMIT 1').get()) {
    const fallback = db.prepare("SELECT id FROM sms_providers WHERE is_enabled=1 AND status!='down' ORDER BY priority LIMIT 1").get();
    if (fallback) db.prepare('UPDATE sms_providers SET is_primary=CASE WHEN id=? THEN 1 ELSE 0 END,updated_at=?').run(fallback.id, iso());
  }
  db.prepare("UPDATE sms_logs SET request_ip=CASE WHEN rowid%19=0 THEN '198.51.100.77' ELSE '192.0.2.' || CAST(20 + rowid%45 AS TEXT) END WHERE request_ip IS NULL").run();
  db.prepare("UPDATE sms_logs SET is_suspicious=1,suspicious_reason=COALESCE(suspicious_reason,'تکرار درخواست OTP از شماره یا IP مشترک') WHERE rowid%31=0").run();
}

function seedFileSettings() {
  db.prepare(`INSERT OR IGNORE INTO file_settings
    (id,allowed_mime_types,max_file_size_bytes,orphan_retention_days,auto_cleanup,updated_at)
    VALUES ('default',?,?,?,?,?)`)
    .run(JSON.stringify(['image/jpeg','image/png','image/webp','image/gif']), 12 * 1024 * 1024, 14, 0, iso());
}

function seedFileManagementData() {
  if (process.env.NODE_ENV === 'production' || process.env.SEED_DEMO_DATA === 'false') return;
  if (db.prepare('SELECT COUNT(*) AS count FROM media_files').get().count) return;
  const users = db.prepare("SELECT id FROM users WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 58").all();
  if (!users.length) return;
  const safeFormats = [
    ['image/jpeg','jpg'],['image/png','png'],['image/webp','webp'],['image/gif','gif']
  ];
  const stmt = db.prepare(`INSERT INTO media_files
    (id,user_id,trade_ref,original_name,storage_key,mime_type,size_bytes,checksum_sha256,status,scan_status,scan_reason,uploaded_at,orphaned_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => users.forEach((user, userIndex) => {
    const count = 2 + (userIndex % 4);
    for (let fileIndex = 0; fileIndex < count; fileIndex++) {
      const index = userIndex * 5 + fileIndex;
      const orphan = index % 7 === 0;
      const unsafeFormat = index % 23 === 0;
      const oversized = !unsafeFormat && index % 19 === 0;
      const format = unsafeFormat ? ['image/svg+xml','svg'] : safeFormats[index % safeFormats.length];
      const size = oversized ? (15 + index % 8) * 1024 * 1024 : (350 + index % 7800) * 1024;
      const suspicious = unsafeFormat || oversized || index % 31 === 0;
      const reason = unsafeFormat ? 'فرمت SVG دارای محتوای اسکریپتی است' : oversized ? 'حجم فایل بیشتر از سقف مجاز است' : suspicious ? 'امضای باینری فایل با پسوند مطابقت ندارد' : null;
      const fileId = id('file');
      const uploadedAt = daysAgo(index % 75, index % 20);
      stmt.run(fileId, user.id, orphan ? null : `trade_${1000 + index}`, `chart-${14050000 + index}.${format[1]}`,
        `demo/${user.id}/${fileId}.${format[1]}`, format[0], size,
        crypto.createHash('sha256').update(`${user.id}:${index}`).digest('hex'),
        suspicious && index % 2 === 0 ? 'quarantined' : 'active', suspicious ? 'suspicious' : 'safe', reason,
        uploadedAt, orphan ? uploadedAt : null);
    }
  }));
  tx();
}

function seedSecurityData() {
  db.prepare("UPDATE security_blocks SET status='expired' WHERE status='active' AND expires_at IS NOT NULL AND expires_at<=?").run(iso());
  if (process.env.NODE_ENV === 'production' || process.env.SEED_DEMO_DATA === 'false') return;
  const owner = db.prepare("SELECT id FROM admins WHERE role='owner' LIMIT 1").get();
  if (!db.prepare('SELECT COUNT(*) AS count FROM security_blocks').get().count) {
    const users = db.prepare('SELECT mobile FROM users WHERE deleted_at IS NULL ORDER BY created_at LIMIT 3').all();
    const stmt = db.prepare(`INSERT INTO security_blocks
      (id,block_type,block_value,reason,source,status,expires_at,created_at,created_by_admin_id,revoked_at,revoked_by_admin_id)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
    stmt.run('block_ip_attack','ip','198.51.100.77','درخواست پرتکرار OTP از یک IP','automatic','active',daysFromNow(3),daysAgo(1),null,null,null);
    stmt.run('block_ip_scan','ip','203.0.113.91','اسکن متوالی مسیرهای API','automatic','active',daysFromNow(1),daysAgo(0,6),null,null,null);
    if (users[0]) stmt.run('block_mobile_demo','mobile',users[0].mobile,'تلاش ناموفق ورود بیش از حد','manual','active',daysFromNow(2),daysAgo(2),owner && owner.id,null,null);
    if (users[1]) stmt.run('block_mobile_expired','mobile',users[1].mobile,'محدودسازی موقت پایان‌یافته','automatic','expired',daysAgo(1),daysAgo(5),null,null,null);
  }
  if (!db.prepare('SELECT COUNT(*) AS count FROM security_alerts').get().count) {
    const stmt = db.prepare(`INSERT INTO security_alerts
      (id,category,severity,title,details,status,detected_at,acknowledged_at,resolved_at,resolved_by_admin_id)
      VALUES (?,?,?,?,?,?,?,?,?,?)`);
    stmt.run('alert_login_burst','authentication','critical','افزایش تلاش‌های ناموفق ورود',JSON.stringify({ failedAttempts: 19, windowMinutes: 15, ip: '198.51.100.77' }),'open',daysAgo(0,2),null,null,null);
    stmt.run('alert_api_errors','api','error','افزایش خطاهای API اشتراک',JSON.stringify({ endpoint: '/api/subscriptions', errorRate: 12.4 }),'open',daysAgo(0,5),null,null,null);
    stmt.run('alert_db_latency','database','warning','افزایش زمان پاسخ دیتابیس',JSON.stringify({ p95Ms: 480, thresholdMs: 300 }),'acknowledged',daysAgo(1),daysAgo(0,20),null,null);
    stmt.run('alert_storage_growth','consumption','warning','رشد غیرعادی مصرف فضای تصاویر',JSON.stringify({ growthPercent: 34, periodHours: 24 }),'open',daysAgo(0,8),null,null,null);
    stmt.run('alert_sms_attack','sms','error','الگوی مشکوک درخواست OTP',JSON.stringify({ uniqueMobiles: 11, sharedIp: '198.51.100.77' }),'open',daysAgo(0,3),null,null,null);
    stmt.run('alert_file_scan','file','warning','فایل‌های قرنطینه‌نشده نیازمند بررسی',JSON.stringify({ suspiciousFiles: 8 }),'resolved',daysAgo(4),daysAgo(3),daysAgo(2),owner && owner.id);
  }
  if (!db.prepare("SELECT COUNT(*) AS count FROM system_errors WHERE source IN ('ADMIN_API','SQLITE_DB') AND occurred_at>=?").get(daysAgo(1)).count) {
    const stmt = db.prepare(`INSERT INTO system_errors (id,severity,source,message,stack,status,occurred_at,resolved_at) VALUES (?,?,?,?,?,'open',?,NULL)
      ON CONFLICT(id) DO UPDATE SET severity=excluded.severity,source=excluded.source,message=excluded.message,stack=excluded.stack,status='open',occurred_at=excluded.occurred_at,resolved_at=NULL`);
    stmt.run('err_security_api','error','ADMIN_API','پاسخ ناموفق سرویس اشتراک','RequestError: subscription service returned 503',daysAgo(0,3));
    stmt.run('err_security_db','warning','SQLITE_DB','افزایش زمان اجرای Query دیتابیس','DatabaseWarning: query p95 exceeded threshold',daysAgo(0,5));
  }
  if (!db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action IN ('LOGIN_FAILED','LOGIN_BLOCKED')").get().count) {
    const stmt = db.prepare(`INSERT INTO audit_logs (id,admin_id,action,entity_type,entity_id,details,ip,created_at) VALUES (?,NULL,?,?,?,?,?,?)`);
    stmt.run(id('aud'),'LOGIN_FAILED','admin',null,JSON.stringify({ mobile: '09123334444' }),'198.51.100.77',daysAgo(0,2));
    stmt.run(id('aud'),'LOGIN_FAILED','admin',null,JSON.stringify({ mobile: '09125556666' }),'203.0.113.91',daysAgo(0,4));
    stmt.run(id('aud'),'LOGIN_BLOCKED','security_block','block_ip_attack',JSON.stringify({ mobile: '09127778888', reason: 'تلاش ورود پرتکرار' }),'198.51.100.77',daysAgo(0,1));
  }
}

function seedAdmin() {
  if (db.prepare('SELECT COUNT(*) AS count FROM admins').get().count) return;
  const isProd = process.env.NODE_ENV === 'production';
  const mobile = normalizeMobile(process.env.ADMIN_MOBILE || (isProd ? '' : '09120000000'));
  const password = process.env.ADMIN_PASSWORD || (isProd ? '' : 'Admin@12345');
  const name = process.env.ADMIN_NAME || 'مدیر اصلی';
  const username = String(process.env.ADMIN_USERNAME || 'owner').trim().toLowerCase();
  if (!/^09\d{9}$/.test(mobile) || password.length < 10 || !/^[a-z][a-z0-9._-]{2,31}$/.test(username)) {
    throw new Error('First admin is missing. Set a valid ADMIN_MOBILE, ADMIN_USERNAME and ADMIN_PASSWORD (minimum 10 characters).');
  }
  db.prepare(`INSERT INTO admins (id,name,username,mobile,password_hash,role,status,created_at,mfa_required)
              VALUES (?,?,?,?,?,?,?,?,1)`)
    .run(id('adm'), name, username, mobile, bcrypt.hashSync(password, 12), 'owner', 'active', iso());
  if (!isProd) {
    console.log(`\n  Development Owner created: ${username} / ${mobile} (password is not printed)\n`);
  }
}

function seedDemoAdmins() {
  if (process.env.NODE_ENV === 'production' || process.env.SEED_DEMO_DATA === 'false') return;
  const accounts = [
    ['adm_demo_admin','مدیر عمومی','09120000001','admin'],
    ['adm_demo_support','کارشناس پشتیبانی','09120000002','support'],
    ['adm_demo_finance','مدیر مالی','09120000003','finance'],
    ['adm_demo_security','کارشناس امنیت','09120000004','security'],
    ['adm_demo_content','مدیر محتوا','09120000005','content_manager']
  ];
  const missing = accounts.filter(account => !db.prepare('SELECT 1 FROM admins WHERE mobile=?').get(account[2]));
  if (!missing.length) return;
  const hash = bcrypt.hashSync('Admin@12345', 12);
  const stmt = db.prepare(`INSERT INTO admins (id,name,mobile,password_hash,role,status,created_at) VALUES (?,?,?,?,?,'active',?)`);
  const tx = db.transaction(() => missing.forEach(account => stmt.run(account[0], account[1], account[2], hash, account[3], iso())));
  tx();
}

function seedAdminUsernames() {
  const preferred=[['09120000000','owner'],['09120000001','admin'],['09120000002','support'],['09120000003','finance'],['09120000004','security'],['09120000005','content']];
  const update=db.prepare('UPDATE admins SET username=? WHERE mobile=? AND username IS NULL');
  const tx=db.transaction(()=>preferred.forEach(([mobile,username])=>{
    if(!db.prepare('SELECT 1 FROM admins WHERE username=?').get(username))update.run(username,mobile);
  }));tx();
  const unnamed=db.prepare('SELECT id FROM admins WHERE username IS NULL').all();
  unnamed.forEach((admin,index)=>{let candidate=`manager${index+1}`,suffix=index+1;while(db.prepare('SELECT 1 FROM admins WHERE username=?').get(candidate))candidate=`manager${++suffix}`;db.prepare('UPDATE admins SET username=? WHERE id=?').run(candidate,admin.id)});
}

function seedRolePermissions() {
  const now = iso();
  const stmt = db.prepare(`INSERT OR IGNORE INTO role_permissions (role,permission,enabled,updated_at,updated_by_admin_id) VALUES (?,?,?,?,NULL)`);
  const tx = db.transaction(() => {
    Object.keys(DEFAULT_ROLE_PERMISSIONS).forEach(role => {
      PERMISSION_KEYS.forEach(permission => stmt.run(role, permission, DEFAULT_ROLE_PERMISSIONS[role].includes(permission) ? 1 : 0, now));
    });
  });
  tx();
}

function seedCmsContent() {
  const now = iso();
  const pages = [
    { id:'cms_page_home', slug:'home', title:'صفحه معرفی', meta:'متن‌های صفحه معرفی اصلی', status:'published', sections:[
      ['cms_home_hero','hero','hero','معامله را ثبت نکن؛ الگوی خودت را کشف کن','یک ژورنال حرفه‌ای برای تبدیل هر ورود و خروج به بینش قابل‌استفاده؛ از آمار عملکرد و مدیریت ریسک تا روانشناسی، انضباط و بازبینی دقیق معاملات.','شروع ژورنال','',10],
      ['cms_home_features_intro','features_intro','content','هر معامله، یک تکه از مزیت معاملاتی توست','ژورنال فقط آرشیو نیست؛ یک سیستم بازخورد حرفه‌ای است که کمک می‌کند نقاط قوت، اشتباهات تکرارشونده و کیفیت اجرای پلن را شفاف ببینی.','','',20],
      ['cms_home_feature_1','feature_1','feature','تحلیل عملکرد واقعی','وین‌ریت، امید ریاضی، فاکتور سود، افت سرمایه و ده‌ها شاخص دیگر؛ دقیق و تفکیک‌شده برای هر حساب.','','',30],
      ['cms_home_feature_2','feature_2','feature','روانشناسی و انضباط','احساس قبل و بعد معامله، اشتباهات رفتاری و میزان پایبندی به پلن را ثبت کن و الگوهای ذهنی خودت را بشناس.','','',40],
      ['cms_home_feature_3','feature_3','feature','کنترل سرمایه و حساب‌ها','چند حساب مستقل، محاسبه موجودی واقعی، ثبت برداشت و بک‌آپ کامل؛ بدون دست‌کاری آمار معاملات.','','',50],
      ['cms_home_final','final','cta','آماده‌ای حرفه‌ای‌تر معامله کنی؟','از معامله بعدی، داده‌هایت را به مزیت رقابتی تبدیل کن.','ورود به ژورنال','',60],
      ['cms_home_footer','footer','footer','SMARTJOURNAL / 2026','طراحی‌شده برای تصمیم‌های دقیق‌تر و اجرای منضبط‌تر','','',70]
    ]},
    { id:'cms_page_login', slug:'login', title:'صفحه ورود کاربران', meta:'متن‌های معرفی و فرم ورود ژورنال', status:'published', sections:[
      ['cms_login_intro','intro','hero','فضای حرفه‌ای تو برای تصمیم‌های دقیق‌تر','با ورود به فضای شخصی ژورنال، داده‌ها، تحلیل‌ها و نظم معاملاتی خودت را در یک محیط متمرکز مدیریت کن.','','',10],
      ['cms_login_form','form','form','خوش آمدی، معامله‌گر','با شماره موبایل و رمز وارد فضای امن و همگام‌شده ژورنال شو.','ورود امن به ژورنال','',20],
      ['cms_login_security','security','content','دسترسی امن','داده‌های ژورنال با نشست امن و رمزنگاری انتقال روی حساب سروری شما همگام می‌شوند.','','',30]
    ]},
    { id:'cms_page_help', slug:'help', title:'راهنما و پشتیبانی', meta:'محتوای ساختاریافته راهنما', status:'draft', sections:[
      ['cms_help_start','getting_started','content','شروع کار با SmartJournal','ابتدا حساب معاملاتی را بسازید، سپس معاملات را همراه با نتیجه، تصاویر و یادداشت ثبت کنید.','','',10],
      ['cms_help_review','review','content','بازبینی عملکرد','از داشبورد، گزارش ریسک و بخش روانشناسی برای پیدا کردن الگوهای تکرارشونده استفاده کنید.','','',20]
    ]},
    { id:'cms_page_pricing', slug:'pricing', title:'قیمت‌گذاری شفاف', meta:'مقایسه شفاف پلن‌های SmartJournal، قیمت ماهانه، سقف معاملات، فضای تصاویر و امکانات.', status:'published', sections:[
      ['cms_pricing_intro','intro','hero','پلنی متناسب با مرحله معاملاتی شما','قیمت، سقف معامله، فضای تصویر و امکانات هر پلن پیش از انتخاب به‌صورت شفاف نمایش داده می‌شود.','مقایسه پلن‌ها','/pricing#compare',10],
      ['cms_pricing_note','note','content','بدون ادعای سود یا نتیجه تضمینی','اشتراک SmartJournal دسترسی به ابزار ثبت و تحلیل را فراهم می‌کند و شامل سیگنال، مشاوره سرمایه‌گذاری یا تضمین سود نیست.','','',20]
    ]},
    { id:'cms_page_faq', slug:'faq', title:'پرسش‌های متداول', meta:'پاسخ به پرسش‌های متداول درباره قیمت، امنیت، همگام‌سازی و حقوق داده در SmartJournal.', status:'published', sections:[
      ['cms_faq_product','product','content','SmartJournal چه کاری انجام می‌دهد؟','SmartJournal یک ابزار ثبت و تحلیل شخصی است؛ معامله، ریسک، تصاویر و یادداشت‌ها را منظم می‌کند و سیگنال ارائه نمی‌دهد.','','',10],
      ['cms_faq_security','security','content','داده‌ها چگونه محافظت می‌شوند؟','نشست امن، کنترل دستگاه، انتقال رمزنگاری‌شده و سیاست‌های امنیتی فایل برای محافظت از داده‌ها استفاده می‌شوند.','','',20],
      ['cms_faq_privacy','privacy','content','چطور داده‌هایم را دریافت یا حذف کنم؟','در مرکز حریم خصوصی داخل حساب می‌توانید نسخه JSON بگیرید یا درخواست حذف ثبت کنید.','','',30]
    ]},
    { id:'cms_page_about', slug:'about', title:'درباره SmartJournal', meta:'ماموریت، اصول محصول و رویکرد SmartJournal به ثبت و بازبینی حرفه‌ای معاملات.', status:'published', sections:[
      ['cms_about_mission','mission','hero','تصمیم بهتر از بازخورد بهتر شروع می‌شود','SmartJournal برای تبدیل تاریخچه پراکنده معاملات به یک روند بازبینی روشن، قابل اندازه‌گیری و مسئولانه ساخته شده است.','','',10],
      ['cms_about_principles','principles','content','اصول محصول','شفافیت به‌جای وعده، حریم خصوصی در طراحی، کنترل داده توسط کاربر و تمرکز بر کیفیت فرایند به‌جای نتیجه کوتاه‌مدت.','','',20]
    ]},
    { id:'cms_page_contact', slug:'contact', title:'تماس و پشتیبانی', meta:'فرم امن تماس و مسیرهای پشتیبانی SmartJournal.', status:'published', sections:[
      ['cms_contact_intro','intro','hero','برای حل مسئله، جزئیات کافی بفرستید','موضوع، شرح کوتاه و یکی از راه‌های پاسخ‌گویی را ثبت کنید؛ رمز عبور، کد OTP یا اطلاعات محرمانه معامله را ارسال نکنید.','','',10],
      ['cms_contact_privacy','privacy','content','درخواست‌های حریم خصوصی','کانال رسمی درخواست دریافت یا حذف داده، مرکز حریم خصوصی داخل حساب است تا هویت درخواست‌کننده تأیید شود.','','',20]
    ]},
    { id:'cms_page_quick_start', slug:'quick-start', title:'راهنمای شروع سریع', meta:'شروع استفاده از SmartJournal در پنج مرحله کوتاه و عملی.', status:'published', sections:[
      ['cms_quick_account','account','content','۱. حساب امن بسازید','شماره موبایل را تأیید کنید و پذیرش جداگانه اسناد فعال را ثبت کنید.','','',10],
      ['cms_quick_trading_account','trading_account','content','۲. حساب معاملاتی را تعریف کنید','نام حساب و موجودی شروع را وارد کنید تا گزارش‌ها مستقل بمانند.','','',20],
      ['cms_quick_trade','trade','content','۳. اولین معامله را ثبت کنید','نماد، نتیجه، ریسک، دلیل ورود، احساس و تصاویر قبل و بعد را کامل کنید.','','',30],
      ['cms_quick_review','review','content','۴. بازبینی هفتگی انجام دهید','شاخص‌های عملکرد و خطاهای رفتاری را کنار هم ببینید.','','',40],
      ['cms_quick_action','action','cta','۵. یک تغییر کوچک انتخاب کنید','فقط یک اقدام قابل اندازه‌گیری برای هفته بعد انتخاب و دوباره ارزیابی کنید.','شروع ژورنال','/journal#signup',50]
    ]},
    { id:'cms_page_guides', slug:'guides', title:'آموزش ژورنال معاملاتی', meta:'راهنماهای ثبت معامله، مدیریت ریسک، بازبینی و روانشناسی معامله‌گری.', status:'published', sections:[
      ['cms_guides_first_trade','first_trade','content','ثبت اولین معامله بدون از دست‌دادن جزئیات مهم','چک‌لیست ثبت دلیل ورود، ریسک، تصویر و نتیجه.','','',10],
      ['cms_guides_weekly_review','weekly_review','content','بازبینی هفتگی ژورنال','تبدیل آمار و یادداشت‌ها به یک اقدام روشن برای هفته بعد.','','',20],
      ['cms_guides_risk','risk','content','درک شاخص‌های ریسک','تعریف ساده وین‌ریت، امید ریاضی، فاکتور سود و افت سرمایه.','','',30],
      ['cms_guides_psychology','psychology','content','ثبت احساسات بدون قضاوت','تشخیص تصمیم هیجانی از اجرای درست پلن، بدون نتیجه‌گرایی.','','',40]
    ]}
  ];
  const pageStmt = db.prepare(`INSERT OR IGNORE INTO cms_pages (id,slug,title,meta_description,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`);
  const sectionStmt = db.prepare(`INSERT OR IGNORE INTO cms_sections (id,page_id,section_key,section_type,title,body,button_label,button_url,sort_order,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,'published',?,?)`);
  const tx = db.transaction(() => pages.forEach(page => {
    pageStmt.run(page.id,page.slug,page.title,page.meta,page.status,now,now);
    page.sections.forEach(section => sectionStmt.run(section[0],page.id,section[1],section[2],section[3],section[4],section[5]||null,section[6]||null,section[7],now,now));
  }));
  tx();
}

function seedCmsMenus() {
  const now=iso(),stmt=db.prepare(`INSERT OR IGNORE INTO cms_menu_items (id,menu_key,label,url,parent_id,sort_order,status,created_at,updated_at) VALUES (?,?,?,?,?,?,'published',?,?)`);
  const rows=[
    ['cms_menu_home','header','صفحه اصلی','/',null,10],
    ['cms_menu_pricing','header','قیمت‌گذاری','/pricing',null,20],
    ['cms_menu_help','header','راهنما','/guides',null,30],
    ['cms_menu_about','header','درباره ما','/about',null,40],
    ['cms_menu_contact','header','تماس','/contact',null,50],
    ['cms_menu_login','header','ورود به ژورنال','/journal#login',null,60],
    ['cms_menu_quick_start','footer','شروع سریع','/quick-start',null,10],
    ['cms_menu_guides','footer','راهنماهای آموزشی','/guides',null,20],
    ['cms_menu_faq','footer','پرسش‌های متداول','/faq',null,30],
    ['cms_menu_terms','footer','قوانین استفاده','/legal/terms',null,40],
    ['cms_menu_privacy','footer','حریم خصوصی','/legal/privacy',null,50]
  ];
  db.transaction(()=>rows.forEach(row=>stmt.run(...row,now,now)))();
  db.prepare("UPDATE cms_menu_items SET url='/guides',sort_order=30,updated_at=? WHERE id='cms_menu_help'").run(now);
  db.prepare("UPDATE cms_menu_items SET url='/journal#login',sort_order=60,updated_at=? WHERE id='cms_menu_login'").run(now);
  db.prepare("UPDATE cms_menu_items SET url='/legal/terms',sort_order=40,updated_at=? WHERE id='cms_menu_terms'").run(now);
  db.prepare("UPDATE cms_menu_items SET url='/legal/privacy',sort_order=50,updated_at=? WHERE id='cms_menu_privacy'").run(now);
}

function syncUserContacts() {
  const now=iso(),rows=db.prepare('SELECT id,name,mobile,created_at FROM users WHERE deleted_at IS NULL').all();
  const byUser=db.prepare('SELECT id FROM user_contacts WHERE user_id=?'),byMobile=db.prepare('SELECT id FROM user_contacts WHERE mobile=?');
  const update=db.prepare("UPDATE user_contacts SET user_id=?,name=?,mobile=?,source='registered',updated_at=? WHERE id=?");
  const insert=db.prepare(`INSERT INTO user_contacts (id,user_id,name,mobile,tags,note,sms_consent,source,created_at,updated_at) VALUES (?,?,?,?,NULL,NULL,0,'registered',?,?)`);
  db.transaction(()=>rows.forEach(user=>{const existing=byUser.get(user.id)||byMobile.get(user.mobile);if(existing)update.run(user.id,user.name,user.mobile,now,existing.id);else insert.run(id('contact'),user.id,user.name,user.mobile,user.created_at||now,now)}))();
}

function seededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function seedDemoData() {
  if (db.prepare('SELECT COUNT(*) AS count FROM users').get().count) return;
  const random = seededRandom(14050813);
  const names = ['علی رضایی','سارا محمدی','امیرحسین کریمی','مریم احمدی','پارسا اکبری','نازنین حسینی','محمد طاهری','آرین موسوی','مهسا جعفری','رضا مرادی','هلیا قاسمی','سامان یوسفی','آیدا صادقی','پوریا رحیمی','فاطمه امینی','کیان نادری','یسنا سلیمانی','آرمان شریفی','ستایش کاظمی','بردیا عباسی'];
  const providers = ['کاوه‌نگار','ملی‌پیامک'];
  const sources = ['AUTH_API','STORAGE_WORKER','SUBSCRIPTION_JOB','JOURNAL_API','SMS_GATEWAY'];
  const errorMessages = [
    'زمان پاسخ سرویس پیامک بیشتر از حد مجاز بود',
    'آپلود تصویر به دلیل قطع ارتباط کامل نشد',
    'نشست کاربر منقضی شده است',
    'پرداخت تمدید اشتراک ناموفق بود',
    'سهمیه فضای ذخیره‌سازی کاربر تکمیل شده است',
    'درخواست‌های ورود بیش از حد مجاز ارسال شد'
  ];
  const userStmt = db.prepare(`INSERT INTO users
    (id,name,mobile,status,created_at,last_seen_at,storage_bytes,trades_count,sms_count)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const subStmt = db.prepare(`INSERT INTO subscriptions
    (id,user_id,plan_id,status,started_at,expires_at,auto_renew,updated_at)
    VALUES (?,?,?,?,?,?,?,?)`);
  const smsStmt = db.prepare(`INSERT INTO sms_logs
    (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  const errorStmt = db.prepare(`INSERT INTO system_errors
    (id,severity,source,message,stack,status,occurred_at,resolved_at)
    VALUES (?,?,?,?,?,?,?,?)`);

  const users = [];
  const tx = db.transaction(() => {
    for (let i = 0; i < 76; i++) {
      const userId = id('usr');
      const createdDays = Math.floor(random() * 210);
      const statusRoll = random();
      const status = statusRoll < .08 ? 'suspended' : statusRoll < .14 ? 'pending' : 'active';
      const planRoll = random();
      const planId = planRoll < .48 ? 'plan_free' : planRoll < .86 ? 'plan_pro' : 'plan_elite';
      const subStatus = status === 'pending' ? 'trial' : random() < .08 ? 'expired' : 'active';
      const storageFactor = planId === 'plan_elite' ? 5.8 : planId === 'plan_pro' ? 1.2 : .075;
      const storage = Math.floor((.08 + random() * storageFactor) * 1024 * 1024 * 1024);
      const trades = Math.floor(8 + random() * (planId === 'plan_free' ? 92 : 720));
      const smsCount = Math.floor(1 + random() * 24);
      const mobile = `0912${String(1000000 + i).slice(-7)}`;
      const created = daysAgo(createdDays, Math.floor(random() * 20));
      const lastSeen = status === 'pending' ? null : daysAgo(Math.floor(random() * (status === 'suspended' ? 35 : 12)), Math.floor(random() * 20));
      userStmt.run(userId, `${names[i % names.length]}${i >= names.length ? ` ${Math.floor(i / names.length) + 1}` : ''}`, mobile, status, created, lastSeen, storage, trades, smsCount);
      subStmt.run(id('sub'), userId, planId, subStatus, created, subStatus === 'expired' ? daysAgo(Math.floor(random() * 25)) : daysFromNow(5 + Math.floor(random() * 60)), random() > .45 ? 1 : 0, daysAgo(Math.floor(random() * 15)));
      users.push({ id: userId, mobile });
    }

    for (let i = 0; i < 248; i++) {
      const user = users[Math.floor(random() * users.length)];
      const failed = random() < .075;
      const suspicious = i % 37 === 0;
      const requestIp = suspicious ? '198.51.100.77' : `192.0.2.${20 + i % 45}`;
      smsStmt.run(id('sms'), user.id, user.mobile, i % 7 === 0 ? 'security' : 'otp', failed ? 'failed' : random() < .6 ? 'delivered' : 'sent', providers[i % providers.length], 320 + Math.floor(random() * 180), failed ? 'PROVIDER_TIMEOUT' : null, requestIp, suspicious ? 1 : 0, suspicious ? 'تکرار درخواست OTP از شماره یا IP مشترک' : null, daysAgo(Math.floor(random() * 70), Math.floor(random() * 23)));
    }

    for (let i = 0; i < 19; i++) {
      const severity = i < 2 ? 'critical' : i < 8 ? 'error' : i < 15 ? 'warning' : 'info';
      const status = i % 4 === 0 ? 'resolved' : i % 7 === 0 ? 'ignored' : 'open';
      const occurred = daysAgo(Math.floor(random() * 28), Math.floor(random() * 20));
      errorStmt.run(id('err'), severity, sources[i % sources.length], errorMessages[i % errorMessages.length], `RequestError: ${errorMessages[i % errorMessages.length]}\n    at service/handler.js:${40 + i}:12`, status, occurred, status === 'resolved' ? daysAgo(Math.max(0, Math.floor(random() * 5))) : null);
    }
  });
  tx();

  const owner = db.prepare("SELECT id FROM admins WHERE role='owner' LIMIT 1").get();
  if (owner) {
    const actions = [
      ['LOGIN_SUCCESS','admin',owner.id,'ورود موفق مدیر به پنل'],
      ['USER_STATUS_UPDATED','user',users[8].id,'وضعیت کاربر به فعال تغییر کرد'],
      ['SUBSCRIPTION_UPDATED','subscription',users[11].id,'اشتراک کاربر به پلن حرفه‌ای ارتقا یافت'],
      ['ERROR_RESOLVED','system_error',null,'خطای درگاه پیامک بررسی و بسته شد']
    ];
    const stmt = db.prepare(`INSERT INTO audit_logs (id,admin_id,action,entity_type,entity_id,details,ip,created_at) VALUES (?,?,?,?,?,?,?,?)`);
    actions.forEach((a, index) => stmt.run(id('aud'), owner.id, ...a, '127.0.0.1', daysAgo(index, 2 + index)));
  }
}

function seedUserSessions() {
  if (!db.prepare('SELECT COUNT(*) AS count FROM users').get().count) return;
  if (!db.prepare('SELECT COUNT(*) AS count FROM user_sessions').get().count) {
    const users = db.prepare("SELECT id FROM users WHERE status='active' AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 42").all();
    const devices = ['Chrome · Windows', 'Safari · iPhone', 'Chrome · Android', 'Firefox · macOS'];
    const stmt = db.prepare(`INSERT INTO user_sessions (id,user_id,device,ip,created_at,last_seen_at,expires_at,revoked_at)
      VALUES (?,?,?,?,?,?,?,NULL)`);
    const tx = db.transaction(() => users.forEach((user, index) => {
      const count = index % 4 === 0 ? 2 : 1;
      for (let sessionIndex = 0; sessionIndex < count; sessionIndex++) {
        stmt.run(id('uses'), user.id, devices[(index + sessionIndex) % devices.length], `192.0.2.${20 + (index % 180)}`, daysAgo(index % 9), daysAgo(index % 5, sessionIndex), daysFromNow(7 + index % 20));
      }
    }));
    tx();
  }
  const hasRequest = db.prepare('SELECT COUNT(*) AS count FROM users WHERE deletion_requested_at IS NOT NULL AND deleted_at IS NULL').get().count;
  if (!hasRequest) {
    const requested = db.prepare("SELECT id FROM users WHERE status IN ('active','suspended') AND deleted_at IS NULL ORDER BY created_at LIMIT 2").all();
    requested.forEach((user, index) => db.prepare('UPDATE users SET deletion_requested_at=? WHERE id=?').run(daysAgo(index + 1), user.id));
  }
}

function seedBillingData() {
  if (process.env.NODE_ENV === 'production' || process.env.SEED_DEMO_DATA === 'false') return;
  if (!db.prepare('SELECT COUNT(*) AS count FROM coupons').get().count) {
    const stmt = db.prepare(`INSERT INTO coupons (id,code,discount_type,value,max_uses,used_count,starts_at,expires_at,is_active,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)`);
    stmt.run('coupon_welcome20', 'WELCOME20', 'percent', 20, 500, 84, daysAgo(90), daysFromNow(120), 1, daysAgo(90));
    stmt.run('coupon_pro100', 'PRO100', 'fixed', 100000, 100, 27, daysAgo(45), daysFromNow(45), 1, daysAgo(45));
    stmt.run('coupon_summer', 'SUMMER35', 'percent', 35, 250, 250, daysAgo(120), daysAgo(10), 0, daysAgo(120));
  }
  if (db.prepare('SELECT COUNT(*) AS count FROM payments').get().count) return;
  const subscriptions = db.prepare(`SELECT s.id,s.user_id,s.plan_id,p.price_monthly FROM subscriptions s JOIN plans p ON p.id=s.plan_id
    JOIN users u ON u.id=s.user_id WHERE u.deleted_at IS NULL AND p.price_monthly>0 ORDER BY s.started_at DESC LIMIT 62`).all();
  const stmt = db.prepare(`INSERT INTO payments (id,user_id,subscription_id,amount,discount_amount,refunded_amount,currency,status,provider,tracking_code,invoice_number,created_at,paid_at,refunded_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => subscriptions.forEach((sub, index) => {
    const status = index % 17 === 0 ? 'failed' : index % 13 === 0 ? 'refunded' : index % 11 === 0 ? 'pending' : 'paid';
    const discount = index % 5 === 0 ? Math.round(sub.price_monthly * .2) : 0;
    const amount = Math.max(0, sub.price_monthly - discount);
    const created = daysAgo(index * 2 % 100, index % 20);
    stmt.run(id('pay'), sub.user_id, sub.id, amount, discount, status === 'refunded' ? amount : 0, 'TOMAN', status, index % 2 ? 'زرین‌پال' : 'آیدی‌پی', status === 'failed' ? null : `TRX${14050000 + index}`, `INV-1405-${String(index + 1).padStart(5, '0')}`, created, ['paid','refunded'].includes(status) ? created : null, status === 'refunded' ? daysAgo(index % 7) : null);
  }));
  tx();
}

function logAudit({ adminId = null, action, entityType = null, entityId = null, details = null, ip = null }) {
  db.prepare(`INSERT INTO audit_logs (id,admin_id,action,entity_type,entity_id,details,ip,created_at)
              VALUES (?,?,?,?,?,?,?,?)`)
    .run(id('aud'), adminId, action, entityType, entityId, typeof details === 'string' ? details : details ? JSON.stringify(details) : null, ip, iso());
}

function recordSystemError({ severity = 'error', source = 'ADMIN_API', message, stack = null }) {
  db.prepare(`INSERT INTO system_errors (id,severity,source,message,stack,status,occurred_at) VALUES (?,?,?,?,?,'open',?)`)
    .run(id('err'), severity, source, message, stack, iso());
}

function recordSecurityAlert({ category = 'attack', severity = 'warning', title, details = null }) {
  db.prepare(`INSERT INTO security_alerts (id,category,severity,title,details,status,detected_at)
    VALUES (?,?,?,?,?,'open',?)`)
    .run(id('alert'), category, severity, title, typeof details === 'string' ? details : details ? JSON.stringify(details) : null, iso());
}

function cleanupExpiredSessions() {
  const now = iso();
  db.prepare('DELETE FROM admin_sessions WHERE expires_at <= ?').run(now);
  db.prepare('UPDATE user_sessions SET revoked_at=COALESCE(revoked_at,?) WHERE expires_at<=?').run(now, now);
  db.prepare("UPDATE account_recovery_requests SET status='expired' WHERE status='pending' AND expires_at<=?").run(now);
  const thirtyDays=new Date(Date.now()-30*86400000).toISOString(),twelveMonths=new Date(Date.now()-365*86400000).toISOString();
  db.prepare('DELETE FROM user_otp_challenges WHERE (consumed_at IS NOT NULL OR expires_at<=?) AND created_at<?').run(now,thirtyDays);
  db.prepare('DELETE FROM user_security_events WHERE created_at<?').run(twelveMonths);
  db.prepare('DELETE FROM user_activity_logs WHERE created_at<?').run(twelveMonths);
  db.prepare('DELETE FROM sms_logs WHERE created_at<? AND is_suspicious=0').run(twelveMonths);
}

module.exports = {
  db,
  initDb,
  logAudit,
  recordSystemError,
  recordSecurityAlert,
  cleanupExpiredSessions,
  normalizeMobile,
  id,
  iso,
  DB_PATH,
  DATABASE_ENGINE,
  PERMISSION_KEYS,
  DEFAULT_ROLE_PERMISSIONS,
  syncUserContacts
};
