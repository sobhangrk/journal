'use strict';
/* ==========================================================================
   SmartJournal — درگاه پیامک (SMS Gateway)

   هدف: مدیر بتواند «همیشه خودش» درگاه پیامک را از پنل تنظیم، فعال، غیرفعال،
   تست و عیب‌یابی کند — بدون اینکه به کد دست بزند.

   این ماژول روی زیرساخت موجود سوار می‌شود و چیزی را دور نمی‌زند:
   جدول‌های sms_providers / sms_settings / sms_logs، رمزنگاری credential،
   permission، CSRF و audit log همان‌های قبلی هستند.

   چیزهایی که اینجا اضافه می‌شود و قبلاً نبود:
     GET    /api/admin/sms/status              وضعیت واقعی «آیا پیامک کار می‌کند؟»
     DELETE /api/admin/sms/providers/:id       حذف درگاه (با محافظ)
     POST   /api/admin/sms/providers/:id/enable
     POST   /api/admin/sms/providers/:id/disable
     POST   /api/admin/sms/test-otp            تست کامل مسیر واقعی OTP
     POST   /api/admin/sms/simulator           روشن/خاموش کردن حالت آزمایشی
   ========================================================================== */

function install(ctx) {
  const {
    app, db, id, iso, clientIp, logAudit, allowPermissions,
    encryptSecret, decryptSecret, deliverWithProvider, IS_PROD, logger,
  } = ctx;

  const log = logger || console;

  /* ------------------------------------------------------------ helpers -- */

  const SETTINGS = () => db.prepare("SELECT * FROM sms_settings WHERE id='default'").get() || {};

  function providers() {
    return db.prepare(
      "SELECT * FROM sms_providers ORDER BY is_primary DESC, is_enabled DESC, priority, name"
    ).all();
  }

  function isConfigured(provider) {
    if (provider.provider_type === 'development') return true;
    try { return !!decryptSecret(provider.credentials_encrypted); } catch { return false; }
  }

  /**
   * آیا همین الان یک کاربر می‌تواند ثبت‌نام کند و کد بگیرد؟
   * این دقیقاً همان شرطی است که deliverSmsDirect استفاده می‌کند.
   */
  function gatewayStatus() {
    const rows = providers();
    const usable = rows.filter(p => p.is_enabled && isConfigured(p));
    const primary = rows.find(p => p.is_primary) || null;
    const simulator = rows.find(p => p.provider_type === 'development' && p.is_enabled) || null;

    const problems = [];
    if (!rows.length) {
      problems.push({ level: 'critical', code: 'no_provider',
        text: 'هیچ درگاه پیامکی تعریف نشده است. کاربران نمی‌توانند ثبت‌نام یا ورود کنند.' });
    } else if (!usable.length) {
      problems.push({ level: 'critical', code: 'no_credentials',
        text: 'هیچ درگاه فعالی با اطلاعات اتصال کامل وجود ندارد. ثبت‌نام و ورود با خطای ۵۰۳ شکست می‌خورد.' });
    }
    if (usable.length && !primary) {
      problems.push({ level: 'warning', code: 'no_primary',
        text: 'درگاه اصلی انتخاب نشده است؛ ارسال بر اساس اولویت انجام می‌شود.' });
    }
    if (primary && !primary.is_enabled) {
      problems.push({ level: 'warning', code: 'primary_disabled',
        text: `درگاه اصلی «${primary.name}» غیرفعال است.` });
    }
    if (simulator && IS_PROD) {
      problems.push({ level: 'critical', code: 'simulator_in_prod',
        text: 'حالت آزمایشی روی سرور واقعی فعال است؛ هیچ پیامک واقعی ارسال نمی‌شود.' });
    }
    if (simulator && !IS_PROD) {
      problems.push({ level: 'info', code: 'simulator_on',
        text: 'حالت آزمایشی روشن است: پیامک واقعی ارسال نمی‌شود و کد در پاسخ API برگردانده می‌شود.' });
    }
    rows.filter(p => p.is_enabled && p.status === 'down').forEach(p => problems.push({
      level: 'warning', code: 'provider_down', text: `درگاه «${p.name}» قطع گزارش شده است.` }));
    rows.filter(p => p.is_enabled && !isConfigured(p)).forEach(p => problems.push({
      level: 'warning', code: 'provider_unconfigured',
      text: `درگاه «${p.name}» فعال است ولی اطلاعات اتصال ندارد و نادیده گرفته می‌شود.` }));

    const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    const last24 = db.prepare(
      `SELECT COUNT(*) total,
              SUM(CASE WHEN status='sent' THEN 1 ELSE 0 END) sent,
              SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed
         FROM sms_logs WHERE created_at>=?`
    ).get(since) || {};
    const lastFailure = db.prepare(
      "SELECT provider,error_code,created_at FROM sms_logs WHERE status='failed' ORDER BY created_at DESC LIMIT 1"
    ).get() || null;

    return {
      ready: usable.length > 0,
      simulator: !!simulator,
      production: !!IS_PROD,
      activeProvider: (usable.find(p => p.is_primary) || usable[0] || null)?.name || null,
      counts: {
        total: rows.length,
        enabled: rows.filter(p => p.is_enabled).length,
        usable: usable.length,
      },
      last24h: {
        total: Number(last24.total || 0),
        sent: Number(last24.sent || 0),
        failed: Number(last24.failed || 0),
      },
      lastFailure,
      problems,
    };
  }

  /* ------------------------------------------------------------- status -- */

  app.get('/api/admin/sms/status',
    allowPermissions('resources.view', 'resources.security', 'resources.manage'),
    (req, res) => {
      try { res.json(gatewayStatus()); }
      catch (error) { res.status(500).json({ error: String(error.message || error) }); }
    });

  /* --------------------------------------------- enable / disable / حذف -- */

  function findProvider(req, res) {
    const provider = db.prepare('SELECT * FROM sms_providers WHERE id=?').get(req.params.id);
    if (!provider) { res.status(404).json({ error: 'درگاه پیامک پیدا نشد.' }); return null; }
    return provider;
  }

  app.post('/api/admin/sms/providers/:id/enable',
    allowPermissions('resources.manage'), (req, res) => {
      const provider = findProvider(req, res); if (!provider) return;
      if (!isConfigured(provider)) {
        return res.status(400).json({ error: 'ابتدا اطلاعات اتصال (API Key) این درگاه را ذخیره کنید.' });
      }
      db.prepare('UPDATE sms_providers SET is_enabled=1,updated_at=? WHERE id=?').run(iso(), provider.id);
      logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_ENABLED', entityType: 'sms_provider',
        entityId: provider.id, details: { name: provider.name }, ip: clientIp(req) });
      res.json({ ok: true, status: gatewayStatus() });
    });

  app.post('/api/admin/sms/providers/:id/disable',
    allowPermissions('resources.manage'), (req, res) => {
      const provider = findProvider(req, res); if (!provider) return;
      const others = db.prepare(
        'SELECT COUNT(*) c FROM sms_providers WHERE id<>? AND is_enabled=1 AND credentials_encrypted IS NOT NULL'
      ).get(provider.id).c;
      if (!others && req.body?.force !== true) {
        return res.status(409).json({
          error: 'این تنها درگاه فعال است. با غیرفعال کردنش هیچ کاربری نمی‌تواند ثبت‌نام یا ورود کند.',
          needsForce: true,
        });
      }
      db.prepare('UPDATE sms_providers SET is_enabled=0,is_primary=0,updated_at=? WHERE id=?').run(iso(), provider.id);
      logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_DISABLED', entityType: 'sms_provider',
        entityId: provider.id, details: { name: provider.name, forced: req.body?.force === true }, ip: clientIp(req) });
      res.json({ ok: true, status: gatewayStatus() });
    });

  app.delete('/api/admin/sms/providers/:id',
    allowPermissions('resources.manage'), (req, res) => {
      const provider = findProvider(req, res); if (!provider) return;
      const others = db.prepare(
        'SELECT COUNT(*) c FROM sms_providers WHERE id<>? AND is_enabled=1 AND credentials_encrypted IS NOT NULL'
      ).get(provider.id).c;
      if (provider.is_enabled && !others && req.body?.force !== true) {
        return res.status(409).json({
          error: 'این تنها درگاه فعال است؛ با حذف آن ثبت‌نام و ورود کاربران از کار می‌افتد.',
          needsForce: true,
        });
      }
      db.prepare('DELETE FROM sms_providers WHERE id=?').run(provider.id);
      logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_DELETED', entityType: 'sms_provider',
        entityId: provider.id, details: { name: provider.name, type: provider.provider_type }, ip: clientIp(req) });
      res.json({ ok: true, status: gatewayStatus() });
    });

  /* ------------------------------------------------- حالت آزمایشی (dev) -- */
  /* یک درگاه ساختگی که پیامک واقعی نمی‌فرستد و کد را در پاسخ API برمی‌گرداند.
     روی NODE_ENV=production اجازه روشن‌شدن ندارد.                              */

  const SIM_KEY = 'simulator';

  app.post('/api/admin/sms/simulator',
    allowPermissions('resources.manage'), (req, res) => {
      const on = req.body?.enabled !== false;
      if (on && IS_PROD) {
        return res.status(400).json({
          error: 'حالت آزمایشی روی سرور واقعی (production) مجاز نیست؛ یک درگاه واقعی تنظیم کنید.',
        });
      }
      const existing = db.prepare('SELECT * FROM sms_providers WHERE provider_key=?').get(SIM_KEY);
      const now = iso();
      if (!on) {
        if (existing) db.prepare('DELETE FROM sms_providers WHERE id=?').run(existing.id);
        logAudit({ adminId: req.admin.id, action: 'SMS_SIMULATOR_DISABLED', entityType: 'sms_provider',
          entityId: existing?.id || null, details: {}, ip: clientIp(req) });
        return res.json({ ok: true, enabled: false, status: gatewayStatus() });
      }
      if (existing) {
        db.prepare('UPDATE sms_providers SET is_enabled=1,status=\'healthy\',updated_at=? WHERE id=?').run(now, existing.id);
      } else {
        db.prepare(`INSERT INTO sms_providers
          (id,provider_key,provider_type,name,config_json,credentials_encrypted,balance,unit_cost,
           status,is_enabled,is_primary,priority,last_checked_at,updated_at)
          VALUES (?,?,'development',?,?,NULL,0,0,'healthy',1,0,99,?,?)`)
          .run(id('sms_provider'), SIM_KEY, 'حالت آزمایشی (بدون پیامک واقعی)',
               JSON.stringify({ note: 'کد در پاسخ API برگردانده می‌شود' }), now, now);
      }
      logAudit({ adminId: req.admin.id, action: 'SMS_SIMULATOR_ENABLED', entityType: 'sms_provider',
        entityId: null, details: {}, ip: clientIp(req) });
      res.json({ ok: true, enabled: true, status: gatewayStatus() });
    });

  /* -------------------------------------------- تست کامل مسیر واقعی OTP -- */
  /* فرق این با /providers/:id/test:
     آن یکی فقط یک درگاه مشخص را صدا می‌زند. این یکی دقیقاً همان مسیری را
     می‌رود که کاربر واقعی موقع ثبت‌نام طی می‌کند (انتخاب درگاه، failover،
     قالب پیام، ثبت در sms_logs) تا مطمئن شویم «واقعاً» کار می‌کند.        */

  app.post('/api/admin/sms/test-otp',
    allowPermissions('resources.manage'), async (req, res) => {
      const mobile = String(req.body?.mobile || '').replace(/[^\d]/g, '')
        .replace(/^0098/, '0').replace(/^98/, '0').replace(/^9/, '09');
      if (!/^09\d{9}$/.test(mobile)) {
        return res.status(400).json({ error: 'شماره موبایل معتبر نیست. نمونه درست: 09123456789' });
      }
      const status = gatewayStatus();
      if (!status.ready) {
        return res.status(503).json({
          error: 'هیچ درگاه فعال و تنظیم‌شده‌ای وجود ندارد.',
          problems: status.problems,
        });
      }
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const template = SETTINGS().otp_template || 'کد ورود SmartJournal: {code}';
      const message = String(template).replaceAll('{code}', code);

      const enabled = providers().filter(p => p.is_enabled && isConfigured(p));
      const attempts = [];
      let delivered = null;

      for (const provider of enabled) {
        const startedAt = Date.now();
        try {
          const result = await deliverWithProvider(provider, mobile, message, code);
          const ms = Date.now() - startedAt;
          attempts.push({ provider: provider.name, ok: true, ms,
            development: !!(result && result.development) });
          db.prepare(`INSERT INTO sms_logs
            (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at)
            VALUES (?,NULL,?,'otp','sent',?,?,NULL,?,0,'admin_test',?)`)
            .run(id('sms'), mobile, provider.name, Number(provider.unit_cost || 0), clientIp(req), iso());
          db.prepare("UPDATE sms_providers SET status='healthy',last_checked_at=?,updated_at=? WHERE id=?")
            .run(iso(), iso(), provider.id);
          delivered = { provider: provider.name, development: !!(result && result.development) };
          break;
        } catch (error) {
          const ms = Date.now() - startedAt;
          attempts.push({ provider: provider.name, ok: false, ms, error: String(error.message || error).slice(0, 160) });
          db.prepare(`INSERT INTO sms_logs
            (id,user_id,mobile,type,status,provider,cost,error_code,request_ip,is_suspicious,suspicious_reason,created_at)
            VALUES (?,NULL,?,'otp','failed',?,0,?,?,0,'admin_test',?)`)
            .run(id('sms'), mobile, provider.name, String(error.message || error).slice(0, 120), clientIp(req), iso());
          db.prepare("UPDATE sms_providers SET status='degraded',last_error_at=?,last_checked_at=?,updated_at=? WHERE id=?")
            .run(iso(), iso(), iso(), provider.id);
          if (!SETTINGS().auto_failover) break;
        }
      }

      logAudit({ adminId: req.admin.id, action: 'SMS_GATEWAY_TESTED', entityType: 'sms_provider',
        entityId: null,
        details: { mobile: `${mobile.slice(0, 4)}***${mobile.slice(-3)}`, ok: !!delivered, attempts },
        ip: clientIp(req) });

      if (!delivered) {
        return res.status(502).json({
          ok: false,
          error: 'هیچ‌کدام از درگاه‌ها پیامک را تحویل ندادند.',
          attempts,
          hint: 'کد خطا را در جدول «پیامک‌های ناموفق» ببینید. رایج‌ترین دلایل: API Key اشتباه، اعتبار تمام‌شده، یا نبود template تاییدشده برای OTP.',
        });
      }
      res.json({
        ok: true,
        provider: delivered.provider,
        attempts,
        message: delivered.development
          ? 'حالت آزمایشی فعال است؛ پیامک واقعی ارسال نشد.'
          : 'پیامک تست ارسال شد. اگر روی گوشی نرسید، اعتبار پنل و تایید بودن قالب پیام را بررسی کنید.',
        // کد فقط در حالت آزمایشی/غیرproduction برگردانده می‌شود
        ...(delivered.development || !IS_PROD ? { code } : {}),
      });
    });


  app.post('/api/admin/sms/providers/:id/clear-credentials',
    allowPermissions('resources.manage'), (req, res) => {
      const provider = findProvider(req, res); if (!provider) return;
      db.prepare("UPDATE sms_providers SET credentials_encrypted=NULL,is_enabled=0,is_primary=0,status='down',updated_at=? WHERE id=?")
        .run(iso(), provider.id);
      logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_CREDENTIALS_CLEARED', entityType: 'sms_provider',
        entityId: provider.id, details: { name: provider.name }, ip: clientIp(req) });
      res.json({ ok: true, status: gatewayStatus() });
    });

  /* ------------------------------------------------- عیب‌یابی گام‌به‌گام -- */
  /* «پیامک نمی‌رود» می‌تواند ۶ علت کاملاً متفاوت داشته باشد. این تست هر حلقه
     زنجیره را جدا بررسی می‌کند تا مدیر دقیقاً بداند کجا خراب است.            */

  const dns = require('dns').promises;
  const net = require('net');
  const tls = require('tls');

  const PROVIDER_HOST = {
    kavenegar: 'api.kavenegar.com',
    melipayamak: 'rest.payamak-panel.com',
  };

  function tcpProbe(host, port = 443, timeout = 7000) {
    return new Promise(resolve => {
      const started = Date.now();
      const socket = net.connect({ host, port });
      const done = (ok, detail) => {
        socket.destroy();
        resolve({ ok, detail, ms: Date.now() - started });
      };
      socket.setTimeout(timeout);
      socket.on('connect', () => done(true, `اتصال TCP به ${host}:${port} برقرار شد`));
      socket.on('timeout', () => done(false, `اتصال TCP به ${host}:${port} در ${timeout}ms پاسخ نداد`));
      socket.on('error', error => done(false, `${error.code || error.message}`));
    });
  }

  function tlsProbe(host, timeout = 9000, port = 443) {
    return new Promise(resolve => {
      const started = Date.now();
      const socket = tls.connect({ host, port, servername: host });
      const done = (ok, detail) => {
        socket.destroy();
        resolve({ ok, detail, ms: Date.now() - started });
      };
      socket.setTimeout(timeout);
      socket.on('secureConnect', () => done(true, 'دست‌دادن TLS موفق بود'));
      socket.on('timeout', () => done(false,
        `دست‌دادن TLS در ${timeout}ms پاسخ نگرفت — معمولاً یعنی سرور شما از ایران خارج است یا فایروال جلوی خروجی را گرفته`));
      socket.on('error', error => done(false, `${error.code || error.message}`));
    });
  }

  async function credentialProbe(provider, credentials) {
    const started = Date.now();
    const ms = () => Date.now() - started;
    try {
      if (provider.provider_type === 'kavenegar') {
        const response = await fetch(
          `https://api.kavenegar.com/v1/${encodeURIComponent(credentials.apiKey)}/account/info.json`,
          { signal: AbortSignal.timeout(10000) });
        const data = await response.json().catch(() => ({}));
        const status = data?.return?.status;
        if (status === 200) {
          const credit = Number(data?.entries?.remaincredit || 0);
          return { ok: true, ms: ms(), detail: `کلید معتبر است · اعتبار باقی‌مانده: ${credit.toLocaleString('fa-IR')} ریال`, credit };
        }
        if (status === 401 || response.status === 401) return { ok: false, ms: ms(), detail: 'API Key اشتباه است (۴۰۱)' };
        return { ok: false, ms: ms(), detail: `کاوه‌نگار کد ${status || response.status} برگرداند: ${data?.return?.message || ''}` };
      }
      if (provider.provider_type === 'melipayamak') {
        const config = JSON.parse(provider.config_json || '{}');
        /* همان قانون ریشه‌ی سرور: متدها زیر /api/SendSMS/ هستند */
        let base = String(config.url || '').trim().replace(/\/+$/, '');
        if (!base) base = 'https://rest.payamak-panel.com/api/SendSMS';
        base = base.replace(/\/(BaseServiceNumber|GetCredit|GetDeliveries2?|SendOtp)$/i, '')
                   .replace(/\/SendSMS\/SendSMS$/i, '/SendSMS');
        const response = await fetch(`${base}/GetCredit`, {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ username: credentials.username, password: credentials.password || credentials.apiKey }),
          signal: AbortSignal.timeout(10000) });
        const data = await response.json().catch(() => ({}));
        if (Number(data?.RetStatus) === 1) {
          const credit = Number(data?.Value || 0);
          return { ok: true, ms: ms(), detail: `نام کاربری و رمز درست است · اعتبار: ${credit.toLocaleString('fa-IR')}`, credit };
        }
        return { ok: false, ms: ms(), detail: `ملی‌پیامک: ${data?.StrRetStatus || data?.RetStatus || response.status}` };
      }
      // webhook سفارشی: فقط در دسترس بودن آدرس
      const config = JSON.parse(provider.config_json || '{}');
      const response = await fetch(config.url, {
        method: 'POST', signal: AbortSignal.timeout(9000),
        headers: { 'content-type': 'application/json',
          ...(credentials.bearerToken ? { authorization: `Bearer ${credentials.bearerToken}` } : {}) },
        body: JSON.stringify({ ping: true, type: 'diagnostic' }) });
      if (response.status === 401 || response.status === 403) {
        return { ok: false, ms: ms(), detail: `Webhook کد ${response.status} داد — توکن احراز هویت اشتباه است` };
      }
      if (response.status >= 500) {
        return { ok: false, ms: ms(), detail: `سرور درگاه خطای ${response.status} داد` };
      }
      if (!response.ok) {
        return { ok: true, ms: ms(),
          detail: `اتصال و توکن درست است؛ درگاه به پیام تشخیصی کد ${response.status} داد (طبیعی است، چون پیام واقعی نیست)` };
      }
      return { ok: true, ms: ms(), detail: `Webhook کد ${response.status} برگرداند — سالم` };
    } catch (error) {
      return { ok: false, ms: ms(), detail: String(error.message || error).slice(0, 160) };
    }
  }

  app.post('/api/admin/sms/providers/:id/diagnose',
    allowPermissions('resources.manage'), async (req, res) => {
      const provider = findProvider(req, res); if (!provider) return;
      const steps = [];
      const push = (key, label, ok, detail, ms) => steps.push({ key, label, ok, detail, ms: ms ?? null });

      // ۱) اطلاعات اتصال
      let credentials = null;
      try { credentials = decryptSecret(provider.credentials_encrypted); } catch {}
      if (provider.provider_type === 'development') {
        push('creds', 'حالت آزمایشی', true, 'این درگاه ساختگی است و پیامک واقعی نمی‌فرستد.');
        return res.json({ ok: true, provider: provider.name, steps });
      }
      push('creds', 'اطلاعات اتصال ذخیره شده', !!credentials,
        credentials ? 'کلید/رمز در پایگاه داده رمزنگاری‌شده موجود است' : 'هیچ API Key یا رمزی ذخیره نشده — از «تنظیم اتصال» واردش کنید');
      if (!credentials) return res.json({ ok: false, provider: provider.name, steps });

      // ۲) آدرس مقصد — پورت و پروتکل واقعی همان URL، نه فرض ۴۴۳
      let host = PROVIDER_HOST[provider.provider_type];
      let port = 443, secureScheme = true;
      /* اگر مدیر برای ملی‌پیامک آدرس دلخواه (آینه یا محیط تست) گذاشته،
         باید همان آدرس تست شود نه دامنه پیش‌فرض. */
      if (provider.provider_type === 'melipayamak') {
        const custom = (JSON.parse(provider.config_json || '{}') || {}).url;
        if (custom && /^https?:\/\//i.test(custom)) host = null;
      }
      if (!host) {
        try {
          const target = new URL(JSON.parse(provider.config_json || '{}').url);
          host = target.hostname;
          secureScheme = target.protocol === 'https:';
          port = Number(target.port) || (secureScheme ? 443 : 80);
        } catch {
          push('host', 'آدرس مقصد', false, 'URL درگاه معتبر نیست');
          return res.json({ ok: false, provider: provider.name, steps });
        }
      }

      // ۳) DNS
      try {
        const started = Date.now();
        const addresses = await dns.lookup(host, { all: true });
        push('dns', `تبدیل نام ${host}`, true, addresses.map(a => a.address).join('، '), Date.now() - started);
      } catch (error) {
        push('dns', `تبدیل نام ${host}`, false, `${error.code || error.message} — DNS سرور را بررسی کنید`);
        return res.json({ ok: false, provider: provider.name, steps });
      }

      // ۴) TCP
      const tcp = await tcpProbe(host, port);
      push('tcp', `اتصال شبکه (TCP ${port})`, tcp.ok, tcp.detail, tcp.ms);
      if (!tcp.ok) return res.json({ ok: false, provider: provider.name, steps });

      // ۵) TLS — فقط وقتی مقصد https است
      if (secureScheme) {
        const secure = await tlsProbe(host, 9000, port);
        push('tls', 'ارتباط امن (TLS)', secure.ok, secure.detail, secure.ms);
        if (!secure.ok) return res.json({ ok: false, provider: provider.name, steps });
      }

      // ۶) کلید و اعتبار
      const auth = await credentialProbe(provider, credentials);
      push('auth', 'اعتبارسنجی کلید و موجودی', auth.ok, auth.detail, auth.ms);
      if (auth.ok && Number.isFinite(auth.credit)) {
        db.prepare('UPDATE sms_providers SET balance=?,updated_at=? WHERE id=?')
          .run(Math.round(auth.credit), iso(), provider.id);
      }

      // ۷) قالب OTP
      if (provider.provider_type === 'melipayamak') {
        const config = JSON.parse(provider.config_json || '{}') || {};
        const bodyId = String(config.template || config.bodyId || '').trim();
        push('template', 'کد متن الگو (bodyId)', !!bodyId,
          bodyId ? `کد متن «${bodyId}» تنظیم شده — تأییدشدنش را در پنل ملی‌پیامک، بخش «وب‌سرویس خدماتی» ببینید`
                 : 'کد متن الگو خالی است؛ کد ورود با خط عادی می‌رود و برای شماره‌های داخل لیست سیاه مخابرات نمی‌رسد. در پنل ملی‌پیامک یک الگو ثبت و کد متن آن را اینجا وارد کنید.');
      }
      if (provider.provider_type === 'kavenegar') {
        const template = (JSON.parse(provider.config_json || '{}') || {}).template;
        push('template', 'قالب کد تایید (template)', !!template,
          template ? `قالب «${template}» تنظیم شده — تایید بودنش را در پنل کاوه‌نگار ببینید`
                   : 'قالب تنظیم نشده؛ کد با خط عادی ارسال می‌شود و در ایران معمولاً فیلتر می‌شود');
      }

      const allOk = steps.every(step => step.ok);
      db.prepare("UPDATE sms_providers SET status=?,last_checked_at=?,updated_at=? WHERE id=?")
        .run(allOk ? 'healthy' : 'degraded', iso(), iso(), provider.id);
      logAudit({ adminId: req.admin.id, action: 'SMS_PROVIDER_DIAGNOSED', entityType: 'sms_provider',
        entityId: provider.id, details: { ok: allOk, steps: steps.map(s => ({ k: s.key, ok: s.ok })) }, ip: clientIp(req) });

      res.json({ ok: allOk, provider: provider.name, steps });
    });

  log.info?.({ event: 'sms_gateway_ready' }, 'SMS gateway admin routes installed');
}

module.exports = { install };
